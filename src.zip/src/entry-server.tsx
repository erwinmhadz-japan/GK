/**
 * SSR entry point for build-time pre-rendering (LPS-864).
 *
 * Used by `npm run build:ssr` → `scripts/prerender.mjs` to inject static HTML
 * into the per-page dist shells so AI crawlers can read page body content.
 *
 * Non-fatal: every renderPage call is wrapped in try/catch so that
 * components using browser APIs (window/document) fail silently and are
 * skipped rather than aborting the entire pre-render run.
 */
import React from "react";
import { renderToString } from "react-dom/server";
import { StaticRouter } from "react-router-dom/server";

type PageMod = { default: React.ComponentType };

// Resolve all page components at Vite build time — no runtime scanning needed
const pageModules = import.meta.glob<PageMod>("./pages/*.tsx", { eager: true });

/**
 * Render a page component to static HTML.
 *
 * @param slug     URL slug — "" for home, "about" for /about
 * @param filePath Optional manifest filePath, e.g. "src/pages/About.tsx"
 * @returns Rendered HTML string, or "" if component not found / render fails
 */
export function renderPage(slug: string, filePath?: string): string {
  let mod: PageMod | undefined;

  // 1. Prefer the manifest's explicit file path (most reliable)
  if (filePath) {
    const key = "./" + filePath.replace(/^src\//, "");
    mod = pageModules[key];
  }

  // 2. Fall back to deriving the module key from the slug
  if (!mod) {
    if (!slug) {
      // Home page is always Index.tsx
      mod = pageModules["./pages/Index.tsx"];
    } else {
      // "about-us" → "AboutUs", "blog-post" → "BlogPost"
      const pascal = slug
        .split(/[-_]/)
        .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
        .join("");
      mod = pageModules[`./pages/${pascal}.tsx`];
    }
  }

  if (!mod?.default) return "";

  const Comp = mod.default;
  const location = slug ? `/${slug}` : "/";

  try {
    return renderToString(
      <StaticRouter location={location}>
        <Comp />
      </StaticRouter>
    );
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    console.warn(`[prerender] renderToString failed (slug="${slug}"): ${msg}`);
    return "";
  }
}
