import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import Footer from "@/components/sections/Footer";
import SheffieldHero from "@/components/sections/SheffieldHero";
import SheffieldEcosystem from "@/components/sections/SheffieldEcosystem";
import SheffieldServices from "@/components/sections/SheffieldServices";
import SheffieldCoverage from "@/components/sections/SheffieldCoverage";
import SheffieldTestimonial from "@/components/sections/SheffieldTestimonial";
import SheffieldFAQ from "@/components/sections/SheffieldFAQ";
import SheffieldContact from "@/components/sections/SheffieldContact";

const localBusinessSchema = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  name: "Sheffield SEO Consultant",
  description:
    "Independent SEO consultant serving Sheffield and South Yorkshire. Services include local SEO, technical SEO, content strategy, and AI search optimisation for Sheffield businesses.",
  url: "https://example.com/locations/sheffield",
  telephone: "+441142000000",
  email: "sheffield@example.com",
  address: {
    "@type": "PostalAddress",
    streetAddress: "Sheffield City Centre",
    addressLocality: "Sheffield",
    addressRegion: "South Yorkshire",
    postalCode: "S1",
    addressCountry: "GB",
  },
  geo: {
    "@type": "GeoCoordinates",
    latitude: 53.3811,
    longitude: -1.4701,
  },
  areaServed: [
    { "@type": "City", name: "Sheffield" },
    { "@type": "City", name: "Rotherham" },
    { "@type": "City", name: "Doncaster" },
    { "@type": "City", name: "Barnsley" },
    { "@type": "City", name: "Chesterfield" },
  ],
  priceRange: "££",
  openingHoursSpecification: {
    "@type": "OpeningHoursSpecification",
    dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
    opens: "09:00",
    closes: "17:30",
  },
};

const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "Sheffield SEO Consultant",
  url: "https://example.com",
  logo: "https://example.com/logo.png",
  contactPoint: {
    "@type": "ContactPoint",
    telephone: "+441142000000",
    contactType: "customer service",
    areaServed: "GB",
    availableLanguage: "English",
  },
  address: {
    "@type": "PostalAddress",
    streetAddress: "Sheffield City Centre",
    addressLocality: "Sheffield",
    addressRegion: "South Yorkshire",
    postalCode: "S1",
    addressCountry: "GB",
  },
  sameAs: [
    "https://www.linkedin.com/",
    "https://twitter.com/",
  ],
};

const LocationsSheffield = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="locations-sheffield">
      {/* LocalBusiness JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(localBusinessSchema) }}
      />
      {/* Organization JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }}
      />
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="SheffieldHero">
          <SheffieldHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SheffieldEcosystem">
          <SheffieldEcosystem />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SheffieldServices">
          <SheffieldServices />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SheffieldCoverage">
          <SheffieldCoverage />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SheffieldTestimonial">
          <SheffieldTestimonial />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SheffieldFAQ">
          <SheffieldFAQ />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SheffieldContact">
          <SheffieldContact />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

LocationsSheffield.displayName = "LocationsSheffield";
export default LocationsSheffield;
