import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import IndustriesPropertyHero from "@/components/sections/IndustriesPropertyHero";
import IndustriesPropertyChallenges from "@/components/sections/IndustriesPropertyChallenges";
import IndustriesPropertySolutions from "@/components/sections/IndustriesPropertySolutions";
import IndustriesPropertyTestimonial from "@/components/sections/IndustriesPropertyTestimonial";
import IndustriesPropertyFAQ from "@/components/sections/IndustriesPropertyFAQ";
import IndustriesPropertyCTA from "@/components/sections/IndustriesPropertyCTA";
import Footer from "@/components/sections/Footer";

const IndustriesEstateAgentsPropertyServices = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="industries-estate-agents-property-services">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="IndustriesPropertyHero">
          <IndustriesPropertyHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="IndustriesPropertyChallenges">
          <IndustriesPropertyChallenges />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="IndustriesPropertySolutions">
          <IndustriesPropertySolutions />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="IndustriesPropertyTestimonial">
          <IndustriesPropertyTestimonial />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="IndustriesPropertyFAQ">
          <IndustriesPropertyFAQ />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="IndustriesPropertyCTA">
          <IndustriesPropertyCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

IndustriesEstateAgentsPropertyServices.displayName = "IndustriesEstateAgentsPropertyServices";

export default IndustriesEstateAgentsPropertyServices;
