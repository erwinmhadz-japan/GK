import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import AiSearchGoogleAiOverviewsHero from "@/components/sections/AiSearchGoogleAiOverviewsHero";
import AiSearchGoogleAiOverviewsWhat from "@/components/sections/AiSearchGoogleAiOverviewsWhat";
import AiSearchGoogleAiOverviewsHow from "@/components/sections/AiSearchGoogleAiOverviewsHow";
import AiSearchGoogleAiOverviewsEEAT from "@/components/sections/AiSearchGoogleAiOverviewsEEAT";
import AiSearchGoogleAiOverviewsTechnical from "@/components/sections/AiSearchGoogleAiOverviewsTechnical";
import AiSearchGoogleAiOverviewsContentStrategy from "@/components/sections/AiSearchGoogleAiOverviewsContentStrategy";
import AiSearchGoogleAiOverviewsFAQ from "@/components/sections/AiSearchGoogleAiOverviewsFAQ";
import AiSearchGoogleAiOverviewsCTASection from "@/components/sections/AiSearchGoogleAiOverviewsCTASection";
import Footer from "@/components/sections/Footer";

const AiSearchGoogleAiOverviews = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="ai-search-google-ai-overviews">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="AiSearchGoogleAiOverviewsHero">
          <AiSearchGoogleAiOverviewsHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchGoogleAiOverviewsWhat">
          <AiSearchGoogleAiOverviewsWhat />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchGoogleAiOverviewsHow">
          <AiSearchGoogleAiOverviewsHow />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchGoogleAiOverviewsEEAT">
          <AiSearchGoogleAiOverviewsEEAT />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchGoogleAiOverviewsTechnical">
          <AiSearchGoogleAiOverviewsTechnical />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchGoogleAiOverviewsContentStrategy">
          <AiSearchGoogleAiOverviewsContentStrategy />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchGoogleAiOverviewsFAQ">
          <AiSearchGoogleAiOverviewsFAQ />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchGoogleAiOverviewsCTASection">
          <AiSearchGoogleAiOverviewsCTASection />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

AiSearchGoogleAiOverviews.displayName = "AiSearchGoogleAiOverviews";

export default AiSearchGoogleAiOverviews;
