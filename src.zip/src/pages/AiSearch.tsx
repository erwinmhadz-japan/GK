import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import AiSearchHero from "@/components/sections/AiSearchHero";
import AiSearchPlatformsHub from "@/components/sections/AiSearchPlatformsHub";
import AiSearchBenefits from "@/components/sections/AiSearchBenefits";
import AiSearchFAQSection from "@/components/sections/AiSearchFAQSection";
import AiSearchHubCTA from "@/components/sections/AiSearchHubCTA";
import Footer from "@/components/sections/Footer";

const AiSearch = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="ai-search">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="AiSearchHero">
          <AiSearchHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchPlatformsHub">
          <AiSearchPlatformsHub />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchBenefits">
          <AiSearchBenefits />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchFAQSection">
          <AiSearchFAQSection />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchHubCTA">
          <AiSearchHubCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

AiSearch.displayName = "AiSearch";

export default AiSearch;
