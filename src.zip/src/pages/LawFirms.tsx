import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import LawFirmsHero from "@/components/sections/LawFirmsHero";
import LawFirmsPainPoints from "@/components/sections/LawFirmsPainPoints";
import LawFirmsSolutions from "@/components/sections/LawFirmsSolutions";
import LawFirmsROI from "@/components/sections/LawFirmsROI";
import LawFirmsTestimonials from "@/components/sections/LawFirmsTestimonials";
import LawFirmsCTA from "@/components/sections/LawFirmsCTA";
import Footer from "@/components/sections/Footer";

const LawFirms = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="law-firms">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="LawFirmsHero">
          <LawFirmsHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LawFirmsPainPoints">
          <LawFirmsPainPoints />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LawFirmsSolutions">
          <LawFirmsSolutions />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LawFirmsROI">
          <LawFirmsROI />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LawFirmsTestimonials">
          <LawFirmsTestimonials />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LawFirmsCTA">
          <LawFirmsCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

LawFirms.displayName = "LawFirms";

export default LawFirms;
