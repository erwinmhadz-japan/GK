import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import SEOAuditSeoAuditHero from "@/components/sections/SEOAuditSeoAuditHero";
import SEOAuditSeoAuditProcess from "@/components/sections/SEOAuditSeoAuditProcess";
import SEOAuditSeoAuditWhatIsIncluded from "@/components/sections/SEOAuditSeoAuditWhatIsIncluded";
import SEOAuditSeoAuditCTA from "@/components/sections/SEOAuditSeoAuditCTA";
import Footer from "@/components/sections/Footer";

const ServicesSeoAudit = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="seo-audit">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="SEOAuditSeoAuditHero">
          <SEOAuditSeoAuditHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SEOAuditSeoAuditProcess">
          <SEOAuditSeoAuditProcess />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SEOAuditSeoAuditWhatIsIncluded">
          <SEOAuditSeoAuditWhatIsIncluded />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SEOAuditSeoAuditCTA">
          <SEOAuditSeoAuditCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

ServicesSeoAudit.displayName = "ServicesSeoAudit";

export default ServicesSeoAudit;
