import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import SeoAuditHero from "@/components/sections/SeoAuditHero";
import SeoAuditProcess from "@/components/sections/SeoAuditProcess";
import SeoAuditWhatIsIncluded from "@/components/sections/SeoAuditWhatIsIncluded";
import SeoAuditCTA from "@/components/sections/SeoAuditCTA";
import Footer from "@/components/sections/Footer";

const SeoAudit = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="seo_audit">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="SeoAuditHero">
          <SeoAuditHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SeoAuditProcess">
          <SeoAuditProcess />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SeoAuditWhatIsIncluded">
          <SeoAuditWhatIsIncluded />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SeoAuditCTA">
          <SeoAuditCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

SeoAudit.displayName = "SeoAudit";

export default SeoAudit;
