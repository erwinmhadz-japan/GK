import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import Footer from "@/components/sections/Footer";
import ManchesterHero from "@/components/sections/ManchesterHero";
import ManchesterMarket from "@/components/sections/ManchesterMarket";
import ManchesterStrategy from "@/components/sections/ManchesterStrategy";
import ManchesterTestimonials from "@/components/sections/ManchesterTestimonials";
import ManchesterLocations from "@/components/sections/ManchesterLocations";
import ManchesterCTA from "@/components/sections/ManchesterCTA";

const localBusinessJsonLd = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  name: "Gregg SEO Consultant — Manchester",
  description:
    "Independent SEO consultant providing enterprise-level local SEO, technical SEO, and content strategy for businesses across Greater Manchester, Salford, Trafford, and Stockport.",
  url: "https://gregg.com/manchester",
  telephone: "+441234567890",
  email: "hello@gregg.com",
  address: {
    "@type": "PostalAddress",
    addressLocality: "Manchester",
    addressRegion: "Greater Manchester",
    addressCountry: "GB",
  },
  areaServed: [
    { "@type": "City", name: "Manchester" },
    { "@type": "City", name: "Salford" },
    { "@type": "City", name: "Trafford" },
    { "@type": "City", name: "Stockport" },
    { "@type": "City", name: "Bolton" },
    { "@type": "City", name: "Bury" },
    { "@type": "City", name: "Oldham" },
    { "@type": "City", name: "Rochdale" },
    { "@type": "City", name: "Wigan" },
    { "@type": "City", name: "Tameside" },
  ],
  serviceType: [
    "Local SEO",
    "Technical SEO",
    "SEO Consulting",
    "Content Strategy",
    "Digital PR",
    "Schema Markup",
    "AI Search Optimisation",
  ],
  priceRange: "££",
  sameAs: [],
};

const Manchester = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="manchester">
      {/* LocalBusiness JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(localBusinessJsonLd) }}
      />

      <div ref={ref}>
        <Header />

        <SectionErrorBoundary sectionName="ManchesterHero">
          <ManchesterHero />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="ManchesterMarket">
          <ManchesterMarket />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="ManchesterStrategy">
          <ManchesterStrategy />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="ManchesterTestimonials">
          <ManchesterTestimonials />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="ManchesterLocations">
          <ManchesterLocations />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="ManchesterCTA">
          <ManchesterCTA />
        </SectionErrorBoundary>

        <Footer />
      </div>
    </PageLayout>
  );
});

Manchester.displayName = "Manchester";

export default Manchester;
