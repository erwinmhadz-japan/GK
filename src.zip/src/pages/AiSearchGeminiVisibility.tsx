import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import AiSearchGeminiHero from "@/components/sections/AiSearchGeminiHero";
import AiSearchGeminiWhatIs from "@/components/sections/AiSearchGeminiWhatIs";
import AiSearchGeminiHowItSources from "@/components/sections/AiSearchGeminiHowItSources";
import AiSearchGeminiOptimisation from "@/components/sections/AiSearchGeminiOptimisation";
import AiSearchGeminiFreshness from "@/components/sections/AiSearchGeminiFreshness";
import AiSearchGeminiFAQ from "@/components/sections/AiSearchGeminiFAQ";
import AiSearchGeminiCTADouble from "@/components/sections/AiSearchGeminiCTADouble";
import Footer from "@/components/sections/Footer";

const AiSearchGeminiVisibility = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="ai-search-gemini-visibility">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="AiSearchGeminiHero">
          <AiSearchGeminiHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchGeminiWhatIs">
          <AiSearchGeminiWhatIs />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchGeminiHowItSources">
          <AiSearchGeminiHowItSources />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchGeminiOptimisation">
          <AiSearchGeminiOptimisation />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchGeminiFreshness">
          <AiSearchGeminiFreshness />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchGeminiFAQ">
          <AiSearchGeminiFAQ />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchGeminiCTADouble">
          <AiSearchGeminiCTADouble />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

AiSearchGeminiVisibility.displayName = "AiSearchGeminiVisibility";

export default AiSearchGeminiVisibility;
