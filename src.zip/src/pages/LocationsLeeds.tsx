import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import Footer from "@/components/sections/Footer";
import LocationsLeedsHero from "@/components/sections/LocationsLeedsHero";
import LocationsLeedsMarket from "@/components/sections/LocationsLeedsMarket";
import LocationsLeedsServices from "@/components/sections/LocationsLeedsServices";
import LocationsLeedsTestimonial from "@/components/sections/LocationsLeedsTestimonial";
import LocationsLeedsFAQ from "@/components/sections/LocationsLeedsFAQ";
import LocationsLeedsCTA from "@/components/sections/LocationsLeedsCTA";

const LocationsLeeds = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="locations-leeds">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="LocationsLeedsHero">
          <LocationsLeedsHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocationsLeedsMarket">
          <LocationsLeedsMarket />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocationsLeedsServices">
          <LocationsLeedsServices />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocationsLeedsTestimonial">
          <LocationsLeedsTestimonial />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocationsLeedsFAQ">
          <LocationsLeedsFAQ />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocationsLeedsCTA">
          <LocationsLeedsCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

LocationsLeeds.displayName = "LocationsLeeds";
export default LocationsLeeds;
