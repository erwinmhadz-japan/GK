import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import ChatgptVisibilityHero from "@/components/sections/ChatgptVisibilityHero";
import ChatgptVisibilityHowToImprove from "@/components/sections/ChatgptVisibilityHowToImprove";
import ChatgptVisibilityWhatItMeans from "@/components/sections/ChatgptVisibilityWhatItMeans";
import ChatgptVisibilityCTA from "@/components/sections/ChatgptVisibilityCTA";
import Footer from "@/components/sections/Footer";

const ChatgptVisibility = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="chatgpt_visibility">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="ChatgptVisibilityHero">
          <ChatgptVisibilityHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="ChatgptVisibilityHowToImprove">
          <ChatgptVisibilityHowToImprove />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="ChatgptVisibilityWhatItMeans">
          <ChatgptVisibilityWhatItMeans />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="ChatgptVisibilityCTA">
          <ChatgptVisibilityCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

ChatgptVisibility.displayName = "ChatgptVisibility";

export default ChatgptVisibility;
