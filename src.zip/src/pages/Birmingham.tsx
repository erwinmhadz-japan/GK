import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import BirminghamHero from "@/components/sections/BirminghamHero";
import BirminghamMarket from "@/components/sections/BirminghamMarket";
import BirminghamStrategy from "@/components/sections/BirminghamStrategy";
import BirminghamIndustries from "@/components/sections/BirminghamIndustries";
import BirminghamTestimonials from "@/components/sections/BirminghamTestimonials";
import BirminghamCTA from "@/components/sections/BirminghamCTA";
import Footer from "@/components/sections/Footer";

const Birmingham = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="birmingham">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="BirminghamHero">
          <BirminghamHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="BirminghamMarket">
          <BirminghamMarket />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="BirminghamStrategy">
          <BirminghamStrategy />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="BirminghamIndustries">
          <BirminghamIndustries />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="BirminghamTestimonials">
          <BirminghamTestimonials />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="BirminghamCTA">
          <BirminghamCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

Birmingham.displayName = "Birmingham";

export default Birmingham;
