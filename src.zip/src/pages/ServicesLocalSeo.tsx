import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import LocalSEOLocalSeoHero from "@/components/sections/LocalSEOLocalSeoHero";
import LocalSEOLocalSeoServices from "@/components/sections/LocalSEOLocalSeoServices";
import LocalSEOLocalSeoLocations from "@/components/sections/LocalSEOLocalSeoLocations";
import LocalSeoWhat from "@/components/sections/LocalSeoWhat";
import LocalSEOLocalSeoIndustries from "@/components/sections/LocalSEOLocalSeoIndustries";
import LocalSeoAISearch from "@/components/sections/LocalSeoAISearch";
import LocalSEOLocalSeoCTA from "@/components/sections/LocalSEOLocalSeoCTA";
import Footer from "@/components/sections/Footer";

const ServicesLocalSeo = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="local-seo">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="LocalSEOLocalSeoHero">
          <LocalSEOLocalSeoHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocalSEOLocalSeoServices">
          <LocalSEOLocalSeoServices />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocalSEOLocalSeoLocations">
          <LocalSEOLocalSeoLocations />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocalSeoWhat">
          <LocalSeoWhat />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocalSEOLocalSeoIndustries">
          <LocalSEOLocalSeoIndustries />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocalSeoAISearch">
          <LocalSeoAISearch />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocalSEOLocalSeoCTA">
          <LocalSEOLocalSeoCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

ServicesLocalSeo.displayName = "ServicesLocalSeo";

export default ServicesLocalSeo;
