import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import EntitySeoHero from "@/components/sections/EntitySeoHero";
import EntitySeoServices from "@/components/sections/EntitySeoServices";
import EntitySeoProcess from "@/components/sections/EntitySeoProcess";
import EntitySeoWhatIs from "@/components/sections/EntitySeoWhatIs";
import EntitySeoWhyItMatters from "@/components/sections/EntitySeoWhyItMatters";
import EntitySeoFAQ from "@/components/sections/EntitySeoFAQ";
import EntitySeoCTA from "@/components/sections/EntitySeoCTA";
import Footer from "@/components/sections/Footer";

const EntitySeo = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="entity_seo">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="EntitySeoHero">
          <EntitySeoHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="EntitySeoWhatIs">
          <EntitySeoWhatIs />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="EntitySeoServices">
          <EntitySeoServices />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="EntitySeoProcess">
          <EntitySeoProcess />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="EntitySeoWhyItMatters">
          <EntitySeoWhyItMatters />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="EntitySeoFAQ">
          <EntitySeoFAQ />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="EntitySeoCTA">
          <EntitySeoCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

EntitySeo.displayName = "EntitySeo";

export default EntitySeo;
