import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import ContentStrategyHero from "@/components/sections/ContentStrategyHero";
import ContentStrategyOverview from "@/components/sections/ContentStrategyOverview";
import ContentStrategyDeliverables from "@/components/sections/ContentStrategyDeliverables";
import ContentStrategyCTA from "@/components/sections/ContentStrategyCTA";
import Footer from "@/components/sections/Footer";

const ContentStrategy = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="content_strategy">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="ContentStrategyHero">
          <ContentStrategyHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="ContentStrategyOverview">
          <ContentStrategyOverview />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="ContentStrategyDeliverables">
          <ContentStrategyDeliverables />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="ContentStrategyCTA">
          <ContentStrategyCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

ContentStrategy.displayName = "ContentStrategy";

export default ContentStrategy;
