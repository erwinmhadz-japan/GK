import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import CopilotVisibilityHero from "@/components/sections/CopilotVisibilityHero";
import CopilotVisibilityWhatIs from "@/components/sections/CopilotVisibilityWhatIs";
import CopilotVisibilityOptimisation from "@/components/sections/CopilotVisibilityOptimisation";
import CopilotVisibilityCTA from "@/components/sections/CopilotVisibilityCTA";
import Footer from "@/components/sections/Footer";

const CopilotVisibility = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="copilot_visibility">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="CopilotVisibilityHero">
          <CopilotVisibilityHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="CopilotVisibilityWhatIs">
          <CopilotVisibilityWhatIs />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="CopilotVisibilityOptimisation">
          <CopilotVisibilityOptimisation />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="CopilotVisibilityCTA">
          <CopilotVisibilityCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

CopilotVisibility.displayName = "CopilotVisibility";

export default CopilotVisibility;
