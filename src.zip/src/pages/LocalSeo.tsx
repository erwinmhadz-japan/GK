import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import LocalSeoHero from "@/components/sections/LocalSeoHero";
import LocalSeoServices from "@/components/sections/LocalSeoServices";
import LocalSeoLocations from "@/components/sections/LocalSeoLocations";
import LocalSeoWhatIsIt from "@/components/sections/LocalSeoWhatIsIt";
import LocalSeoIndustries from "@/components/sections/LocalSeoIndustries";
import LocalSeoTestimonials from "@/components/sections/LocalSeoTestimonials";
import LocalSeoCTA from "@/components/sections/LocalSeoCTA";
import Footer from "@/components/sections/Footer";

const LocalSeo = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="local_seo">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="LocalSeoHero">
          <LocalSeoHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocalSeoServices">
          <LocalSeoServices />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocalSeoLocations">
          <LocalSeoLocations />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocalSeoWhatIsIt">
          <LocalSeoWhatIsIt />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocalSeoIndustries">
          <LocalSeoIndustries />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocalSeoTestimonials">
          <LocalSeoTestimonials />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocalSeoCTA">
          <LocalSeoCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

LocalSeo.displayName = "LocalSeo";

export default LocalSeo;
