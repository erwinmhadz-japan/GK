import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import Page4Hero from "@/components/sections/Page4Hero";
import Page4Guides from "@/components/sections/Page4Guides";
import Page4Tools from "@/components/sections/Page4Tools";
import Page4FAQ from "@/components/sections/Page4FAQ";
import Page4CTA from "@/components/sections/Page4CTA";
import Footer from "@/components/sections/Footer";

const Page4 = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="resources">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="Page4Hero">
          <Page4Hero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="Page4Guides">
          <Page4Guides />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="Page4Tools">
          <Page4Tools />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="Page4FAQ">
          <Page4FAQ />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="Page4CTA">
          <Page4CTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

Page4.displayName = "Page4";

export default Page4;
