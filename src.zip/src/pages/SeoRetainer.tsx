import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import SeoRetainerHero from "@/components/sections/SeoRetainerHero";
import SeoRetainerWhatIsIt from "@/components/sections/SeoRetainerWhatIsIt";
import SeoRetainerWhatIsIncluded from "@/components/sections/SeoRetainerWhatIsIncluded";
import SeoRetainerWhyRetainer from "@/components/sections/SeoRetainerWhyRetainer";
import SeoRetainerCTA from "@/components/sections/SeoRetainerCTA";
import Footer from "@/components/sections/Footer";

const SeoRetainer = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="seo_retainer">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="SeoRetainerHero">
          <SeoRetainerHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SeoRetainerWhatIsIt">
          <SeoRetainerWhatIsIt />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SeoRetainerWhatIsIncluded">
          <SeoRetainerWhatIsIncluded />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SeoRetainerWhyRetainer">
          <SeoRetainerWhyRetainer />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SeoRetainerCTA">
          <SeoRetainerCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

SeoRetainer.displayName = "SeoRetainer";

export default SeoRetainer;
