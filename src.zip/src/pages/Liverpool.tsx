import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import LiverpoolHero from "@/components/sections/LiverpoolHero";
import LiverpoolMarket from "@/components/sections/LiverpoolMarket";
import LiverpoolSolutions from "@/components/sections/LiverpoolSolutions";
import LiverpoolTestimonials from "@/components/sections/LiverpoolTestimonials";
import LiverpoolCTA from "@/components/sections/LiverpoolCTA";
import Footer from "@/components/sections/Footer";

const Liverpool = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="liverpool">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="LiverpoolHero">
          <LiverpoolHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LiverpoolMarket">
          <LiverpoolMarket />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LiverpoolSolutions">
          <LiverpoolSolutions />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LiverpoolTestimonials">
          <LiverpoolTestimonials />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LiverpoolCTA">
          <LiverpoolCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

Liverpool.displayName = "Liverpool";

export default Liverpool;
