import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import TechnicalSeoHero from "@/components/sections/TechnicalSeoHero";
import TechnicalSeoProcess from "@/components/sections/TechnicalSeoProcess";
import TechnicalSeoWhatICover from "@/components/sections/TechnicalSeoWhatICover";
import TechnicalSeoCTA from "@/components/sections/TechnicalSeoCTA";
import Footer from "@/components/sections/Footer";

const TechnicalSeo = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="technical_seo">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="TechnicalSeoHero">
          <TechnicalSeoHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="TechnicalSeoProcess">
          <TechnicalSeoProcess />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="TechnicalSeoWhatICover">
          <TechnicalSeoWhatICover />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="TechnicalSeoCTA">
          <TechnicalSeoCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

TechnicalSeo.displayName = "TechnicalSeo";

export default TechnicalSeo;
