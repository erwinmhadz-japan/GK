import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import LocationsHero from "@/components/sections/LocationsHero";
import LocationsGrid from "@/components/sections/LocationsGrid";
import LocationsWhyLocal from "@/components/sections/LocationsWhyLocal";
import LocationsCTA from "@/components/sections/LocationsCTA";
import Footer from "@/components/sections/Footer";

const Locations = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="locations">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="LocationsHero">
          <LocationsHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocationsGrid">
          <LocationsGrid />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocationsWhyLocal">
          <LocationsWhyLocal />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LocationsCTA">
          <LocationsCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

Locations.displayName = "Locations";

export default Locations;
