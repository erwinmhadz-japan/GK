import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import Page3Hero from "@/components/sections/Page3Hero";
import Page3KeyMetrics from "@/components/sections/Page3KeyMetrics";
import Page3FeaturedResults from "@/components/sections/Page3FeaturedResults";
import Page3Testimonials from "@/components/sections/Page3Testimonials";
import Page3CTA from "@/components/sections/Page3CTA";
import Footer from "@/components/sections/Footer";

const Page3 = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="page3">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="Page3Hero">
          <Page3Hero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="Page3KeyMetrics">
          <Page3KeyMetrics />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="Page3FeaturedResults">
          <Page3FeaturedResults />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="Page3Testimonials">
          <Page3Testimonials />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="Page3CTA">
          <Page3CTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

Page3.displayName = "Page3";

export default Page3;
