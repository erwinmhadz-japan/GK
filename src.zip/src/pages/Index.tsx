import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import Hero from "@/components/sections/Hero";
import HomeServices from "@/components/sections/HomeServices";
import HomeLocations from "@/components/sections/HomeLocations";
import HomeTrustBar from "@/components/sections/HomeTrustBar";
import HomeAISearch from "@/components/sections/HomeAISearch";
import HomeIndustries from "@/components/sections/HomeIndustries";
import HomeTestimonials from "@/components/sections/HomeTestimonials";
import HomeCTA from "@/components/sections/HomeCTA";
import Footer from "@/components/sections/Footer";

const Index = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="home">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="Hero">
          <Hero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="HomeServices">
          <HomeServices />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="HomeTrustBar">
          <HomeTrustBar />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="HomeLocations">
          <HomeLocations />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="HomeAISearch">
          <HomeAISearch />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="HomeIndustries">
          <HomeIndustries />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="HomeTestimonials">
          <HomeTestimonials />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="HomeCTA">
          <HomeCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

Index.displayName = "Index";

export default Index;
