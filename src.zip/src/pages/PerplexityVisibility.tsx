import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import PerplexityVisibilityHero from "@/components/sections/PerplexityVisibilityHero";
import PerplexityVisibilityExplainer from "@/components/sections/PerplexityVisibilityExplainer";
import PerplexityVisibilityApproach from "@/components/sections/PerplexityVisibilityApproach";
import PerplexityVisibilityCTA from "@/components/sections/PerplexityVisibilityCTA";
import Footer from "@/components/sections/Footer";

const PerplexityVisibility = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="perplexity_visibility">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="PerplexityVisibilityHero">
          <PerplexityVisibilityHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="PerplexityVisibilityExplainer">
          <PerplexityVisibilityExplainer />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="PerplexityVisibilityApproach">
          <PerplexityVisibilityApproach />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="PerplexityVisibilityCTA">
          <PerplexityVisibilityCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

PerplexityVisibility.displayName = "PerplexityVisibility";

export default PerplexityVisibility;
