import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import Footer from "@/components/sections/Footer";
import ManchesterHero from "@/components/sections/ManchesterHero";
import ManchesterSEOChallenges from "@/components/sections/ManchesterSEOChallenges";
import ManchesterDigitalLandscape from "@/components/sections/ManchesterDigitalLandscape";
import ManchesterServiceAreas from "@/components/sections/ManchesterServiceAreas";
import ManchesterTestimonial from "@/components/sections/ManchesterTestimonial";
import ManchesterFAQ from "@/components/sections/ManchesterFAQ";
import ManchesterContactCTA from "@/components/sections/ManchesterContactCTA";

/* ─── Structured Data ──────────────────────────────────────────── */
const localBusinessSchema = {
  "@context": "https://schema.org",
  "@type": ["LocalBusiness", "ProfessionalService"],
  name: "Gregg Strickland SEO — Manchester",
  description:
    "Expert SEO consultant serving Manchester and Greater Manchester. Specialising in local SEO, technical SEO, content strategy, and AI search optimisation for North West businesses.",
  url: "https://greggstrickland.co.uk/locations/manchester",
  telephone: "+44-7700-900123",
  email: "hello@greggstrickland.co.uk",
  address: {
    "@type": "PostalAddress",
    addressLocality: "Manchester",
    addressRegion: "Greater Manchester",
    addressCountry: "GB",
    postalCode: "M1",
  },
  geo: {
    "@type": "GeoCoordinates",
    latitude: 53.4808,
    longitude: -2.2426,
  },
  areaServed: [
    { "@type": "City", name: "Manchester" },
    { "@type": "City", name: "Salford" },
    { "@type": "City", name: "Stockport" },
    { "@type": "City", name: "Bolton" },
    { "@type": "City", name: "Oldham" },
    { "@type": "City", name: "Bury" },
    { "@type": "City", name: "Wigan" },
    { "@type": "AdministrativeArea", name: "Greater Manchester" },
  ],
  openingHoursSpecification: [
    {
      "@type": "OpeningHoursSpecification",
      dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
      opens: "09:00",
      closes: "18:00",
    },
  ],
  priceRange: "££",
  currenciesAccepted: "GBP",
  paymentAccepted: "Invoice, Bank Transfer",
  sameAs: [
    "https://www.linkedin.com/in/greggstrickland",
    "https://twitter.com/greggstrickland",
  ],
};

const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "Organization",
  name: "Gregg Strickland SEO",
  url: "https://greggstrickland.co.uk",
  logo: "https://greggstrickland.co.uk/logo.png",
  description:
    "Independent SEO consultant specialising in technical SEO, local SEO, and AI search optimisation for UK businesses.",
  foundingDate: "2018",
  founder: {
    "@type": "Person",
    name: "Gregg Strickland",
    jobTitle: "SEO Consultant",
  },
  contactPoint: {
    "@type": "ContactPoint",
    telephone: "+44-7700-900123",
    contactType: "customer service",
    areaServed: "GB",
    availableLanguage: "English",
  },
  address: {
    "@type": "PostalAddress",
    addressLocality: "Manchester",
    addressRegion: "Greater Manchester",
    addressCountry: "GB",
  },
};

/* ─── Page Component ────────────────────────────────────────────── */
const LocationsManchester = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="locations-manchester">
      {/* Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(localBusinessSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }}
      />

      <div ref={ref}>
        <Header />

        <SectionErrorBoundary sectionName="ManchesterHero">
          <ManchesterHero />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="ManchesterSEOChallenges">
          <ManchesterSEOChallenges />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="ManchesterDigitalLandscape">
          <ManchesterDigitalLandscape />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="ManchesterServiceAreas">
          <ManchesterServiceAreas />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="ManchesterTestimonial">
          <ManchesterTestimonial />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="ManchesterFAQ">
          <ManchesterFAQ />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="ManchesterContactCTA">
          <ManchesterContactCTA />
        </SectionErrorBoundary>

        <Footer />
      </div>
    </PageLayout>
  );
});

LocationsManchester.displayName = "LocationsManchester";

export default LocationsManchester;
