import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import ServicesHero from "@/components/sections/ServicesHero";
import ServicesList from "@/components/sections/ServicesList";
import ServicesWhyGregg from "@/components/sections/ServicesWhyGregg";
import ServicesCTA from "@/components/sections/ServicesCTA";
import Footer from "@/components/sections/Footer";

const Services = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="services">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="ServicesHero">
          <ServicesHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="ServicesList">
          <ServicesList />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="ServicesWhyGregg">
          <ServicesWhyGregg />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="ServicesCTA">
          <ServicesCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

Services.displayName = "Services";

export default Services;
