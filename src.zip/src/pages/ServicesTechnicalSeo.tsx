import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import TechnicalSEOHero from "@/components/sections/TechnicalSEOHero";
import TechnicalSEOServices from "@/components/sections/TechnicalSEOServices";
import TechnicalSEOProcess from "@/components/sections/TechnicalSEOProcess";
import TechnicalSEOWhyGregg from "@/components/sections/TechnicalSEOWhyGregg";
import TechnicalSEOCTA from "@/components/sections/TechnicalSEOCTA";
import Footer from "@/components/sections/Footer";

const ServicesTechnicalSeo = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="technical-seo">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="TechnicalSEOHero">
          <TechnicalSEOHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="TechnicalSEOServices">
          <TechnicalSEOServices />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="TechnicalSEOProcess">
          <TechnicalSEOProcess />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="TechnicalSEOWhyGregg">
          <TechnicalSEOWhyGregg />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="TechnicalSEOCTA">
          <TechnicalSEOCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

ServicesTechnicalSeo.displayName = "ServicesTechnicalSeo";

export default ServicesTechnicalSeo;
