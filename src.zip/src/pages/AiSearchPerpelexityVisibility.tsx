import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import AiSearchPerplexityHero from "@/components/sections/AiSearchPerplexityHero";
import AiSearchPerplexityExplainer from "@/components/sections/AiSearchPerplexityExplainer";
import AiSearchPerplexityFactors from "@/components/sections/AiSearchPerplexityFactors";
import AiSearchPerplexityVsChatGPT from "@/components/sections/AiSearchPerplexityVsChatGPT";
import AiSearchPerplexityFAQ from "@/components/sections/AiSearchPerplexityFAQ";
import AiSearchPerplexityCTA from "@/components/sections/AiSearchPerplexityCTA";
import Footer from "@/components/sections/Footer";

const AiSearchPerpelexityVisibility = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="perplexity-visibility">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="AiSearchPerplexityHero">
          <AiSearchPerplexityHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchPerplexityExplainer">
          <AiSearchPerplexityExplainer />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchPerplexityFactors">
          <AiSearchPerplexityFactors />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchPerplexityVsChatGPT">
          <AiSearchPerplexityVsChatGPT />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchPerplexityFAQ">
          <AiSearchPerplexityFAQ />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchPerplexityCTA">
          <AiSearchPerplexityCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

AiSearchPerpelexityVisibility.displayName = "AiSearchPerpelexityVisibility";

export default AiSearchPerpelexityVisibility;
