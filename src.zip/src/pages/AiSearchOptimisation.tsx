import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import AiSearchOptimisationHero from "@/components/sections/AiSearchOptimisationHero";
import AiSearchWhatIsIt from "@/components/sections/AiSearchWhatIsIt";
import AiSearchPlatforms from "@/components/sections/AiSearchPlatforms";
import AiSearchApproach from "@/components/sections/AiSearchApproach";
import AiSearchIndustries from "@/components/sections/AiSearchIndustries";
import AiSearchTestimonials from "@/components/sections/AiSearchTestimonials";
import AiSearchCTA from "@/components/sections/AiSearchCTA";
import Footer from "@/components/sections/Footer";

const AiSearchOptimisation = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="ai_search_optimisation">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="AiSearchOptimisationHero">
          <AiSearchOptimisationHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchWhatIsIt">
          <AiSearchWhatIsIt />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchPlatforms">
          <AiSearchPlatforms />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchApproach">
          <AiSearchApproach />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchIndustries">
          <AiSearchIndustries />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchTestimonials">
          <AiSearchTestimonials />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchCTA">
          <AiSearchCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

AiSearchOptimisation.displayName = "AiSearchOptimisation";

export default AiSearchOptimisation;
