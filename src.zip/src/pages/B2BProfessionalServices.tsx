import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import B2BHero from "@/components/sections/B2BHero";
import B2BChallenges from "@/components/sections/B2BChallenges";
import B2BSEOSolutions from "@/components/sections/B2BSEOSolutions";
import B2BLeadROI from "@/components/sections/B2BLeadROI";
import B2BTestimonials from "@/components/sections/B2BTestimonials";
import B2BCTA from "@/components/sections/B2BCTA";
import Footer from "@/components/sections/Footer";

const B2BProfessionalServices = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="b2b-professional-services">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="B2BHero">
          <B2BHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="B2BChallenges">
          <B2BChallenges />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="B2BSEOSolutions">
          <B2BSEOSolutions />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="B2BLeadROI">
          <B2BLeadROI />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="B2BTestimonials">
          <B2BTestimonials />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="B2BCTA">
          <B2BCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

B2BProfessionalServices.displayName = "B2BProfessionalServices";

export default B2BProfessionalServices;
