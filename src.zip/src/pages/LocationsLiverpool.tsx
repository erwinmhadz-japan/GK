import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import LiverpoolHero from "@/components/sections/LiverpoolHero";
import LiverpoolEcosystem from "@/components/sections/LiverpoolEcosystem";
import LiverpoolLocalSEO from "@/components/sections/LiverpoolLocalSEO";
import LiverpoolTestimonial from "@/components/sections/LiverpoolTestimonial";
import LiverpoolFAQ from "@/components/sections/LiverpoolFAQ";
import LiverpoolCTA from "@/components/sections/LiverpoolCTA";
import Footer from "@/components/sections/Footer";

const LocationsLiverpool = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="locations-liverpool">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="LiverpoolHero">
          <LiverpoolHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LiverpoolEcosystem">
          <LiverpoolEcosystem />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LiverpoolLocalSEO">
          <LiverpoolLocalSEO />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LiverpoolTestimonial">
          <LiverpoolTestimonial />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LiverpoolFAQ">
          <LiverpoolFAQ />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LiverpoolCTA">
          <LiverpoolCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

LocationsLiverpool.displayName = "LocationsLiverpool";

export default LocationsLiverpool;
