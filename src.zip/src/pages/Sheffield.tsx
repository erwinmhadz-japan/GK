import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import SheffieldHero from "@/components/sections/SheffieldHero";
import SheffieldMarket from "@/components/sections/SheffieldMarket";
import SheffieldSolutions from "@/components/sections/SheffieldSolutions";
import SheffieldTestimonials from "@/components/sections/SheffieldTestimonials";
import SheffieldCTA from "@/components/sections/SheffieldCTA";
import Footer from "@/components/sections/Footer";

const sheffieldJsonLd = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  name: "Gregg Everett SEO — Sheffield",
  description:
    "Independent SEO consultancy providing local SEO services to Sheffield and South Yorkshire businesses. Specialising in manufacturing, B2B, professional services, and retail sectors.",
  url: "https://greggseo.com/locations/sheffield",
  telephone: "+44-114-000-0000",
  address: {
    "@type": "PostalAddress",
    addressLocality: "Sheffield",
    addressRegion: "South Yorkshire",
    postalCode: "S1",
    addressCountry: "GB",
  },
  areaServed: [
    { "@type": "City", name: "Sheffield" },
    { "@type": "AdministrativeArea", name: "South Yorkshire" },
    { "@type": "City", name: "Rotherham" },
    { "@type": "City", name: "Barnsley" },
    { "@type": "City", name: "Doncaster" },
  ],
  serviceType: [
    "Local SEO",
    "Technical SEO",
    "B2B SEO",
    "Content Strategy",
    "SEO Consulting",
  ],
  geo: {
    "@type": "GeoCoordinates",
    latitude: 53.3811,
    longitude: -1.4701,
  },
  sameAs: ["https://greggseo.com"],
};

const Sheffield = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="sheffield">
      {/* LocalBusiness JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(sheffieldJsonLd) }}
      />

      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="SheffieldHero">
          <SheffieldHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SheffieldMarket">
          <SheffieldMarket />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SheffieldSolutions">
          <SheffieldSolutions />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SheffieldTestimonials">
          <SheffieldTestimonials />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SheffieldCTA">
          <SheffieldCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

Sheffield.displayName = "Sheffield";

export default Sheffield;
