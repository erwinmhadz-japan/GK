import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import Footer from "@/components/sections/Footer";
import B2BHero from "@/components/sections/B2BHero";
import B2BChallenges from "@/components/sections/B2BChallenges";
import B2BSolutions from "@/components/sections/B2BSolutions";
import B2BTestimonial from "@/components/sections/B2BTestimonial";
import B2BFAQ from "@/components/sections/B2BFAQ";
import B2BCTA from "@/components/sections/B2BCTA";

/* ─── Structured Data ─────────────────────────────────────────── */
const serviceJsonLd = {
  "@context": "https://schema.org",
  "@type": "Service",
  name: "B2B & Professional Services SEO",
  description:
    "Specialist SEO services for B2B and professional services firms — covering entity SEO, thought leadership content strategy, schema markup, and Digital PR to drive qualified inbound pipeline.",
  provider: {
    "@type": ["Organization", "LocalBusiness", "ProfessionalService"],
    name: "Gregg Coppen SEO",
    url: "https://greggcoppenseo.com",
    "@id": "https://greggcoppenseo.com/#organization",
    description:
      "Independent SEO consultant specialising in B2B, professional services, and AI search optimisation.",
    areaServed: [
      { "@type": "Country", name: "United Kingdom" },
      { "@type": "Country", name: "United States" },
      { "@type": "AdministrativeArea", name: "Europe" },
    ],
    knowsAbout: [
      "B2B SEO",
      "Entity SEO",
      "Professional Services Marketing",
      "Content Strategy",
      "Schema Markup",
      "Digital PR",
      "AI Search Optimisation",
    ],
  },
  serviceType: "Search Engine Optimisation",
  audience: {
    "@type": "Audience",
    audienceType:
      "B2B companies, management consultancies, law firms, accountancies, SaaS businesses, financial advisory firms",
  },
  url: "https://greggcoppenseo.com/industries/b2b-professional-services",
};

const localBusinessJsonLd = {
  "@context": "https://schema.org",
  "@type": ["LocalBusiness", "ProfessionalService"],
  "@id": "https://greggcoppenseo.com/#organization",
  name: "Gregg Coppen SEO",
  url: "https://greggcoppenseo.com",
  sameAs: [
    "https://www.linkedin.com/in/greggcoppen",
    "https://twitter.com/greggcoppen",
  ],
  description:
    "Independent SEO consultant delivering specialist B2B and professional services SEO — entity authority, content strategy, schema markup, and Digital PR.",
  priceRange: "££–£££",
  currenciesAccepted: "GBP, USD, EUR",
  openingHours: "Mo-Fr 09:00-18:00",
  telephone: "+44 20 0000 0000",
  address: {
    "@type": "PostalAddress",
    addressLocality: "London",
    addressCountry: "GB",
  },
  hasOfferCatalog: {
    "@type": "OfferCatalog",
    name: "B2B SEO Services",
    itemListElement: [
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Service",
          name: "Entity SEO for B2B Firms",
          url: "https://greggcoppenseo.com/entity-seo",
        },
      },
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Service",
          name: "Content Strategy for Professional Services",
          url: "https://greggcoppenseo.com/content-strategy",
        },
      },
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Service",
          name: "Schema Markup — Organization & ProfessionalService",
          url: "https://greggcoppenseo.com/schema-markup",
        },
      },
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Service",
          name: "Digital PR for B2B Authority",
          url: "https://greggcoppenseo.com/digital-pr",
        },
      },
    ],
  },
};

const IndustriesB2bProfessionalServices = React.forwardRef<HTMLDivElement>(
  (props, ref) => {
    return (
      <PageLayout currentPage="industries-b2b-professional-services">
        {/* Service JSON-LD */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceJsonLd) }}
        />
        {/* LocalBusiness / ProfessionalService JSON-LD */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(localBusinessJsonLd),
          }}
        />

        <div ref={ref}>
          <Header />

          <SectionErrorBoundary sectionName="B2BHero">
            <B2BHero />
          </SectionErrorBoundary>

          <SectionErrorBoundary sectionName="B2BChallenges">
            <B2BChallenges />
          </SectionErrorBoundary>

          <SectionErrorBoundary sectionName="B2BSolutions">
            <B2BSolutions />
          </SectionErrorBoundary>

          <SectionErrorBoundary sectionName="B2BTestimonial">
            <B2BTestimonial />
          </SectionErrorBoundary>

          <SectionErrorBoundary sectionName="B2BFAQ">
            <B2BFAQ />
          </SectionErrorBoundary>

          <SectionErrorBoundary sectionName="B2BCTA">
            <B2BCTA />
          </SectionErrorBoundary>

          <Footer />
        </div>
      </PageLayout>
    );
  }
);

IndustriesB2bProfessionalServices.displayName =
  "IndustriesB2bProfessionalServices";

export default IndustriesB2bProfessionalServices;
