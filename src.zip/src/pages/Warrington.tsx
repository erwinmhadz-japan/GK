import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import WarringtonHero from "@/components/sections/WarringtonHero";
import WarringtonLocalLandscape from "@/components/sections/WarringtonLocalLandscape";
import WarringtonChallenges from "@/components/sections/WarringtonChallenges";
import WarringtonSolutions from "@/components/sections/WarringtonSolutions";
import WarringtonTestimonials from "@/components/sections/WarringtonTestimonials";
import WarringtonCTA from "@/components/sections/WarringtonCTA";
import Footer from "@/components/sections/Footer";

const Warrington = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="warrington">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="WarringtonHero">
          <WarringtonHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="WarringtonLocalLandscape">
          <WarringtonLocalLandscape />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="WarringtonChallenges">
          <WarringtonChallenges />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="WarringtonSolutions">
          <WarringtonSolutions />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="WarringtonTestimonials">
          <WarringtonTestimonials />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="WarringtonCTA">
          <WarringtonCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

Warrington.displayName = "Warrington";

export default Warrington;
