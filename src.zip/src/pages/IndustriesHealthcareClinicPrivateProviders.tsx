import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import HealthcareHero from "@/components/sections/HealthcareHero";
import HealthcareChallenges from "@/components/sections/HealthcareChallenges";
import HealthcareSolutions from "@/components/sections/HealthcareSolutions";
import HealthcareTestimonial from "@/components/sections/HealthcareTestimonial";
import HealthcareFAQ from "@/components/sections/HealthcareFAQ";
import HealthcareCTA from "@/components/sections/HealthcareCTA";
import Footer from "@/components/sections/Footer";

const IndustriesHealthcareClinicPrivateProviders = React.forwardRef<HTMLDivElement>(
  (props, ref) => {
    return (
      <PageLayout currentPage="industries-healthcare-clinic-private-providers">
        <div ref={ref}>
          <Header />
          <SectionErrorBoundary sectionName="HealthcareHero">
            <HealthcareHero />
          </SectionErrorBoundary>
          <SectionErrorBoundary sectionName="HealthcareChallenges">
            <HealthcareChallenges />
          </SectionErrorBoundary>
          <SectionErrorBoundary sectionName="HealthcareSolutions">
            <HealthcareSolutions />
          </SectionErrorBoundary>
          <SectionErrorBoundary sectionName="HealthcareTestimonial">
            <HealthcareTestimonial />
          </SectionErrorBoundary>
          <SectionErrorBoundary sectionName="HealthcareFAQ">
            <HealthcareFAQ />
          </SectionErrorBoundary>
          <SectionErrorBoundary sectionName="HealthcareCTA">
            <HealthcareCTA />
          </SectionErrorBoundary>
          <Footer />
        </div>
      </PageLayout>
    );
  }
);

IndustriesHealthcareClinicPrivateProviders.displayName =
  "IndustriesHealthcareClinicPrivateProviders";

export default IndustriesHealthcareClinicPrivateProviders;
