import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import Footer from "@/components/sections/Footer";
import AiSearchChatgptHero from "@/components/sections/AiSearchChatgptHero";
import AiSearchChatgptWhatIs from "@/components/sections/AiSearchChatgptWhatIs";
import AiSearchChatgptHowItSources from "@/components/sections/AiSearchChatgptHowItSources";
import AiSearchChatgptTechnical from "@/components/sections/AiSearchChatgptTechnical";
import AiSearchChatgptBestPractices from "@/components/sections/AiSearchChatgptBestPractices";
import AiSearchChatgptVsGoogle from "@/components/sections/AiSearchChatgptVsGoogle";
import AiSearchChatgptCaseInsight from "@/components/sections/AiSearchChatgptCaseInsight";
import AiSearchChatgptFAQ from "@/components/sections/AiSearchChatgptFAQ";

const AiSearchChatgptVisibility = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="ai-search-chatgpt-visibility">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="AiSearchChatgptHero">
          <AiSearchChatgptHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchChatgptWhatIs">
          <AiSearchChatgptWhatIs />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchChatgptHowItSources">
          <AiSearchChatgptHowItSources />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchChatgptTechnical">
          <AiSearchChatgptTechnical />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchChatgptBestPractices">
          <AiSearchChatgptBestPractices />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchChatgptVsGoogle">
          <AiSearchChatgptVsGoogle />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchChatgptCaseInsight">
          <AiSearchChatgptCaseInsight />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchChatgptFAQ">
          <AiSearchChatgptFAQ />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

AiSearchChatgptVisibility.displayName = "AiSearchChatgptVisibility";

export default AiSearchChatgptVisibility;
