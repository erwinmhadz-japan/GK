import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import InsightsHero from "@/components/sections/InsightsHero";
import InsightsFeaturedArticle from "@/components/sections/InsightsFeaturedArticle";
import InsightsGrid from "@/components/sections/InsightsGrid";
import InsightsCTA from "@/components/sections/InsightsCTA";
import Footer from "@/components/sections/Footer";

const Insights = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="insights">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="InsightsHero">
          <InsightsHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="InsightsFeaturedArticle">
          <InsightsFeaturedArticle />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="InsightsGrid">
          <InsightsGrid />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="InsightsCTA">
          <InsightsCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

Insights.displayName = "Insights";

export default Insights;
