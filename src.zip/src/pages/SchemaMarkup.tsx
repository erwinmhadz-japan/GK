import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import SchemaMarkupHero from "@/components/sections/SchemaMarkupHero";
import SchemaMarkupServices from "@/components/sections/SchemaMarkupServices";
import SchemaMarkupIntro from "@/components/sections/SchemaMarkupIntro";
import SchemaMarkupCTA from "@/components/sections/SchemaMarkupCTA";
import Footer from "@/components/sections/Footer";

const SchemaMarkup = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="schema_markup">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="SchemaMarkupHero">
          <SchemaMarkupHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SchemaMarkupServices">
          <SchemaMarkupServices />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SchemaMarkupIntro">
          <SchemaMarkupIntro />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="SchemaMarkupCTA">
          <SchemaMarkupCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

SchemaMarkup.displayName = "SchemaMarkup";

export default SchemaMarkup;
