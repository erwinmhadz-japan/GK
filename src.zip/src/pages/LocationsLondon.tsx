import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import LondonHero from "@/components/sections/LondonHero";
import LondonCompetitiveLandscape from "@/components/sections/LondonCompetitiveLandscape";
import LondonServices from "@/components/sections/LondonServices";
import LondonBoroughs from "@/components/sections/LondonBoroughs";
import LondonTestimonial from "@/components/sections/LondonTestimonial";
import LondonFAQ from "@/components/sections/LondonFAQ";
import LondonContact from "@/components/sections/LondonContact";
import Footer from "@/components/sections/Footer";

const LocationsLondon = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="locations-london">
      <div ref={ref}>
        <Header />

        <SectionErrorBoundary sectionName="LondonHero">
          <LondonHero />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="LondonCompetitiveLandscape">
          <LondonCompetitiveLandscape />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="LondonServices">
          <LondonServices />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="LondonBoroughs">
          <LondonBoroughs />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="LondonTestimonial">
          <LondonTestimonial />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="LondonFAQ">
          <LondonFAQ />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="LondonContact">
          <LondonContact />
        </SectionErrorBoundary>

        <Footer />
      </div>
    </PageLayout>
  );
});

LocationsLondon.displayName = "LocationsLondon";
export default LocationsLondon;
