import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import Footer from "@/components/sections/Footer";
import HealthcareClinicsHero from "@/components/sections/HealthcareClinicsHero";
import HealthcareClinicsPainPoints from "@/components/sections/HealthcareClinicsPainPoints";
import HealthcareClinicsSolutions from "@/components/sections/HealthcareClinicsSOlutions";
import HealthcareClinicsTestimonials from "@/components/sections/HealthcareClinicsTestimonials";
import HealthcareClinicsTrustSignals from "@/components/sections/HealthcareClinicsTrustSignals";
import HealthcareClinicsFAQ from "@/components/sections/HealthcareClinicsFAQ";
import HealthcareClinicsCTA from "@/components/sections/HealthcareClinicsCTA";

/* ─── JSON-LD Structured Data ─────────────────────────────────────────────── */
const localBusinessSchema = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  name: "Healthcare Clinic SEO Specialist",
  description:
    "Specialist SEO services for healthcare clinics and private medical providers. We drive patient acquisition through local SEO, schema markup, entity SEO, and YMYL-compliant content strategy.",
  url: "https://www.example.com/industries/healthcare-clinics",
  "@id": "https://www.example.com/#healthcare-seo",
  areaServed: {
    "@type": "Country",
    name: "United Kingdom",
  },
  serviceType: [
    "Healthcare SEO",
    "Local SEO for Medical Practices",
    "Schema Markup for Clinics",
    "YMYL Content Strategy",
    "Entity SEO for Healthcare Providers",
  ],
  knowsAbout: [
    "YMYL SEO",
    "Medical E-E-A-T",
    "Healthcare Local Search",
    "Medical Schema Markup",
    "CQC Compliance Content",
    "NHS and Private Clinic SEO",
  ],
};

const serviceSchema = {
  "@context": "https://schema.org",
  "@type": "Service",
  name: "Healthcare SEO for Clinics and Private Medical Providers",
  description:
    "Comprehensive SEO solutions for healthcare clinics: local SEO for patient acquisition, schema markup for medical services, entity SEO for practitioner authority, and YMYL-compliant content strategy.",
  provider: {
    "@type": "LocalBusiness",
    name: "Healthcare Clinic SEO Specialist",
    url: "https://www.example.com",
  },
  areaServed: "United Kingdom",
  serviceOutput: "Increased patient enquiries through organic search",
  hasOfferCatalog: {
    "@type": "OfferCatalog",
    name: "Healthcare SEO Services",
    itemListElement: [
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Service",
          name: "Local SEO for Healthcare Clinics",
          url: "https://www.example.com/services/local-seo",
        },
      },
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Service",
          name: "Healthcare Schema Markup",
          url: "https://www.example.com/services/schema-markup",
        },
      },
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Service",
          name: "Entity SEO for Medical Providers",
          url: "https://www.example.com/services/entity-seo",
        },
      },
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Service",
          name: "YMYL Content Strategy",
          url: "https://www.example.com/services/content-strategy",
        },
      },
    ],
  },
};

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: [
    {
      "@type": "Question",
      name: "What makes healthcare SEO different from standard SEO?",
      acceptedAnswer: {
        "@type": "Answer",
        text: "Healthcare content falls under Google's 'Your Money or Your Life' (YMYL) classification, requiring the highest standards of E-E-A-T (Experience, Expertise, Authoritativeness, Trustworthiness). Standard SEO tactics can damage rankings for medical providers. Healthcare SEO requires compliant content, clinical authorship, and adherence to ASA guidelines.",
      },
    },
    {
      "@type": "Question",
      name: "How long does healthcare SEO take to show results?",
      acceptedAnswer: {
        "@type": "Answer",
        text: "Local pack improvements typically appear within 60–90 days of Google Business Profile and citation optimisation. Organic content rankings for competitive healthcare keywords take 4–9 months depending on domain authority and competitive landscape.",
      },
    },
    {
      "@type": "Question",
      name: "Can you help with NHS and CQC compliance for healthcare content?",
      acceptedAnswer: {
        "@type": "Answer",
        text: "Yes. All content strategies are reviewed against ASA CAP Code guidelines, CQC care standards, and Google's YMYL quality criteria. We produce evidence-based content with clear clinical attribution that meets compliance requirements.",
      },
    },
    {
      "@type": "Question",
      name: "What is schema markup and why is it important for clinics?",
      acceptedAnswer: {
        "@type": "Answer",
        text: "Schema markup (structured data) helps Google precisely understand your medical business. For healthcare providers, MedicalOrganization, Physician, MedicalProcedure, and FAQPage schemas can generate rich results showing star ratings, opening hours, and services directly in search results, increasing click-through rates and patient trust.",
      },
    },
    {
      "@type": "Question",
      name: "Do you work with both NHS and private healthcare providers?",
      acceptedAnswer: {
        "@type": "Answer",
        text: "Yes. For NHS-funded providers, the focus is on digital accessibility and awareness. For private clinics, the emphasis is on patient acquisition and appointment conversion. The core methodology is consistent, but commercial objectives and keyword strategies are tailored to each operating model.",
      },
    },
  ],
};

/* ─── Page Component ──────────────────────────────────────────────────────── */
const HealthcareClinics = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="healthcare-clinics">
      {/* JSON-LD Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(localBusinessSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceSchema) }}
      />
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />

      <div ref={ref}>
        <Header />

        {/* Breadcrumb — Industries > Healthcare Clinics */}
        <nav aria-label="Breadcrumb" className="bg-muted border-b border-border">
          <div className="container py-3">
            <ol className="flex items-center gap-2 text-xs text-muted-foreground">
              <li><a href="/" className="hover:text-foreground transition-colors">Home</a></li>
              <li aria-hidden="true" className="select-none">›</li>
              <li><a href="#industries-cta" className="hover:text-foreground transition-colors">Industries</a></li>
              <li aria-hidden="true" className="select-none">›</li>
              <li className="text-foreground font-medium" aria-current="page">Healthcare Clinics</li>
            </ol>
          </div>
        </nav>

        <SectionErrorBoundary sectionName="HealthcareClinicsHero">
          <HealthcareClinicsHero />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="HealthcareClinicsPainPoints">
          <HealthcareClinicsPainPoints />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="HealthcareClinicsSolutions">
          <HealthcareClinicsSolutions />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="HealthcareClinicsTestimonials">
          <HealthcareClinicsTestimonials />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="HealthcareClinicsTrustSignals">
          <HealthcareClinicsTrustSignals />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="HealthcareClinicsFAQ">
          <HealthcareClinicsFAQ />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="HealthcareClinicsCTA">
          <HealthcareClinicsCTA />
        </SectionErrorBoundary>

        <Footer />
      </div>
    </PageLayout>
  );
});

HealthcareClinics.displayName = "HealthcareClinics";

export default HealthcareClinics;
