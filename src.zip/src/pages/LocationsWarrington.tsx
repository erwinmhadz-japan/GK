import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import Footer from "@/components/sections/Footer";
import WarringtonHero from "@/components/sections/WarringtonHero";
import WarringtonServices from "@/components/sections/WarringtonServices";
import WarringtonLandscape from "@/components/sections/WarringtonLandscape";
import WarringtonTestimonial from "@/components/sections/WarringtonTestimonial";
import WarringtonFAQ from "@/components/sections/WarringtonFAQ";
import WarringtonCTA from "@/components/sections/WarringtonCTA";

const LocationsWarrington = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="locations-warrington">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="WarringtonHero">
          <WarringtonHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="WarringtonServices">
          <WarringtonServices />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="WarringtonLandscape">
          <WarringtonLandscape />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="WarringtonTestimonial">
          <WarringtonTestimonial />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="WarringtonFAQ">
          <WarringtonFAQ />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="WarringtonCTA">
          <WarringtonCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

LocationsWarrington.displayName = "LocationsWarrington";

export default LocationsWarrington;
