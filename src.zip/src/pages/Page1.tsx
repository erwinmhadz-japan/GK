import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import Page1Hero from "@/components/sections/Page1Hero";
import Page1Process from "@/components/sections/Page1Process";
import Page1WhyIndependent from "@/components/sections/Page1WhyIndependent";
import Page1Testimonials from "@/components/sections/Page1Testimonials";
import Page1CTA from "@/components/sections/Page1CTA";
import Footer from "@/components/sections/Footer";

const Page1 = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="page1">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="Page1Hero"><Page1Hero /></SectionErrorBoundary>
        <SectionErrorBoundary sectionName="Page1Process"><Page1Process /></SectionErrorBoundary>
        <SectionErrorBoundary sectionName="Page1WhyIndependent"><Page1WhyIndependent /></SectionErrorBoundary>
        <SectionErrorBoundary sectionName="Page1Testimonials"><Page1Testimonials /></SectionErrorBoundary>
        <SectionErrorBoundary sectionName="Page1CTA"><Page1CTA /></SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

Page1.displayName = "Page1";

export default Page1;
