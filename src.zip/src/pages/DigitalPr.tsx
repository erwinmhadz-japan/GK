import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import DigitalPrHero from "@/components/sections/DigitalPrHero";
import DigitalPrServices from "@/components/sections/DigitalPrServices";
import DigitalPrApproach from "@/components/sections/DigitalPrApproach";
import DigitalPrCTA from "@/components/sections/DigitalPrCTA";
import Footer from "@/components/sections/Footer";

const DigitalPr = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="digital_pr">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="DigitalPrHero">
          <DigitalPrHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="DigitalPrServices">
          <DigitalPrServices />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="DigitalPrApproach">
          <DigitalPrApproach />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="DigitalPrCTA">
          <DigitalPrCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

DigitalPr.displayName = "DigitalPr";

export default DigitalPr;
