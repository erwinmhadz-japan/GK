import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import AISearchOptimisationHero from "@/components/sections/AISearchOptimisationHero";
import AISearchServices from "@/components/sections/AISearchServices";
import AISearchLocations from "@/components/sections/AISearchLocations";
import AISearchWhatItIs from "@/components/sections/AISearchWhatItIs";
import AISearchApproach from "@/components/sections/AISearchApproach";
import AISearchIndustries from "@/components/sections/AISearchIndustries";
import AISearchTestimonials from "@/components/sections/AISearchTestimonials";
import AISearchCTA from "@/components/sections/AISearchCTA";
import Footer from "@/components/sections/Footer";

const ServicesAiSearchOptimisation = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="ai-search-optimisation">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="AISearchOptimisationHero">
          <AISearchOptimisationHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AISearchServices">
          <AISearchServices />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AISearchLocations">
          <AISearchLocations />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AISearchWhatItIs">
          <AISearchWhatItIs />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AISearchApproach">
          <AISearchApproach />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AISearchIndustries">
          <AISearchIndustries />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AISearchTestimonials">
          <AISearchTestimonials />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AISearchCTA">
          <AISearchCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

ServicesAiSearchOptimisation.displayName = "ServicesAiSearchOptimisation";

export default ServicesAiSearchOptimisation;
