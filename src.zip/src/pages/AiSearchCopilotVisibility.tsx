import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import AiSearchCopilotHero from "@/components/sections/AiSearchCopilotHero";
import AiSearchCopilotWhatIs from "@/components/sections/AiSearchCopilotWhatIs";
import AiSearchCopilotTechnical from "@/components/sections/AiSearchCopilotTechnical";
import AiSearchCopilotContentStrategy from "@/components/sections/AiSearchCopilotContentStrategy";
import AiSearchCopilotVsPeers from "@/components/sections/AiSearchCopilotVsPeers";
import AiSearchCopilotCaseInsight from "@/components/sections/AiSearchCopilotCaseInsight";
import AiSearchCopilotFAQ from "@/components/sections/AiSearchCopilotFAQ";
import AiSearchCopilotFinalCTA from "@/components/sections/AiSearchCopilotFinalCTA";
import Footer from "@/components/sections/Footer";

const AiSearchCopilotVisibility = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="ai-search-copilot-visibility">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="AiSearchCopilotHero">
          <AiSearchCopilotHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchCopilotWhatIs">
          <AiSearchCopilotWhatIs />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchCopilotTechnical">
          <AiSearchCopilotTechnical />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchCopilotContentStrategy">
          <AiSearchCopilotContentStrategy />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchCopilotVsPeers">
          <AiSearchCopilotVsPeers />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchCopilotCaseInsight">
          <AiSearchCopilotCaseInsight />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchCopilotFAQ">
          <AiSearchCopilotFAQ />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AiSearchCopilotFinalCTA">
          <AiSearchCopilotFinalCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

AiSearchCopilotVisibility.displayName = "AiSearchCopilotVisibility";

export default AiSearchCopilotVisibility;
