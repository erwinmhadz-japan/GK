import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import ContactHero from "@/components/sections/ContactHero";
import ContactInfo from "@/components/sections/ContactInfo";
import ContactForm from "@/components/sections/ContactForm";
import Footer from "@/components/sections/Footer";

const Contact = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="contact">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="ContactHero">
          <ContactHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="ContactInfo">
          <ContactInfo />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="ContactForm">
          <ContactForm />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

Contact.displayName = "Contact";

export default Contact;
