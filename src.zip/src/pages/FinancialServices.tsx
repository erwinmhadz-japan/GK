import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import Footer from "@/components/sections/Footer";
import FinancialServicesHero from "@/components/sections/FinancialServicesHero";
import FinancialServicesPainPoints from "@/components/sections/FinancialServicesPainPoints";
import FinancialServicesSolutions from "@/components/sections/FinancialServicesSolutions";
import FinancialServicesTestimonials from "@/components/sections/FinancialServicesTestimonials";
import FinancialServicesLeadQuality from "@/components/sections/FinancialServicesLeadQuality";
import FinancialServicesFAQ from "@/components/sections/FinancialServicesFAQ";
import FinancialServicesCTA from "@/components/sections/FinancialServicesCTA";

const jsonLd = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "LocalBusiness",
      "@id": "https://www.greggconsulting.co.uk/#organization",
      "name": "Gregg SEO Consulting",
      "url": "https://www.greggconsulting.co.uk",
      "description":
        "Specialist SEO consulting for financial services firms. Entity SEO, E-E-A-T content strategy and schema markup for banks, wealth managers, financial planners and fintech companies.",
      "areaServed": "United Kingdom",
      "serviceType": "SEO Consulting",
    },
    {
      "@type": "Service",
      "@id": "https://www.greggconsulting.co.uk/financial-services#service",
      "name": "Financial Services SEO",
      "provider": {
        "@id": "https://www.greggconsulting.co.uk/#organization",
      },
      "description":
        "Specialist SEO services for the financial services sector. Covering YMYL compliance, E-E-A-T signals, entity SEO for financial authority, schema markup for financial products, and compliant content strategy for banks, wealth managers, mortgage brokers and fintech firms.",
      "areaServed": "United Kingdom",
      "hasOfferCatalog": {
        "@type": "OfferCatalog",
        "name": "Financial Services SEO Services",
        "itemListElement": [
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Entity SEO for Financial Authority",
              "url": "https://www.greggconsulting.co.uk/entity-seo",
            },
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Schema Markup for Financial Services",
              "url": "https://www.greggconsulting.co.uk/schema-markup",
            },
          },
          {
            "@type": "Offer",
            "itemOffered": {
              "@type": "Service",
              "name": "Compliant Financial Content Strategy",
              "url": "https://www.greggconsulting.co.uk/content-strategy",
            },
          },
        ],
      },
    },
    {
      "@type": "FAQPage",
      "@id": "https://www.greggconsulting.co.uk/financial-services#faq",
      "mainEntity": [
        {
          "@type": "Question",
          "name": "What does YMYL mean for financial services SEO?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text":
              "YMYL stands for 'Your Money or Your Life' — a classification Google uses for content types that could significantly impact a person's financial wellbeing. Google applies stricter quality evaluation to YMYL pages, requiring financial firms to demonstrate genuine E-E-A-T signals including author credentials, authoritative backlinks and accurate regulatory information.",
          },
        },
        {
          "@type": "Question",
          "name": "How does E-E-A-T work for financial services websites?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text":
              "E-E-A-T is Google's quality framework: Experience, Expertise, Authoritativeness and Trustworthiness. For financial services, this means publishing content authored by qualified financial professionals, earning backlinks from respected financial publications, and demonstrating real-world experience through case studies and client outcomes.",
          },
        },
        {
          "@type": "Question",
          "name": "Can you create content that passes FCA compliance review?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text":
              "Yes. Our content strategy for financial services firms is built with regulatory compliance as a foundation. We create content briefs that map FCA requirements into the structure before a word is written, regularly achieving first-pass approval rates above 90%.",
          },
        },
        {
          "@type": "Question",
          "name": "How long does financial services SEO take to show results?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text":
              "For competitive financial keywords, meaningful ranking movement typically begins within four to six months, with significant organic traffic gains from six to twelve months. Entity SEO and schema markup improvements can yield quicker wins in AI-generated search features and rich results.",
          },
        },
        {
          "@type": "Question",
          "name": "What is entity SEO and why does it matter for financial firms?",
          "acceptedAnswer": {
            "@type": "Answer",
            "text":
              "Entity SEO builds a clearly structured presence in Google's knowledge graph so Google understands exactly who you are, what services you offer and why you're authoritative. For financial services firms, this means improved rankings, featured appearances in AI-generated answers, and greater brand visibility in knowledge panels.",
          },
        },
      ],
    },
  ],
};

const FinancialServices = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="financial-services">
      <div ref={ref}>
        {/* JSON-LD Structured Data */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }}
        />

        <Header />

        <SectionErrorBoundary sectionName="FinancialServicesHero">
          <FinancialServicesHero />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="FinancialServicesPainPoints">
          <FinancialServicesPainPoints />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="FinancialServicesSolutions">
          <FinancialServicesSolutions />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="FinancialServicesTestimonials">
          <FinancialServicesTestimonials />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="FinancialServicesLeadQuality">
          <FinancialServicesLeadQuality />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="FinancialServicesFAQ">
          <FinancialServicesFAQ />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="FinancialServicesCTA">
          <FinancialServicesCTA />
        </SectionErrorBoundary>

        <Footer />
      </div>
    </PageLayout>
  );
});

FinancialServices.displayName = "FinancialServices";

export default FinancialServices;
