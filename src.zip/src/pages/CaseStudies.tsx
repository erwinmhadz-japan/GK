import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import CaseStudiesHero from "@/components/sections/CaseStudiesHero";
import CaseStudiesFilter from "@/components/sections/CaseStudiesFilter";
import CaseStudiesFeatured from "@/components/sections/CaseStudiesFeatured";
import CaseStudiesStats from "@/components/sections/CaseStudiesStats";
import CaseStudiesTestimonials from "@/components/sections/CaseStudiesTestimonials";
import CaseStudiesFAQ from "@/components/sections/CaseStudiesFAQ";
import CaseStudiesCTA from "@/components/sections/CaseStudiesCTA";
import Footer from "@/components/sections/Footer";

const CaseStudies = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="case-studies">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="CaseStudiesHero">
          <CaseStudiesHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="CaseStudiesFilter">
          <CaseStudiesFilter />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="CaseStudiesFeatured">
          <CaseStudiesFeatured />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="CaseStudiesStats">
          <CaseStudiesStats />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="CaseStudiesTestimonials">
          <CaseStudiesTestimonials />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="CaseStudiesFAQ">
          <CaseStudiesFAQ />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="CaseStudiesCTA">
          <CaseStudiesCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

CaseStudies.displayName = "CaseStudies";

export default CaseStudies;
