import React from "react";
import { Link } from "react-router-dom";
import { ChevronRight, Home } from "lucide-react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import EstateAgentsHero from "@/components/sections/EstateAgentsHero";
import EstateAgentsChallenges from "@/components/sections/EstateAgentsChallenges";
import EstateAgentsSolutions from "@/components/sections/EstateAgentsSolutions";
import EstateAgentsCaseStudies from "@/components/sections/EstateAgentsCaseStudies";
import EstateAgentsROI from "@/components/sections/EstateAgentsROI";
import EstateAgentsCTA from "@/components/sections/EstateAgentsCTA";
import Footer from "@/components/sections/Footer";

const EstateAgents = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="estate-agents">
      <div ref={ref}>
        <Header />
        {/* Breadcrumb — Industries > Estate Agents */}
        <nav
          aria-label="Breadcrumb"
          className="bg-muted border-b border-border"
        >
          <div className="container py-2.5">
            <ol className="flex items-center gap-1.5 text-sm text-muted-foreground flex-wrap">
              <li>
                <Link to="/" className="hover:text-foreground transition-colors">
                  Home
                </Link>
              </li>
              <li aria-hidden="true">
                <ChevronRight className="h-3.5 w-3.5" />
              </li>
              <li>
                <Link to="#industries-cta" className="hover:text-foreground transition-colors">
                  Industries
                </Link>
              </li>
              <li aria-hidden="true">
                <ChevronRight className="h-3.5 w-3.5" />
              </li>
              <li className="text-foreground font-medium" aria-current="page">
                Estate Agents
              </li>
            </ol>
          </div>
        </nav>
        <SectionErrorBoundary sectionName="EstateAgentsHero">
          <EstateAgentsHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="EstateAgentsChallenges">
          <EstateAgentsChallenges />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="EstateAgentsSolutions">
          <EstateAgentsSolutions />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="EstateAgentsCaseStudies">
          <EstateAgentsCaseStudies />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="EstateAgentsROI">
          <EstateAgentsROI />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="EstateAgentsCTA">
          <EstateAgentsCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

EstateAgents.displayName = "EstateAgents";

export default EstateAgents;
