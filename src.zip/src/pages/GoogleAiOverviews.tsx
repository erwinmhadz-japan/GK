import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import GoogleAIOverviewsHero from "@/components/sections/GoogleAIOverviewsHero";
import GoogleAIOverviewsExplainer from "@/components/sections/GoogleAIOverviewsExplainer";
import GoogleAIOverviewsOptimisation from "@/components/sections/GoogleAIOverviewsOptimisation";
import GoogleAIOverviewsCTA from "@/components/sections/GoogleAIOverviewsCTA";
import Footer from "@/components/sections/Footer";

const GoogleAiOverviews = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="google_ai_overviews">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="GoogleAIOverviewsHero">
          <GoogleAIOverviewsHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="GoogleAIOverviewsExplainer">
          <GoogleAIOverviewsExplainer />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="GoogleAIOverviewsOptimisation">
          <GoogleAIOverviewsOptimisation />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="GoogleAIOverviewsCTA">
          <GoogleAIOverviewsCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

GoogleAiOverviews.displayName = "GoogleAiOverviews";

export default GoogleAiOverviews;
