import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import LondonHero from "@/components/sections/LondonHero";
import LondonLandscape from "@/components/sections/LondonLandscape";
import LondonEnterpriseStrategy from "@/components/sections/LondonEnterpriseStrategy";
import LondonExpansion from "@/components/sections/LondonExpansion";
import LondonCaseStudies from "@/components/sections/LondonCaseStudies";
import LondonCTA from "@/components/sections/LondonCTA";
import Footer from "@/components/sections/Footer";

const London = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="london">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="LondonHero">
          <LondonHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LondonLandscape">
          <LondonLandscape />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LondonEnterpriseStrategy">
          <LondonEnterpriseStrategy />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LondonExpansion">
          <LondonExpansion />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LondonCaseStudies">
          <LondonCaseStudies />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LondonCTA">
          <LondonCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

London.displayName = "London";

export default London;
