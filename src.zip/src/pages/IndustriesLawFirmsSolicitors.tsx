import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import LawFirmsHero from "@/components/sections/LawFirmsHero";
import LawFirmsChallenges from "@/components/sections/LawFirmsChallenges";
import LawFirmsSolutions from "@/components/sections/LawFirmsSolutions";
import LawFirmsTestimonial from "@/components/sections/LawFirmsTestimonial";
import LawFirmsFAQ from "@/components/sections/LawFirmsFAQ";
import LawFirmsCTA from "@/components/sections/LawFirmsCTA";
import Footer from "@/components/sections/Footer";

const IndustriesLawFirmsSolicitors = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="industries-law-firms-solicitors">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="LawFirmsHero">
          <LawFirmsHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LawFirmsChallenges">
          <LawFirmsChallenges />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LawFirmsSolutions">
          <LawFirmsSolutions />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LawFirmsTestimonial">
          <LawFirmsTestimonial />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LawFirmsFAQ">
          <LawFirmsFAQ />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="LawFirmsCTA">
          <LawFirmsCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

IndustriesLawFirmsSolicitors.displayName = "IndustriesLawFirmsSolicitors";

export default IndustriesLawFirmsSolicitors;
