import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import AboutHero from "@/components/sections/AboutHero";
import AboutStory from "@/components/sections/AboutStory";
import AboutCredentials from "@/components/sections/AboutCredentials";
import AboutConsultation from "@/components/sections/AboutConsultation";
import Footer from "@/components/sections/Footer";

const About = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="about">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="AboutHero">
          <AboutHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AboutStory">
          <AboutStory />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AboutCredentials">
          <AboutCredentials />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="AboutConsultation">
          <AboutConsultation />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

About.displayName = "About";

export default About;
