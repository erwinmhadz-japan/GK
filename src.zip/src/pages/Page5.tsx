import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import FaqHero from "@/components/sections/FaqHero";
import FaqQuestions from "@/components/sections/FaqQuestions";
import FaqResourceLinks from "@/components/sections/FaqResourceLinks";
import Footer from "@/components/sections/Footer";

const Page5 = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="faq">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="FaqHero">
          <FaqHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="FaqQuestions">
          <FaqQuestions />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="FaqResourceLinks">
          <FaqResourceLinks />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

Page5.displayName = "Page5";

export default Page5;
