import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import Page2Hero from "@/components/sections/Page2Hero";
import Page2Glossary from "@/components/sections/Page2Glossary";
import Page2ResourcesGrid from "@/components/sections/Page2ResourcesGrid";
import Page2FAQ from "@/components/sections/Page2FAQ";
import Page2CTA from "@/components/sections/Page2CTA";
import Footer from "@/components/sections/Footer";

const Page2 = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="page2">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="Page2Hero">
          <Page2Hero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="Page2Glossary">
          <Page2Glossary />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="Page2ResourcesGrid">
          <Page2ResourcesGrid />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="Page2FAQ">
          <Page2FAQ />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="Page2CTA">
          <Page2CTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

Page2.displayName = "Page2";

export default Page2;
