import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import BirminghamHero from "@/components/sections/BirminghamHero";
import BirminghamMarket from "@/components/sections/BirminghamMarket";
import BirminghamServices from "@/components/sections/BirminghamServices";
import BirminghamCoverage from "@/components/sections/BirminghamCoverage";
import BirminghamTestimonial from "@/components/sections/BirminghamTestimonial";
import BirminghamFAQ from "@/components/sections/BirminghamFAQ";
import BirminghamCTA from "@/components/sections/BirminghamCTA";
import Footer from "@/components/sections/Footer";

const LocationsBirmingham = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="locations-birmingham">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="BirminghamHero">
          <BirminghamHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="BirminghamMarket">
          <BirminghamMarket />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="BirminghamServices">
          <BirminghamServices />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="BirminghamCoverage">
          <BirminghamCoverage />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="BirminghamTestimonial">
          <BirminghamTestimonial />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="BirminghamFAQ">
          <BirminghamFAQ />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="BirminghamCTA">
          <BirminghamCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

LocationsBirmingham.displayName = "LocationsBirmingham";

export default LocationsBirmingham;
