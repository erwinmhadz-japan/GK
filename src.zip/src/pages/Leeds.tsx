import React from "react";
import { Link } from "react-router-dom";
import { ChevronRight, Home, Map as MapIcon } from "lucide-react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import LeedsHero from "@/components/sections/LeedsHero";
import LeedsMarket from "@/components/sections/LeedsMarket";
import LeedsApproach from "@/components/sections/LeedsApproach";
import LeedsRegional from "@/components/sections/LeedsRegional";
import LeedsTestimonials from "@/components/sections/LeedsTestimonials";
import LeedsCTA from "@/components/sections/LeedsCTA";
import Footer from "@/components/sections/Footer";

/** LocalBusiness JSON-LD for Leeds service area */
const leedsJsonLd = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  name: "Gregg SEO — Leeds",
  description:
    "Independent SEO consultant delivering local search visibility, rankings, and organic growth for businesses in Leeds, West Yorkshire and the wider Yorkshire region.",
  url: "https://greggseo.co.uk/locations/leeds",
  areaServed: [
    { "@type": "City", name: "Leeds" },
    { "@type": "AdministrativeArea", name: "West Yorkshire" },
    { "@type": "AdministrativeArea", name: "Yorkshire" },
  ],
  address: {
    "@type": "PostalAddress",
    addressLocality: "Leeds",
    addressRegion: "West Yorkshire",
    addressCountry: "GB",
  },
  serviceArea: {
    "@type": "GeoCircle",
    geoMidpoint: {
      "@type": "GeoCoordinates",
      latitude: 53.8008,
      longitude: -1.5491,
    },
    geoRadius: "50000",
  },
  knowsAbout: [
    "Local SEO",
    "Google Business Profile",
    "Leeds SEO",
    "Yorkshire SEO",
    "Map Pack Optimisation",
    "Technical SEO",
    "Content Strategy",
  ],
  hasOfferCatalog: {
    "@type": "OfferCatalog",
    name: "Leeds SEO Services",
    itemListElement: [
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Service",
          name: "Leeds Local SEO",
          url: "https://greggseo.co.uk/services/local-seo",
        },
      },
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Service",
          name: "SEO Consulting for Leeds Businesses",
          url: "https://greggseo.co.uk/services",
        },
      },
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Service",
          name: "Technical SEO Audit",
          url: "https://greggseo.co.uk/services",
        },
      },
    ],
  },
};

const Leeds = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="leeds">
      {/* LocalBusiness JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(leedsJsonLd) }}
      />

      <div ref={ref}>
        <Header />

        {/* Breadcrumb — Locations hierarchy */}
        <nav
          aria-label="Breadcrumb"
          className="bg-muted border-b border-border"
        >
          <div className="container max-w-6xl mx-auto px-4 py-2">
            <ol className="flex items-center gap-1 text-xs text-muted-foreground flex-wrap">
              <li>
                <Link to="/" className="hover:text-foreground transition-colors">
                  Home
                </Link>
              </li>
              <li aria-hidden="true">
                <ChevronRight className="h-3 w-3" />
              </li>
              <li>
                <Link to="/locations" className="hover:text-foreground transition-colors">
                  Locations
                </Link>
              </li>
              <li aria-hidden="true">
                <ChevronRight className="h-3 w-3" />
              </li>
              <li aria-current="page" className="text-foreground font-medium">
                Leeds
              </li>
            </ol>
          </div>
        </nav>

        <SectionErrorBoundary sectionName="LeedsHero">
          <LeedsHero />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="LeedsMarket">
          <LeedsMarket />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="LeedsApproach">
          <LeedsApproach />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="LeedsRegional">
          <LeedsRegional />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="LeedsTestimonials">
          <LeedsTestimonials />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="LeedsCTA">
          <LeedsCTA />
        </SectionErrorBoundary>

        <Footer />
      </div>
    </PageLayout>
  );
});

Leeds.displayName = "Leeds";

export default Leeds;
