import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import GeminiVisibilityHero from "@/components/sections/GeminiVisibilityHero";
import GeminiVisibilityHowItWorks from "@/components/sections/GeminiVisibilityHowItWorks";
import GeminiVisibilityWhatIsGemini from "@/components/sections/GeminiVisibilityWhatIsGemini";
import GeminiVisibilityCTA from "@/components/sections/GeminiVisibilityCTA";
import Footer from "@/components/sections/Footer";

const GeminiVisibility = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="gemini_visibility">
      <div ref={ref}>
        <Header />
        <SectionErrorBoundary sectionName="GeminiVisibilityHero">
          <GeminiVisibilityHero />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="GeminiVisibilityHowItWorks">
          <GeminiVisibilityHowItWorks />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="GeminiVisibilityWhatIsGemini">
          <GeminiVisibilityWhatIsGemini />
        </SectionErrorBoundary>
        <SectionErrorBoundary sectionName="GeminiVisibilityCTA">
          <GeminiVisibilityCTA />
        </SectionErrorBoundary>
        <Footer />
      </div>
    </PageLayout>
  );
});

GeminiVisibility.displayName = "GeminiVisibility";

export default GeminiVisibility;
