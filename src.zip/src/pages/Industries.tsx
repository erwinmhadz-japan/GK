import React from "react";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import IndustriesHero from "@/components/sections/IndustriesHero";
import IndustriesGrid from "@/components/sections/IndustriesGrid";
import IndustriesWhySpecialist from "@/components/sections/IndustriesWhySpecialist";
import IndustriesCTA from "@/components/sections/IndustriesCTA";
import Footer from "@/components/sections/Footer";

const Industries = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <div ref={ref}>
      <Header />
      <SectionErrorBoundary sectionName="IndustriesHero">
        <IndustriesHero />
      </SectionErrorBoundary>
      <SectionErrorBoundary sectionName="IndustriesGrid">
        <IndustriesGrid />
      </SectionErrorBoundary>
      <SectionErrorBoundary sectionName="IndustriesWhySpecialist">
        <IndustriesWhySpecialist />
      </SectionErrorBoundary>
      <SectionErrorBoundary sectionName="IndustriesCTA">
        <IndustriesCTA />
      </SectionErrorBoundary>
      <Footer />
    </div>
  );
});

Industries.displayName = "Industries";

export default Industries;
