import React from "react";
import { PageLayout } from "@/components/layout/PageLayout";
import SectionErrorBoundary from "@/components/SectionErrorBoundary";
import Header from "@/components/sections/Header";
import Footer from "@/components/sections/Footer";
import FinServHero from "@/components/sections/FinServHero";
import FinServChallenges from "@/components/sections/FinServChallenges";
import FinServSolutions from "@/components/sections/FinServSolutions";
import FinServTestimonial from "@/components/sections/FinServTestimonial";
import FinServFAQ from "@/components/sections/FinServFAQ";
import FinServCTA from "@/components/sections/FinServCTA";

// Service JSON-LD
const serviceJsonLd = {
  "@context": "https://schema.org",
  "@type": "Service",
  name: "Financial Services SEO",
  description:
    "Specialist SEO services for financial services firms including YMYL-compliant content strategy, entity SEO, schema markup for financial products, and technical SEO. Serving banks, wealth managers, mortgage brokers, and fintech companies.",
  provider: {
    "@type": "LocalBusiness",
    name: "Gregg Blanchard SEO Consulting",
    url: "https://greggblanchard.com",
    areaServed: ["United Kingdom", "United States", "Australia"],
  },
  serviceType: "Search Engine Optimisation",
  audience: {
    "@type": "Audience",
    audienceType: "Financial Services Businesses",
  },
};

// LocalBusiness + FinancialService JSON-LD
const localBusinessJsonLd = {
  "@context": "https://schema.org",
  "@type": ["LocalBusiness", "FinancialService"],
  name: "Gregg Blanchard SEO Consulting — Financial Services",
  description:
    "Independent SEO consultant specialising in financial services SEO, YMYL compliance, entity SEO for brand authority, and schema markup for regulated financial content.",
  url: "https://greggblanchard.com/industries/financial-services",
  telephone: "+44-20-0000-0000",
  address: {
    "@type": "PostalAddress",
    addressLocality: "London",
    addressCountry: "GB",
  },
  knowsAbout: [
    "Financial Services SEO",
    "YMYL Compliance",
    "E-E-A-T Optimisation",
    "Schema Markup for Financial Products",
    "Entity SEO",
    "FCA-Compliant Content Strategy",
    "Technical SEO for Financial Websites",
  ],
  hasOfferCatalog: {
    "@type": "OfferCatalog",
    name: "Financial Services SEO Services",
    itemListElement: [
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Service",
          name: "YMYL SEO Audit",
          description: "Comprehensive audit of E-E-A-T signals, YMYL compliance, and trust factors for financial websites.",
        },
      },
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Service",
          name: "Entity SEO for Financial Brands",
          description: "Knowledge Graph entity establishment and brand authority building for financial services firms.",
        },
      },
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Service",
          name: "Financial Product Schema Markup",
          description: "Implementation of FinancialProduct, Organisation, and FAQPage schema for improved rich results.",
        },
      },
      {
        "@type": "Offer",
        itemOffered: {
          "@type": "Service",
          name: "Regulatory-Compliant Content Strategy",
          description: "FCA and jurisdiction-appropriate content pipelines that rank and convert without compliance risk.",
        },
      },
    ],
  },
};

const IndustriesFinancialServices = React.forwardRef<HTMLDivElement>((props, ref) => {
  return (
    <PageLayout currentPage="industries-financial-services">
      <div ref={ref}>
        {/* Structured Data */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(serviceJsonLd) }}
        />
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(localBusinessJsonLd) }}
        />

        <Header />

        <SectionErrorBoundary sectionName="FinServHero">
          <FinServHero />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="FinServChallenges">
          <FinServChallenges />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="FinServSolutions">
          <FinServSolutions />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="FinServTestimonial">
          <FinServTestimonial />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="FinServFAQ">
          <FinServFAQ />
        </SectionErrorBoundary>

        <SectionErrorBoundary sectionName="FinServCTA">
          <FinServCTA />
        </SectionErrorBoundary>

        <Footer />
      </div>
    </PageLayout>
  );
});

IndustriesFinancialServices.displayName = "IndustriesFinancialServices";

export default IndustriesFinancialServices;
