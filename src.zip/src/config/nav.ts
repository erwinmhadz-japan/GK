// src/config/nav.ts
// Auto-generated from pages.manifest.json — do not edit manually.
// The groupNavItems() function enforces a hard cap of 6 top-level nav items.
// Any overflow is collected into a "More" dropdown group.

export interface NavItem {
  label: string;
  to?: string;
  children?: NavItem[];
}

const MAX_NAV_ITEMS = 6;

function groupNavItems(items: NavItem[]): NavItem[] {
  if (items.length <= MAX_NAV_ITEMS) return items;
  const visible = items.slice(0, MAX_NAV_ITEMS - 1);
  const overflow = items.slice(MAX_NAV_ITEMS - 1);
  return [...visible, { label: "More", children: overflow }];
}

const _rawNavItems: NavItem[] = [
  { label: "About", to: "/about" },
  { label: "Services", to: "/services" },
  { label: "Locations", children: [
    { label: "Locations", to: "/locations" },
    { label: "Locations Birmingham", to: "/locations-birmingham" },
    { label: "Locations Leeds", to: "/locations-leeds" },
    { label: "Locations Liverpool", to: "/locations-liverpool" },
    { label: "Locations London", to: "/locations-london" },
    { label: "Locations Manchester", to: "/locations-manchester" },
    { label: "Locations Sheffield", to: "/locations-sheffield" },
    { label: "Locations Warrington", to: "/locations-warrington" },
  ] },
  { label: "seo-audit", to: "/seo-audit" },
  { label: "seo-retainer", to: "/seo-retainer" },
  { label: "More", children: [
    { label: "technical-seo", to: "/technical-seo" },
    { label: "schema-markup", to: "/schema-markup" },
    { label: "entity-seo", to: "/entity-seo" },
    { label: "content-strategy", to: "/content-strategy" },
    { label: "local-seo", to: "/local-seo" },
    { label: "digital-pr", to: "/digital-pr" },
    { label: "ai-search-optimisation", to: "/ai-search-optimisation" },
    { label: "chatgpt-visibility", to: "/chatgpt-visibility" },
    { label: "perplexity-visibility", to: "/perplexity-visibility" },
    { label: "google-ai-overviews", to: "/google-ai-overviews" },
    { label: "gemini-visibility", to: "/gemini-visibility" },
    { label: "copilot-visibility", to: "/copilot-visibility" },
    { label: "Ai Search Chatgpt Visibility", to: "/ai-search-chatgpt-visibility" },
    { label: "Ai Search Copilot Visibility", to: "/ai-search-copilot-visibility" },
    { label: "Ai Search Gemini Visibility", to: "/ai-search-gemini-visibility" },
    { label: "Ai Search Google Ai Overviews", to: "/ai-search-google-ai-overviews" },
    { label: "Ai Search Perpelexity Visibility", to: "/ai-search-perpelexity-visibility" },
    { label: "Industries B2b Professional Services", to: "/industries-b2b-professional-services" },
    { label: "Industries Estate Agents Property Services", to: "/industries-estate-agents-property-services" },
    { label: "Industries Financial Services", to: "/industries-financial-services" },
    { label: "Industries Healthcare Clinic Private Providers", to: "/industries-healthcare-clinic-private-providers" },
    { label: "Industries Law Firms Solicitors", to: "/industries-law-firms-solicitors" },
  ] },
];

export const navItems: NavItem[] = groupNavItems(_rawNavItems);
