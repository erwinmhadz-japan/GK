import { forwardRef, HTMLAttributes, ImgHTMLAttributes } from "react";
import { cn } from "@/lib/utils";

interface ImageBackgroundProps extends HTMLAttributes<HTMLElement> {
  /** Image src from the Image Pool */
  src: string;
  /** Descriptive alt text */
  alt: string;
  /** Extra img attributes (fetchpriority, loading, etc.) */
  imgProps?: Omit<ImgHTMLAttributes<HTMLImageElement>, "src" | "alt" | "className">;
  /** Wrapper element — defaults to "section" */
  as?: "section" | "div";
}

/**
 * ImageBackground — full-bleed background image with an always-on gradient mask.
 *
 * The gradient mask is structurally guaranteed by this component — the AI does not
 * need to write or remember the overlay div. Text inside is always readable
 * regardless of pool image brightness or color saturation.
 *
 * Layer order (internal):
 *   1. <img> — absolute, full cover, behind everything
 *   2. gradient mask — from-black/85 → via-black/80 → to-black/70, always present
 *   3. {children} — caller's content; wrap in <div className="container relative z-10">
 *
 * Usage:
 * ```tsx
 * <ImageBackground
 *   src="<pool-url>?w=1920&h=1080&fit=crop"
 *   alt="Hero background"
 *   imgProps={{ fetchpriority: "high", loading: "eager" }}
 *   className="min-h-[85vh] md:min-h-screen flex items-center"
 * >
 *   <div className="container relative z-10">
 *     <h1 className="text-white">Headline</h1>
 *     <p className="text-white/90">Subheadline</p>
 *   </div>
 * </ImageBackground>
 * ```
 *
 * Do NOT add another overlay or gradient inside — the mask is already applied.
 */
const ImageBackground = forwardRef<HTMLElement, ImageBackgroundProps>(
  ({ src, alt, imgProps, as: Tag = "section", className, children, ...props }, ref) => {
    return (
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      <Tag ref={ref as any} className={cn("relative isolate overflow-hidden", className)} {...props}>
        {/* Layer 1 — background image */}
        <img
          src={src}
          alt={alt}
          className="absolute inset-0 w-full h-full object-cover"
          {...imgProps}
        />
        {/* Layer 2 — always-on gradient mask. from-black/85 ensures text readability
            even on dashboard screenshots, infographics, or high-key pool images. */}
        <div className="absolute inset-0 bg-gradient-to-b from-black/85 via-black/80 to-black/70 pointer-events-none" />
        {/* Layer 3 — caller content */}
        {children}
      </Tag>
    );
  }
);

ImageBackground.displayName = "ImageBackground";

export { ImageBackground };
export type { ImageBackgroundProps };
