import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle, FileSearch, Sparkles } from "lucide-react";

const bullets = [
  "Thorough, consultant-crafted — not a tool-generated PDF",
  "Clear, prioritised recommendations you can act on",
  "Covers technical health, on-page signals, content gaps, backlinks, and AI visibility",
];

const SEOAuditSeoAuditCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seoaudit-seo-audit-cta"
      className="relative py-20 md:py-32 border-t border-border bg-[hsl(225_28%_14%)] overflow-hidden"
    >
      {/* Subtle dot-grid texture overlay */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(119 35% 61%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      {/* Ambient glow accent — top-right */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-32 -right-32 w-[480px] h-[480px] rounded-full opacity-[0.08]"
        style={{
          background:
            "radial-gradient(circle, hsl(84 74% 58%) 0%, transparent 70%)",
        }}
      />

      {/* Ambient glow accent — bottom-left */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-24 -left-24 w-[360px] h-[360px] rounded-full opacity-[0.06]"
        style={{
          background:
            "radial-gradient(circle, hsl(119 35% 61%) 0%, transparent 70%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">

          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut" }}
            className="flex items-center justify-center gap-2 mb-6"
          >
            <FileSearch className="h-4 w-4 text-[hsl(84_74%_60%)]" aria-hidden="true" />
            <span className="text-xs uppercase tracking-[0.2em] text-[hsl(214_32%_60%)] font-medium">
              Free SEO Audit
            </span>
          </motion.div>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.08 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight tracking-tight mb-5"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Ready to Find Out What's{" "}
            <span
              className="inline-block"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 60%), hsl(119 35% 61%))",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              Holding Your Site Back?
            </span>
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.16 }}
            className="text-base md:text-lg text-white/80 leading-relaxed mb-8 max-w-2xl mx-auto"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Request a free SEO audit and get a clear, prioritised picture of your
            site's SEO health — delivered by an independent consultant, not an
            automated tool.
          </motion.p>

          {/* Bullet points */}
          <motion.ul
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.24 }}
            className="flex flex-col sm:flex-row sm:flex-wrap sm:justify-center gap-3 mb-10"
          >
            {bullets.map((bullet, index) => (
              <li
                key={index}
                className="flex items-start gap-2 text-sm text-white/80 text-left sm:text-left"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                <CheckCircle
                  className="h-4 w-4 mt-0.5 flex-shrink-0 text-[hsl(119_35%_61%)]"
                  aria-hidden="true"
                />
                <span>{bullet}</span>
              </li>
            ))}
          </motion.ul>

          {/* CTA Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.32 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Button
              asChild
              size="lg"
              className="h-12 px-8 text-base font-semibold text-[hsl(225_28%_14%)] border-0 shadow-lg transition-all duration-300 hover:scale-[1.02]"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 60%), hsl(119 35% 61%))",
                boxShadow: "0 0 32px hsl(84 74% 58% / 0.28)",
              }}
            >
              <Link to="/contact" className="flex items-center gap-2">
                Request Your Free SEO Audit
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
            </Button>
          </motion.div>

          {/* Reassurance line */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease: "easeOut", delay: 0.44 }}
            className="mt-5 text-xs text-white/80 tracking-wide"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            No obligation. I'll personally review your site and get back to you.
          </motion.p>

          {/* Decorative divider */}
          <motion.div
            initial={{ scaleX: 0 }}
            whileInView={{ scaleX: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8, ease: "easeOut", delay: 0.5 }}
            className="mt-12 mx-auto h-px max-w-xs origin-center"
            style={{
              background:
                "linear-gradient(90deg, transparent, hsl(214 32% 60% / 0.4), transparent)",
            }}
            aria-hidden="true"
          />

          {/* Gregg King byline */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.58 }}
            className="mt-8 flex items-center justify-center gap-3"
          >
            <div className="flex items-center justify-center w-9 h-9 rounded-full border border-[hsl(214_32%_60%/0.35)] bg-[hsl(231_9%_16%)]">
              <Sparkles
                className="h-4 w-4 text-[hsl(84_74%_60%)]"
                aria-hidden="true"
              />
            </div>
            <p
              className="text-sm text-white/80"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              <span className="text-white font-medium">Gregg King</span>
              {" "}— Independent SEO Consultant, Warrington, Cheshire
            </p>
          </motion.div>

        </div>
      </div>
    </section>
  );
});

SEOAuditSeoAuditCTA.displayName = "SEOAuditSeoAuditCTA";

export default SEOAuditSeoAuditCTA;
