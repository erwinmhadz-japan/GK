import React from "react";
import { motion } from "framer-motion";
import { CheckCircle, Target, TrendingUp, Shield, UserCheck, Briefcase } from "lucide-react";

const pillars = [
  {
    icon: UserCheck,
    heading: "Direct access to senior expertise",
    body:
      "When you engage with an independent consultant, you speak directly with the person doing the work. There are no account managers, no junior handovers, no diluted strategy.",
  },
  {
    icon: Target,
    heading: "Outcomes-led, not deliverables-led",
    body:
      "Agencies count reports and hours. Independent consulting is measured against one thing: meaningful, sustainable improvement in your organic performance.",
  },
  {
    icon: TrendingUp,
    heading: "Strategy built around your business",
    body:
      "Every recommendation is shaped by your sector, your competitors, and your commercial goals — not applied from a template designed for a different client.",
  },
  {
    icon: Shield,
    heading: "Accountability without the overhead",
    body:
      "There is no team to hide behind. Every piece of work, every strategic decision, carries direct personal accountability — which is exactly how it should be.",
  },
  {
    icon: Briefcase,
    heading: "Sector knowledge that translates",
    body:
      "Working across law, healthcare, finance, and property gives you a consultant who understands regulated, trust-led environments and the SEO challenges they present.",
  },
  {
    icon: CheckCircle,
    heading: "A consistent point of contact",
    body:
      "No rotation between account managers. No re-briefing every quarter. You build a working relationship with one expert who understands your business from the outset.",
  },
];

const differentiators = [
  "Bespoke strategy — not an agency playbook",
  "Senior-level thinking throughout",
  "No long-term lock-in contracts",
  "Transparent, honest counsel",
  "UK-based, British English content focus",
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const SeoConsultingIntro = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seo-consulting-intro"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Header block */}
        <motion.div
          initial={{ opacity: 0, y: 28 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="max-w-2xl mb-16 md:mb-20"
        >
          <span className="inline-block text-xs uppercase tracking-[0.18em] text-primary font-semibold mb-5">
            Independent consulting
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground leading-snug mb-5">
            What independent SEO consulting actually means
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-prose">
            Working with an independent consultant is a fundamentally different engagement model to hiring an agency. The distinction matters — and it shapes everything from how your strategy is developed to who you speak with when questions arise.
          </p>
        </motion.div>

        {/* Two-column prose block */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
          className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 mb-20 md:mb-24 p-8 md:p-10 rounded-md border border-border bg-muted/30"
        >
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-3">
              The agency model and its limitations
            </h3>
            <p className="text-muted-foreground leading-relaxed text-sm md:text-base">
              Most agencies operate on volume: a large client base managed by rotating teams, templated processes, and deliverables that look busy without necessarily driving results. Strategy is often set at the start of an engagement and revisited infrequently. The person you met in the pitch is rarely the person doing the work.
            </p>
            <p className="text-muted-foreground leading-relaxed text-sm md:text-base mt-3">
              For UK businesses in competitive, trust-led sectors — law, healthcare, finance, property — this distance between strategy and execution is a meaningful risk.
            </p>
          </div>
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-3">
              The independent consultant difference
            </h3>
            <p className="text-muted-foreground leading-relaxed text-sm md:text-base">
              As an independent SEO consultant, I work with a focused number of clients at any one time. That deliberate constraint means your engagement receives consistent attention, senior-level thinking at every stage, and a strategy that evolves alongside your business rather than being set and forgotten.
            </p>
            <p className="text-muted-foreground leading-relaxed text-sm md:text-base mt-3">
              Decisions are made by one person who is directly accountable for the outcome. That clarity of responsibility is difficult to replicate inside an agency structure.
            </p>
          </div>
        </motion.div>

        {/* Pillars grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="mb-20 md:mb-24"
        >
          <motion.div
            variants={itemVariants}
            className="mb-10 md:mb-12"
          >
            <h3 className="text-2xl md:text-3xl font-bold text-foreground">
              What you can expect from this engagement
            </h3>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {pillars.map((pillar) => {
              const Icon = pillar.icon;
              return (
                <motion.div
                  key={pillar.heading}
                  variants={itemVariants}
                  className="group flex flex-col gap-4 p-6 rounded-md border border-border bg-background hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%_/_0.10),_0_1px_4px_hsl(222_28%_11%_/_0.05)] transition-shadow duration-300"
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="text-base font-semibold text-foreground mb-2">
                      {pillar.heading}
                    </h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {pillar.body}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Differentiator strip */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="border-t border-border pt-12"
        >
          <div className="flex flex-col md:flex-row md:items-center gap-8 md:gap-16">
            <div className="md:shrink-0 md:max-w-xs">
              <h3 className="text-xl font-bold text-foreground mb-2">
                A consultancy built on direct accountability
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                These are the standards that govern every client engagement — not aspirational values, but practical commitments.
              </p>
            </div>
            <ul className="flex flex-col gap-3 flex-1">
              {differentiators.map((item) => (
                <li key={item} className="flex items-start gap-3">
                  <CheckCircle className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span className="text-sm md:text-base text-foreground">
                    {item}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </motion.div>

      </div>
    </section>
  );
});

SeoConsultingIntro.displayName = "SeoConsultingIntro";

export default SeoConsultingIntro;
