import React from "react";
import { TrendingUp, CheckCircle, Search } from "lucide-react";

const outcomes = [
  "GPTBot unblocked and 47 key pages re-submitted within 72 hours",
  "FAQPage, Article, and LocalBusiness schema deployed across 60+ pages",
  "Content restructured into direct-answer format for top 30 queries",
  "Brand appeared in ChatGPT Browse citations within 3 weeks of launch",
  "Organic traffic uplift of 34% — Google and AI Search compounding",
];

const AiSearchChatgptCaseInsight = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section ref={ref} className="relative py-20 md:py-32 border-t border-border bg-muted">
      <div className="container">
        <div className="grid lg:grid-cols-2 gap-12 xl:gap-20 items-center">
          {/* Left — image */}
          <div className="relative rounded-2xl overflow-hidden shadow-card-hover">
            <img
              src="https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=800&h=600&fit=crop"
              alt="Consultant reviewing AI search analytics on a laptop"
              width={800}
              height={600}
              loading="lazy"
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
            <div className="absolute bottom-6 left-6 right-6">
              <div className="flex items-center gap-3 bg-white/10 backdrop-blur-sm border border-white/20 rounded-lg px-4 py-3">
                <TrendingUp className="h-5 w-5 text-primary shrink-0" />
                <p className="text-sm text-white font-medium">34% organic traffic uplift in 90 days</p>
              </div>
            </div>
          </div>

          {/* Right — content */}
          <div>
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
              Real-world insight
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-5">
              From Google-Only to AI Search: A B2B Services Case
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-5">
              A B2B professional services firm with 15 years of excellent Google rankings found itself invisible in ChatGPT results. Despite strong backlinks and authoritative content, their robots.txt blocked GPTBot and they had zero structured data.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              After a focused AI Search audit — covering crawl access, schema deployment, and content restructuring — the firm began appearing as a cited source in ChatGPT answers for their core service queries within three weeks. The same technical work also drove a 34% uplift in Google traffic, demonstrating how AI Search optimisation and traditional SEO reinforce each other.
            </p>
            <ul className="space-y-3 mb-8">
              {outcomes.map((outcome) => (
                <li key={outcome} className="flex items-start gap-3">
                  <CheckCircle className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                  <span className="text-sm text-foreground leading-relaxed">{outcome}</span>
                </li>
              ))}
            </ul>
            <a
              href="/services-ai-search-optimisation"
              className="inline-flex items-center text-primary font-semibold hover:underline text-sm"
            >
              See how we approach AI Search Optimisation →
            </a>
          </div>
        </div>
      </div>
    </section>
  );
});

AiSearchChatgptCaseInsight.displayName = "AiSearchChatgptCaseInsight";
export default AiSearchChatgptCaseInsight;
