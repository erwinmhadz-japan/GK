import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { ArrowRight, MessageSquare, Book, Search } from "lucide-react";

const AiSearchGeminiCTADouble = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="gemini-cta"
      aria-label="Gemini Visibility CTA section"
      src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=1920&h=1080&fit=crop"
      alt="Team collaborating on AI search strategy"
      imgProps={{ fetchpriority: "low", loading: "lazy" }}
      className="py-24 md:py-36"
    >
      <div className="container relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4">
            Ready to Improve Gemini Visibility?
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-5">
            Get Your Brand Cited by Google Gemini
          </h2>
          <p className="text-lg text-white/90 leading-relaxed mb-10 max-w-2xl mx-auto">
            As an independent SEO consultant, I work with ambitious businesses
            to build the content authority, technical foundations, and structured
            data signals that Gemini trusts. No agency overhead — just focused,
            specialist work that moves the needle.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
              asChild
            >
              <a href="/services-ai-search-optimisation">
                Explore AI Search Optimisation
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10 font-semibold"
              asChild
            >
              <a href="/contact">
                <MessageSquare className="mr-2 h-4 w-4" />
                Book a Free Consultation
              </a>
            </Button>
          </div>

          <p className="mt-8 text-sm text-white/80">
            Independent consultant · No retainer lock-in · Results-driven approach
          </p>
        </div>
      </div>
    </ImageBackground>
  );
});

AiSearchGeminiCTADouble.displayName = "AiSearchGeminiCTADouble";

export default AiSearchGeminiCTADouble;
