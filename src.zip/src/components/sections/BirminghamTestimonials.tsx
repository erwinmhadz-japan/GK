import React from "react";
import { Star, ArrowRight, Group, Quote, Section, Stars, View } from "lucide-react";
import { Button } from "@/components/ui/button";

const testimonials = [
  {
    quote:
      "We were buried on page 4 for every relevant search term in Birmingham. Within five months, we were ranking top 3 for over 20 local keywords. The enquiry volume shift was dramatic — and these are high-value B2B leads, not tyre-kickers.",
    author: "Richard Townsend",
    role: "Managing Director",
    company: "Townsend Precision Engineering, Tyseley",
    image: "https://images.unsplash.com/photo-1605857840732-188f2f08cb31?w=400&h=400&fit=crop&crop=face",
    stars: 5,
  },
  {
    quote:
      "The local SEO strategy transformed our ability to compete against national firms in Birmingham city centre. We're now appearing in the local pack consistently, and our Google Business Profile is generating 4× the calls it was before.",
    author: "Priya Sharma",
    role: "Head of Marketing",
    company: "Midlands Commercial Law, Colmore Row",
    image: "https://images.unsplash.com/photo-1681500920181-0aff411f8cab?w=400&h=400&fit=crop&crop=face",
    stars: 5,
  },
  {
    quote:
      "After two years of mediocre results with a generic agency, switching to a Birmingham-focused SEO consultant made an immediate difference. Understanding the local market nuances — even down to neighbourhood-level search behaviour — has been game-changing.",
    author: "James McCarthy",
    role: "Founder",
    company: "McCarthy Property Group, Solihull",
    image: "https://images.unsplash.com/photo-1734830268394-6c4a1f165af1?w=400&h=400&fit=crop&crop=face",
    stars: 5,
  },
];

const caseStudyPreviews = [
  {
    title: "Manufacturing firm achieves 68% uplift in B2B enquiries",
    sector: "Advanced Manufacturing",
    metric: "+68% enquiries",
    timeframe: "6 months",
  },
  {
    title: "Professional services firm enters Birmingham local pack",
    sector: "Legal Services",
    metric: "Top 3 local pack",
    timeframe: "4 months",
  },
  {
    title: "Retail group doubles Google Business Profile conversions",
    sector: "Retail & Hospitality",
    metric: "2× GBP conversions",
    timeframe: "5 months",
  },
];

const BirminghamTestimonials = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="birmingham-testimonials"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-3xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            Birmingham Client Results
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-5">
            What Birmingham Businesses Say
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            We measure success in pipeline, not just rankings. Here's what Birmingham
            business leaders say about working with a Midlands SEO specialist who
            understands their market.
          </p>
        </div>

        {/* Testimonials grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          {testimonials.map(({ quote, author, role, company, image, stars }) => (
            <div
              key={author}
              className="bg-card border border-border rounded-xl p-7 shadow-card hover-lift flex flex-col"
            >
              {/* Stars */}
              <div className="flex gap-0.5 mb-4">
                {Array.from({ length: stars }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 text-primary fill-primary" />
                ))}
              </div>

              {/* Quote */}
              <blockquote className="text-sm text-muted-foreground leading-relaxed italic mb-6 flex-1">
                "{quote}"
              </blockquote>

              {/* Author */}
              <div className="flex items-center gap-3 pt-4 border-t border-border">
                <img
                  src={image}
                  alt={`${author} — ${company}`}
                  loading="lazy"
                  width="400"
                  height="400"
                  className="h-11 w-11 rounded-full object-cover shrink-0"
                />
                <div>
                  <p className="text-sm font-semibold text-foreground">{author}</p>
                  <p className="text-xs text-muted-foreground">{role}</p>
                  <p className="text-xs text-primary font-medium">{company}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Case study previews */}
        <div className="mb-10">
          <h3 className="text-xl font-bold text-foreground mb-6">
            Recent Birmingham Case Study Highlights
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {caseStudyPreviews.map(({ title, sector, metric, timeframe }) => (
              <div
                key={title}
                className="bg-card border border-border rounded-xl p-6 shadow-soft hover-lift"
              >
                <span className="inline-block text-xs uppercase tracking-wider text-primary font-semibold bg-primary/10 rounded-md px-2 py-1 mb-3">
                  {sector}
                </span>
                <p className="text-sm font-medium text-foreground mb-4 leading-snug">{title}</p>
                <div className="flex items-center justify-between pt-3 border-t border-border">
                  <span className="text-lg font-bold text-primary">{metric}</span>
                  <span className="text-xs text-muted-foreground">{timeframe}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Case studies CTA */}
        <div className="text-center">
          <Button asChild>
            <a href="#case-studies-cta" className="inline-flex items-center gap-2">
              View Full Case Studies
              <ArrowRight className="h-4 w-4" />
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
});

BirminghamTestimonials.displayName = "BirminghamTestimonials";

export default BirminghamTestimonials;
