import React, { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Search, Tag, Building, File, Key, Layout, Link, Section } from "lucide-react";
import { Input } from "@/components/ui/input";

const terms = [
  {
    term: "AI Search Optimisation",
    category: "AI Search",
    definition:
      "The practice of structuring your content and authority signals so that AI-driven search engines — including ChatGPT, Perplexity, and Google AI Overviews — surface your brand as a trusted, cited source.",
  },
  {
    term: "Entity SEO",
    category: "Technical",
    definition:
      "An approach to SEO that focuses on establishing your brand, people, and products as named entities within Google's Knowledge Graph, improving context, trust, and semantic relevance.",
  },
  {
    term: "Schema Markup",
    category: "Technical",
    definition:
      "Structured data added to web pages in JSON-LD, Microdata, or RDFa format that helps search engines understand the meaning of your content and powers rich results in SERPs.",
  },
  {
    term: "Core Web Vitals",
    category: "Technical",
    definition:
      "A set of Google page experience metrics — Largest Contentful Paint (LCP), Interaction to Next Paint (INP), and Cumulative Layout Shift (CLS) — used as ranking signals.",
  },
  {
    term: "E-E-A-T",
    category: "Content",
    definition:
      "Experience, Expertise, Authoritativeness, and Trustworthiness. Google's quality framework for evaluating the credibility of content and its authors, particularly in YMYL niches.",
  },
  {
    term: "Topical Authority",
    category: "Content",
    definition:
      "The degree to which a website is recognised as a comprehensive, reliable source on a given subject area. Built through depth and breadth of expert content over time.",
  },
  {
    term: "Digital PR",
    category: "Link Building",
    definition:
      "The practice of earning high-quality editorial backlinks and brand mentions through news-worthy content, data studies, and media outreach — combining PR tactics with SEO goals.",
  },
  {
    term: "Knowledge Graph",
    category: "AI Search",
    definition:
      "Google's database of entities and their relationships. Appearing in the Knowledge Graph as a recognised entity can significantly improve your brand's visibility in AI-generated answers.",
  },
  {
    term: "Crawl Budget",
    category: "Technical",
    definition:
      "The number of pages Googlebot will crawl on your site within a given timeframe. Optimising crawl budget ensures your most important pages are indexed and refreshed regularly.",
  },
  {
    term: "Log File Analysis",
    category: "Technical",
    definition:
      "The examination of server access logs to understand exactly how search engine bots are crawling your website — identifying wasted crawl budget, crawl errors, and coverage gaps.",
  },
  {
    term: "Local Pack",
    category: "Local SEO",
    definition:
      "The map-based set of three business listings displayed prominently in Google search results for queries with local intent. Ranking in the Local Pack depends on proximity, relevance, and prominence.",
  },
  {
    term: "Search Intent",
    category: "Content",
    definition:
      "The underlying goal or motivation behind a user's search query — whether informational, navigational, commercial, or transactional. Matching intent is the foundation of effective keyword targeting.",
  },
];

const categories = ["All", "AI Search", "Technical", "Content", "Link Building", "Local SEO"];

const categoryColours: Record<string, string> = {
  "AI Search": "bg-primary/10 text-primary border-primary/20",
  Technical: "bg-blue-500/10 text-blue-600 border-blue-500/20",
  Content: "bg-emerald-500/10 text-emerald-600 border-emerald-500/20",
  "Link Building": "bg-purple-500/10 text-purple-600 border-purple-500/20",
  "Local SEO": "bg-orange-500/10 text-orange-600 border-orange-500/20",
};

const Page2Glossary = React.forwardRef<HTMLElement>((props, ref) => {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("All");

  const filtered = terms.filter((t) => {
    const matchesSearch =
      !query ||
      t.term.toLowerCase().includes(query.toLowerCase()) ||
      t.definition.toLowerCase().includes(query.toLowerCase());
    const matchesCategory = activeCategory === "All" || t.category === activeCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <section
      ref={ref}
      id="seo-glossary"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        {/* Section header */}
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="inline-flex items-center gap-1.5 text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            <Tag className="h-3.5 w-3.5" />
            SEO Glossary
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Key SEO &amp; AI Search Terms Explained
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Plain-English definitions for the concepts that matter most in modern search optimisation.
          </p>
        </div>

        {/* Search and filter */}
        <div className="flex flex-col md:flex-row gap-4 mb-8 max-w-3xl mx-auto">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              type="text"
              placeholder="Search terms..."
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="flex flex-wrap gap-2">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setActiveCategory(cat)}
                className={`px-3 py-1.5 rounded-full text-sm font-medium border transition-colors ${
                  activeCategory === cat
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-background text-muted-foreground border-border hover:border-primary/40 hover:text-foreground"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        {/* Terms grid */}
        {filtered.length > 0 ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 max-w-5xl mx-auto">
            {filtered.map((item) => (
              <div
                key={item.term}
                className="bg-card border border-border rounded-xl p-6 shadow-soft hover:shadow-card transition-shadow"
              >
                <div className="flex items-start justify-between gap-3 mb-3">
                  <h3 className="text-lg font-bold text-foreground leading-tight">{item.term}</h3>
                  <Badge
                    variant="outline"
                    className={`shrink-0 text-xs ${categoryColours[item.category] ?? "bg-muted text-muted-foreground"}`}
                  >
                    {item.category}
                  </Badge>
                </div>
                <p className="text-muted-foreground text-sm leading-relaxed">{item.definition}</p>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-12 text-muted-foreground">
            <Search className="h-10 w-10 mx-auto mb-3 opacity-30" />
            <p className="text-lg">No terms match your search. Try a different keyword.</p>
          </div>
        )}
      </div>
    </section>
  );
});

Page2Glossary.displayName = "Page2Glossary";

export default Page2Glossary;
