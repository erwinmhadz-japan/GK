import React from "react";
import { Search, MapPin, Globe, Target, Star, ArrowRight, View } from "lucide-react";
import { Button } from "@/components/ui/button";

const services = [
  {
    icon: Search,
    title: "Sheffield SEO Consulting",
    description:
      "Strategic SEO advice tailored to the Sheffield market. I audit your current performance, identify the gaps your local competitors are exploiting, and build a clear roadmap to ranking dominance.",
    href: "#seo-consulting-cta",
  },
  {
    icon: MapPin,
    title: "Local SEO for Sheffield",
    description:
      "Get found by Sheffield customers when they're ready to buy. Google Business Profile optimisation, local citation building, and neighbourhood-specific landing pages that drive footfall and enquiries.",
    href: "/local-seo",
  },
  {
    icon: Globe,
    title: "Technical SEO",
    description:
      "Deep technical audits covering Core Web Vitals, crawlability, indexation, and site architecture — the foundations that Sheffield businesses need before any other SEO activity can succeed.",
    href: "/technical-seo",
  },
  {
    icon: Target,
    title: "Content Strategy",
    description:
      "Topic clusters and content plans built around what Sheffield audiences are actually searching for. From sector-specific guides to local landing pages, I create the content that earns rankings.",
    href: "/content-strategy",
  },
  {
    icon: Star,
    title: "AI Search Optimisation",
    description:
      "Sheffield businesses are already appearing (or missing) in ChatGPT, Perplexity, and Google AI Overviews. I ensure your brand is the answer those AI engines serve up to your target audience.",
    href: "/ai-search-optimisation",
  },
  {
    icon: Globe,
    title: "SEO Retainer",
    description:
      "Monthly SEO management for Sheffield businesses that want sustained, compounding growth. Priority support, regular reporting, and ongoing optimisation — all without the agency overhead.",
    href: "/seo-retainer",
  },
];

const SheffieldServices = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-3">
            Tailored for Sheffield
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground">
            SEO Services for Sheffield Businesses
          </h2>
          <p className="mt-4 text-muted-foreground text-lg leading-relaxed">
            Every service is adapted to the Sheffield market — the search trends, the competition, and the customers that South Yorkshire businesses need to reach.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <a
                key={service.title}
                href={service.href}
                className="group bg-muted rounded-xl p-7 border border-border hover:border-primary/30 hover:shadow-card-hover transition-all duration-300 hover-lift flex flex-col"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 mb-4 group-hover:bg-primary/20 transition-colors">
                  <Icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-lg font-bold text-foreground mb-2">
                  {service.title}
                </h3>
                <p className="text-muted-foreground text-sm leading-relaxed flex-1">
                  {service.description}
                </p>
                <div className="flex items-center gap-1 mt-4 text-primary text-sm font-medium">
                  Learn more <ArrowRight className="h-4 w-4" />
                </div>
              </a>
            );
          })}
        </div>

        <div className="text-center">
          <Button size="lg" asChild>
            <a href="/services">View All Services</a>
          </Button>
        </div>
      </div>
    </section>
  );
});

SheffieldServices.displayName = "SheffieldServices";
export default SheffieldServices;
