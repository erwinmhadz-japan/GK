import React from "react";
import { motion } from "framer-motion";
import { Shield, Clock, FileText, Database, Award, Rss, BadgeCheck, Code, Icon } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const technicalFactors = [
  {
    icon: Rss,
    label: "Crawlability",
    detail: "Perplexity's PerplexityBot must be able to access your pages. Ensure your robots.txt does not block it and that your sitemap is up to date.",
  },
  {
    icon: Clock,
    label: "Content Freshness",
    detail: "Perplexity heavily weights recency. Pages with clear publish and updated dates signal that your content reflects the current state of a topic.",
  },
  {
    icon: Code,
    label: "Structured Data (Schema)",
    detail: "Article, FAQ, HowTo, and Organization schema help Perplexity parse your content structure quickly — and signal that your page is a formal, citable document.",
  },
  {
    icon: FileText,
    label: "Clear Factual Claims",
    detail: "Perplexity surfaces pages with discrete, citable facts. Write with specificity: statistics, definitions, named processes — not vague assertions.",
  },
];

const contentFactors = [
  {
    icon: Shield,
    label: "Source Credibility & E-E-A-T",
    detail: "Perplexity evaluates whether your domain is a trusted authority in its niche. External citations, digital PR, and a clear author-expertise footprint all strengthen your citation probability.",
  },
  {
    icon: Award,
    label: "Topical Authority",
    detail: "Sites with deep topical coverage — not single orphan pages — are selected more frequently. A coherent content cluster around your subject matter signals authoritative status.",
  },
  {
    icon: Database,
    label: "Citation-Friendly Formatting",
    detail: "Short, clearly attributed statements, bullet summaries, and defined terms give Perplexity clean excerpts to quote. Dense walls of prose are harder for the model to use as a source.",
  },
  {
    icon: BadgeCheck,
    label: "Brand Entity Recognition",
    detail: "If your business exists as a named entity in Perplexity's understanding, your site is more likely to surface when that entity is mentioned in a query. Entity SEO underpins Perplexity visibility.",
  },
];

const AiSearchPerplexityFactors = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="perplexity-factors"
      className="relative isolate py-24 md:py-36"
      aria-label="Technical and content factors for Perplexity visibility"
    >
      {/* Background image with brand tint */}
      <img
        src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=1920&h=1080&fit=crop"
        alt="Team working together on laptops in a collaborative office environment"
        className="absolute inset-0 w-full h-full object-cover"
        width="1920"
        height="1080"
        loading="lazy"
        aria-hidden="true"
      />
      <div className="absolute inset-0 bg-gradient-to-br from-primary/80 via-primary/55 to-accent/60 pointer-events-none" />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        {/* Eyebrow + heading */}
        <div className="max-w-3xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4">
            Visibility Factors
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">
            What Determines Whether Perplexity Cites You?
          </h2>
          <p className="text-lg text-white/90 leading-relaxed">
            Perplexity citation isn't random — it's the result of technical accessibility, content quality, and domain authority working together. Here's what matters most.
          </p>
        </div>

        {/* Two-column grid: Technical | Content */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Technical factors */}
          <div>
            <Badge className="mb-5 bg-white/15 text-white border-white/20 text-xs uppercase tracking-widest">
              Technical Factors
            </Badge>
            <div className="space-y-4">
              {technicalFactors.map(({ icon: Icon, label, detail }, i) => (
                <motion.div
                  key={label}
                  initial={{ opacity: 0, x: -16 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.08 }}
                  className="flex gap-4 rounded-xl bg-white/10 backdrop-blur-sm border border-white/15 p-5"
                >
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-white/15">
                    <Icon className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <p className="font-semibold text-white mb-1">{label}</p>
                    <p className="text-sm text-white/80 leading-relaxed">{detail}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Content & authority factors */}
          <div>
            <Badge className="mb-5 bg-white/15 text-white border-white/20 text-xs uppercase tracking-widest">
              Content and Authority Factors
            </Badge>
            <div className="space-y-4">
              {contentFactors.map(({ icon: Icon, label, detail }, i) => (
                <motion.div
                  key={label}
                  initial={{ opacity: 0, x: 16 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.4, delay: i * 0.08 }}
                  className="flex gap-4 rounded-xl bg-white/10 backdrop-blur-sm border border-white/15 p-5"
                >
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-white/15">
                    <Icon className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <p className="font-semibold text-white mb-1">{label}</p>
                    <p className="text-sm text-white/80 leading-relaxed">{detail}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

AiSearchPerplexityFactors.displayName = "AiSearchPerplexityFactors";

export default AiSearchPerplexityFactors;
