import React from "react";
import { motion } from "framer-motion";
import { ArrowRight, Clock, Tag, BookOpen, Image, Search, Section } from "lucide-react";
import { Link } from "react-router-dom";

const InsightsFeaturedArticle = React.forwardRef<HTMLElement>((props, ref) => {
  const featuredArticle = {
    category: "AI Search",
    categorySlug: "ai-search",
    headline: "How AI Overviews Are Reshaping Organic Visibility — and What UK Businesses Need to Do Now",
    excerpt:
      "Google's AI Overviews have fundamentally altered the first page of search results for millions of queries. For UK businesses in competitive sectors — law, healthcare, finance — the question is no longer whether AI search will affect your visibility, but how quickly you can adapt. This piece examines the signals that determine AI Overview inclusion and what a structured optimisation approach looks like in practice.",
    readTime: "9 min read",
    date: "12 June 2025",
    image: "https://images.unsplash.com/photo-1571120245989-c2878f4c89b9?w=1200&h=700&fit=crop",
    imageAlt: "Modern editorial workspace with architectural light — representing analytical depth and authority",
  };

  return (
    <section
      ref={ref}
      id="insights-featured-article"
      className="relative py-16 md:py-24 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section label */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="mb-8 md:mb-10"
        >
          <span className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.18em] font-medium text-muted-foreground">
            <BookOpen className="h-3.5 w-3.5" />
            Featured Article
          </span>
        </motion.div>

        {/* Feature card — dark navy background, editorial layout */}
        <motion.article
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.65, ease: "easeOut", delay: 0.1 }}
          className="relative overflow-hidden rounded-md"
          style={{ background: "hsl(var(--navy-deep))" }}
        >
          {/* Two-column layout on desktop: image left, content right */}
          <div className="grid md:grid-cols-[1fr_1fr] lg:grid-cols-[5fr_7fr]">
            {/* Image column */}
            <div className="relative overflow-hidden aspect-[4/3] md:aspect-auto md:min-h-[400px] lg:min-h-[460px]">
              <img
                src={featuredArticle.image}
                alt={featuredArticle.imageAlt}
                width="800"
                height="600"
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover opacity-80"
              />
              {/* Subtle brand-tinted overlay on image */}
              <div
                className="absolute inset-0 pointer-events-none"
                style={{
                  background:
                    "linear-gradient(135deg, hsl(222 42% 8% / 0.55) 0%, hsl(84 74% 58% / 0.08) 100%)",
                }}
              />
            </div>

            {/* Content column */}
            <div className="flex flex-col justify-center px-8 py-10 md:px-10 md:py-12 lg:px-14 lg:py-14">
              {/* Category tag */}
              <div className="flex items-center gap-2 mb-5">
                <span
                  className="inline-flex items-center gap-1.5 text-xs uppercase tracking-[0.16em] font-semibold px-2.5 py-1 rounded-sm"
                  style={{
                    background: "hsl(84 74% 58% / 0.15)",
                    color: "hsl(var(--green-bright))",
                  }}
                >
                  <Tag className="h-3 w-3" />
                  {featuredArticle.category}
                </span>
              </div>

              {/* Headline */}
              <h2 className="text-xl md:text-2xl lg:text-3xl font-bold leading-snug text-white mb-5 max-w-xl">
                {featuredArticle.headline}
              </h2>

              {/* Excerpt */}
              <p className="text-sm md:text-base leading-relaxed text-white/80 mb-8 max-w-lg">
                {featuredArticle.excerpt}
              </p>

              {/* Meta row */}
              <div className="flex flex-wrap items-center gap-4 mb-8">
                <span className="inline-flex items-center gap-1.5 text-xs text-white/60">
                  <Clock className="h-3.5 w-3.5" />
                  {featuredArticle.readTime}
                </span>
                <span className="inline-flex items-center gap-1.5 text-xs text-white/60">
                  <span
                    className="inline-block w-1 h-1 rounded-full"
                    style={{ background: "hsl(var(--green-bright))" }}
                    aria-hidden="true"
                  />
                  {featuredArticle.date}
                </span>
              </div>

              {/* Read-more link — text link only, no button */}
              <Link
                to="/ai-search-optimisation"
                className="inline-flex items-center gap-2 text-sm font-medium group"
                style={{ color: "hsl(var(--green-bright))" }}
              >
                <span className="border-b border-transparent group-hover:border-current transition-colors duration-200">
                  Read the full article
                </span>
                <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
              </Link>
            </div>
          </div>

          {/* Decorative bottom border accent */}
          <div
            className="h-0.5 w-full"
            style={{
              background:
                "linear-gradient(90deg, hsl(84 74% 58% / 0.6) 0%, hsl(119 35% 61% / 0.3) 50%, transparent 100%)",
            }}
          />
        </motion.article>

        {/* Subtle editorial note beneath */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, ease: "easeOut", delay: 0.4 }}
          className="mt-6 text-xs text-muted-foreground text-right"
        >
          Analysis and commentary by{" "}
          <span className="text-foreground font-medium">Gregg King</span>,
          independent SEO consultant
        </motion.p>
      </div>
    </section>
  );
});

InsightsFeaturedArticle.displayName = "InsightsFeaturedArticle";

export default InsightsFeaturedArticle;
