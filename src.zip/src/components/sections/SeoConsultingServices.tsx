import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ChevronRight, Search, ScanLine, RefreshCw, Code, Layers, Network, FileText, MapPin, Megaphone, BrainCircuit, Building, Section, View } from "lucide-react";

interface ServiceItem {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  slug: string;
  description: string;
  badge?: string;
}

const services: ServiceItem[] = [
  {
    icon: Search,
    title: "SEO Consulting",
    slug: "/seo-consulting",
    description:
      "Independent strategic SEO direction for UK businesses seeking expert guidance rather than a managed retainer. I work directly with your team to build a durable organic growth strategy.",
    badge: "Core Service",
  },
  {
    icon: ScanLine,
    title: "SEO Audit",
    slug: "/seo-audit",
    description:
      "A thorough technical and strategic review of your site's current position — identifying what's holding back rankings, what's working, and exactly where to focus effort.",
  },
  {
    icon: RefreshCw,
    title: "SEO Retainer",
    slug: "/seo-retainer",
    description:
      "Ongoing monthly SEO consultancy for businesses that want sustained expert input without the overhead of an agency. Transparent scope, direct access, measurable progress.",
  },
  {
    icon: Code,
    title: "Technical SEO",
    slug: "/technical-seo",
    description:
      "Crawlability, indexing, site architecture, Core Web Vitals, and structured data — the technical foundations that determine whether Google can properly discover and rank your content.",
  },
  {
    icon: Layers,
    title: "Schema Markup",
    slug: "/schema-markup",
    description:
      "Implementing structured data to help search engines and AI systems understand your content, entities, and offerings — improving visibility in rich results and AI-generated responses.",
  },
  {
    icon: Network,
    title: "Entity SEO",
    slug: "/entity-seo",
    description:
      "Building the knowledge graph signals that establish your brand as a recognised, trusted entity in your sector — critical for topical authority and AI search visibility.",
    badge: "Emerging",
  },
  {
    icon: FileText,
    title: "Content Strategy",
    slug: "/content-strategy",
    description:
      "Keyword-led content planning that maps your expertise to real search demand — structured to build topical authority, capture informational queries, and support commercial pages.",
  },
  {
    icon: MapPin,
    title: "Local SEO",
    slug: "/local-seo",
    description:
      "Targeted local search optimisation for UK businesses competing in city or region-level results — Google Business Profile, local citations, and geo-targeted content.",
  },
  {
    icon: Megaphone,
    title: "Digital PR",
    slug: "/digital-pr",
    description:
      "Earning high-authority editorial links through strategic outreach and expert commentary placements — strengthening domain authority and brand trust signals in competitive sectors.",
  },
  {
    icon: BrainCircuit,
    title: "AI Search Optimisation",
    slug: "/ai-search-optimisation",
    description:
      "Positioning your brand to appear in ChatGPT, Perplexity, Google AI Overviews, and other generative AI responses — the next frontier for organic visibility.",
    badge: "New",
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.07,
      delayChildren: 0.1,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5,
      ease: "easeOut",
    },
  },
};

const SeoConsultingServices = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seo-consulting-services"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          className="max-w-2xl mb-12 md:mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <span className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium">
            Full Service Range
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight max-w-xl">
            SEO Services Available
          </h2>
          <p className="mt-4 text-base md:text-lg text-muted-foreground leading-relaxed max-w-prose">
            I offer a focused set of SEO disciplines — each delivered directly
            by me, without account managers or subcontractors. Select a service
            below to understand what's involved and whether it's the right fit
            for your business.
          </p>
        </motion.div>

        {/* Services grid — exactly 10 items in a 2-column layout (2×5) */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-5"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
        >
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <motion.div key={service.slug} variants={cardVariants}>
                <Link
                  to={service.slug}
                  className="group block h-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary rounded-md"
                  aria-label={`Learn more about ${service.title}`}
                >
                  <Card className="h-full border border-border bg-background shadow-none transition-all duration-300 group-hover:border-primary/40 group-hover:shadow-md rounded-md overflow-hidden">
                    <CardContent className="p-6">
                      <div className="flex items-start gap-4">
                        {/* Icon container */}
                        <div className="flex-shrink-0 flex items-center justify-center w-11 h-11 rounded-md bg-primary/10 text-primary transition-colors duration-300 group-hover:bg-primary/20">
                          <Icon className="h-5 w-5" />
                        </div>

                        {/* Content */}
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1.5 flex-wrap">
                            <h3 className="text-base font-semibold text-foreground leading-snug">
                              {service.title}
                            </h3>
                            {service.badge && (
                              <Badge
                                variant="secondary"
                                className="text-[10px] px-1.5 py-0.5 h-auto leading-tight font-medium"
                              >
                                {service.badge}
                              </Badge>
                            )}
                          </div>
                          <p className="text-sm text-muted-foreground leading-relaxed">
                            {service.description}
                          </p>
                          <span className="inline-flex items-center gap-1 mt-3 text-xs font-medium text-primary transition-colors duration-200 group-hover:text-primary/80">
                            View service
                            <ChevronRight className="h-3.5 w-3.5 transition-transform duration-200 group-hover:translate-x-0.5" />
                          </span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </Link>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Subtle footer note */}
        <motion.p
          className="mt-10 text-sm text-muted-foreground"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3, ease: "easeOut" }}
        >
          All services are delivered personally by Gregg King — an independent
          SEO consultant based in Warrington, Cheshire.
        </motion.p>
      </div>
    </section>
  );
});

SeoConsultingServices.displayName = "SeoConsultingServices";

export default SeoConsultingServices;
