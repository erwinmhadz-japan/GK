import React from "react";
import { Bot, Brain, Globe, CheckCircle, ArrowRight, Focus, Key, Search, Target } from "lucide-react";

const platforms = [
  {
    icon: Bot,
    name: "Microsoft Copilot",
    source: "Bing Index + Azure AI",
    emphasis: "Bing crawlability, structured data, and Bing Webmaster Tools signals are paramount.",
    citeStyle: "Inline citations with source links — users can verify claims.",
    keyDiff: "Strongest enterprise reach. Embedded into Microsoft 365, Windows, and Edge.",
    highlight: true,
    tactics: [
      "Submit sitemap to Bing Webmaster Tools",
      "Implement Schema.org structured data",
      "Earn authority through Bing-indexed backlinks",
      "Optimise for Bing's quality and freshness signals",
    ],
  },
  {
    icon: Brain,
    name: "ChatGPT / GPT-4o",
    source: "OpenAI training data + Bing Browse (GPT-4)",
    emphasis: "Training data inclusion matters more; freshness depends on Browse mode activation.",
    citeStyle: "Citations provided in Browse mode only — answers can be uncited when drawing on training.",
    keyDiff: "Consumer-facing; higher adoption for personal use cases vs. professional workflows.",
    highlight: false,
    tactics: [
      "Earn high-quality backlinks for training data inclusion",
      "Structure content for direct answer extraction",
      "Ensure Bing accessibility for GPT Browse mode",
      "Build topical authority in your niche",
    ],
  },
  {
    icon: Globe,
    name: "Google AI Overviews (Gemini)",
    source: "Google Search Index",
    emphasis: "Google Search ranking signals, E-E-A-T, and structured data are primary levers.",
    citeStyle: "Source cards shown — Google's own search reputation underpins visibility.",
    keyDiff: "Dominant consumer search; AI Overviews appear above organic results for many queries.",
    highlight: false,
    tactics: [
      "Maintain strong Google Search rankings",
      "Implement HowTo, FAQ, and Article schema",
      "Build E-E-A-T with author bios and credentials",
      "Target featured snippet positions as AI Overview precursor",
    ],
  },
];

const AiSearchCopilotVsPeers = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="copilot-vs-peers"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            AI Platform Comparison
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Copilot vs. ChatGPT vs. Google AI Overviews
          </h2>
          <p className="text-muted-foreground text-base md:text-lg leading-relaxed">
            Not all AI platforms source content the same way. Understanding the distinctions helps you prioritise where to invest your optimisation effort — and why Copilot demands its own dedicated strategy.
          </p>
          <a href="#ai-search-cta" className="inline-flex items-center gap-1.5 mt-5 text-sm text-primary font-medium hover:underline underline-offset-4">
            Explore all AI search platforms
            <ArrowRight className="h-3.5 w-3.5" />
          </a>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-7">
          {platforms.map((p) => (
            <div
              key={p.name}
              className={`p-7 rounded-xl border hover-lift shadow-card ${
                p.highlight
                  ? "bg-primary/5 border-primary/30 ring-1 ring-primary/20"
                  : "bg-card border-border"
              }`}
            >
              {p.highlight && (
                <span className="inline-block text-xs uppercase tracking-widest text-primary font-semibold mb-3">
                  This Page's Focus
                </span>
              )}
              <div className="flex items-center gap-3 mb-5">
                <div className={`flex h-10 w-10 items-center justify-center rounded-lg ${p.highlight ? "bg-primary/15" : "bg-muted"}`}>
                  <p.icon className={`h-5 w-5 ${p.highlight ? "text-primary" : "text-muted-foreground"}`} />
                </div>
                <h3 className="text-lg font-bold text-foreground">{p.name}</h3>
              </div>

              <div className="space-y-3 mb-6 text-sm">
                <div>
                  <span className="text-xs uppercase tracking-widest text-muted-foreground font-medium">Source</span>
                  <p className="text-foreground mt-1">{p.source}</p>
                </div>
                <div>
                  <span className="text-xs uppercase tracking-widest text-muted-foreground font-medium">Citation style</span>
                  <p className="text-foreground mt-1">{p.citeStyle}</p>
                </div>
                <div>
                  <span className="text-xs uppercase tracking-widest text-muted-foreground font-medium">Key differentiator</span>
                  <p className="text-foreground mt-1">{p.keyDiff}</p>
                </div>
              </div>

              <div className="border-t border-border pt-5">
                <span className="text-xs uppercase tracking-widest text-muted-foreground font-medium mb-3 block">
                  Top optimisation tactics
                </span>
                <ul className="space-y-2">
                  {p.tactics.map((t) => (
                    <li key={t} className="flex items-start gap-2 text-sm text-foreground">
                      <CheckCircle className={`h-3.5 w-3.5 shrink-0 mt-0.5 ${p.highlight ? "text-primary" : "text-muted-foreground"}`} />
                      {t}
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
});

AiSearchCopilotVsPeers.displayName = "AiSearchCopilotVsPeers";
export default AiSearchCopilotVsPeers;
