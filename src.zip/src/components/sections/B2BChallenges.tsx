import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Clock, Users, FileText, BarChart, Search, Globe, Volume } from "lucide-react";

const challenges = [
  {
    icon: Clock,
    title: "Long, Complex Sales Cycles",
    description:
      "B2B buyers research for weeks or months before engaging a firm. Your content must rank at awareness, consideration, and decision stages — capturing prospects at every touchpoint, not just the bottom of the funnel.",
  },
  {
    icon: Users,
    title: "Multiple Decision-Makers",
    description:
      "Procurement teams, CFOs, CTOs, and end users all search differently. A single keyword strategy won't cut it — you need content mapped to each persona's questions, concerns, and authority level.",
  },
  {
    icon: FileText,
    title: "Technical Content That Must Rank",
    description:
      "Whitepapers, thought leadership articles, and service pages compete with large publishers. Without entity authority and proper schema, Google can't determine whether your firm is the credible expert it is.",
  },
  {
    icon: BarChart,
    title: "Low Search Volume, High Intent",
    description:
      "B2B keywords often have modest monthly search volumes, but each click can represent tens of thousands in pipeline value. Ranking for the right terms — not just high-volume ones — drives qualified leads.",
  },
  {
    icon: Search,
    title: "Saturated Organic SERP Competition",
    description:
      "Big four consultancies, industry associations, and well-funded competitors dominate the results pages your clients check. Breaking through requires a differentiated entity and content approach.",
  },
  {
    icon: Globe,
    title: "AI Search Visibility Gap",
    description:
      "Buyers increasingly use AI tools like ChatGPT and Perplexity to shortlist vendors. If your firm isn't structured as a recognised entity with authoritative content, you won't be cited — and you won't be considered.",
  },
];

const B2BChallenges = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="b2b-challenges"
      className="relative py-20 md:py-32 border-t border-border bg-background"
      aria-label="SEO challenges for B2B professional services"
    >
      <div className="container">
        {/* Header */}
        <div className="max-w-2xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            The B2B SEO Problem
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-5">
            Why B2B SEO Fails Without a Specialist Strategy
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Professional services firms face unique organic search challenges
            that generic SEO agencies aren't equipped to solve. Here's what
            makes B2B SEO fundamentally different.
          </p>
        </div>

        {/* Challenges grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {challenges.map((challenge, index) => {
            const Icon = challenge.icon;
            return (
              <Card
                key={index}
                className="group border border-border bg-card hover:shadow-card-hover transition-shadow duration-300"
              >
                <CardHeader className="pb-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-4 group-hover:bg-primary/20 transition-colors">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <CardTitle className="text-lg text-foreground">
                    {challenge.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {challenge.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
});

B2BChallenges.displayName = "B2BChallenges";

export default B2BChallenges;
