import React from "react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { HelpCircle, Search } from "lucide-react";

const FaqHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="faq-hero"
      className="relative py-20 md:py-32 border-t border-border bg-muted overflow-hidden"
    >
      {/* Decorative background blobs */}
      <div
        className="absolute inset-0 pointer-events-none"
        aria-hidden="true"
        style={{
          backgroundImage:
            "radial-gradient(circle at 80% 15%, hsl(88 59% 56% / 0.07) 0%, transparent 50%), radial-gradient(circle at 12% 85%, hsl(214 32% 60% / 0.06) 0%, transparent 45%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          {/* Eyebrow badge */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            <Badge
              variant="outline"
              className="inline-flex items-center gap-1.5 text-xs font-medium tracking-wide uppercase border-border text-muted-foreground mb-6"
            >
              <HelpCircle className="h-3 w-3 text-primary" />
              SEO FAQ · UK Businesses
            </Badge>
          </motion.div>

          {/* H1 */}
          <motion.h1
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.08 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold leading-[1.1] tracking-tight text-foreground mb-6"
          >
            Frequently Asked{" "}
            <span className="text-gradient-green">SEO Questions</span>
          </motion.h1>

          {/* Sub-headline */}
          <motion.p
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.18 }}
            className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-2xl mx-auto mb-8"
          >
            Honest, straightforward answers to the questions UK business owners most commonly ask about SEO, AI search, and working with an independent consultant.
          </motion.p>

          {/* Decorative divider */}
          <motion.div
            initial={{ opacity: 0, scaleX: 0 }}
            animate={{ opacity: 1, scaleX: 1 }}
            transition={{ duration: 0.5, ease: "easeOut", delay: 0.3 }}
            className="mx-auto w-16 h-0.5 rounded-full"
            style={{ background: "hsl(var(--primary))" }}
            aria-hidden="true"
          />
        </div>
      </div>
    </section>
  );
});

FaqHero.displayName = "FaqHero";

export default FaqHero;
