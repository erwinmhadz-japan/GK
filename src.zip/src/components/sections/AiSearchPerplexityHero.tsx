import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Search, Globe, Zap, Icon } from "lucide-react";
import { ImageBackground } from "@/components/ImageBackground";

const AiSearchPerplexityHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="perplexity-visibility-hero"
      aria-label="Perplexity AI Visibility Hero"
      src="https://images.unsplash.com/photo-1573496528298-f0e9d3c7ce55?w=1920&h=1080&fit=crop"
      alt="Professional working at a computer researching AI search optimisation"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center"
    >
      <div className="container relative z-10 max-w-6xl mx-auto px-4 py-24 md:py-36">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left column */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5 }}
              className="flex flex-wrap items-center gap-2 mb-6"
            >
              <Badge className="bg-primary/20 text-primary border-primary/30 text-xs uppercase tracking-widest">
                AI Search Visibility
              </Badge>
              <Badge variant="outline" className="border-white/30 text-white/80 text-xs uppercase tracking-widest">
                Perplexity AI
              </Badge>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6"
            >
              Get Cited by{" "}
              <span className="text-gradient-green">Perplexity AI</span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-lg md:text-xl text-white/90 mb-8 leading-relaxed"
            >
              Perplexity is the AI-native search engine that millions of researchers, professionals, and curious minds trust for real-time, source-cited answers. Learn how to optimise your content so Perplexity selects and cites your website.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="flex flex-wrap gap-4 mb-10"
            >
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold" asChild>
                <a href="/services-ai-search-optimisation">
                  Get Optimised for AI Search
                  <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="bg-transparent text-white border-white hover:bg-white/10"
                asChild
              >
                <a href="/contact">Talk to a Specialist</a>
              </Button>
            </motion.div>

            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.45 }}
              className="flex flex-wrap gap-6"
            >
              {[
                { icon: Search, label: "Real-time web indexing" },
                { icon: Globe, label: "Source citations" },
                { icon: Zap, label: "Answer engine optimisation" },
              ].map(({ icon: Icon, label }) => (
                <div key={label} className="flex items-center gap-2 text-white/80 text-sm">
                  <Icon className="h-4 w-4 text-primary shrink-0" />
                  <span>{label}</span>
                </div>
              ))}
            </motion.div>
          </div>

          {/* Right column — stat cards */}
          <motion.div
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, delay: 0.35 }}
            className="hidden lg:flex flex-col gap-4"
          >
            {[
              {
                metric: "100M+",
                label: "monthly queries on Perplexity",
                sub: "Growing 3× year-on-year",
              },
              {
                metric: "Real-time",
                label: "web crawling & live indexing",
                sub: "Fresh sources prioritised in answers",
              },
              {
                metric: "Cited Sources",
                label: "visible alongside every answer",
                sub: "Your brand, named in the response",
              },
            ].map(({ metric, label, sub }) => (
              <div
                key={metric}
                className="rounded-xl border border-white/15 bg-white/10 backdrop-blur-sm p-5"
              >
                <p className="text-2xl font-bold text-primary mb-1">{metric}</p>
                <p className="text-white font-medium text-sm">{label}</p>
                <p className="text-white/80 text-xs mt-1">{sub}</p>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </ImageBackground>
  );
});

AiSearchPerplexityHero.displayName = "AiSearchPerplexityHero";

export default AiSearchPerplexityHero;
