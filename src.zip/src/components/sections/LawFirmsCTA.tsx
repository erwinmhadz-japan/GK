import React from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight, FileText, Phone, Book, View } from "lucide-react";

const LawFirmsCTA = React.forwardRef<HTMLElement>((props, ref) => {
  // Service + LocalBusiness JSON-LD schema
  const structuredData = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      name: "SEO for Law Firms & Solicitors",
      description:
        "Specialist search engine optimisation services for UK law firms and solicitor practices, including local SEO, content marketing, technical SEO, and schema markup for legal entities. Fully compliant with SRA advertising standards.",
      provider: {
        "@type": "ProfessionalService",
        name: "Gregg Blanchard SEO",
        url: "https://www.greggblanchardseo.co.uk",
      },
      areaServed: {
        "@type": "Country",
        name: "United Kingdom",
      },
      serviceType: "SEO Consultancy",
      category: "Legal Services SEO",
    },
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      name: "Gregg Blanchard SEO",
      description:
        "Independent SEO consultant specialising in law firms, solicitors, and regulated professional services across the UK.",
      url: "https://www.greggblanchardseo.co.uk",
      areaServed: [
        { "@type": "Country", name: "United Kingdom" },
      ],
      knowsAbout: [
        "Legal SEO",
        "Law Firm SEO",
        "Solicitor SEO",
        "Local SEO for Law Firms",
        "SRA Compliant Content",
        "LegalService Schema Markup",
      ],
    },
  ];

  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
      aria-label="Law firm SEO call to action"
    >
      {/* Structured data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(structuredData) }}
      />

      <div className="container">
        <div className="max-w-4xl mx-auto">
          {/* Primary CTA */}
          <div className="text-center mb-16">
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
              Ready to Grow?
            </span>
            <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">
              Let's Build Your Law Firm's Online Authority
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto mb-10">
              Book a free discovery call to discuss your firm's SEO goals, current
              visibility challenges, and how a tailored strategy can drive more
              qualified client enquiries — compliantly and consistently.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold" asChild>
                <a href="/contact">
                  <Phone className="h-4 w-4 mr-2" />
                  Book a Free Discovery Call
                </a>
              </Button>
              <Button size="lg" variant="outline" className="border-border" asChild>
                <a href="#case-studies-cta">
                  <ArrowRight className="h-4 w-4 mr-2" />
                  View Case Studies
                </a>
              </Button>
            </div>
          </div>

          {/* Supporting links grid */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <a
              href="/local-seo"
              className="group flex items-start gap-3 p-5 rounded-xl border border-border bg-card hover:border-primary/40 hover:shadow-card transition-all"
            >
              <FileText className="h-5 w-5 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="font-semibold text-foreground text-sm group-hover:text-primary transition-colors">
                  Local SEO Services
                </p>
                <p className="text-muted-foreground text-xs mt-1">
                  Dominate your local search market
                </p>
              </div>
            </a>
            <a
              href="/content-strategy"
              className="group flex items-start gap-3 p-5 rounded-xl border border-border bg-card hover:border-primary/40 hover:shadow-card transition-all"
            >
              <FileText className="h-5 w-5 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="font-semibold text-foreground text-sm group-hover:text-primary transition-colors">
                  Content Strategy
                </p>
                <p className="text-muted-foreground text-xs mt-1">
                  SRA-compliant content that converts
                </p>
              </div>
            </a>
            <a
              href="/entity-seo"
              className="group flex items-start gap-3 p-5 rounded-xl border border-border bg-card hover:border-primary/40 hover:shadow-card transition-all"
            >
              <FileText className="h-5 w-5 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="font-semibold text-foreground text-sm group-hover:text-primary transition-colors">
                  Entity & Schema SEO
                </p>
                <p className="text-muted-foreground text-xs mt-1">
                  Build authority with structured data
                </p>
              </div>
            </a>
          </div>

          {/* Third CTA — industries link */}
          <div className="mt-10 text-center">
            <p className="text-sm text-muted-foreground">
              Not in legal?{" "}
              <a href="#industries-cta" className="text-primary hover:underline underline-offset-4 font-medium">
                See all industries we work with
              </a>
              .
            </p>
          </div>
        </div>
      </div>
    </section>
  );
});

LawFirmsCTA.displayName = "LawFirmsCTA";

export default LawFirmsCTA;
