import React from "react";
import { motion } from "framer-motion";
import { Quote, Star, Group, Section } from "lucide-react";

const testimonials = [
  {
    quote:
      "Gregg completely transformed how we approach search. Within six months we'd gone from page three to dominating the top three for our most valuable terms. The ROI is undeniable.",
    author: "Sarah Mitchell",
    title: "Marketing Director, Manchester Law Firm",
    image: "https://images.unsplash.com/photo-1710778044102-56a3a6b69a1b?w=400&h=400&fit=crop&crop=face",
  },
  {
    quote:
      "As a SaaS founder I needed someone who could move fast, think strategically, and not need hand-holding. Gregg is exactly that. Our CAC via organic is now a fraction of what we pay for PPC.",
    author: "James Chen",
    title: "Founder & CEO, B2B SaaS Platform",
    image: "https://images.unsplash.com/photo-1734830268394-6c4a1f165af1?w=400&h=400&fit=crop&crop=face",
  },
  {
    quote:
      "We'd worked with agencies before and always felt like a small fish. With Gregg, we get senior-level attention on every single piece of work. The technical depth is unlike anything we've experienced.",
    author: "Priya Sharma",
    title: "Head of Digital, Private Healthcare Group",
    image: "https://images.unsplash.com/photo-1681500920181-0aff411f8cab?w=400&h=400&fit=crop&crop=face",
  },
  {
    quote:
      "Our post-migration audit revealed issues three agencies had missed. The implementation roadmap was clear, prioritised, and the results came faster than expected. Highly recommended.",
    author: "Thomas Whitfield",
    title: "E-Commerce Director, UK Retail Brand",
    image: "https://images.unsplash.com/photo-1605857840732-188f2f08cb31?w=400&h=400&fit=crop&crop=face",
  },
  {
    quote:
      "AI Overviews were threatening our click-through rates. Gregg's approach to entity SEO and schema made us a trusted source — our visibility in AI search has grown consistently.",
    author: "Louise Barnett",
    title: "SEO Lead, National Content Publisher",
    image: "https://images.unsplash.com/photo-1710777915903-a7d7f159f2c0?w=400&h=400&fit=crop&crop=face",
  },
  {
    quote:
      "The SEO retainer pays for itself every month. Gregg keeps us ahead of algorithm changes without us having to chase an account manager. Direct access to the expert — no layers.",
    author: "Michael O'Brien",
    title: "Managing Director, Professional Services Firm",
    image: "https://images.unsplash.com/photo-1633625576932-348e73c45e82?w=400&h=400&fit=crop&crop=face",
  },
];

const Page3Testimonials = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="page3-testimonials"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div
        className="absolute inset-0 pointer-events-none"
        aria-hidden="true"
        style={{
          backgroundImage:
            "radial-gradient(circle at 50% 0%, hsl(88 59% 56% / 0.05) 0%, transparent 55%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        {/* Section header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Client voices
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
            What clients say
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Independent opinions from the founders, directors, and marketing leads
            who've worked directly with Gregg King.
          </p>
        </div>

        {/* Testimonials grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {testimonials.map(({ quote, author, title, image }, index) => (
            <motion.div
              key={author}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.07 }}
              className="group relative flex flex-col rounded-xl border border-border bg-card p-8 shadow-card hover-lift"
            >
              {/* Star row */}
              <div className="flex gap-1 mb-5" aria-label="5 stars">
                {Array.from({ length: 5 }).map((_, i) => (
                  <Star
                    key={i}
                    className="h-4 w-4 fill-primary text-primary"
                    aria-hidden="true"
                  />
                ))}
              </div>

              {/* Quote icon */}
              <Quote
                className="h-7 w-7 text-primary/30 mb-3"
                aria-hidden="true"
              />

              {/* Quote text */}
              <blockquote className="flex-1 text-sm text-muted-foreground leading-relaxed mb-6">
                "{quote}"
              </blockquote>

              {/* Author */}
              <div className="flex items-center gap-3 pt-5 border-t border-border">
                <img
                  src={image}
                  alt={`${author} headshot`}
                  width="400"
                  height="400"
                  loading="lazy"
                  className="h-10 w-10 rounded-full object-cover shrink-0"
                />
                <div>
                  <div className="text-sm font-semibold text-foreground">
                    {author}
                  </div>
                  <div className="text-xs text-muted-foreground">{title}</div>
                </div>
              </div>

              {/* Hover accent */}
              <div className="absolute bottom-0 left-8 right-8 h-0.5 rounded-full bg-gradient-to-r from-primary to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
});

Page3Testimonials.displayName = "Page3Testimonials";

export default Page3Testimonials;
