import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Clock, ArrowRight, Building, Calendar, Search, Section, View, Volume } from "lucide-react";

interface Article {
  category: string;
  headline: string;
  excerpt: string;
  date: string;
  readTime: string;
  slug: string;
}

const articles: Article[] = [
  {
    category: "AI Search",
    headline: "How AI Overviews Are Reshaping Organic Visibility for UK Businesses",
    excerpt:
      "Google's AI Overviews now appear for a significant proportion of commercial queries. Understanding how they select source content — and what structured signals influence inclusion — is becoming essential for any serious SEO strategy.",
    date: "12 June 2025",
    readTime: "8 min read",
    slug: "/ai-search-optimisation",
  },
  {
    category: "SEO Strategy",
    headline: "Why Independent SEO Consultants Outperform Agencies for Mid-Market Firms",
    excerpt:
      "Mid-market UK businesses often find agency retainers deliver thin results relative to their cost. A dedicated independent consultant — with direct accountability and no account-management overhead — tends to produce stronger ROI.",
    date: "28 May 2025",
    readTime: "6 min read",
    slug: "/services",
  },
  {
    category: "Technical SEO",
    headline: "Core Web Vitals in 2025: What Has Changed and What Still Matters",
    excerpt:
      "Google's page experience signals continue to evolve. This piece clarifies which performance metrics carry genuine ranking weight in the current algorithm, and how to prioritise remediation work on a constrained development budget.",
    date: "14 May 2025",
    readTime: "7 min read",
    slug: "/services/technical-seo",
  },
  {
    category: "Content Strategy",
    headline: "Topical Authority Over Keyword Volume: A More Durable Content Model",
    excerpt:
      "Chasing high-volume keywords in isolation is an increasingly fragile strategy. Building demonstrable topical authority across a coherent subject cluster produces more sustainable ranking gains — particularly in trust-led sectors such as law and healthcare.",
    date: "2 May 2025",
    readTime: "9 min read",
    slug: "/services/content-strategy",
  },
  {
    category: "Digital PR",
    headline: "Digital PR and Entity SEO: How Earned Coverage Signals Expertise to Google",
    excerpt:
      "Links from authoritative UK publications do more than pass PageRank. When coverage appears alongside consistent entity signals — name, address, credentials — it reinforces the Knowledge Graph entities that underpin modern search rankings.",
    date: "17 April 2025",
    readTime: "7 min read",
    slug: "/services/digital-pr",
  },
  {
    category: "Local SEO",
    headline: "Local SEO for Professional Services: Beyond the Google Business Profile",
    excerpt:
      "Most local SEO guides focus on GBP optimisation. For law firms, private clinics, and financial advisers, the competitive differentiation lies in localised content depth, review signals, and structured data — areas where most competitors remain underinvested.",
    date: "3 April 2025",
    readTime: "6 min read",
    slug: "/services/local-seo",
  },
];

const categoryStyles: Record<string, string> = {
  "AI Search":
    "bg-[hsl(84_74%_58%/0.12)] text-[hsl(84_55%_32%)] border-[hsl(84_74%_58%/0.28)]",
  "SEO Strategy":
    "bg-[hsl(214_32%_60%/0.12)] text-[hsl(214_32%_36%)] border-[hsl(214_32%_60%/0.28)]",
  "Technical SEO":
    "bg-[hsl(222_35%_22%/0.08)] text-[hsl(222_35%_28%)] border-[hsl(222_35%_22%/0.20)]",
  "Content Strategy":
    "bg-[hsl(119_35%_61%/0.12)] text-[hsl(119_35%_33%)] border-[hsl(119_35%_61%/0.28)]",
  "Digital PR":
    "bg-[hsl(358_65%_52%/0.08)] text-[hsl(358_65%_36%)] border-[hsl(358_65%_52%/0.22)]",
  "Local SEO":
    "bg-[hsl(84_74%_58%/0.10)] text-[hsl(84_55%_30%)] border-[hsl(84_74%_58%/0.24)]",
};

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 22 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const InsightsGrid = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="insights-grid"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.55, ease: "easeOut" }}
          className="mb-12 md:mb-16"
        >
          <span className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground mb-3 font-medium">
            Latest Articles
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground max-w-2xl leading-snug">
            Commentary, Analysis &amp; Practical Guidance
          </h2>
          <p className="mt-4 text-base text-muted-foreground max-w-2xl leading-relaxed">
            Independent thinking on SEO, AI search, and digital strategy — written for UK businesses that take organic visibility seriously.
          </p>
        </motion.div>

        {/* Article grid — exactly 6 items */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
        >
          {articles.map((article) => (
            <motion.article
              key={article.headline}
              variants={cardVariants}
              className="group flex flex-col bg-background border border-border rounded-md overflow-hidden transition-all duration-300 hover:border-[hsl(84_74%_58%/0.38)] hover:[box-shadow:0_8px_40px_-8px_hsl(222_28%_11%/0.16),0_2px_8px_hsl(222_28%_11%/0.08)]"
            >
              <div className="flex flex-col flex-1 p-6 md:p-7">

                {/* Category badge */}
                <div className="mb-4">
                  <span
                    className={`inline-flex items-center text-[11px] font-semibold uppercase tracking-[0.14em] px-2.5 py-1 rounded border ${
                      categoryStyles[article.category] ??
                      "bg-muted text-muted-foreground border-border"
                    }`}
                  >
                    {article.category}
                  </span>
                </div>

                {/* Headline */}
                <h3 className="text-base md:text-[17px] font-semibold text-foreground leading-snug mb-3 group-hover:text-[hsl(84_55%_32%)] transition-colors duration-200">
                  {article.headline}
                </h3>

                {/* Excerpt */}
                <p className="text-sm text-muted-foreground leading-relaxed flex-1 mb-5 line-clamp-4">
                  {article.excerpt}
                </p>

                {/* Meta row + read link */}
                <div className="flex items-center justify-between mt-auto pt-4 border-t border-border">
                  <div className="flex items-center gap-4 text-xs text-muted-foreground">
                    {/* Date — rendered inline without Calendar icon to avoid import conflict */}
                    <span className="flex items-center gap-1.5">
                      <CalendarMiniIcon />
                      {article.date}
                    </span>
                    <span className="flex items-center gap-1.5">
                      <Clock className="h-3.5 w-3.5 shrink-0" />
                      {article.readTime}
                    </span>
                  </div>
                  <Link
                    to={article.slug}
                    className="inline-flex items-center gap-1 text-xs font-semibold text-[hsl(84_55%_32%)] hover:text-[hsl(84_74%_44%)] transition-colors duration-150 group/link"
                    aria-label={`Read: ${article.headline}`}
                  >
                    Read
                    <ArrowRight className="h-3.5 w-3.5 transition-transform duration-150 group-hover/link:translate-x-0.5" />
                  </Link>
                </div>
              </div>
            </motion.article>
          ))}
        </motion.div>

        {/* Subtle text link — not a CTA block */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.35, ease: "easeOut" }}
          className="mt-12 text-center"
        >
          <Link
            to="#insights-cta"
            className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors duration-150"
          >
            View all articles
            <ChevronRightMini />
          </Link>
        </motion.div>

        {/* Related topic navigation */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.45, ease: "easeOut" }}
          className="mt-16 pt-10 border-t border-border"
        >
          <p className="text-xs uppercase tracking-[0.16em] text-muted-foreground mb-5 font-medium">Explore by topic</p>
          <div className="flex flex-wrap gap-3">
            <Link to="/ai-search-optimisation" className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded border border-border bg-background text-foreground hover:border-[hsl(84_74%_58%/0.5)] transition-colors duration-150">
              AI Search Optimisation <ChevronRightMini />
            </Link>
            <Link to="/services" className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded border border-border bg-background text-foreground hover:border-[hsl(84_74%_58%/0.5)] transition-colors duration-150">
              SEO Services <ChevronRightMini />
            </Link>
            <Link to="/services-technical-seo" className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded border border-border bg-background text-foreground hover:border-[hsl(84_74%_58%/0.5)] transition-colors duration-150">
              Technical SEO <ChevronRightMini />
            </Link>
            <Link to="/content-strategy" className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded border border-border bg-background text-foreground hover:border-[hsl(84_74%_58%/0.5)] transition-colors duration-150">
              Content Strategy <ChevronRightMini />
            </Link>
            <Link to="#" className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded border border-border bg-background text-foreground hover:border-[hsl(84_74%_58%/0.5)] transition-colors duration-150">
              Digital PR <ChevronRightMini />
            </Link>
            <Link to="/services-local-seo" className="inline-flex items-center gap-1.5 text-xs font-medium px-3 py-1.5 rounded border border-border bg-background text-foreground hover:border-[hsl(84_74%_58%/0.5)] transition-colors duration-150">
              Local SEO <ChevronRightMini />
            </Link>
          </div>
        </motion.div>

      </div>
    </section>
  );
});

InsightsGrid.displayName = "InsightsGrid";

/** Inline SVG calendar icon — avoids shadcn ui/calendar import conflict */
function CalendarMiniIcon() {
  return (
    <svg
      width="14"
      height="14"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      className="shrink-0"
      aria-hidden="true"
    >
      <rect x="3" y="4" width="18" height="18" rx="2" ry="2" />
      <line x1="16" y1="2" x2="16" y2="6" />
      <line x1="8" y1="2" x2="8" y2="6" />
      <line x1="3" y1="10" x2="21" y2="10" />
    </svg>
  );
}

/** Inline SVG chevron-right icon */
function ChevronRightMini() {
  return (
    <svg
      width="14"
      height="14"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <polyline points="9 18 15 12 9 6" />
    </svg>
  );
}

export default InsightsGrid;
