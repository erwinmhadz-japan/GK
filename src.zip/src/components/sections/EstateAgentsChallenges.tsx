import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { MapPin, Clock, Search, Users, TrendingDown, Building2, Section } from "lucide-react";

const challenges = [
  {
    icon: MapPin,
    title: "Hyperlocal Competition",
    description:
      "Every high street in the UK has multiple competing agencies. Ranking for broad terms like 'estate agents' is a race to the bottom. The agents winning online own precise postcode-level and neighbourhood keywords that match how buyers and vendors actually search.",
    tag: "Local Search",
  },
  {
    icon: Clock,
    title: "Seasonal Demand Fluctuations",
    description:
      "Property search volumes surge in spring and autumn yet most agencies have no SEO infrastructure to capitalise on them. A consistent content and technical SEO foundation ensures your site captures peak traffic exactly when market intent is highest.",
    tag: "Seasonal Strategy",
  },
  {
    icon: Search,
    title: "Location-Specific Keywords",
    description:
      "Generic keywords produce generic leads. Buyers searching 'family homes near good schools in [area]' or 'flats to rent [postcode]' are high-intent searchers. Mapping and ranking for these long-tail, location-specific queries is where organic estate agent leads are won.",
    tag: "Keyword Architecture",
  },
  {
    icon: Users,
    title: "Portal Dependency",
    description:
      "Rightmove and Zoopla eat into your margins with rising listing fees. Agents who build independent organic presence own their lead flow rather than renting it. SEO is the long-term antidote to portal reliance.",
    tag: "Lead Independence",
  },
  {
    icon: TrendingDown,
    title: "Thin or Duplicate Content",
    description:
      "Most agency websites repeat the same generic service descriptions across branch pages, triggering Google's duplicate content filters. Unique, locally authoritative content for each area you serve is essential for multi-office operators.",
    tag: "Content Quality",
  },
  {
    icon: Building2,
    title: "Weak Google Business Profiles",
    description:
      "Estate agents rank locally primarily through Google's Local Pack. An under-optimised Google Business Profile — missing categories, no service areas, sparse reviews — hands visibility to competitors with a better local SEO setup.",
    tag: "Local Pack Rankings",
  },
];

const EstateAgentsChallenges = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="estate-agents-challenges"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-2xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Industry Challenges
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-5">
            Why Property SEO Is Uniquely Complex
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Estate agents face a distinctive set of search challenges that
            generic SEO agencies consistently misunderstand. Getting these
            right requires deep sector knowledge and a hyperlocal mindset.
          </p>
        </div>

        {/* Challenge cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {challenges.map((challenge) => {
            const Icon = challenge.icon;
            return (
              <Card
                key={challenge.title}
                className="group hover-lift border-border bg-card shadow-card"
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <Badge variant="secondary" className="text-xs shrink-0">
                      {challenge.tag}
                    </Badge>
                  </div>
                  <CardTitle className="text-lg text-foreground leading-snug">
                    {challenge.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {challenge.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
});

EstateAgentsChallenges.displayName = "EstateAgentsChallenges";

export default EstateAgentsChallenges;
