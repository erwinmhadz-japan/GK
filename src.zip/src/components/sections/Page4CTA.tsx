import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle, Book } from "lucide-react";

const benefits = [
  "Free 30-minute discovery call",
  "Tailored strategy, not off-the-shelf packages",
  "Independent — no agency bias or hidden upsells",
  "Serving clients across the UK and internationally",
];

const Page4CTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="resources-cta"
      className="relative isolate py-24 md:py-36 border-t border-border overflow-hidden"
    >
      {/* Faded background image */}
      <img
        src="https://images.unsplash.com/photo-1591484385394-f5083609ed6a?w=1920&h=1080&fit=crop"
        alt="Modern office building — contact Gregg Holliman SEO Consultancy"
        width={1920}
        height={1080}
        loading="lazy"
        className="absolute inset-0 w-full h-full object-cover opacity-[0.07]"
      />
      {/* Gradient overlay for the dark panel */}
      <div className="absolute inset-0 bg-gradient-section-dark pointer-events-none" />

      <div className="container relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55 }}
          >
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 font-medium mb-5">
              Ready to Grow?
            </span>
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 leading-tight">
              Guides Are Great.{" "}
              <span className="text-gradient-green">Expert Execution Is Better.</span>
            </h2>
            <p className="text-lg text-white/90 leading-relaxed mb-10 max-w-xl mx-auto">
              The resources on this page give you the knowledge. Gregg gives you the
              implementation — strategy, oversight, and delivery from one of the UK's
              most experienced independent SEO consultants.
            </p>
          </motion.div>

          {/* Benefits list */}
          <motion.ul
            className="flex flex-col sm:flex-row flex-wrap gap-3 justify-center mb-10"
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.15 }}
          >
            {benefits.map((benefit) => (
              <li
                key={benefit}
                className="flex items-center gap-2 text-sm text-white/90 bg-white/10 border border-white/15 rounded-full px-4 py-2"
              >
                <CheckCircle className="h-4 w-4 text-primary shrink-0" />
                {benefit}
              </li>
            ))}
          </motion.ul>

          {/* CTAs */}
          <motion.div
            className="flex flex-wrap gap-4 justify-center"
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.25 }}
          >
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold shadow-green-glow"
              asChild
            >
              <a href="/contact">
                Book a Discovery Call
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10 font-semibold"
              asChild
            >
              <a href="/services">Explore Services</a>
            </Button>
          </motion.div>

          <motion.p
            className="mt-8 text-sm text-white/80"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.35 }}
          >
            No commitment required · Response within one business day
          </motion.p>
        </div>
      </div>
    </section>
  );
});

Page4CTA.displayName = "Page4CTA";

export default Page4CTA;
