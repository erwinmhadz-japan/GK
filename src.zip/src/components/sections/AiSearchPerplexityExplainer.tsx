import React from "react";
import { motion } from "framer-motion";
import { Search, Globe, Brain, Users, Newspaper, BookOpen, Currency, Icon } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const whatCards = [
  {
    icon: Brain,
    title: "An Answer Engine, Not a Directory",
    body: "Unlike Google's ten blue links, Perplexity synthesises information from multiple live web sources and delivers a single, cited answer. It reads, interprets, and summarises your content — then attributes it by name.",
  },
  {
    icon: Globe,
    title: "Real-Time Web Crawling",
    body: "Perplexity actively crawls the web in real time, prioritising fresh, authoritative content. It indexes pages continuously, which means recency is a genuine ranking signal — unlike static LLM training snapshots.",
  },
  {
    icon: Newspaper,
    title: "Source Citations Are the Currency",
    body: "Every Perplexity answer shows numbered source links. When your content is cited, your brand name and URL appear directly in the response UI — giving you visibility that looks and behaves more like editorial endorsement than an ad.",
  },
];

const audiencePoints = [
  { icon: Users, label: "Researchers and academics — fact-checking with sourced confidence" },
  { icon: BookOpen, label: "Business professionals — quick briefings before client calls or decisions" },
  { icon: Search, label: "Tech-savvy users — who have moved away from traditional search engines" },
];

const AiSearchPerplexityExplainer = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="perplexity-explainer"
      className="relative py-20 md:py-32 border-t border-border bg-background"
      aria-label="What is Perplexity AI and who uses it"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className="max-w-3xl mb-14">
          <Badge variant="outline" className="mb-4 text-xs uppercase tracking-widest text-muted-foreground">
            Understanding Perplexity
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            What is Perplexity AI — and Who Uses It?
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Perplexity AI is the fastest-growing answer engine on the web. It pulls live search results, reads the most relevant pages, and returns a structured response that cites every source. For businesses, that citation is brand new real estate.
          </p>
          <p className="text-base text-muted-foreground leading-relaxed mt-4">
            Unlike ChatGPT's knowledge-cutoff model, Perplexity retrieves live web pages for every query. This makes it closer to a traditional search engine in architecture — but with an AI layer that surfaces, summarises, and endorses a small handful of sources per answer.
          </p>
        </div>

        {/* What cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
          {whatCards.map(({ icon: Icon, title, body }, i) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: i * 0.1 }}
              className="rounded-xl border border-border bg-card p-6 shadow-card hover-lift"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-4">
                <Icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="text-lg font-bold text-foreground mb-2">{title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{body}</p>
            </motion.div>
          ))}
        </div>

        {/* Audience block */}
        <div className="rounded-2xl border border-border bg-muted p-8 md:p-10">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold text-foreground mb-3">Who Trusts Perplexity?</h3>
              <p className="text-muted-foreground leading-relaxed mb-6">
                Perplexity's user base skews towards high-intent, high-value audiences — exactly the people most businesses want to reach. These aren't casual browsers; they're people actively seeking authoritative answers before making decisions.
              </p>
              <ul className="space-y-3">
                {audiencePoints.map(({ icon: Icon, label }) => (
                  <li key={label} className="flex items-start gap-3">
                    <div className="mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-primary/10">
                      <Icon className="h-3.5 w-3.5 text-primary" />
                    </div>
                    <span className="text-sm text-foreground">{label}</span>
                  </li>
                ))}
              </ul>
            </div>
            <div className="relative overflow-hidden rounded-xl">
              <img
                src="https://images.unsplash.com/photo-1499751360447-b19be8fe80f5?w=800&h=600&fit=crop"
                alt="Professional researcher using a laptop to find authoritative sources online"
                width="800"
                height="600"
                loading="lazy"
                className="w-full h-56 md:h-64 object-cover rounded-xl"
              />
            </div>
          </div>
        </div>

        {/* Internal links */}
        <p className="mt-8 text-sm text-muted-foreground">
          Explore related guides:{" "}
          <a href="#ai-search-cta" className="text-primary underline underline-offset-2 hover:text-primary/80">AI search overview</a>
          {" · "}
          <a href="/entity-seo" className="text-primary underline underline-offset-2 hover:text-primary/80">Entity SEO</a>
          {" · "}
          <a href="/content-strategy" className="text-primary underline underline-offset-2 hover:text-primary/80">Content strategy</a>
        </p>
      </div>
    </section>
  );
});

AiSearchPerplexityExplainer.displayName = "AiSearchPerplexityExplainer";

export default AiSearchPerplexityExplainer;
