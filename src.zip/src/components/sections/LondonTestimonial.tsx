import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star, ArrowRight, Stars, View } from "lucide-react";

const LondonTestimonial = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="london-testimonial"
      className="relative isolate py-24 md:py-36 border-t border-border"
    >
      {/* Layer 1 — image */}
      <img
        src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=1920&h=1080&fit=crop"
        alt="London business professionals collaborating around laptops"
        className="absolute inset-0 w-full h-full object-cover"
        loading="lazy"
        width="1920"
        height="1080"
      />
      {/* Layer 2 — brand tint overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/80 via-primary/55 to-accent/60 pointer-events-none" />

      {/* Layer 3 — content */}
      <div className="container relative z-10">
        <div className="max-w-2xl mx-auto text-center mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4">
            London Client Success
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">
            Results That Speak for Themselves
          </h2>
          <p className="text-white/90 text-lg leading-relaxed">
            Real outcomes for real London businesses — from boutique firms in Mayfair to
            e-commerce operations in East London.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          {/* Case study / testimonial card */}
          <div className="rounded-2xl bg-white/10 backdrop-blur-sm border border-white/20 p-8 md:p-12 text-center shadow-xl">
            {/* Stars */}
            <div className="flex justify-center gap-1 mb-6">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-5 w-5 text-primary fill-primary" />
              ))}
            </div>

            <blockquote className="text-white/90 text-lg md:text-xl italic leading-relaxed mb-8">
              "Within six months of working with Gregg, our London-based law firm ranked on page one
              for eight highly competitive keywords — including 'employment solicitor London' which
              had eluded us for years. The growth in qualified enquiries has been transformational
              for our practice. Gregg's deep understanding of London's legal search landscape set
              him apart from every other SEO consultant we'd tried."
            </blockquote>

            <div className="flex items-center justify-center gap-4">
              <img
                src="https://images.unsplash.com/photo-1734830268394-6c4a1f165af1?w=400&h=400&fit=crop&crop=face"
                alt="Daniel Hargreaves, Managing Partner at a London law firm"
                width="56"
                height="56"
                className="rounded-full border-2 border-white/40 object-cover w-14 h-14"
                loading="lazy"
              />
              <div className="text-left">
                <p className="font-semibold text-white">Daniel Hargreaves</p>
                <p className="text-white/80 text-sm">Managing Partner, Hargreaves Legal LLP — City of London</p>
              </div>
            </div>

            {/* Case study stats */}
            <div className="grid grid-cols-3 gap-6 mt-10 pt-8 border-t border-white/20">
              <div>
                <p className="text-3xl font-bold text-white">312%</p>
                <p className="text-white/80 text-sm mt-1">Organic traffic increase</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-white">8</p>
                <p className="text-white/80 text-sm mt-1">Page-one rankings achieved</p>
              </div>
              <div>
                <p className="text-3xl font-bold text-white">6 mo</p>
                <p className="text-white/80 text-sm mt-1">Time to results</p>
              </div>
            </div>
          </div>

          <div className="mt-8 text-center">
            <Button
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10"
              asChild
            >
              <a href="#case-studies-cta">
                View More Case Studies
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
          </div>
        </div>

        <div className="mt-12 text-center">
          <Badge className="bg-white/15 text-white border-white/30 backdrop-blur-sm">
            Independent consultant — no agency overhead
          </Badge>
        </div>
      </div>
    </section>
  );
});

LondonTestimonial.displayName = "LondonTestimonial";
export default LondonTestimonial;
