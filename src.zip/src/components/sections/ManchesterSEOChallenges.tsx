import React from "react";
import { Search, Target, Shield, Zap, TrendingUp, Globe } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const challenges = [
  {
    icon: Search,
    title: "Intense Local Competition",
    problem: "Manchester's thriving economy means fierce competition across every sector — from tech startups in Spinningfields to retailers on Market Street.",
    solution: "Hyper-local keyword strategies and competitive gap analysis tailored to Greater Manchester search behaviour and buyer intent.",
  },
  {
    icon: Target,
    title: "Multi-Borough Targeting",
    problem: "Reaching customers across Salford, Trafford, Stockport, Oldham, and beyond requires a nuanced, area-specific SEO approach.",
    solution: "Location-specific landing pages, Google Business Profile optimisation, and local citation building across all Manchester boroughs.",
  },
  {
    icon: Globe,
    title: "Northern Vs National Rankings",
    problem: "Many Manchester businesses struggle to rank locally while also competing with national brands targeting the same keywords.",
    solution: "A dual-track strategy — local pack dominance combined with authority-building content that competes nationally where it matters.",
  },
  {
    icon: Zap,
    title: "Fast-Evolving Digital Market",
    problem: "Manchester's tech and creative sectors move fast. Yesterday's SEO tactics don't keep pace with AI-driven search changes in 2024.",
    solution: "Future-proof SEO integrating traditional signals, E-E-A-T optimisation, and AI search visibility (ChatGPT, Perplexity, Google AI Overviews).",
  },
  {
    icon: Shield,
    title: "Thin Local Authority",
    problem: "New and growing Manchester businesses often lack the local backlinks and citations needed to build trust with Google.",
    solution: "Manchester-focused digital PR, local link acquisition from regional publications, and entity SEO to establish genuine local authority.",
  },
  {
    icon: TrendingUp,
    title: "Measuring Local ROI",
    problem: "Businesses often invest in SEO without clear visibility into which efforts drive footfall, calls, and leads from the Manchester area.",
    solution: "Robust local tracking — call tracking, Google Business Profile insights, and conversion attribution tied to Manchester-specific queries.",
  },
];

const ManchesterSEOChallenges = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Manchester SEO
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
            Manchester SEO Challenges — and How We Solve Them
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Every city has its own digital landscape. Here's what makes SEO in Manchester uniquely challenging — and exactly how we tackle each obstacle.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {challenges.map((item, index) => {
            const Icon = item.icon;
            return (
              <Card key={index} className="hover-lift shadow-card border-border bg-card">
                <CardHeader className="pb-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 mb-4">
                    <Icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-lg text-foreground">{item.title}</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <div>
                    <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-1">The Challenge</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{item.problem}</p>
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-wider text-primary font-semibold mb-1">Our Solution</p>
                    <p className="text-sm text-foreground leading-relaxed">{item.solution}</p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="mt-12 text-center">
          <p className="text-muted-foreground text-sm">
            Looking for Manchester-specific local SEO?{" "}
            <a href="/local-seo" className="text-primary font-medium hover:underline">
              Explore our Local SEO services →
            </a>
          </p>
        </div>
      </div>
    </section>
  );
});

ManchesterSEOChallenges.displayName = "ManchesterSEOChallenges";

export default ManchesterSEOChallenges;
