import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, Bot, Globe, Search, Sparkles, Cpu, Key, Section } from "lucide-react";

const platforms = [
  {
    name: "ChatGPT",
    icon: Bot,
    slug: "chatgpt-visibility",
    description:
      "OpenAI's ChatGPT is the world's most widely used AI assistant, consulted by millions daily for product recommendations, service comparisons, and local business queries. Being cited in ChatGPT responses positions your brand as a trusted authority.",
    keyFact: "Over 100 million weekly active users",
    colour: "bg-emerald-50 border-emerald-200",
    iconColour: "text-emerald-600",
    badgeColour: "border-emerald-300 text-emerald-700 bg-emerald-50",
  },
  {
    name: "Perplexity AI",
    icon: Search,
    slug: "perplexity-visibility",
    description:
      "Perplexity AI is rapidly growing as a research-first search engine that cites sources directly. It surfaces authoritative, well-structured content — making it critical for B2B and high-consideration purchase categories.",
    keyFact: "Growing 100%+ year-on-year in user base",
    colour: "bg-blue-50 border-blue-200",
    iconColour: "text-blue-600",
    badgeColour: "border-blue-300 text-blue-700 bg-blue-50",
  },
  {
    name: "Google AI Overviews",
    icon: Globe,
    slug: "google-ai-overviews",
    description:
      "Google's AI Overviews appear above traditional search results, summarising answers directly on the SERP. Appearing in these AI-generated summaries is essential for maintaining organic visibility in Google.",
    keyFact: "Shown on billions of Google searches",
    colour: "bg-yellow-50 border-yellow-200",
    iconColour: "text-yellow-600",
    badgeColour: "border-yellow-300 text-yellow-700 bg-yellow-50",
  },
  {
    name: "Google Gemini",
    icon: Sparkles,
    slug: "gemini-visibility",
    description:
      "Google Gemini is integrated across the Google ecosystem — including Search, Workspace, and Android — generating AI-powered responses that draw from Google's vast index. Structured data and E-E-A-T signals are key here.",
    keyFact: "Deep integration across Google's 3B+ user ecosystem",
    colour: "bg-purple-50 border-purple-200",
    iconColour: "text-purple-600",
    badgeColour: "border-purple-300 text-purple-700 bg-purple-50",
  },
  {
    name: "Microsoft Copilot",
    icon: Cpu,
    slug: "copilot-visibility",
    description:
      "Microsoft Copilot is embedded in Bing, Edge, Windows and Microsoft 365, making it ubiquitous in enterprise and professional contexts. Bing-optimised content and structured web presence form the backbone of Copilot visibility.",
    keyFact: "Built into Windows, Office 365 and Edge",
    colour: "bg-sky-50 border-sky-200",
    iconColour: "text-sky-600",
    badgeColour: "border-sky-300 text-sky-700 bg-sky-50",
  },
];

const AiSearchPlatformsHub = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        {/* Section header */}
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Platform Coverage
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
            The Major AI Search Platforms
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Each AI platform has distinct ranking signals, retrieval mechanisms, and citation
            patterns. Understanding how each one works is the first step to appearing in their
            responses.
          </p>
        </div>

        {/* Platform cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-10">
          {platforms.map((platform) => {
            const Icon = platform.icon;
            return (
              <Card
                key={platform.slug}
                className={`border ${platform.colour} hover-lift transition-all duration-300 cursor-pointer group`}
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-white shadow-soft">
                      <Icon className={`h-5 w-5 ${platform.iconColour}`} />
                    </div>
                    <Badge
                      variant="outline"
                      className={`text-xs px-2 py-0.5 ${platform.badgeColour}`}
                    >
                      {platform.keyFact}
                    </Badge>
                  </div>
                  <CardTitle className="text-lg font-bold text-foreground mt-3">
                    {platform.name}
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                    {platform.description}
                  </p>
                  <a
                    href={`#`}
                    className={`inline-flex items-center gap-1.5 text-sm font-semibold ${platform.iconColour} hover:gap-2.5 transition-all duration-200`}
                  >
                    Learn more about {platform.name} visibility
                    <ArrowRight className="h-3.5 w-3.5" />
                  </a>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Bottom comparison note */}
        <div className="bg-background rounded-xl border border-border p-6 md:p-8 max-w-3xl mx-auto text-center">
          <h3 className="text-lg font-bold text-foreground mb-2">
            AI Search vs. Traditional SEO: Key Differences
          </h3>
          <p className="text-muted-foreground text-sm leading-relaxed mb-4">
            Traditional SEO focuses on ranking blue links — position 1 through 10. AI Search
            optimisation is about being cited, named, or summarised by the AI model itself. This
            requires entity authority, structured data, semantic depth, and earned mentions across
            the web — not just keyword placement.
          </p>
          <Button variant="outline" asChild>
            <a href="/ai-search-optimisation">
              See the Full AI Search Optimisation Service
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
});

AiSearchPlatformsHub.displayName = "AiSearchPlatformsHub";

export default AiSearchPlatformsHub;
