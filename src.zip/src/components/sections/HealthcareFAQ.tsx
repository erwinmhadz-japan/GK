import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";

const faqs = [
  {
    question: "What is YMYL and how does it affect my clinic's SEO?",
    answer:
      "YMYL stands for 'Your Money or Your Life' — a category Google uses to identify content that could directly impact a person's health, financial wellbeing, or safety. Healthcare content is squarely in this category. Google applies stricter quality assessment to YMYL pages, meaning thin content, unattributed advice, or a lack of practitioner credentials can actively suppress rankings. For clinics, this means every service page and patient-facing article must demonstrate clear authorship by qualified professionals, cite accreditations, and reflect E-E-A-T (Experience, Expertise, Authoritativeness, and Trustworthiness) throughout.",
  },
  {
    question: "Can I use patient reviews in my SEO strategy, and are there compliance issues?",
    answer:
      "Yes — patient reviews are one of the most powerful local SEO and trust signals available to healthcare providers. However, there are compliance considerations: you must not incentivise or manufacture reviews, patient confidentiality must be respected in any public response, and claims made in reviews you promote must not be misleading under ASA and CMA guidelines. We help you build a compliant review acquisition strategy — encouraging authentic reviews on Google, Trustpilot, and Doctify, then marking them up with structured data so they appear in search results as rich snippets.",
  },
  {
    question: "How does local SEO work for a clinic with multiple locations?",
    answer:
      "Multi-location clinics need a carefully structured local SEO architecture. Each location should have its own dedicated landing page with unique content, localised service descriptions, and consistent NAP (Name, Address, Phone) data across all directories. Each location also needs a separate, fully optimised Google Business Profile. We implement LocalBusiness and MedicalClinic schema at the location level, build location-specific citation profiles on healthcare directories (NHS Choices, Yell, Healthily), and ensure your internal linking supports each location's authority independently — preventing cannibalisation between branches.",
  },
  {
    question: "Is SEO HIPAA-compliant, and what does HIPAA mean for a UK clinic's website?",
    answer:
      "HIPAA is a US regulation (Health Insurance Portability and Accountability Act), but UK private clinics are governed by the UK GDPR and the Data Protection Act 2018, which have equivalent requirements for patient data security. In practical SEO terms, this means your contact forms, booking systems, and any patient portal must be served over HTTPS with valid TLS certificates, tracking pixels (GA4, Meta) must be configured to avoid capturing personally identifiable information, and third-party scripts must be audited for data leakage. Our technical SEO audit covers all of these areas as standard.",
  },
  {
    question: "How long does healthcare SEO take to show results?",
    answer:
      "Healthcare SEO is not a quick-win channel — and you should be suspicious of anyone who claims otherwise. YMYL content takes longer to build trust signals with Google than commercial or entertainment content. For most private clinics starting from a low organic baseline, we expect meaningful movement in local rankings within 3–4 months, with measurable growth in patient enquiries from organic search within 6 months. Full authority building for competitive service terms typically takes 9–12 months of consistent work. We track and report on leading indicators (crawl health, local pack positions, click-through rates) monthly so you can see progress throughout.",
  },
  {
    question: "Do I need a specialist healthcare SEO consultant, or can a generalist agency handle this?",
    answer:
      "The consequences of generic SEO advice in healthcare can be serious: inadvertently publishing misleading medical claims, violating ASA guidelines on healthcare advertising, or triggering a Google quality rater penalty that takes months to recover from. A healthcare specialist understands the regulatory landscape, knows which schema types apply to medical entities, and can build content frameworks that satisfy both patients and Google's quality raters simultaneously. Generalist agencies often apply ecommerce or B2B SEO playbooks to healthcare — strategies that actively hurt rather than help in a YMYL context.",
  },
];

const HealthcareFAQ: React.FC = () => {
  const faqJsonLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map(({ question, answer }) => ({
      "@type": "Question",
      name: question,
      acceptedAnswer: {
        "@type": "Answer",
        text: answer,
      },
    })),
  };

  return (
    <section className="relative py-20 md:py-32 border-t border-border bg-muted">
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />

      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Common Questions
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">
            Healthcare SEO{" "}
            <span className="text-gradient-green">Frequently Asked Questions</span>
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Compliance, patient reviews, local visibility, and HIPAA/GDPR — everything clinics
            and private providers ask before starting an SEO engagement.
          </p>
        </div>

        <div className="max-w-3xl mx-auto mb-14">
          <Accordion type="single" collapsible className="w-full space-y-3">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="rounded-xl border border-border bg-card shadow-soft px-6"
              >
                <AccordionTrigger className="text-left font-semibold text-foreground py-5 hover:no-underline">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed pb-5 text-sm">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        {/* Internal links cluster */}
        <div className="text-center">
          <p className="text-sm text-muted-foreground mb-5">
            Learn more about the specific services we use for healthcare clients:
          </p>
          <div className="flex flex-wrap gap-3 justify-center">
            {[
              { label: "Local SEO for Clinics", href: "/local-seo" },
              { label: "Schema Markup", href: "/schema-markup" },
              { label: "Entity SEO", href: "/entity-seo" },
              { label: "All Industries", href: "#industries-cta" },
            ].map(({ label, href }) => (
              <Badge key={href} variant="outline" className="px-4 py-1.5 text-sm cursor-pointer" asChild>
                <a href={href}>{label}</a>
              </Badge>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HealthcareFAQ;
