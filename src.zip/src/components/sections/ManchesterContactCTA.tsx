import React from "react";
import { MapPin, Phone, Mail, Clock, ArrowRight, Book, View } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ImageBackground } from "@/components/ImageBackground";

const contactDetails = [
  {
    icon: MapPin,
    label: "Manchester Address",
    value: "Servicing Greater Manchester & North West",
    sub: "Remote-first — no travel required",
  },
  {
    icon: Phone,
    label: "Phone",
    value: "+44 (0) 7700 900123",
    sub: "Monday – Friday, 9am–6pm",
  },
  {
    icon: Mail,
    label: "Email",
    value: "hello@greggstrickland.co.uk",
    sub: "Response within 24 hours",
  },
  {
    icon: Clock,
    label: "Response Time",
    value: "Same-day reply guaranteed",
    sub: "Free initial consultation included",
  },
];

const ManchesterContactCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      src="https://images.unsplash.com/photo-1730851357916-3802b6405271?w=1920&h=1080&fit=crop"
      alt="Manchester business professional in suit and tie standing in a modern office"
      imgProps={{ loading: "lazy" }}
      className="py-24 md:py-36 border-t border-border"
    >
      <div className="container relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-14 items-start">
          {/* Left: CTA copy */}
          <div>
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4">
              Get Started Today
            </span>
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
              Ready to Grow Your Manchester Business?
            </h2>
            <p className="text-lg text-white/90 mb-8 leading-relaxed">
              Let's talk about your SEO goals. I offer a free, no-obligation consultation for Manchester businesses — I'll review your current rankings, identify your biggest opportunities, and outline a clear path forward.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 mb-10">
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
                asChild
              >
                <a href="/contact">
                  Book Free Consultation <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="bg-transparent text-white border-white hover:bg-white/10"
                asChild
              >
                <a href="/services">View All Services</a>
              </Button>
            </div>

            <div className="flex flex-wrap gap-4">
              {[
                "No long-term contracts",
                "Transparent monthly reporting",
                "Manchester market expertise",
              ].map((item, i) => (
                <span
                  key={i}
                  className="inline-flex items-center gap-1.5 text-white/80 text-sm"
                >
                  <span className="h-1.5 w-1.5 rounded-full bg-primary flex-shrink-0" />
                  {item}
                </span>
              ))}
            </div>
          </div>

          {/* Right: contact details */}
          <div className="space-y-4">
            {contactDetails.map((detail, index) => {
              const Icon = detail.icon;
              return (
                <div
                  key={index}
                  className="bg-white/15 backdrop-blur-sm border border-white/20 rounded-xl p-5 flex items-start gap-4"
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/30 flex-shrink-0">
                    <Icon className="h-5 w-5 text-white" />
                  </div>
                  <div>
                    <p className="text-xs uppercase tracking-wider text-white/80 mb-1 font-medium">
                      {detail.label}
                    </p>
                    <p className="font-semibold text-white">{detail.value}</p>
                    <p className="text-xs text-white/80 mt-0.5">{detail.sub}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Internal links row */}
        <div className="mt-14 pt-8 border-t border-white/20">
          <p className="text-white/80 text-sm mb-4 font-medium">Explore More:</p>
          <div className="flex flex-wrap gap-4">
            {[
              { label: "All Locations", href: "/locations" },
              { label: "Local SEO Services", href: "/local-seo" },
              { label: "Industries We Serve", href: "#industries-cta" },
              { label: "SEO Consulting", href: "#seo-consulting-cta" },
            ].map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="inline-flex items-center gap-1.5 text-white/80 hover:text-white text-sm font-medium transition-colors border border-white/20 rounded-lg px-4 py-2 hover:bg-white/10"
              >
                {link.label} <ArrowRight className="h-3.5 w-3.5" />
              </a>
            ))}
          </div>
        </div>
      </div>
    </ImageBackground>
  );
});

ManchesterContactCTA.displayName = "ManchesterContactCTA";

export default ManchesterContactCTA;
