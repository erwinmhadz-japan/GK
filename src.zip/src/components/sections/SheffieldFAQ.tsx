import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "Do I need a Sheffield-based SEO consultant, or can I work with anyone?",
    answer:
      "Local knowledge genuinely matters for local SEO. Understanding Sheffield's neighbourhoods, business clusters, search intent patterns, and competitor landscape means faster, more targeted results. That said, I work remotely with Sheffield businesses across the UK — so you get local market expertise without needing to be in the same room.",
  },
  {
    question: "How competitive is the SEO landscape in Sheffield?",
    answer:
      "Sheffield is competitive in sectors like legal, dental, construction, and hospitality — but far less saturated than London. For most niches, consistent technical SEO, strong local signals, and quality content can push a Sheffield business onto page 1 within three to six months. The opportunity is significant for businesses that act now before the market matures further.",
  },
  {
    question: "What local SEO work do you do for Sheffield businesses?",
    answer:
      "Local SEO for Sheffield covers Google Business Profile setup and optimisation, local citation building across key directories, Sheffield-specific landing pages, review strategy, neighbourhood-targeted content, and local link acquisition from South Yorkshire publications and organisations.",
  },
  {
    question: "Can you help my Sheffield business rank across South Yorkshire?",
    answer:
      "Yes. Many Sheffield businesses need regional reach — covering Rotherham, Doncaster, Barnsley, and Chesterfield alongside the city itself. I build multi-location SEO strategies that allow a single Sheffield-headquartered business to rank prominently across the whole South Yorkshire region.",
  },
  {
    question: "How much does SEO for a Sheffield business cost?",
    answer:
      "Pricing depends on the scope and competitiveness of your sector. Project-based work (audits, strategy) starts from £750. Monthly SEO retainers for Sheffield businesses typically range from £500 to £2,500 per month. I offer transparent, fixed-price proposals with no hidden costs — get in touch for a quote tailored to your Sheffield business.",
  },
];

const SheffieldFAQ = React.forwardRef<HTMLElement>((props, ref) => {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: faq.answer,
      },
    })),
  };

  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      {/* FAQ JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />

      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-3">
            Frequently Asked Questions
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground">
            Sheffield SEO Questions Answered
          </h2>
          <p className="mt-4 text-muted-foreground text-lg leading-relaxed">
            Everything you need to know about working with a Sheffield SEO consultant.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="border border-border bg-background rounded-xl mb-3 px-6"
              >
                <AccordionTrigger className="text-left font-semibold text-foreground py-5 hover:no-underline">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed pb-5">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        <div className="text-center mt-10">
          <p className="text-muted-foreground mb-4">
            Have a question not listed here?
          </p>
          <a
            href="/contact"
            className="text-primary font-semibold hover:underline"
          >
            Ask me directly →
          </a>
        </div>
      </div>
    </section>
  );
});

SheffieldFAQ.displayName = "SheffieldFAQ";
export default SheffieldFAQ;
