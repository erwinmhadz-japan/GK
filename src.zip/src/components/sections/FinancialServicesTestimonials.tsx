import React from "react";
import { Quote, Star, Cross, Stars } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const testimonials = [
  {
    quote:
      "Gregg's entity SEO approach transformed how Google understood our wealth management brand. Within eight months we moved from page three to position one for our core advisory terms — and the quality of inbound enquiries improved dramatically. Compliance signed off every piece of content first time.",
    author: "Sarah Thornton",
    role: "Head of Marketing",
    company: "Thornton Private Wealth",
    image: "https://images.unsplash.com/photo-1681500920181-0aff411f8cab?w=400&h=400&fit=crop&crop=face",
    result: "+312% organic enquiries",
  },
  {
    quote:
      "We'd struggled for years to rank for competitive financial planning keywords. The structured E-E-A-T content strategy and schema implementation made an immediate difference. Our financial advisers are now cited as authoritative sources in Google's AI Overviews — something our competitors simply aren't achieving.",
    author: "Marcus Webb",
    role: "Digital Director",
    company: "Meridian Financial Planning",
    image: "https://images.unsplash.com/photo-1633625576932-348e73c45e82?w=400&h=400&fit=crop&crop=face",
    result: "Page 1 for 47 target terms",
  },
  {
    quote:
      "As a fintech challenger, we needed to build credibility fast in a space dominated by incumbents. The compliant content programme and digital PR strategy delivered authoritative backlinks from publications our target clients actually read. Organic has overtaken paid as our top lead generation channel.",
    author: "Priya Sharma",
    role: "CMO",
    company: "ClearVault Fintech",
    image: "https://images.unsplash.com/photo-1645107914072-6f16b732f224?w=400&h=400&fit=crop&crop=face",
    result: "Organic now #1 lead source",
  },
];

const FinancialServicesTestimonials = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="financial-testimonials"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="max-w-2xl mx-auto text-center mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            Client Results
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Financial Services Firms That Trust Us
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Wealth managers, financial planners and fintech firms have used our specialist approach
            to build lasting organic authority and generate more qualified client enquiries.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-14">
          {testimonials.map((testimonial, index) => (
            <Card
              key={index}
              className="bg-card border-border shadow-card hover-lift transition-all duration-300 flex flex-col h-full"
            >
              <CardContent className="p-6 flex flex-col h-full">
                {/* Stars */}
                <div className="flex gap-1 mb-4">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="h-4 w-4 text-primary fill-primary"
                    />
                  ))}
                </div>

                {/* Quote */}
                <div className="relative mb-6 flex-1">
                  <Quote className="h-6 w-6 text-primary/30 absolute -top-1 -left-1" />
                  <p className="text-muted-foreground leading-relaxed text-sm pl-4 italic">
                    {testimonial.quote}
                  </p>
                </div>

                {/* Result badge */}
                <Badge className="self-start mb-4 bg-primary/10 text-primary border-primary/20 font-semibold text-xs">
                  {testimonial.result}
                </Badge>

                {/* Author */}
                <div className="flex items-center gap-3 pt-4 border-t border-border">
                  <img
                    src={testimonial.image}
                    alt={`${testimonial.author}, ${testimonial.role} at ${testimonial.company}`}
                    width="400"
                    height="400"
                    loading="lazy"
                    className="h-10 w-10 rounded-full object-cover shrink-0"
                  />
                  <div>
                    <p className="text-foreground font-semibold text-sm">{testimonial.author}</p>
                    <p className="text-muted-foreground text-xs">
                      {testimonial.role} — {testimonial.company}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Case study pull-quote */}
        <div className="max-w-3xl mx-auto bg-card border border-border rounded-2xl p-8 md:p-10 shadow-card text-center">
          <p className="text-foreground text-lg md:text-xl font-medium leading-relaxed mb-6">
            "The combination of entity SEO, compliant content creation and schema markup gave us a
            competitive advantage that pure PPC spend never could. Our organic leads convert at 2.4×
            the rate of paid — at a fraction of the cost per acquisition."
          </p>
          <div className="flex items-center justify-center gap-4">
            <img
              src="https://images.unsplash.com/photo-1710777915903-a7d7f159f2c0?w=400&h=400&fit=crop&crop=face"
              alt="Natalie Cross, Growth Director at Alverton Capital"
              width="400"
              height="400"
              loading="lazy"
              className="h-12 w-12 rounded-full object-cover"
            />
            <div className="text-left">
              <p className="text-foreground font-bold text-sm">Natalie Cross</p>
              <p className="text-muted-foreground text-xs">Growth Director — Alverton Capital</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

FinancialServicesTestimonials.displayName = "FinancialServicesTestimonials";

export default FinancialServicesTestimonials;
