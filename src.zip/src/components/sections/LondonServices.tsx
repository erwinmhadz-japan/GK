import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, ArrowRight, View } from "lucide-react";

const services = [
  {
    title: "London Local SEO",
    description:
      "Dominate 'near me' searches and borough-specific queries with Google Business Profile optimisation, local citation building, and hyper-targeted content that resonates with London audiences.",
    features: [
      "Google Business Profile management",
      "London borough citation building",
      "Local schema markup & structured data",
      "Competitor gap analysis across London",
    ],
    link: "/local-seo",
    linkLabel: "Local SEO Services",
  },
  {
    title: "Technical SEO for London Businesses",
    description:
      "Fast, crawlable, and indexable websites are the foundation of London SEO success. We audit and fix the technical issues holding your site back from the rankings it deserves.",
    features: [
      "Core Web Vitals optimisation",
      "Crawl budget management",
      "Structured data & schema implementation",
      "International & multi-location hreflang setup",
    ],
    link: "/technical-seo",
    linkLabel: "Technical SEO Services",
  },
  {
    title: "SEO Consulting & Strategy",
    description:
      "For London businesses that need expert strategic direction without a full-service retainer. Get a bespoke roadmap, priority-ranked recommendations, and direct access to a senior SEO consultant.",
    features: [
      "Comprehensive London market analysis",
      "Keyword strategy for London verticals",
      "Content gap & opportunity mapping",
      "Monthly progress reviews & reporting",
    ],
    link: "#seo-consulting-cta",
    linkLabel: "SEO Consulting",
  },
];

const LondonServices = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="london-services"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        <div className="max-w-2xl mx-auto text-center mb-14">
          <Badge variant="outline" className="mb-4 text-primary border-primary/30">
            London-Specific Services
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            SEO Services Tailored for London Businesses
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Every service is adapted to London's unique competitive dynamics — from local borough
            targeting to enterprise-level technical SEO for the capital's largest brands.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {services.map((service, idx) => (
            <div
              key={service.title}
              className="relative flex flex-col rounded-xl border border-border bg-card p-8 shadow-card hover-lift"
            >
              <span className="text-4xl font-bold text-primary/20 mb-4 leading-none select-none">
                {String(idx + 1).padStart(2, "0")}
              </span>
              <h3 className="text-xl font-bold text-foreground mb-3">{service.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed mb-6">
                {service.description}
              </p>
              <ul className="space-y-2 mb-8 flex-1">
                {service.features.map((feature) => (
                  <li key={feature} className="flex items-start gap-2 text-sm text-foreground">
                    <CheckCircle className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
              <Button variant="outline" className="mt-auto w-full group" asChild>
                <a href={service.link}>
                  {service.linkLabel}
                  <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                </a>
              </Button>
            </div>
          ))}
        </div>

        <div className="mt-10 text-center">
          <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90" asChild>
            <a href="/services">View All SEO Services</a>
          </Button>
        </div>
      </div>
    </section>
  );
});

LondonServices.displayName = "LondonServices";
export default LondonServices;
