import React from "react";
import { Link } from "react-router-dom";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Shield, TrendingUp, Award, ChevronRight, Search } from "lucide-react";

const FinancialServicesHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="financial-services-hero"
      aria-label="Financial Services SEO Hero"
      src="https://images.unsplash.com/photo-1685492259744-f42597aac776?w=1920&h=1080&fit=crop"
      alt="Modern financial district buildings against the sky"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[88vh] md:min-h-screen flex items-center"
    >
      <div className="container relative z-10 py-24 md:py-36">
        <div className="max-w-3xl">
          <Badge className="mb-6 bg-primary/20 text-white border-primary/40 text-xs uppercase tracking-widest font-semibold">
            Financial Services SEO
          </Badge>

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
            Build Trust &amp; Authority in Competitive Financial Markets Through Strategic SEO
          </h1>

          <p className="text-lg md:text-xl text-white/90 mb-8 leading-relaxed max-w-2xl">
            Financial services firms face the highest scrutiny online. Google's YMYL standards and
            E-E-A-T requirements demand more than keywords — they demand demonstrable expertise,
            authoritative backlinks, and a content strategy built for compliance. We help banks,
            wealth managers, and fintech firms earn the organic visibility that converts high-value clients.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 mb-12">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold px-8"
              asChild
            >
              <a href="/contact">Get a Financial SEO Strategy</a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10 font-semibold px-8"
              asChild
            >
              <a href="/ai-search-optimisation">Explore AI Search Optimisation</a>
            </Button>
          </div>

          <div className="flex flex-col sm:flex-row gap-6">
            <div className="flex items-center gap-2">
              <Shield className="h-5 w-5 text-primary" />
              <span className="text-white/80 text-sm">YMYL &amp; E-E-A-T Compliant</span>
            </div>
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              <span className="text-white/80 text-sm">High-Value Lead Acquisition</span>
            </div>
            <div className="flex items-center gap-2">
              <Award className="h-5 w-5 text-primary" />
              <span className="text-white/80 text-sm">Regulatory-Ready Content</span>
            </div>
          </div>
        </div>
      </div>
    </ImageBackground>
  );
});

FinancialServicesHero.displayName = "FinancialServicesHero";

export default FinancialServicesHero;
