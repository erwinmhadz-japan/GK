import React from "react";
import { Star, CheckCircle, View } from "lucide-react";

const results = [
  "Ranked #1 in Warrington for core service terms within 6 months",
  "47% increase in organic sessions from local search",
  "Google Business Profile impressions up 180% year-on-year",
  "12 new B2B enquiries per month attributed to SEO",
];

const WarringtonTestimonial = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative isolate py-24 md:py-36 border-t border-border"
    >
      {/* bg_treatment: image_brand_tint */}
      <img
        src="https://images.unsplash.com/photo-1484863137850-59afcfe05386?w=1920&h=1080&fit=crop"
        alt="Professional working at a laptop in a business setting"
        className="absolute inset-0 w-full h-full object-cover"
        loading="lazy"
        width="1920"
        height="1080"
        aria-hidden="true"
      />
      <div className="absolute inset-0 bg-gradient-to-br from-primary/80 via-primary/55 to-accent/60 pointer-events-none" />

      <div className="container relative z-10">
        <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-6 font-medium">
          Warrington Client Case Study
        </span>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Testimonial quote */}
          <div>
            <div className="flex gap-1 mb-5">
              {[...Array(5)].map((_, i) => (
                <Star
                  key={i}
                  className="h-5 w-5 fill-white text-white"
                  aria-hidden="true"
                />
              ))}
            </div>

            <blockquote className="text-xl md:text-2xl font-semibold text-white leading-relaxed mb-6">
              "Before working with Gregg, we were buried on page three for every
              Warrington search term that mattered. Within six months we were
              ranking first for our primary services, and we've held those
              positions ever since. The ROI has been transformational for our
              business."
            </blockquote>

            <div className="flex items-center gap-4">
              <img
                src="https://images.unsplash.com/photo-1542909168-82c3e7fdca5c?w=400&h=400&fit=crop&crop=face"
                alt="Portrait of James T., director of a Warrington logistics firm"
                width="56"
                height="56"
                className="rounded-full border-2 border-white/40 object-cover h-14 w-14"
                loading="lazy"
              />
              <div>
                <p className="font-semibold text-white">James T.</p>
                <p className="text-white/80 text-sm">
                  Director, Warrington Logistics & Distribution Firm
                </p>
              </div>
            </div>
          </div>

          {/* Results panel */}
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-8">
            <p className="text-sm uppercase tracking-[0.2em] text-white/80 font-medium mb-6">
              Measurable Results
            </p>
            <ul className="space-y-4">
              {results.map((result) => (
                <li key={result} className="flex items-start gap-3">
                  <CheckCircle
                    className="h-5 w-5 text-white shrink-0 mt-0.5"
                    aria-hidden="true"
                  />
                  <span className="text-white/90 text-sm leading-relaxed">
                    {result}
                  </span>
                </li>
              ))}
            </ul>

            <div className="mt-8 pt-6 border-t border-white/20">
              <p className="text-xs text-white/80 mb-4">
                See more results from Warrington and across the North West:
              </p>
              <a
                href="#case-studies-cta"
                className="inline-flex items-center text-sm font-semibold text-white hover:text-white/80 transition-colors"
              >
                View All Case Studies →
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

WarringtonTestimonial.displayName = "WarringtonTestimonial";

export default WarringtonTestimonial;
