import React from "react";
import { Button } from "@/components/ui/button";
import { Quote, Star, ArrowRight, Group, Map as MapIcon, Search, Section, View } from "lucide-react";

const testimonials = [
  {
    quote:
      "Within eight months of working with Gregg, our family law practice had moved from page four to the top three results for every key term in our area. Enquiry volume has doubled and the quality of leads is considerably higher than anything paid ads delivered.",
    author: "Sarah Whitmore",
    role: "Senior Partner",
    firm: "Whitmore Family Law Solicitors",
    practice: "Family Law",
    image:
      "https://images.unsplash.com/photo-1681500920181-0aff411f8cab?w=400&h=400&fit=crop&crop=face",
    result: "2× enquiry volume in 8 months",
  },
  {
    quote:
      "The entity SEO work completely transformed how Google understood our firm. We now appear in the Knowledge Panel for multiple practice area searches, and our Google Business Profile consistently sits in the Map Pack for commercial property queries across three counties.",
    author: "James Carrington",
    role: "Managing Partner",
    firm: "Carrington & Associates",
    practice: "Commercial Property",
    image:
      "https://images.unsplash.com/photo-1605857840732-188f2f08cb31?w=400&h=400&fit=crop&crop=face",
    result: "Map Pack top 3 across 3 counties",
  },
  {
    quote:
      "Gregg's understanding of legal sector compliance and E-E-A-T was immediately apparent. The schema markup implementation alone generated rich results across 14 practice area pages — something our previous agency hadn't even attempted in two years.",
    author: "Priya Mehta",
    role: "Head of Marketing",
    firm: "Meridian Legal Group",
    practice: "Multi-Practice",
    image:
      "https://images.unsplash.com/photo-1710778044102-56a3a6b69a1b?w=400&h=400&fit=crop&crop=face",
    result: "Rich results on 14 practice pages",
  },
];

function StarRating() {
  return (
    <div className="flex gap-0.5 mb-4">
      {[1, 2, 3, 4, 5].map((s) => (
        <Star key={s} className="h-4 w-4 text-primary fill-primary" />
      ))}
    </div>
  );
}

const LawFirmsTestimonials = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-2xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Client Results
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Law Firms That Are Winning on Search
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            From family law to commercial property — specialist SEO consistently
            delivers measurable client growth for legal practices across the UK.
          </p>
        </div>

        {/* Testimonials */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-14">
          {testimonials.map((t) => (
            <div
              key={t.author}
              className="bg-card rounded-xl border border-border shadow-card p-8 hover-lift transition-all duration-300 flex flex-col"
            >
              {/* Quote icon */}
              <Quote className="h-8 w-8 text-primary/30 mb-4 shrink-0" />
              <StarRating />

              {/* Result badge */}
              <div className="inline-flex mb-4">
                <span className="text-xs font-semibold uppercase tracking-widest text-primary bg-primary/10 rounded-full px-3 py-1">
                  {t.result}
                </span>
              </div>

              {/* Quote text */}
              <blockquote className="text-foreground text-sm leading-relaxed flex-grow mb-6">
                "{t.quote}"
              </blockquote>

              {/* Attribution */}
              <div className="flex items-center gap-4 pt-4 border-t border-border">
                <img
                  src={t.image}
                  alt={`${t.author} from ${t.firm}`}
                  width="48"
                  height="48"
                  className="h-12 w-12 rounded-full object-cover shrink-0"
                />
                <div>
                  <p className="font-semibold text-foreground text-sm">
                    {t.author}
                  </p>
                  <p className="text-xs text-muted-foreground">{t.role}</p>
                  <p className="text-xs text-muted-foreground">{t.firm}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Case studies link */}
        <div className="flex flex-col sm:flex-row items-center gap-4 justify-center bg-muted rounded-xl p-8">
          <div className="text-center sm:text-left">
            <p className="font-semibold text-foreground mb-1">
              Want to see the full case studies?
            </p>
            <p className="text-muted-foreground text-sm">
              Detailed breakdowns of strategy, tactics, and measurable results
              for legal sector clients.
            </p>
          </div>
          <Button size="lg" variant="outline" className="shrink-0" asChild>
            <a href="#case-studies-cta">
              View Case Studies
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
});

LawFirmsTestimonials.displayName = "LawFirmsTestimonials";

export default LawFirmsTestimonials;
