import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight, Calendar, CheckCircle, Clock, Contact, Icon } from "lucide-react";
import { Link } from "react-router-dom";

const reassurances = [
  { icon: CheckCircle, text: "No long-term contracts required" },
  { icon: Calendar, text: "Flexible arrangements to suit your business" },
  { icon: Clock, text: "Direct access to me — no account managers" },
];

const SeoRetainerCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seo-retainer-cta"
      className="relative py-20 md:py-32 border-t border-border bg-background"
      style={{
        background:
          "linear-gradient(160deg, hsl(225 28% 14%) 0%, hsl(231 9% 16%) 60%, hsl(225 28% 18%) 100%)",
      }}
    >
      {/* Subtle dot-grid texture overlay */}
      <div
        className="absolute inset-0 pointer-events-none opacity-20"
        aria-hidden="true"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(214 32% 60% / 0.3) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          {/* Eyebrow label */}
          <motion.span
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut" }}
            className="inline-block text-xs uppercase tracking-[0.2em] font-medium mb-5"
            style={{ color: "hsl(84 74% 60%)" }}
          >
            SEO Retainer — Gregg King
          </motion.span>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.08 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-5"
            style={{ fontFamily: "'Sora', sans-serif" }}
          >
            Discuss a Retained SEO Arrangement
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.16 }}
            className="text-lg md:text-xl leading-relaxed mb-10 max-w-2xl mx-auto"
            style={{ color: "hsl(214 32% 75%)" }}
          >
            No long-term contracts forced on you. Start with a conversation
            about what sustained SEO consultancy could achieve for your business.
          </motion.p>

          {/* Reassurance chips */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.24 }}
            className="flex flex-wrap justify-center gap-4 mb-10"
          >
            {reassurances.map(({ icon: Icon, text }) => (
              <div
                key={text}
                className="flex items-center gap-2 text-sm"
                style={{ color: "hsl(214 32% 75%)" }}
              >
                <Icon
                  className="h-4 w-4 shrink-0"
                  style={{ color: "hsl(119 35% 61%)" }}
                />
                <span>{text}</span>
              </div>
            ))}
          </motion.div>

          {/* CTA Button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.32 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Button
              size="lg"
              asChild
              className="h-12 px-8 text-base font-semibold rounded-md group"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                color: "hsl(225 28% 10%)",
                border: "none",
                boxShadow: "0 0 0 0 hsl(84 74% 58% / 0)",
                transition:
                  "box-shadow 0.3s ease, transform 0.2s ease",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.boxShadow =
                  "0 0 32px hsl(84 74% 58% / 0.4)";
                (e.currentTarget as HTMLElement).style.transform = "translateY(-1px)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.boxShadow =
                  "0 0 0 0 hsl(84 74% 58% / 0)";
                (e.currentTarget as HTMLElement).style.transform = "translateY(0)";
              }}
            >
              <Link to="/contact" className="flex items-center gap-2">
                Contact Me
                <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
              </Link>
            </Button>
          </motion.div>

          {/* Subtle trust note */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease: "easeOut", delay: 0.44 }}
            className="mt-6 text-sm"
            style={{ color: "hsl(214 32% 55%)" }}
          >
            Independent SEO consultant based in Warrington, Cheshire
          </motion.p>
        </div>
      </div>
    </section>
  );
});

SeoRetainerCTA.displayName = "SeoRetainerCTA";

export default SeoRetainerCTA;
