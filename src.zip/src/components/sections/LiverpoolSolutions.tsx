import React from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Search, MapPin, Target, BarChart, CheckCircle, ArrowRight, Zap, Section, View } from "lucide-react";

const solutions = [
  {
    icon: MapPin,
    badge: "Foundation",
    title: "Google Business Profile Optimisation",
    description:
      "Your Google Business Profile is the single most important local ranking factor. I audit, optimise, and actively manage your GBP to ensure maximum visibility in Liverpool's local pack — including proper category selection, service area configuration, and review velocity strategy.",
    link: "/local-seo",
  },
  {
    icon: Search,
    badge: "Content",
    title: "Liverpool-Specific Keyword Strategy",
    description:
      "I identify exactly what Liverpool consumers search for — 'SEO agency Liverpool', 'accountant in Allerton', 'solicitor Kensington Liverpool' — and build a content architecture that captures those searches with locally-relevant authority pages.",
    link: "/content-strategy",
  },
  {
    icon: Target,
    badge: "Authority",
    title: "Local Citation & NAP Consistency",
    description:
      "Inconsistent business listings across directories, local chambers (Liverpool Chamber of Commerce), and data aggregators destroy local rankings. I perform a full NAP audit and build consistent citations across Liverpool's key local directories.",
    link: "/local-seo",
  },
  {
    icon: BarChart,
    badge: "Visibility",
    title: "Competitor Gap Analysis",
    description:
      "I map every competing business ranking above you in Liverpool SERPs, identify their backlink sources, content gaps, and technical advantages — then build a prioritised plan to outrank them within realistic timescales.",
    link: "#case-studies-cta",
  },
  {
    icon: Zap,
    badge: "Technical",
    title: "Technical SEO for Liverpool Sites",
    description:
      "Core Web Vitals, mobile performance, structured data (LocalBusiness, Review, FAQPage schemas), and crawl health — all audited and resolved so Google can trust and rank your Liverpool business pages confidently.",
    link: "/services",
  },
];

const outcomes = [
  "First-page rankings for Liverpool 'near me' searches",
  "More qualified leads from local organic search",
  "Higher Google Maps pack visibility across Merseyside",
  "Stronger online reputation through review strategy",
  "Measurable ROI tracked against local search KPIs",
];

const LiverpoolSolutions = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="liverpool-solutions"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-3xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Local SEO Solutions
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-5">
            How I Help Liverpool Businesses Rank &amp; Win Local Search
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Every Liverpool business has a different competitive position.
            Whether you're a sole trader in Aigburth, a law firm in the city
            centre, or an e-commerce brand based in Speke — I build a local SEO
            strategy shaped around your specific market and growth objectives.
          </p>
        </div>

        {/* Solutions list */}
        <div className="space-y-6 mb-14">
          {solutions.map((solution) => {
            const Icon = solution.icon;
            return (
              <div
                key={solution.title}
                className="flex flex-col md:flex-row gap-6 bg-card rounded-xl border border-border p-6 md:p-8 shadow-soft hover-lift"
              >
                <div className="flex-shrink-0">
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10">
                    <Icon className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <div className="flex-1">
                  <div className="flex flex-wrap items-center gap-3 mb-2">
                    <Badge
                      variant="secondary"
                      className="text-xs uppercase tracking-wider"
                    >
                      {solution.badge}
                    </Badge>
                    <h3 className="text-lg font-semibold text-foreground">
                      {solution.title}
                    </h3>
                  </div>
                  <p className="text-muted-foreground leading-relaxed mb-3">
                    {solution.description}
                  </p>
                  <a
                    href={solution.link}
                    className="inline-flex items-center gap-1 text-primary text-sm font-medium hover:underline"
                  >
                    Learn more <ArrowRight className="h-3 w-3" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* Outcomes strip */}
        <div className="bg-card border border-border rounded-xl p-8 md:p-10">
          <h3 className="text-xl font-bold text-foreground mb-6">
            What Liverpool Clients Achieve
          </h3>
          <ul className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
            {outcomes.map((outcome) => (
              <li key={outcome} className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                <span className="text-foreground text-sm leading-snug">
                  {outcome}
                </span>
              </li>
            ))}
          </ul>
          <div className="mt-8 flex flex-wrap gap-4">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90"
              asChild
            >
              <a href="/local-seo">
                Explore Local SEO Services
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button size="lg" variant="outline" asChild>
              <a href="#case-studies-cta">View Case Studies</a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
});

LiverpoolSolutions.displayName = "LiverpoolSolutions";

export default LiverpoolSolutions;
