import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { ArrowRight, Building, Sidebar } from "lucide-react";

const faqs = [
  {
    question: "How long does it take to see SEO results for an estate agent website?",
    answer:
      "Most estate agent clients start to see meaningful movement in local pack rankings and organic traffic within 3–5 months of a structured campaign beginning. Technical fixes and Google Business Profile optimisation often deliver quicker wins — improved local pack visibility can appear within 6–8 weeks. Sustained growth in organic traffic and vendor enquiries typically compounds over a 6–12 month period as domain authority, content depth, and schema signals accumulate.",
  },
  {
    question: "What is local SEO for estate agents and why does it matter?",
    answer:
      "Local SEO for estate agents is the practice of optimising your agency's online presence to appear prominently when vendors, landlords, and buyers search for property services in your specific area. This includes ranking in the Google local pack (the map results), optimising your Google Business Profile, building consistent citations across property directories, and creating geo-targeted content. It matters because over 70% of property searches include a local intent — people want an agent in their area, not a national brand. Ranking prominently in local results directly drives instruction enquiries and appraisal bookings.",
  },
  {
    question: "How does schema markup help property listing visibility?",
    answer:
      "Schema markup (structured data) is code added to your website pages that tells Google exactly what type of content is on each page. For estate agents, RealEstateAgent and LocalBusiness schema helps Google surface your agency in rich results — showing your star rating, address, phone number, and opening hours directly in search results. For individual property listings, schema can signal property type, price, location, and availability, making it easier for Google to index and rank your listings accurately. Properly implemented schema is one of the fastest ways to achieve visual standout in a competitive property SERP.",
  },
  {
    question: "Can SEO help my agency compete against Rightmove and Zoopla?",
    answer:
      "You can't outrank Rightmove for generic 'houses for sale' queries — they have enormous domain authority built over decades. However, you absolutely can outrank them for hyper-local and branded searches that matter most to your business: '[your agency name]', 'estate agents in [your town]', 'houses for sale in [specific neighbourhood]', and 'property valuation [postcode]'. These searches have higher commercial intent and typically convert to instructions and viewings far better than generic portal traffic. A well-executed local SEO strategy wins the searches the portals can't dominate.",
  },
  {
    question: "What is entity SEO and why is it important for my agency's brand?",
    answer:
      "Entity SEO is about helping Google understand and trust your agency as a distinct, authoritative entity — not just a collection of web pages. Google's Knowledge Graph connects entities (businesses, people, places) and uses these connections to determine which sources to trust and recommend. For estate agents, strong entity signals mean Google is more likely to feature your agency in AI-generated answers, local packs, and 'near me' searches. Building entity authority involves consistent NAP data, knowledge panel establishment, Wikipedia or Wikidata entries where applicable, and earning co-citations from authoritative local sources. It's the difference between being mentioned in an AI summary versus being invisible in one.",
  },
  {
    question: "Do you work with multi-branch estate agency groups?",
    answer:
      "Yes. Multi-branch agencies present unique SEO challenges — primarily around ranking each branch separately without causing keyword cannibalisation between your own offices. We structure multi-location SEO campaigns with dedicated location pages for each branch, individual Google Business Profiles optimised per branch, branch-specific schema markup, and a content strategy that builds local authority for each patch. This architecture ensures your Winchester branch ranks for Winchester searches without competing against your Southampton office — both benefit from the overall brand authority while each ranks individually.",
  },
  {
    question: "How do I optimise my property listings to rank in organic search?",
    answer:
      "Most estate agent property listing pages are thin — they contain syndicated portal descriptions, a price, and a postcode. To rank organically, listings need unique descriptive content, proper use of heading tags, internal linking to relevant neighbourhood pages, image alt text, and structured data (schema). At a portfolio level, category pages ('3-bedroom houses for sale in [area]') with unique introductory copy, FAQ sections, and local market context perform significantly better than portals, which rarely have this level of specificity. We audit your existing listings architecture and build a template structure that maximises organic ranking potential across your entire property portfolio.",
  },
];

const IndustriesPropertyFAQ = React.forwardRef<HTMLElement>((props, ref) => {
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: faq.answer,
      },
    })),
  };

  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      {/* FAQ JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />

      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 lg:gap-16">
          {/* Sidebar */}
          <div className="lg:col-span-1">
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
              FAQ
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-5">
              Property SEO — Common Questions
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Answers to the questions estate agents and property service providers
              ask most often about SEO, local visibility, and listing optimisation.
            </p>
            <Button asChild>
              <a href="/contact">
                Ask us anything
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
          </div>

          {/* FAQ Accordion */}
          <div className="lg:col-span-2">
            <Accordion type="single" collapsible className="w-full space-y-1">
              {faqs.map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`faq-${index}`}
                  className="border border-border rounded-lg bg-card px-6 data-[state=open]:shadow-card"
                >
                  <AccordionTrigger className="text-left font-medium text-foreground hover:text-primary transition-colors py-5">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed pb-5">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </div>
    </section>
  );
});

IndustriesPropertyFAQ.displayName = "IndustriesPropertyFAQ";
export default IndustriesPropertyFAQ;
