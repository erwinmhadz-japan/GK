import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Search, MapPin, Zap, Target, Globe, Shield, ArrowRight, View } from "lucide-react";

const services = [
  {
    icon: Search,
    title: "Birmingham SEO Consulting",
    description:
      "Strategic, independent SEO advice tailored to Birmingham's competitive landscape. No generic playbooks — everything is shaped around your market, competitors, and growth objectives.",
    href: "#seo-consulting-cta",
  },
  {
    icon: MapPin,
    title: "Local SEO for Birmingham",
    description:
      "Dominate 'near me' and neighbourhood searches across Birmingham's key districts — Edgbaston, Harborne, Sutton Coldfield, Erdington, and beyond. Google Business Profile optimisation included.",
    href: "/local-seo",
  },
  {
    icon: Shield,
    title: "Technical SEO",
    description:
      "Core Web Vitals, crawlability, structured data, and site architecture — all the under-the-hood factors that determine whether Google ranks your Birmingham site or ignores it.",
    href: "/technical-seo",
  },
  {
    icon: Target,
    title: "SEO Audit",
    description:
      "A comprehensive audit of your Birmingham business's organic search performance. Identify exactly what's holding you back and what to fix first for the fastest gains.",
    href: "/seo-audit",
  },
  {
    icon: Globe,
    title: "AI Search Optimisation",
    description:
      "Ensure your Birmingham business appears in ChatGPT, Google AI Overviews, and Perplexity responses — the new frontier of local business discovery.",
    href: "/ai-search-optimisation",
  },
  {
    icon: Zap,
    title: "Content Strategy",
    description:
      "Topical authority and content that positions your Birmingham brand as the go-to expert in your sector — driving qualified traffic and conversions, not vanity metrics.",
    href: "/content-strategy",
  },
];

const BirminghamServices: React.FC = () => {
  return (
    <section className="relative py-20 md:py-32 border-t border-border bg-muted">
      <div className="container">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <Badge variant="secondary" className="mb-4 text-xs uppercase tracking-widest">
            Services for Birmingham
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            SEO Services Tailored for Birmingham Businesses
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Whether you're a local independent or a multi-site enterprise headquartered
            in Birmingham, I provide expert SEO that drives measurable results in the
            West Midlands market.
          </p>
        </div>

        {/* Services grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {services.map((service) => (
            <a
              key={service.title}
              href={service.href}
              className="group bg-card border border-border rounded-xl p-7 shadow-soft hover:shadow-card-hover transition-all hover-lift"
            >
              <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-primary/10 mb-5 group-hover:bg-primary/20 transition-colors">
                <service.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-base font-semibold text-foreground mb-2 group-hover:text-primary transition-colors">
                {service.title}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {service.description}
              </p>
            </a>
          ))}
        </div>

        <div className="text-center">
          <Button size="lg" asChild>
            <a href="/services">
              View All Services
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </Button>
        </div>

        {/* Internal link */}
        <p className="mt-8 text-center text-sm text-muted-foreground">
          Serving businesses across multiple sectors:{" "}
          <a href="#industries-cta" className="text-primary font-medium hover:underline">
            Industries we work with →
          </a>
        </p>
      </div>
    </section>
  );
};

export default BirminghamServices;
