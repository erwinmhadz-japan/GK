import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { MapPin, BadgeCheck, ArrowRight, Award, Briefcase, Contact, Text, View } from "lucide-react";

const credentials = [
  {
    icon: Briefcase,
    label: "Independent Consultant",
    detail: "No account managers. No juniors.",
  },
  {
    icon: BadgeCheck,
    label: "UK SEO Specialist",
    detail: "Technical, local, entity & AI search.",
  },
  {
    icon: Award,
    label: "Sector Experience",
    detail: "Law, healthcare, finance & B2B.",
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut", delay: i * 0.12 },
  }),
};

const AboutHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="about-hero"
      className="relative py-20 md:py-32 border-t border-border bg-background overflow-hidden"
      aria-label="About Gregg King"
    >
      {/* Subtle dot-grid background texture */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.035]"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(var(--foreground)) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">

          {/* LEFT — Text content */}
          <div className="space-y-6 md:space-y-8">

            {/* Eyebrow */}
            <motion.div
              custom={0}
              initial="hidden"
              animate="visible"
              variants={fadeUp}
              className="flex items-center gap-2"
            >
              <MapPin className="h-4 w-4 text-primary flex-shrink-0" aria-hidden="true" />
              <span className="text-sm text-muted-foreground tracking-wide">
                Warrington, Cheshire — UK
              </span>
            </motion.div>

            {/* H1 */}
            <motion.h1
              custom={1}
              initial="hidden"
              animate="visible"
              variants={fadeUp}
              className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight tracking-tight text-foreground font-[Sora,sans-serif] max-w-xl"
            >
              Gregg King —{" "}
              <span className="text-primary">
                Independent SEO Consultant
              </span>
            </motion.h1>

            {/* Subheadline */}
            <motion.p
              custom={2}
              initial="hidden"
              animate="visible"
              variants={fadeUp}
              className="text-lg md:text-xl text-muted-foreground max-w-lg leading-relaxed"
            >
              UK-based SEO expertise without the agency overhead.
              Warrington, Cheshire.
            </motion.p>

            {/* Positioning statement */}
            <motion.p
              custom={3}
              initial="hidden"
              animate="visible"
              variants={fadeUp}
              className="text-base text-muted-foreground max-w-lg leading-relaxed"
            >
              I work directly with UK businesses — including law firms, healthcare providers,
              financial services, and B2B organisations — to deliver measurable improvements
              in organic search performance. Every engagement is handled personally by me.
              There is no team. No handoffs. No agency overhead.
            </motion.p>

            {/* CTAs */}
            <motion.div
              custom={4}
              initial="hidden"
              animate="visible"
              variants={fadeUp}
              className="flex flex-col sm:flex-row gap-3 pt-2"
            >
              <Button
                size="lg"
                className="text-base h-12 px-8 font-semibold"
                style={{
                  background:
                    "linear-gradient(135deg, hsl(84 74% 60%), hsl(119 35% 61%))",
                  color: "hsl(225 28% 14%)",
                }}
                asChild
              >
                <Link to="/contact">
                  Contact Gregg
                  <ArrowRight className="ml-2 h-4 w-4" aria-hidden="true" />
                </Link>
              </Button>

              <Button
                size="lg"
                variant="outline"
                className="text-base h-12 px-8 border-border text-foreground hover:bg-muted transition-colors"
                asChild
              >
                <Link to="/services">
                  View Services
                </Link>
              </Button>
            </motion.div>

            {/* Trust badge strip */}
            <motion.div
              custom={5}
              initial="hidden"
              animate="visible"
              variants={fadeUp}
              className="flex flex-wrap gap-2 pt-1"
            >
              <Badge
                variant="secondary"
                className="text-xs font-medium px-3 py-1 border border-border"
              >
                SEO Consultant UK
              </Badge>
              <Badge
                variant="secondary"
                className="text-xs font-medium px-3 py-1 border border-border"
              >
                Independent — Not an Agency
              </Badge>
              <Badge
                variant="secondary"
                className="text-xs font-medium px-3 py-1 border border-border"
              >
                Direct Client Relationships
              </Badge>
            </motion.div>
          </div>

          {/* RIGHT — Photo + credential cards */}
          <div className="relative flex flex-col items-center lg:items-end gap-6">

            {/* Portrait photo */}
            <motion.div
              initial={{ opacity: 0, scale: 0.97 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.75, ease: "easeOut", delay: 0.2 }}
              className="relative w-full max-w-sm"
            >
              <div
                aria-hidden="true"
                className="absolute -inset-3 rounded-xl opacity-20 blur-2xl"
                style={{
                  background:
                    "linear-gradient(135deg, hsl(84 74% 60%), hsl(119 35% 61%))",
                }}
              />
              <img
                src="https://images.unsplash.com/photo-1730851357916-3802b6405271?w=800&h=600&fit=crop"
                alt="Gregg King, independent SEO consultant based in Warrington, Cheshire"
                width={800}
                height={600}
                loading="eager"
                fetchPriority="high"
                className="relative w-full rounded-xl object-cover shadow-lg"
                style={{
                  aspectRatio: "4/3",
                  boxShadow:
                    "0 8px 40px hsl(225 28% 14% / 0.18), 0 2px 8px hsl(225 28% 14% / 0.1)",
                }}
              />

              {/* Floating location chip */}
              <div
                className="absolute -bottom-4 left-4 flex items-center gap-2 rounded-md border border-border bg-background px-3 py-2 shadow-md"
                aria-hidden="true"
              >
                <MapPin className="h-4 w-4 text-primary" aria-hidden="true" />
                <span className="text-sm font-medium text-foreground">
                  Warrington, Cheshire
                </span>
              </div>
            </motion.div>

            {/* Credential cards */}
            <div className="w-full max-w-sm space-y-3 pt-6">
              {credentials.map((item, index) => (
                <motion.div
                  key={item.label}
                  custom={index + 4}
                  initial="hidden"
                  animate="visible"
                  variants={fadeUp}
                  className="flex items-start gap-3 rounded-md border border-border bg-muted/40 px-4 py-3"
                >
                  <div
                    className="mt-0.5 flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-md"
                    style={{
                      background:
                        "linear-gradient(135deg, hsl(84 74% 60% / 0.15), hsl(119 35% 61% / 0.1))",
                    }}
                  >
                    <item.icon
                      className="h-4 w-4 text-primary"
                      aria-hidden="true"
                    />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">
                      {item.label}
                    </p>
                    <p className="text-xs text-muted-foreground leading-relaxed mt-0.5">
                      {item.detail}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

AboutHero.displayName = "AboutHero";

export default AboutHero;
