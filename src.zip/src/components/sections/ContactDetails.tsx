import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { MapPin, Phone, Mail, Clock, ExternalLink, ChevronRight, Contact, Home, Search, Section, Send } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (delay: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay },
  }),
};

interface ContactItem {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  primary: string;
  secondary?: string;
  href?: string;
  hrefLabel?: string;
}

const contactItems: ContactItem[] = [
  {
    icon: Phone,
    label: "Telephone",
    primary: "01925 214707",
    href: "tel:01925214707",
    hrefLabel: "Call now",
  },
  {
    icon: Mail,
    label: "Email",
    primary: "gregg@greggking.co.uk",
    href: "mailto:gregg@greggking.co.uk",
    hrefLabel: "Send an email",
  },
  {
    icon: MapPin,
    label: "Address",
    primary: "22 Foxdale Court",
    secondary: "Warrington, WA4 5BS, Cheshire, GB",
  },
  {
    icon: Clock,
    label: "Response time",
    primary: "Typically within one business day",
    secondary: "Monday – Friday, 9am – 6pm",
  },
];

const ContactDetails = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="contact-details"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Breadcrumb */}
        <nav aria-label="Breadcrumb" className="mb-8">
          <ol className="flex flex-wrap items-center gap-1 text-xs text-muted-foreground">
            <li>
              <Link to="/" className="hover:text-foreground transition-colors duration-200">Home</Link>
            </li>
            <li aria-hidden="true"><ChevronRight className="h-3 w-3" /></li>
            <li>
              <Link to="/contact" className="font-medium text-foreground" aria-current="page">Contact</Link>
            </li>
          </ol>
        </nav>

        {/* Section header */}
        <motion.div
          className="mb-12 md:mb-16 max-w-2xl"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          custom={0}
          variants={fadeUp}
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Contact Information
          </span>
          <h2 className="text-2xl md:text-3xl font-bold text-foreground font-[Sora,sans-serif] leading-snug">
            Speak directly with Gregg
          </h2>
          <p className="mt-4 text-base text-muted-foreground leading-relaxed max-w-prose">
            As an independent SEO consultant, every enquiry is handled personally.
            There are no account managers or automated responses — just a direct conversation
            about your business and how I can help.
          </p>
        </motion.div>

        {/* Contact detail cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 md:gap-8">
          {contactItems.map((item, i) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.label}
                className="group flex items-start gap-5 rounded-md border border-border bg-background p-6 shadow-[0_2px_12px_-2px_hsl(222_28%_11%_/_0.06),_0_1px_3px_hsl(222_28%_11%_/_0.04)] hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%_/_0.10),_0_1px_4px_hsl(222_28%_11%_/_0.05)] transition-shadow duration-300"
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-40px" }}
                custom={0.1 + i * 0.1}
                variants={fadeUp}
              >
                {/* Icon container */}
                <div className="flex-shrink-0 flex h-11 w-11 items-center justify-center rounded-md bg-primary/10 group-hover:bg-primary/15 transition-colors duration-300">
                  <Icon className="h-5 w-5 text-primary" />
                </div>

                {/* Content */}
                <div className="min-w-0">
                  <p className="text-xs uppercase tracking-[0.15em] text-muted-foreground font-medium mb-1.5">
                    {item.label}
                  </p>
                  {item.href ? (
                    <a
                      href={item.href}
                      className="inline-flex items-center gap-1.5 text-base font-semibold text-foreground hover:text-primary transition-colors duration-200"
                    >
                      {item.primary}
                      <ExternalLink className="h-3.5 w-3.5 opacity-50" />
                    </a>
                  ) : (
                    <p className="text-base font-semibold text-foreground">
                      {item.primary}
                    </p>
                  )}
                  {item.secondary && (
                    <p className="mt-1 text-sm text-muted-foreground">
                      {item.secondary}
                    </p>
                  )}
                  {item.hrefLabel && item.href && (
                    <a
                      href={item.href}
                      className="mt-2 inline-block text-xs text-primary hover:underline font-medium tracking-wide"
                    >
                      {item.hrefLabel} →
                    </a>
                  )}
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Consultant identity note */}
        <motion.div
          className="mt-12 md:mt-16 pt-8 border-t border-border"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          custom={0.6}
          variants={fadeUp}
        >
          <div className="flex flex-col sm:flex-row sm:items-start gap-6 max-w-2xl">
            {/* Green accent bar */}
            <div
              className="hidden sm:block w-0.5 flex-shrink-0 self-stretch rounded-full"
              style={{
                background:
                  "linear-gradient(180deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
              }}
            />
            <div>
              <p className="text-sm text-muted-foreground leading-relaxed">
                <span className="font-semibold text-foreground">Gregg King</span> is an independent
                SEO Consultant UK based in Warrington, Cheshire. All work is carried out directly —
                there is no subcontracting, no offshore team, and no junior staff. When you get in
                touch, you work with Gregg throughout.
              </p>
            </div>
          </div>
        </motion.div>

        {/* Internal linking — related services */}
        <motion.div
          className="mt-10 pt-8 border-t border-border"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          custom={0.7}
          variants={fadeUp}
        >
          <p className="text-xs uppercase tracking-[0.15em] text-muted-foreground mb-4 font-medium">
            Explore Services
          </p>
          <div className="flex flex-wrap gap-2">
            {[
              { label: "SEO Consulting", to: "#seo-consulting-cta" },
              { label: "SEO Audit", to: "/seo-audit" },
              { label: "SEO Retainer", to: "/seo-retainer" },
              { label: "Technical SEO", to: "/technical-seo" },
              { label: "Local SEO", to: "/local-seo" },
              { label: "AI Search Optimisation", to: "/ai-search-optimisation" },
              { label: "Content Strategy", to: "/content-strategy" },
            ].map((service) => (
              <Link
                key={service.to}
                to={service.to}
                className="inline-flex items-center gap-1 rounded-md border border-border px-3 py-1.5 text-xs font-medium text-muted-foreground hover:text-foreground hover:border-foreground/25 hover:bg-accent/50 transition-colors duration-200"
              >
                {service.label}
                <ChevronRight className="h-3 w-3" aria-hidden="true" />
              </Link>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
});

ContactDetails.displayName = "ContactDetails";

export default ContactDetails;
