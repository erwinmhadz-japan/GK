import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, BarChart, TrendingUp, Award, Icon } from "lucide-react";

const stats = [
  { label: "Average Traffic Increase", value: "312%", icon: TrendingUp },
  { label: "Clients Ranked Page 1", value: "94%", icon: Award },
  { label: "Case Studies Published", value: "50+", icon: BarChart },
];

const CaseStudiesHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="case-studies-hero"
      aria-label="Case studies hero section"
      src="https://images.unsplash.com/photo-1573496130141-209d200cebd8?w=1920&h=1080&fit=crop"
      alt="Two professionals reviewing SEO performance results"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[80vh] flex items-center py-24 md:py-36"
    >
      <div className="container relative z-10">
        <div className="max-w-3xl">
          <Badge className="mb-4 bg-primary/20 text-primary border-primary/30 text-sm uppercase tracking-widest">
            Results That Speak for Themselves
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Real SEO Results.<br />
            <span className="text-gradient-green">Proven Case Studies.</span>
          </h1>
          <p className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl leading-relaxed">
            Every engagement starts with a clear objective and ends with measurable outcomes.
            Explore how businesses across legal, healthcare, property, financial, and B2B
            sectors have transformed their organic search performance.
          </p>
          <div className="flex flex-wrap gap-4">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
              asChild
            >
              <a href="#featured-case-studies">
                Explore Case Studies <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10"
              asChild
            >
              <a href="/contact">Work With Gregg</a>
            </Button>
          </div>
        </div>

        {/* Stat bar */}
        <div className="mt-16 grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-3xl">
          {stats.map(({ label, value, icon: Icon }) => (
            <div
              key={label}
              className="flex items-center gap-4 bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl px-5 py-4"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20 shrink-0">
                <Icon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold text-white">{value}</p>
                <p className="text-xs text-white/80 leading-tight">{label}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </ImageBackground>
  );
});

CaseStudiesHero.displayName = "CaseStudiesHero";

export default CaseStudiesHero;
