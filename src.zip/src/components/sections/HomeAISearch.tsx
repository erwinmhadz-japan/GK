import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, Bot, Globe, Sparkles, MonitorSmartphone, ExternalLink, Search, Component, Section, Text, View } from "lucide-react";

/* ─────────────────────────────────────────────
   Data — five AI platforms (expected_count: 5)
───────────────────────────────────────────── */
const platforms = [
  {
    label: "ChatGPT Visibility",
    description:
      "Optimise for citation and brand mentions within ChatGPT responses.",
    icon: Bot,
    href: "/ai-search-chatgpt-visibility",
  },
  {
    label: "Perplexity Visibility",
    description:
      "Ensure your authority signals surface in Perplexity's AI-cited answers.",
    icon: Search,
    href: "/ai-search-perpelexity-visibility",
  },
  {
    label: "Google AI Overviews",
    description:
      "Structured content and entity clarity to appear in Google's AI Overviews.",
    icon: Globe,
    href: "/ai-search-google-ai-overviews",
  },
  {
    label: "Gemini Visibility",
    description:
      "Build the topical authority and entity signals Gemini draws from.",
    icon: Sparkles,
    href: "/ai-search-gemini-visibility",
  },
  {
    label: "Microsoft Copilot",
    description:
      "Establish a credible digital footprint that Copilot surfaces with confidence.",
    icon: MonitorSmartphone,
    href: "/ai-search-copilot-visibility",
  },
];

/* ─────────────────────────────────────────────
   Animation variants
───────────────────────────────────────────── */
const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.55,
      ease: "easeOut",
      delay: i * 0.1,
    },
  }),
};

/* ─────────────────────────────────────────────
   Section colours (dark navy background)
   bg_treatment: solid — background colour is
   applied via inline style so it sits outside
   the light design-token range without
   conflicting with Tailwind's bg-background.
───────────────────────────────────────────── */
const BG = "hsl(225 28% 10%)";
const BORDER_COLOR = "hsl(225 28% 22%)";
const MUTED_BLUE = "hsl(214 32% 60%)";
const MUTED_BLUE_BODY = "hsl(214 32% 75%)";
const MUTED_BLUE_SUBTLE = "hsl(214 32% 65%)";
const MUTED_BLUE_DIM = "hsl(214 32% 50%)";
const GREEN_START = "hsl(84 74% 58%)";
const GREEN_END = "hsl(119 35% 61%)";
const DARK_TEXT = "hsl(225 28% 10%)";

/* ─────────────────────────────────────────────
   Component
───────────────────────────────────────────── */
const HomeAISearch = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="home-aisearch"
      className="relative py-20 md:py-32 border-t border-border overflow-hidden"
      style={{ background: BG }}
    >
      {/* Subtle dot-grid texture */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={{
          backgroundImage: `radial-gradient(circle, ${MUTED_BLUE} 1px, transparent 1px)`,
          backgroundSize: "28px 28px",
          opacity: 0.08,
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">

        {/* ── Header block ── */}
        <div className="max-w-2xl mb-14 md:mb-20">
          <motion.span
            custom={0}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            className="inline-block text-xs uppercase tracking-[0.2em] font-medium mb-4"
            style={{ color: MUTED_BLUE }}
          >
            AI Search Optimisation
          </motion.span>

          <motion.h2
            custom={1}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            className="text-3xl md:text-4xl lg:text-5xl font-bold leading-tight text-white max-w-xl"
          >
            Be visible where your clients are searching
          </motion.h2>

          <motion.p
            custom={2}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            className="mt-5 text-base md:text-lg leading-relaxed max-w-prose"
            style={{ color: MUTED_BLUE_BODY }}
          >
            AI-powered search is reshaping how buyers find and evaluate professional services. I help UK businesses build the authority signals that AI models draw from — so your name surfaces across ChatGPT, Perplexity, Google AI Overviews, Gemini, and Copilot.
          </motion.p>
        </div>

        {/* ── Platform list — editorial, not a feature grid ── */}
        <div className="flex flex-col" style={{ borderTop: `1px solid ${BORDER_COLOR}` }}>
          {platforms.map((platform, i) => {
            const Icon = platform.icon;
            return (
              <motion.div
                key={platform.label}
                custom={i + 3}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-40px" }}
                variants={fadeUp}
                className="group flex items-start md:items-center gap-5 py-6 md:py-7"
                style={{ borderBottom: `1px solid ${BORDER_COLOR}` }}
              >
                {/* Icon badge */}
                <div
                  className="flex-shrink-0 flex items-center justify-center w-10 h-10 rounded-md"
                  style={{
                    background: `${MUTED_BLUE}1a`,
                    border: `1px solid ${MUTED_BLUE}33`,
                  }}
                >
                  <Icon
                    className="w-5 h-5"
                    style={{ color: MUTED_BLUE_BODY }}
                  />
                </div>

                {/* Text */}
                <div className="flex-1 min-w-0">
                  <p className="text-base font-semibold text-white leading-snug">
                    {platform.label}
                  </p>
                  <p
                    className="mt-1 text-sm leading-relaxed hidden md:block"
                    style={{ color: MUTED_BLUE_SUBTLE }}
                  >
                    {platform.description}
                  </p>
                </div>

                {/* Link arrow */}
                <Link
                  to={platform.href}
                  className="flex-shrink-0 flex items-center gap-1.5 text-xs font-medium transition-all duration-200 opacity-60 group-hover:opacity-100"
                  style={{ color: GREEN_START }}
                  aria-label={`Learn more about ${platform.label}`}
                >
                  <span className="hidden sm:inline">Learn more</span>
                  <ArrowRight className="w-4 h-4 group-hover:translate-x-0.5 transition-transform duration-200" />
                </Link>
              </motion.div>
            );
          })}
        </div>

        {/* ── CTA row ── */}
        <motion.div
          custom={9}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          variants={fadeUp}
          className="mt-12 md:mt-16 flex flex-col sm:flex-row items-start sm:items-center gap-5"
        >
          <Button
            size="lg"
            asChild
            className="text-sm font-semibold px-8 border-0 hover:opacity-90 transition-opacity duration-200"
            style={{
              background: `linear-gradient(135deg, ${GREEN_START}, ${GREEN_END})`,
              color: DARK_TEXT,
            }}
          >
            <Link to="/services-ai-search-optimisation">
              View AI Search Services
              <ArrowRight className="ml-2 w-4 h-4" />
            </Link>
          </Button>

          <Link
            to="/ai-search-optimisation"
            className="inline-flex items-center gap-1.5 text-sm font-medium transition-colors duration-200 hover:opacity-80"
            style={{ color: MUTED_BLUE_SUBTLE }}
          >
            <ExternalLink className="w-4 h-4" />
            <span>Explore the AI search hub</span>
          </Link>
        </motion.div>

        {/* ── Consultant footnote ── */}
        <motion.p
          custom={10}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          variants={fadeUp}
          className="mt-8 text-xs leading-relaxed max-w-xl"
          style={{ color: MUTED_BLUE_DIM }}
        >
          I work with UK businesses in competitive sectors to build the entity authority, structured content, and credibility signals that AI models rely on — an increasingly important layer of modern search strategy.
        </motion.p>

      </div>
    </section>
  );
});

HomeAISearch.displayName = "HomeAISearch";

export default HomeAISearch;
