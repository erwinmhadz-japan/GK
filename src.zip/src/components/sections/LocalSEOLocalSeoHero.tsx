import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { ArrowRight, MapPin, CheckCircle, Search, Key } from "lucide-react";

const trustPoints = [
  "Independent UK consultant — no account managers, no junior staff",
  "Ranked local businesses in Warrington, Manchester, Liverpool & beyond",
  "Google Business Profile, citations, local schema & map-pack strategy",
];

const LocalSEOLocalSeoHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="local-seolocal-seo-hero"
      className="relative isolate overflow-hidden border-t border-border bg-[hsl(225_28%_14%)]"
      aria-label="Local SEO Consultant UK hero"
    >
      {/* Subtle dot-grid texture overlay */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(214 32% 60%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
        aria-hidden="true"
      />

      {/* Gradient wash — bottom fade toward section below */}
      <div
        className="pointer-events-none absolute inset-x-0 bottom-0 h-32"
        style={{
          background:
            "linear-gradient(to bottom, transparent, hsl(225 28% 14% / 0.95))",
        }}
        aria-hidden="true"
      />

      <div className="container max-w-6xl mx-auto px-4 py-24 md:py-36 relative z-10">
        <div className="max-w-3xl">
          {/* Eyebrow label */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0 }}
            className="flex items-center gap-2 mb-6"
          >
            <MapPin className="h-4 w-4 text-[hsl(84_74%_60%)]" aria-hidden="true" />
            <span className="text-xs uppercase tracking-[0.22em] text-[hsl(214_32%_60%)] font-medium">
              Warrington, Cheshire — serving the UK
            </span>
          </motion.div>

          {/* H1 */}
          <motion.h1
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-[1.08] tracking-tight max-w-2xl"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Local SEO{" "}
            <span
              className="text-transparent bg-clip-text"
              style={{
                backgroundImage:
                  "linear-gradient(135deg, hsl(84 74% 60%), hsl(119 35% 61%))",
              }}
            >
              Consultant UK
            </span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.2 }}
            className="mt-5 text-lg md:text-xl text-white/80 leading-relaxed max-w-2xl"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Helping UK businesses rank where it matters — in the local searches
            your customers are actually making.
          </motion.p>

          {/* Trust points */}
          <motion.ul
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
            className="mt-8 space-y-3"
            aria-label="Key credentials"
          >
            {trustPoints.map((point, i) => (
              <li key={i} className="flex items-start gap-3">
                <CheckCircle
                  className="h-5 w-5 mt-0.5 shrink-0 text-[hsl(84_74%_60%)]"
                  aria-hidden="true"
                />
                <span className="text-sm md:text-base text-white/80">
                  {point}
                </span>
              </li>
            ))}
          </motion.ul>

          {/* CTA buttons */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.42 }}
            className="mt-10 flex flex-wrap items-center gap-4"
          >
            <Button
              size="lg"
              asChild
              className="h-12 px-8 text-base font-semibold text-[hsl(225_28%_14%)] border-0 shadow-none"
              style={{
                backgroundImage:
                  "linear-gradient(135deg, hsl(84 74% 60%), hsl(119 35% 61%))",
              }}
            >
              <Link to="/contact">
                Enquire Now
                <ArrowRight className="ml-2 h-4 w-4" aria-hidden="true" />
              </Link>
            </Button>

            <Button
              size="lg"
              variant="outline"
              asChild
              className="h-12 px-8 text-base font-medium bg-transparent text-white border-white/30 hover:bg-white/10 hover:border-white/60 transition-colors"
            >
              <Link to="/contact">
                <Search className="mr-2 h-4 w-4" aria-hidden="true" />
                FREE GBP AUDIT
              </Link>
            </Button>
          </motion.div>

          {/* Independent consultant badge strip */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.54 }}
            className="mt-8 flex flex-wrap gap-2"
            aria-label="Consultant credentials"
          >
            <Badge
              variant="outline"
              className="text-xs border-white/20 text-white/80 bg-white/5"
            >
              Independent consultant
            </Badge>
            <Badge
              variant="outline"
              className="text-xs border-white/20 text-white/80 bg-white/5"
            >
              Not an agency
            </Badge>
            <Badge
              variant="outline"
              className="text-xs border-white/20 text-white/80 bg-white/5"
            >
              UK-based
            </Badge>
            <Badge
              variant="outline"
              className="text-xs border-white/20 text-white/80 bg-white/5"
            >
              Local SEO specialist
            </Badge>
          </motion.div>
        </div>
      </div>
    </section>
  );
});

LocalSEOLocalSeoHero.displayName = "LocalSEOLocalSeoHero";

export default LocalSEOLocalSeoHero;
