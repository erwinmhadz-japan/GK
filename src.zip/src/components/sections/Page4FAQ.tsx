import React from "react";
import { motion } from "framer-motion";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { ArrowRight, Search, View } from "lucide-react";

const faqs = [
  {
    question: "Are the guides completely free to access?",
    answer:
      "Yes — every guide, checklist, and framework linked from this page is free. There are no email gates or paywalls. Gregg believes in giving away knowledge generously; clients who benefit from the free resources often return when they're ready for hands-on consultancy.",
  },
  {
    question: "Which guide should I start with if I'm new to SEO?",
    answer:
      "Start with the Technical SEO Audit Checklist to understand the foundations. From there, move to Topic Cluster Strategy for content, then explore the AI Search guides to future-proof your visibility. Each guide is self-contained, so you can read in any order.",
  },
  {
    question: "Do these resources apply to UK businesses specifically?",
    answer:
      "The frameworks and principles are universal, but examples and context are often drawn from UK professional services clients — law firms, accountancies, financial advisers, and B2B consultancies. The local SEO guide is specifically tailored to UK geographies and Google Business Profile for UK regions.",
  },
  {
    question: "How often are the guides updated?",
    answer:
      "Core guides are reviewed at least once per quarter. AI Search and technical content is updated more frequently — often within weeks of significant algorithm or platform changes. The publication date shown on each guide reflects the most recent review.",
  },
  {
    question: "Can I share these resources with my team or clients?",
    answer:
      "Absolutely. The guides are designed to be shared internally. You're welcome to distribute them within your organisation, cite them in presentations, or send them to clients — just please attribute them to Gregg Holliman SEO Consultancy.",
  },
];

const Page4FAQ = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="faq"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          {/* Left column — heading + CTA */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55 }}
          >
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground font-medium mb-4">
              Common Questions
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6 leading-tight">
              Everything You Need to{" "}
              <span className="text-gradient-green">Know</span>
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Questions about the resources, tools, or working with Gregg directly?
              If your question isn't answered here, get in touch — responses within
              one business day.
            </p>
            <div className="flex flex-col sm:flex-row gap-3">
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
                asChild
              >
                <a href="/contact">
                  Ask Gregg
                  <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="/services">View Services</a>
              </Button>
            </div>

            {/* Trust note */}
            <div className="mt-10 p-5 rounded-xl bg-muted border border-border">
              <p className="text-sm text-muted-foreground leading-relaxed">
                <span className="font-semibold text-foreground">No sales pressure.</span>{" "}
                Gregg offers a free 30-minute discovery call for qualified projects. If
                there's no fit, you'll receive honest advice on the best path forward —
                at no cost.
              </p>
            </div>
          </motion.div>

          {/* Right column — accordion */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, delay: 0.1 }}
          >
            <Accordion type="single" collapsible className="w-full space-y-1">
              {faqs.map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="border border-border rounded-lg px-1 mb-2 last:mb-0 bg-card shadow-soft"
                >
                  <AccordionTrigger className="text-left font-medium text-foreground hover:no-underline px-4 py-4 hover:text-primary transition-colors">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed px-4 pb-4">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </motion.div>
        </div>
      </div>
    </section>
  );
});

Page4FAQ.displayName = "Page4FAQ";

export default Page4FAQ;
