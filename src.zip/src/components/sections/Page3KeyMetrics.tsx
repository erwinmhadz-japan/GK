import React from "react";
import { motion } from "framer-motion";
import { TrendingUp, Search, BarChart2, Zap, Target, Users, Icon, Section } from "lucide-react";

const metrics = [
  {
    icon: TrendingUp,
    value: "312%",
    label: "Average organic traffic growth across all retained clients within 12 months",
    accent: "text-primary",
  },
  {
    icon: Search,
    value: "Top 3",
    label: "Average keyword ranking position achieved for primary commercial terms",
    accent: "text-primary",
  },
  {
    icon: BarChart2,
    value: "4.8×",
    label: "Return on investment from SEO retainers — measured against equivalent paid traffic cost",
    accent: "text-primary",
  },
  {
    icon: Zap,
    value: "48 hrs",
    label: "Average turnaround for technical SEO audits with actionable implementation guidance",
    accent: "text-primary",
  },
  {
    icon: Target,
    value: "91%",
    label: "Client retention rate — most clients continue for 12+ months",
    accent: "text-primary",
  },
  {
    icon: Users,
    value: "80+",
    label: "UK businesses served across professional services, SaaS, healthcare, and retail",
    accent: "text-primary",
  },
];

const Page3KeyMetrics = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="page3-key-metrics"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      {/* Subtle decorative radial */}
      <div
        className="absolute inset-0 pointer-events-none"
        aria-hidden="true"
        style={{
          backgroundImage:
            "radial-gradient(circle at 80% 50%, hsl(88 59% 56% / 0.05) 0%, transparent 55%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        {/* Section header */}
        <div className="max-w-2xl mb-14">
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4">
            By the numbers
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
            Results that speak for themselves
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Every metric below reflects real client outcomes — no inflated
            averages, no cherry-picked wins. Independent consultancy means
            accountability to you, not a sales quota.
          </p>
        </div>

        {/* Metrics grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {metrics.map(({ icon: Icon, value, label, accent }, index) => (
            <motion.div
              key={value + label}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.08 }}
              className="group relative rounded-xl border border-border bg-card p-8 hover-lift shadow-card"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 mb-5">
                <Icon className={`h-6 w-6 ${accent}`} aria-hidden="true" />
              </div>
              <div className="text-4xl font-bold text-foreground mb-3">
                {value}
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {label}
              </p>

              {/* Hover accent line */}
              <div className="absolute bottom-0 left-8 right-8 h-0.5 rounded-full bg-gradient-to-r from-primary to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
});

Page3KeyMetrics.displayName = "Page3KeyMetrics";

export default Page3KeyMetrics;
