import React from "react";
import { motion } from "framer-motion";
import { RefreshCw, CalendarDays, MessageSquare, TrendingUp, Target, Layers, Section } from "lucide-react";

const pillars = [
  {
    icon: RefreshCw,
    title: "Ongoing, not one-off",
    body: "An SEO retainer is a sustained monthly engagement rather than a discrete project. Instead of handing over a report and stepping away, I remain actively involved — iterating on strategy as your site, your competitors, and the search landscape evolve.",
  },
  {
    icon: CalendarDays,
    title: "Strategic continuity",
    body: "Organic search rewards consistency. A retainer provides the structured cadence — monthly reviews, quarterly strategy sessions, and continuous technical oversight — that allows compounding gains to build rather than stall between engagements.",
  },
  {
    icon: Target,
    title: "Aligned to your commercial goals",
    body: "Each retained engagement begins with a clear understanding of your business objectives. Every recommendation I make is measured against the metrics that matter to you: qualified organic traffic, lead volume, local visibility, or revenue-driving keyword positions.",
  },
  {
    icon: TrendingUp,
    title: "Accountable, measurable progress",
    body: "You receive clear monthly reporting — not dashboards full of vanity metrics, but concise commentary on what has moved, why, and what I am doing about it. Progress is documented and transparent throughout.",
  },
  {
    icon: MessageSquare,
    title: "Direct consultant access",
    body: "There is no account manager between you and me. When you have a question, a concern, or a time-sensitive decision to make, you contact me directly. This is the practical difference between working with an independent consultant and working through an agency.",
  },
  {
    icon: Layers,
    title: "Flexible in scope, fixed in commitment",
    body: "A retained arrangement adapts as your needs shift — scaling up activity when you are entering a new market, focusing on technical remediation when a core update lands, or pivoting toward AI search visibility as that channel matures. The commitment to your results stays constant.",
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay: i * 0.1 },
  }),
};

const SeoRetainerWhatIsIt = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seo-retainer-what-is-it"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          className="max-w-3xl mb-14 md:mb-18"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            What is an SEO retainer?
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground leading-snug mb-5 max-w-2xl">
            Sustained consultancy, not a&nbsp;one-off&nbsp;project
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl">
            An SEO retainer means I work with your business on an ongoing monthly basis — providing the strategic oversight, technical rigour, and consistent execution that lasting organic growth requires. It is not a report, a fixed deliverable, or a hands-off subscription. It is an active, accountable consulting relationship.
          </p>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl mt-4">
            For UK businesses in competitive sectors — professional services, healthcare, law, finance, and property — organic search is rarely won through a single burst of activity. The sites that perform consistently are those with a sustained programme behind them. That is precisely what a retained arrangement delivers.
          </p>
        </motion.div>

        {/* Pillar grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {pillars.map((pillar, i) => {
            const Icon = pillar.icon;
            return (
              <motion.div
                key={pillar.title}
                custom={i}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-40px" }}
                className="group bg-background border border-border rounded-md p-6 md:p-7 hover:shadow-md transition-shadow duration-300"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10 shrink-0">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="text-base font-semibold text-foreground leading-tight">
                    {pillar.title}
                  </h3>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {pillar.body}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Closing distinction note */}
        <motion.div
          className="mt-14 md:mt-18 max-w-2xl"
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.55, ease: "easeOut", delay: 0.1 }}
        >
          <p className="text-sm text-muted-foreground leading-relaxed border-l-2 border-primary pl-5">
            <strong className="text-foreground font-semibold">A note on how this differs from an agency retainer:</strong> When you retain an agency, you retain a team — an account manager co-ordinates multiple specialists, each handling a slice of your account. When you retain me, you work directly with a single senior consultant who holds the full picture of your SEO strategy. There is no handoff, no interpretation layer, and no dilution of focus.
          </p>
        </motion.div>
      </div>
    </section>
  );
});

SeoRetainerWhatIsIt.displayName = "SeoRetainerWhatIsIt";

export default SeoRetainerWhatIsIt;
