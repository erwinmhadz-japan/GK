import React from "react";
import { Star, CheckCircle } from "lucide-react";

const results = [
  "Ranked page 1 for 15 Sheffield target keywords within 4 months",
  "Organic enquiries increased by 140% year-on-year",
  "Google Business Profile calls up 85% after local SEO work",
];

const SheffieldTestimonial = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-3">
              Sheffield Case Study
            </span>
            <h2 className="text-3xl md:text-5xl font-bold text-foreground">
              Real Results for Sheffield Businesses
            </h2>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
            {/* Testimonial card */}
            <div className="bg-muted rounded-2xl p-8 border border-border shadow-card">
              <div className="flex gap-1 mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className="h-5 w-5 text-primary fill-primary"
                  />
                ))}
              </div>
              <blockquote className="text-foreground text-lg leading-relaxed font-medium mb-6">
                "Working with Gregg transformed our online visibility in Sheffield. We were invisible on Google before — now we're getting consistent enquiries from customers across South Yorkshire. The structured, no-nonsense approach made all the difference."
              </blockquote>
              <div className="flex items-center gap-4">
                <img
                  src="https://images.unsplash.com/photo-1734830268394-6c4a1f165af1?w=400&h=400&fit=crop&crop=face"
                  alt="Sheffield business owner testimonial"
                  width="48"
                  height="48"
                  className="rounded-full object-cover w-12 h-12"
                  loading="lazy"
                />
                <div>
                  <div className="font-bold text-foreground">James Hartley</div>
                  <div className="text-sm text-muted-foreground">
                    Director, Sheffield Facilities Management
                  </div>
                </div>
              </div>
            </div>

            {/* Results */}
            <div>
              <h3 className="text-xl font-bold text-foreground mb-6">
                What We Achieved Together
              </h3>
              <ul className="space-y-4">
                {results.map((result) => (
                  <li key={result} className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                    <span className="text-muted-foreground leading-relaxed">
                      {result}
                    </span>
                  </li>
                ))}
              </ul>
              <div className="mt-8 p-5 rounded-xl bg-primary/10 border border-primary/20">
                <p className="text-sm text-foreground font-medium leading-relaxed">
                  Results vary by business, competition, and sector — but strategic Sheffield SEO consistently delivers measurable organic growth within the first three to six months.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

SheffieldTestimonial.displayName = "SheffieldTestimonial";
export default SheffieldTestimonial;
