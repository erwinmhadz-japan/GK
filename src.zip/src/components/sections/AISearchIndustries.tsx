import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight, Gavel, Stethoscope, Home, Landmark, Briefcase, Focus, Section } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface Industry {
  icon: React.ComponentType<{ className?: string }>;
  sector: string;
  keyword: string;
  description: string;
  aiRelevance: string;
  href: string;
}

const industries: Industry[] = [
  {
    icon: Gavel,
    sector: "Law Firms & Solicitors",
    keyword: "SEO for law firms UK",
    description:
      "Legal services operate under strict professional conduct rules and intense search competition. EEAT signals — expertise, authoritativeness, and trustworthiness — are non-negotiable for AI engines surfacing legal guidance.",
    aiRelevance:
      "AI search tools cite authoritative legal sources. I build the entity signals and citation authority that position your firm as a credible, named source in AI-generated answers.",
    href: "/services-ai-search-optimisation",
  },
  {
    icon: Stethoscope,
    sector: "Healthcare & Private Providers",
    keyword: "SEO for healthcare providers UK",
    description:
      "Healthcare and private clinic searches carry life-affecting weight. Google and AI platforms apply heightened scrutiny to medical content, demanding clear authorship, clinical credentials, and structured factual accuracy.",
    aiRelevance:
      "AI tools like Perplexity and ChatGPT heavily favour verified, entity-rich medical sources. Structured data, practitioner schema, and citation-backed content are essential to appear in AI overviews.",
    href: "/services-ai-search-optimisation",
  },
  {
    icon: Home,
    sector: "Estate Agents & Property Services",
    keyword: "SEO for estate agents UK",
    description:
      "Property search is local, high-intent, and increasingly driven by AI-assisted comparison. Buyers and vendors now ask AI tools for local agency recommendations before visiting portals.",
    aiRelevance:
      "Local entity signals, Google Business Profile optimisation, and structured property schema combine to ensure your agency is surfaced when AI search recommends local property professionals.",
    href: "/services-ai-search-optimisation",
  },
  {
    icon: Landmark,
    sector: "Financial Services",
    keyword: "SEO consultant for financial services UK",
    description:
      "Financial services face Your Money or Your Life (YMYL) classification across every major search engine. Brand trust, regulatory credibility, and structured factual content are the foundations of AI visibility.",
    aiRelevance:
      "AI platforms apply rigorous source filtering on financial topics. I build the entity authority, schema markup, and citation profile that signals credibility to AI systems — not just traditional search algorithms.",
    href: "/services-ai-search-optimisation",
  },
  {
    icon: Briefcase,
    sector: "B2B & Professional Services",
    keyword: "SEO for B2B professional services UK",
    description:
      "B2B buyers research extensively before engaging suppliers. Decision-makers increasingly use AI tools to shortlist consultants, agencies, and service providers — often before any human-led web browsing.",
    aiRelevance:
      "Being cited and named in AI-generated shortlists requires strong entity recognition, authoritative content, and consistent brand signals across the web. I build exactly this for professional service firms.",
    href: "/services-ai-search-optimisation",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const headingVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" },
  },
};

const AISearchIndustries = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="aisearch-industries"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          className="max-w-2xl mb-14 md:mb-18"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={headingVariants}
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Sector Focus
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 leading-tight">
            Sectors I Work With
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
            AI search engines apply their most rigorous source-quality filters to sectors where trust and authority matter most. These are the industries where EEAT signals and citation authority are not optional — they are the difference between being cited and being invisible.
          </p>
        </motion.div>

        {/* Industry cards — 5 items in a 2+3 layout */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={containerVariants}
        >
          {/* Top row: 2 cards */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
            {industries.slice(0, 2).map((industry) => {
              const Icon = industry.icon;
              return (
                <motion.div
                  key={industry.sector}
                  variants={cardVariants}
                  className="group relative bg-card border border-border rounded-md p-7 flex flex-col gap-5 hover:border-primary/40 hover:shadow-md transition-all duration-300"
                >
                  {/* Icon + sector */}
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-base font-semibold text-foreground leading-snug mb-1">
                        {industry.sector}
                      </h3>
                      <Badge
                        variant="secondary"
                        className="text-xs font-normal text-muted-foreground"
                      >
                        {industry.keyword}
                      </Badge>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {industry.description}
                  </p>

                  {/* AI relevance callout */}
                  <div className="border-l-2 border-primary/40 pl-4">
                    <p className="text-xs text-muted-foreground leading-relaxed italic">
                      <span className="not-italic font-medium text-foreground">
                        AI search:
                      </span>{" "}
                      {industry.aiRelevance}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>

          {/* Bottom row: 3 cards */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {industries.slice(2, 5).map((industry) => {
              const Icon = industry.icon;
              return (
                <motion.div
                  key={industry.sector}
                  variants={cardVariants}
                  className="group relative bg-card border border-border rounded-md p-7 flex flex-col gap-5 hover:border-primary/40 hover:shadow-md transition-all duration-300"
                >
                  {/* Icon + sector */}
                  <div className="flex items-start gap-4">
                    <div className="flex-shrink-0 flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="text-sm font-semibold text-foreground leading-snug mb-1">
                        {industry.sector}
                      </h3>
                      <Badge
                        variant="secondary"
                        className="text-xs font-normal text-muted-foreground"
                      >
                        {industry.keyword}
                      </Badge>
                    </div>
                  </div>

                  {/* Description */}
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {industry.description}
                  </p>

                  {/* AI relevance callout */}
                  <div className="border-l-2 border-primary/40 pl-4 mt-auto">
                    <p className="text-xs text-muted-foreground leading-relaxed italic">
                      <span className="not-italic font-medium text-foreground">
                        AI search:
                      </span>{" "}
                      {industry.aiRelevance}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Footer link to industries hub */}
        <motion.div
          className="mt-12 flex items-center gap-2"
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4, ease: "easeOut" }}
        >
          <Link
            to="/services-ai-search-optimisation"
            className="inline-flex items-center gap-1.5 text-sm font-medium text-foreground hover:text-primary transition-colors duration-200 group"
          >
            Explore AI search optimisation by sector
            <ArrowRight className="h-4 w-4 group-hover:translate-x-0.5 transition-transform duration-200" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
});

AISearchIndustries.displayName = "AISearchIndustries";

export default AISearchIndustries;
