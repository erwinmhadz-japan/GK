import React from "react";
import { motion, type Variants } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Target, Layers, Search, CalendarDays, FileText, Link2, ListChecks, TrendingUp, ArrowRight, Anchor, Calendar, Section, Volume } from "lucide-react";

interface Deliverable {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  outputs: string[];
}

const deliverables: Deliverable[] = [
  {
    icon: Target,
    title: "Topical Authority Mapping",
    description:
      "I map the full topical landscape for your sector — identifying the clusters of content needed to demonstrate deep expertise to both search engines and prospective clients.",
    outputs: [
      "Pillar topic identification",
      "Supporting topic clusters",
      "Entity coverage gaps",
      "Competitor authority analysis",
    ],
  },
  {
    icon: Search,
    title: "Keyword Clustering & Intent Analysis",
    description:
      "Keyword research structured around search intent — grouping terms by commercial, informational, and navigational purpose to ensure every page owns a distinct position.",
    outputs: [
      "Intent-grouped keyword clusters",
      "Volume and difficulty benchmarks",
      "SERP feature opportunities",
      "Cannibalisation risk report",
    ],
  },
  {
    icon: Layers,
    title: "Content Audit",
    description:
      "A structured review of existing content — identifying what to keep, consolidate, update, or retire. The audit provides a clear baseline before any new content is planned.",
    outputs: [
      "Page-level performance review",
      "Thin or duplicate content flags",
      "Consolidation recommendations",
      "Quick-win improvement targets",
    ],
  },
  {
    icon: CalendarDays,
    title: "Editorial Calendar",
    description:
      "A prioritised publishing schedule aligned to your commercial calendar, keyword opportunities, and audience behaviour — ensuring output is strategic rather than ad hoc.",
    outputs: [
      "12-month editorial roadmap",
      "Prioritised content queue",
      "Seasonal and topical hooks",
      "Production-ready scheduling framework",
    ],
  },
  {
    icon: FileText,
    title: "Content Briefs",
    description:
      "Detailed briefs for each content asset — covering target keywords, recommended structure, entity coverage, word count guidance, internal linking anchors, and tone of voice direction.",
    outputs: [
      "Keyword-mapped content structure",
      "Entity and NLP term guidance",
      "Suggested headings and subheadings",
      "Internal link placement strategy",
    ],
  },
  {
    icon: Link2,
    title: "Internal Linking Strategy",
    description:
      "A systematic plan for how content assets link to one another — distributing authority logically, reinforcing keyword ownership, and guiding users through clear informational journeys.",
    outputs: [
      "Site-wide link architecture diagram",
      "Anchor text recommendations",
      "Cluster interlinking plan",
      "Orphaned page resolution",
    ],
  },
];

const processSteps = [
  {
    step: "01",
    label: "Discovery",
    detail: "Audience, sector, and competitive landscape review",
  },
  {
    step: "02",
    label: "Audit",
    detail: "Assess existing content against search performance data",
  },
  {
    step: "03",
    label: "Strategy",
    detail: "Topical mapping, keyword clustering, and gap analysis",
  },
  {
    step: "04",
    label: "Planning",
    detail: "Editorial calendar, briefs, and internal linking framework",
  },
  {
    step: "05",
    label: "Handover",
    detail: "Structured documentation ready for implementation",
  },
];

const containerVariants: Variants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants: Variants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55 },
  },
};

const ContentStrategyDeliverables = React.forwardRef<HTMLElement>(
  (props, ref) => {
    return (
      <section
        ref={ref}
        id="content-strategy-deliverables"
        className="relative py-20 md:py-32 border-t border-border bg-background"
      >
        <div className="container max-w-6xl mx-auto px-4">
          {/* Section header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="mb-16 md:mb-20"
          >
            <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
              Scope &amp; Deliverables
            </span>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground max-w-2xl leading-snug">
              What a content strategy engagement includes
            </h2>
            <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
              I work exclusively on strategy and planning — not content
              production. Every engagement delivers a structured, evidence-based
              framework that your team or preferred writers can implement with
              confidence.
            </p>
          </motion.div>

          {/* Deliverables grid */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-20"
          >
            {deliverables.map((item) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.title}
                  variants={itemVariants}
                  className="group rounded-md border border-border bg-card p-6 hover:border-primary/40 hover:shadow-md transition-all duration-300"
                >
                  {/* Icon */}
                  <div className="flex items-center justify-center w-10 h-10 rounded-md bg-primary/10 mb-5">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>

                  {/* Title & description */}
                  <h3 className="text-base font-semibold text-foreground mb-2 leading-snug">
                    {item.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-5">
                    {item.description}
                  </p>

                  {/* Output list */}
                  <ul className="space-y-2">
                    {item.outputs.map((output) => (
                      <li
                        key={output}
                        className="flex items-start gap-2 text-sm text-muted-foreground"
                      >
                        <ArrowRight className="h-3.5 w-3.5 text-primary mt-0.5 shrink-0" />
                        <span>{output}</span>
                      </li>
                    ))}
                  </ul>
                </motion.div>
              );
            })}
          </motion.div>

          {/* Engagement clarification */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="rounded-md border border-border bg-muted/40 p-8 md:p-10 mb-20"
          >
            <div className="flex flex-col md:flex-row md:items-start gap-6 md:gap-10">
              <div className="flex-shrink-0">
                <div className="flex items-center justify-center w-12 h-12 rounded-md bg-primary/10">
                  <ListChecks className="h-6 w-6 text-primary" />
                </div>
              </div>
              <div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  Strategy consultancy, not content production
                </h3>
                <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-4">
                  My content strategy service provides the strategic layer —
                  the architecture, prioritisation, and brief writing — that
                  makes content marketing work. I do not write articles,
                  landing pages, or blog posts as part of this engagement.
                </p>
                <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                  This distinction matters for competitive sectors such as law,
                  finance, healthcare, and professional services, where the
                  quality of strategy — not simply the volume of output —
                  determines whether content earns rankings and drives
                  qualified enquiries.
                </p>
                <div className="mt-5 flex flex-wrap gap-2">
                  {[
                    "Law firms",
                    "Healthcare",
                    "Financial services",
                    "Property",
                    "B2B professional services",
                  ].map((sector) => (
                    <Badge
                      key={sector}
                      variant="secondary"
                      className="text-xs font-normal"
                    >
                      {sector}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </motion.div>

          {/* Engagement process */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          >
            <div className="mb-10">
              <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-3 font-medium">
                How I work
              </span>
              <h2 className="text-xl md:text-2xl font-bold text-foreground">
                The engagement process
              </h2>
            </div>

            <div className="relative">
              {/* Connector line — desktop only */}
              <div
                className="hidden lg:block absolute top-5 left-[2.25rem] right-[2.25rem] h-px bg-border"
                aria-hidden="true"
              />

              <motion.ol
                variants={containerVariants}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-60px" }}
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 relative"
              >
                {processSteps.map((s) => (
                  <motion.li
                    key={s.step}
                    variants={itemVariants}
                    className="flex flex-col items-start lg:items-center lg:text-center"
                  >
                    {/* Step number circle */}
                    <div className="flex items-center justify-center w-9 h-9 rounded-full border-2 border-primary bg-background text-primary text-xs font-bold mb-4 relative z-10">
                      {s.step}
                    </div>
                    <h4 className="text-sm font-semibold text-foreground mb-1">
                      {s.label}
                    </h4>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {s.detail}
                    </p>
                  </motion.li>
                ))}
              </motion.ol>
            </div>

            {/* Subtle text link — no CTA block here per CTA placement rules */}
            <div className="mt-12 flex items-center gap-2 text-sm text-muted-foreground">
              <TrendingUp className="h-4 w-4 text-primary shrink-0" />
              <span>
                Engagements are structured to deliver a complete, actionable
                strategy — not an ongoing dependency.{" "}
                <a
                  href="/contact"
                  className="text-foreground font-medium underline underline-offset-2 hover:text-primary transition-colors"
                >
                  Get in touch to discuss your requirements →
                </a>
              </span>
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
);

ContentStrategyDeliverables.displayName = "ContentStrategyDeliverables";

export default ContentStrategyDeliverables;
