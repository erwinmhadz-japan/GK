import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, Building2, Users, Globe, ArrowRight, Target, Grid, View } from "lucide-react";

const opportunities = [
  {
    icon: Building2,
    title: "Over 100,000 Businesses",
    description:
      "Greater Manchester is home to more than 100,000 registered businesses, from MediaCity tech firms in Salford to established professional services in the city centre. The competition for page-one visibility is fierce — and growing.",
  },
  {
    icon: TrendingUp,
    title: "£74bn Regional Economy",
    description:
      "Manchester's economy is the UK's second largest outside London. Businesses that rank in local and national search capture a disproportionate share of B2B and B2C demand in sectors including legal, finance, tech, and healthcare.",
  },
  {
    icon: Users,
    title: "2.8M Population Catchment",
    description:
      "The Greater Manchester conurbation spans Salford, Trafford, Stockport, Bury, Bolton, Oldham, Tameside, Wigan, and Rochdale. A well-structured local SEO strategy captures intent across the entire catchment area.",
  },
  {
    icon: Globe,
    title: "National Digital Hub",
    description:
      "With MediaCity UK, a thriving Northern Quarter tech scene, and increasing inward investment, Manchester attracts nationally and internationally competitive search queries. Your SEO strategy must perform at both city and national scale.",
  },
  {
    icon: Target,
    title: "High-Intent Commercial Queries",
    description:
      "Keywords like 'SEO agency Manchester', 'solicitor Manchester', and 'accountant Manchester' attract hundreds of monthly searches with strong commercial intent. Ranking in these categories delivers measurable pipeline growth.",
  },
  {
    icon: Building2,
    title: "Rising Enterprise Competition",
    description:
      "Manchester's FTSE-listed and private equity-backed companies invest heavily in SEO. Independent businesses must match enterprise-level technical quality and content depth to hold their ground in competitive SERPs.",
  },
];

const stats = [
  { value: "87%", label: "of consumers search online before visiting a Manchester business" },
  { value: "3×", label: "more clicks to the top 3 organic results vs. paid ads" },
  { value: "46%", label: "of all Google searches have local intent" },
  { value: "£2.4K", label: "average monthly value of a page-one Manchester keyword ranking" },
];

const ManchesterMarket = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="manchester-market"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className="max-w-2xl mb-14">
          <motion.span
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="inline-block text-xs uppercase tracking-[0.2em] text-primary font-semibold mb-4"
          >
            Manchester Market Intelligence
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, delay: 0.06 }}
            className="text-3xl md:text-4xl font-bold text-foreground mb-5"
          >
            The Manchester Competitive Landscape
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, delay: 0.12 }}
            className="text-lg text-muted-foreground leading-relaxed"
          >
            Understanding Manchester's search landscape is the foundation of a strategy that
            delivers real commercial outcomes — not just rankings.
          </motion.p>
        </div>

        {/* Stats Row */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-14"
        >
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="bg-muted rounded-xl px-5 py-6 text-center border border-border"
            >
              <div className="text-3xl md:text-4xl font-bold text-primary mb-2">{stat.value}</div>
              <div className="text-xs text-muted-foreground leading-snug">{stat.label}</div>
            </div>
          ))}
        </motion.div>

        {/* Opportunities Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {opportunities.map((item, idx) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.07 }}
            >
              <Card className="h-full border border-border hover-lift shadow-card">
                <CardContent className="p-6">
                  <div className="flex items-center justify-center w-11 h-11 rounded-lg bg-primary/10 mb-4">
                    <item.icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="text-base font-semibold text-foreground mb-2">{item.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{item.description}</p>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="flex flex-wrap gap-4"
        >
          <Button size="lg" asChild>
            <Link to="/local-seo">
              Explore Manchester Local SEO
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button size="lg" variant="outline" asChild>
            <Link to="#case-studies-cta">View Manchester Case Studies</Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
});

ManchesterMarket.displayName = "ManchesterMarket";

export default ManchesterMarket;
