import React from "react";
import { motion } from "framer-motion";
import { Search, FileSearch, ClipboardList, Code, Activity, ArrowRight, Section } from "lucide-react";

const processSteps = [
  {
    number: "01",
    icon: Search,
    label: "Discovery Call",
    heading: "Understanding Your Site and Goals",
    body:
      "We begin with a focused discovery call — typically 30 to 45 minutes. I want to understand your site's history, any previous technical work, what's been tried before, and where you believe the problems lie. This is not a sales call. It's a diagnostic conversation that shapes everything that follows.",
  },
  {
    number: "02",
    icon: FileSearch,
    label: "Technical Audit",
    heading: "A Thorough, Independent Assessment",
    body:
      "I conduct a comprehensive technical audit personally — not delegated to a junior or automated entirely by a tool. I review crawl data, indexation health, Core Web Vitals, site architecture, redirect logic, structured data, JavaScript rendering, and log files where available. The output is a detailed, prioritised report written for your team to act on.",
  },
  {
    number: "03",
    icon: ClipboardList,
    label: "Prioritised Recommendations",
    heading: "Clear Guidance, Not Jargon",
    body:
      "Not every technical issue carries equal weight. I prioritise findings by likely search impact and implementation effort, so your development resource is directed where it matters most. Recommendations are written in plain language — with context, rationale, and enough technical specificity for your developers to implement without ambiguity.",
  },
  {
    number: "04",
    icon: Code,
    label: "Implementation Support",
    heading: "Hands-On Where It Counts",
    body:
      "I work alongside your developers or in-house team during implementation — available to answer questions, review proposed solutions, and QA fixes before they go live. Many clients find this direct collaboration the most valuable part of the engagement. There is no account manager in the middle; you work directly with me throughout.",
  },
  {
    number: "05",
    icon: Activity,
    label: "Monitoring and Review",
    heading: "Measuring What Changes",
    body:
      "Once fixes are deployed, I monitor crawl behaviour, indexation signals, and ranking movement to confirm the changes are taking effect. If further issues surface — or if the data suggests adjustments — I'll advise accordingly. The goal is lasting improvement, not a one-time tick-box audit.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" },
  },
};

const TechnicalSeoProcess = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="technical-seo-process"
      className="relative py-20 md:py-32 border-t border-border bg-[hsl(225_28%_14%)]"
      aria-labelledby="process-heading"
    >
      {/* Subtle dot-grid background texture */}
      <div
        className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(84 74% 60%) 1px, transparent 1px)",
          backgroundSize: "32px 32px",
        }}
        aria-hidden="true"
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">

        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.65, ease: "easeOut" }}
          className="mb-14 md:mb-20"
        >
          <span
            className="inline-block text-xs uppercase tracking-[0.2em] text-white/60 mb-4 font-medium"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            My Process
          </span>
          <h2
            id="process-heading"
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white max-w-3xl leading-tight"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            How a Technical SEO Engagement Works
          </h2>
          <p
            className="mt-5 text-white/80 text-base md:text-lg max-w-2xl leading-relaxed"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Every engagement is handled directly by me — from the initial call through to
            post-implementation monitoring. You deal with one person throughout, not a
            rotating team of account managers or junior analysts.
          </p>
        </motion.div>

        {/* Process step list */}
        <motion.ol
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="relative space-y-0"
          aria-label="Technical SEO process steps"
        >
          {/* Vertical connector line — visible on sm+ screens */}
          <div
            className="absolute left-7 md:left-9 top-7 bottom-7 w-px bg-white/10 pointer-events-none hidden sm:block"
            aria-hidden="true"
          />

          {processSteps.map((step, index) => {
            const Icon = step.icon;
            const isLast = index === processSteps.length - 1;

            return (
              <motion.li
                key={step.number}
                variants={itemVariants}
                className={`relative flex gap-5 md:gap-8 ${isLast ? "" : "pb-10 md:pb-12"}`}
              >
                {/* Step icon bubble */}
                <div className="relative flex-shrink-0 z-10">
                  <div
                    className="flex h-14 w-14 md:h-[4.5rem] md:w-[4.5rem] items-center justify-center rounded-full border border-white/15 bg-[hsl(231_9%_16%)]"
                    aria-hidden="true"
                  >
                    <Icon className="h-5 w-5 md:h-6 md:w-6 text-[hsl(84_74%_60%)]" />
                  </div>
                </div>

                {/* Step content */}
                <div className="flex-1 min-w-0 pb-1">
                  {/* Step label row */}
                  <div className="flex flex-wrap items-center gap-2 mb-2">
                    <span
                      className="text-xs font-semibold tracking-[0.18em] uppercase text-[hsl(84_74%_60%)]"
                      style={{ fontFamily: "Sora, sans-serif" }}
                    >
                      {step.number}
                    </span>
                    <span className="h-px w-6 bg-white/15 shrink-0" aria-hidden="true" />
                    <span
                      className="text-xs uppercase tracking-[0.14em] text-white/50"
                      style={{ fontFamily: "Inter, sans-serif" }}
                    >
                      {step.label}
                    </span>
                  </div>

                  {/* Step heading */}
                  <h3
                    className="text-lg md:text-xl font-semibold text-white mb-3 leading-snug"
                    style={{ fontFamily: "Sora, sans-serif" }}
                  >
                    {step.heading}
                  </h3>

                  {/* Step body */}
                  <p
                    className="text-white/75 text-sm md:text-base leading-relaxed max-w-2xl"
                    style={{ fontFamily: "Inter, sans-serif" }}
                  >
                    {step.body}
                  </p>

                  {/* Mobile divider between steps */}
                  {!isLast && (
                    <div
                      className="mt-6 flex sm:hidden items-center gap-2 text-white/20"
                      aria-hidden="true"
                    >
                      <div className="h-px flex-1 bg-white/10" />
                      <ArrowRight className="h-3 w-3 rotate-90 shrink-0" />
                      <div className="h-px flex-1 bg-white/10" />
                    </div>
                  )}
                </div>
              </motion.li>
            );
          })}
        </motion.ol>

        {/* Closing editorial note */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.6, ease: "easeOut", delay: 0.15 }}
          className="mt-14 md:mt-20 pt-10 border-t border-white/10"
        >
          <p
            className="text-white/60 text-sm md:text-base leading-relaxed max-w-2xl"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Engagements are scoped to your situation. I don't apply a one-size-fits-all
            methodology — whether you need a standalone audit or ongoing technical oversight,
            the approach is always direct, measured, and focused on what will actually move
            the needle for your site.
          </p>
        </motion.div>

      </div>
    </section>
  );
});

TechnicalSeoProcess.displayName = "TechnicalSeoProcess";

export default TechnicalSeoProcess;
