import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star, Quote, TrendingUp, Users, MapPin, Section } from "lucide-react";

const caseStudies = [
  {
    clinic: "South London Physio Clinic",
    specialty: "Physiotherapy",
    result: "+312% organic patient enquiries",
    period: "in 9 months",
    quote:
      "Before working with this team, we barely appeared in local search results. Now we dominate 'physiotherapist near me' queries across three London boroughs. Our appointment book is consistently full from organic search alone.",
    author: "Dr. Sarah Mitchell",
    role: "Clinical Director",
    image: "https://images.unsplash.com/photo-1573496527892-904f897eb744?w=400&h=400&fit=crop&crop=face",
    stats: [
      { label: "Organic sessions", value: "+312%" },
      { label: "Local pack positions", value: "12 keywords" },
      { label: "Patient enquiries/mo", value: "4× increase" },
    ],
  },
  {
    clinic: "Harley Street Dermatology",
    specialty: "Dermatology",
    result: "+187% new patient registrations",
    period: "in 6 months",
    quote:
      "The schema markup and entity SEO work was transformational. We now appear in Google's Knowledge Panel for key dermatology searches, and our structured data generates rich results that immediately build patient trust before they even visit our site.",
    author: "Mr. James Chen",
    role: "Practice Manager",
    image: "https://images.unsplash.com/photo-1614023342667-6f060e9d1e04?w=400&h=400&fit=crop&crop=face",
    stats: [
      { label: "New patient registrations", value: "+187%" },
      { label: "Knowledge Panel", value: "Established" },
      { label: "Rich result CTR", value: "+44%" },
    ],
  },
  {
    clinic: "Birmingham Women's Wellness Centre",
    specialty: "Women's Health",
    result: "Page 1 for 28 priority keywords",
    period: "in 12 months",
    quote:
      "Women's health is a sensitive search category and we needed an SEO partner who understood both the clinical nuances and Google's YMYL guidelines. The compliant content strategy delivered rankings we never thought possible as an independent practice.",
    author: "Dr. Emma Okafor",
    role: "Founder & GP",
    image: "https://images.unsplash.com/photo-1607990283143-e81e7a2c9349?w=400&h=400&fit=crop&crop=face",
    stats: [
      { label: "Page 1 keywords", value: "28" },
      { label: "Organic traffic growth", value: "+241%" },
      { label: "Avg. booking conversion", value: "6.8%" },
    ],
  },
];

const metrics = [
  { icon: TrendingUp, value: "3.2×", label: "average organic traffic increase across healthcare clients" },
  { icon: Users, value: "850+", label: "healthcare patient enquiries generated per month (aggregate)" },
  { icon: MapPin, value: "94%", label: "of clients achieve local pack placement within 90 days" },
  { icon: Star, value: "4.9/5", label: "average client satisfaction rating from medical practices" },
];

const HealthcareClinicsTestimonials = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="healthcare-case-studies"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-2xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4 font-semibold">
            Case Studies & Testimonials
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Real Results for Real Healthcare Providers
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            From independent GPs to multi-site specialist clinics — here's how specialist
            healthcare SEO delivers measurable patient growth.
          </p>
        </div>

        {/* Metrics bar */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-14">
          {metrics.map((metric) => {
            const Icon = metric.icon;
            return (
              <div
                key={metric.label}
                className="flex flex-col items-center text-center p-5 rounded-xl bg-card border border-border shadow-soft"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 mb-3">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <span className="text-2xl font-bold text-foreground">{metric.value}</span>
                <span className="text-xs text-muted-foreground mt-1 leading-tight">
                  {metric.label}
                </span>
              </div>
            );
          })}
        </div>

        {/* Case study cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {caseStudies.map((cs) => (
            <Card
              key={cs.clinic}
              className="bg-card border-border shadow-card hover-lift flex flex-col"
            >
              <CardContent className="p-6 flex flex-col gap-4 flex-1">
                {/* Quote */}
                <div className="flex-1">
                  <Quote className="h-6 w-6 text-primary mb-3" />
                  <p className="text-foreground text-sm leading-relaxed italic">
                    "{cs.quote}"
                  </p>
                </div>

                {/* Stats row */}
                <div className="grid grid-cols-3 gap-2 py-3 border-y border-border">
                  {cs.stats.map((stat) => (
                    <div key={stat.label} className="text-center">
                      <p className="text-sm font-bold text-primary">{stat.value}</p>
                      <p className="text-xs text-muted-foreground leading-tight">
                        {stat.label}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Author */}
                <div className="flex items-center gap-3">
                  <img
                    src={cs.image}
                    alt={`${cs.author} — ${cs.role} at ${cs.clinic}`}
                    width={48}
                    height={48}
                    className="h-12 w-12 rounded-full object-cover"
                    loading="lazy"
                  />
                  <div>
                    <p className="text-sm font-semibold text-foreground">{cs.author}</p>
                    <p className="text-xs text-muted-foreground">{cs.role}</p>
                    <Badge variant="secondary" className="mt-1 text-xs px-2 py-0.5">
                      {cs.specialty}
                    </Badge>
                  </div>
                </div>

                {/* Result highlight */}
                <div className="bg-primary/10 rounded-lg px-4 py-2 flex items-center gap-2">
                  <TrendingUp className="h-4 w-4 text-primary shrink-0" />
                  <span className="text-xs font-semibold text-foreground">
                    {cs.result} <span className="text-muted-foreground font-normal">{cs.period}</span>
                  </span>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
});

HealthcareClinicsTestimonials.displayName = "HealthcareClinicsTestimonials";

export default HealthcareClinicsTestimonials;
