import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Star, Quote, Section, Stars, Triangle } from "lucide-react";

const testimonials = [
  {
    name: "Sarah Pemberton",
    role: "Director",
    company: "Pemberton Property Management, Liverpool",
    image:
      "https://images.unsplash.com/photo-1710778044102-56a3a6b69a1b?w=400&h=400&fit=crop&crop=face",
    quote:
      "Within four months, our Liverpool lettings agency went from page three to the top three in Google Maps. We now get 60% more enquiries from organic search alone. The ROI has been incredible — I only wish I'd started sooner.",
    rating: 5,
  },
  {
    name: "Marcus Nkemdirim",
    role: "Managing Partner",
    company: "Nkemdirim & Co Solicitors, Liverpool City Centre",
    image:
      "https://images.unsplash.com/photo-1678282955795-200c1e18bc7d?w=400&h=400&fit=crop&crop=face",
    quote:
      "Our firm was invisible online despite 15 years in Liverpool. Gregg restructured our entire content strategy around Liverpool legal search queries and within six months we ranked for over 40 high-intent local terms. New client enquiries from Google increased by over 90%.",
    rating: 5,
  },
  {
    name: "Claire Devlin",
    role: "Owner",
    company: "Baltic Brew Co., Baltic Triangle Liverpool",
    image:
      "https://images.unsplash.com/photo-1681500920181-0aff411f8cab?w=400&h=400&fit=crop&crop=face",
    quote:
      "As a small independent business in Liverpool's tech quarter, I was sceptical about SEO. The results have been transformative — we now dominate local coffee shop searches and foot traffic from organic search has doubled.",
    rating: 5,
  },
];

const LiverpoolTestimonials = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="liverpool-testimonials"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-3xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Client Testimonials
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-5">
            What Liverpool Businesses Say
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Real results from real Liverpool clients — from Baltic Triangle
            independents to city centre law firms. Local SEO works when it's
            built on genuine expertise and honest strategy.
          </p>
        </div>

        {/* Testimonial cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-14">
          {testimonials.map((t) => (
            <Card
              key={t.name}
              className="border border-border shadow-card hover-lift bg-card flex flex-col"
            >
              <CardContent className="p-6 md:p-8 flex flex-col h-full">
                {/* Stars */}
                <div className="flex gap-1 mb-4">
                  {Array.from({ length: t.rating }).map((_, i) => (
                    <Star
                      key={i}
                      className="h-4 w-4 fill-primary text-primary"
                    />
                  ))}
                </div>

                {/* Quote icon */}
                <Quote className="h-8 w-8 text-primary/20 mb-3" />

                {/* Quote text */}
                <p className="text-foreground leading-relaxed mb-6 flex-1 italic">
                  "{t.quote}"
                </p>

                {/* Author */}
                <div className="flex items-center gap-3 pt-4 border-t border-border">
                  <img
                    src={t.image}
                    alt={`${t.name}, ${t.role} at ${t.company}`}
                    width={48}
                    height={48}
                    className="h-12 w-12 rounded-full object-cover"
                    loading="lazy"
                  />
                  <div>
                    <p className="font-semibold text-foreground text-sm">
                      {t.name}
                    </p>
                    <p className="text-muted-foreground text-xs">{t.role}</p>
                    <p className="text-muted-foreground text-xs">
                      {t.company}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Trust stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 bg-muted rounded-xl p-8 border border-border">
          {[
            { stat: "94%", label: "Client retention rate" },
            { stat: "3.5×", label: "Average organic traffic lift" },
            { stat: "60+", label: "Liverpool businesses helped" },
            { stat: "Top 3", label: "Average local pack ranking" },
          ].map(({ stat, label }) => (
            <div key={label} className="text-center">
              <p className="text-3xl md:text-4xl font-bold text-foreground mb-1">
                {stat}
              </p>
              <p className="text-sm text-muted-foreground">{label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
});

LiverpoolTestimonials.displayName = "LiverpoolTestimonials";

export default LiverpoolTestimonials;
