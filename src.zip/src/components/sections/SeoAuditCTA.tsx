import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, CheckCircle } from "lucide-react";

const trustPoints = [
  "Independent assessment — not an automated tool report",
  "No agency pitch, no upsell, no obligation",
  "Delivered by a senior UK SEO consultant",
  "Actionable findings written in plain English",
];

const SeoAuditCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seo-audit-cta"
      className="relative py-20 md:py-32 border-t border-border bg-muted overflow-hidden"
    >
      {/* Subtle background texture — dot grid via CSS gradient, no external image */}
      <div
        className="absolute inset-0 pointer-events-none opacity-30"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(225 28% 14% / 0.18) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
        aria-hidden="true"
      />

      {/* Dark navy content band */}
      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div
          className="rounded-md overflow-hidden"
          style={{
            background:
              "linear-gradient(160deg, hsl(225 28% 14%) 0%, hsl(231 9% 16%) 60%, hsl(214 32% 22%) 100%)",
            boxShadow: "0 8px 48px hsl(225 28% 8% / 0.45)",
          }}
        >
          <div className="px-8 py-14 md:px-16 md:py-20">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">

              {/* Left column — headline and copy */}
              <motion.div
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.65, ease: "easeOut" }}
              >
                {/* Eyebrow */}
                <span className="inline-block text-xs uppercase tracking-[0.2em] font-medium text-white/80 mb-5">
                  Free SEO Audit
                </span>

                {/* Headline */}
                <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight max-w-lg">
                  Request a Free SEO Audit
                </h2>

                {/* Subheadline */}
                <p className="mt-5 text-base md:text-lg text-white/80 max-w-md leading-relaxed">
                  Find out where your site stands. No obligation, no agency pitch — just an honest independent assessment.
                </p>

                {/* CTA button */}
                <div className="mt-10">
                  <Button
                    size="lg"
                    asChild
                    className="text-base font-semibold h-12 px-8 rounded-md border-0"
                    style={{
                      background:
                        "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                      color: "hsl(225 28% 10%)",
                      boxShadow: "0 0 0 0 hsl(84 74% 58% / 0)",
                      transition:
                        "box-shadow 0.3s ease, transform 0.2s ease",
                    }}
                    onMouseEnter={(e) => {
                      const el = e.currentTarget as HTMLElement;
                      el.style.boxShadow =
                        "0 0 32px hsl(84 74% 58% / 0.28)";
                      el.style.transform = "translateY(-1px)";
                    }}
                    onMouseLeave={(e) => {
                      const el = e.currentTarget as HTMLElement;
                      el.style.boxShadow =
                        "0 0 0 0 hsl(84 74% 58% / 0)";
                      el.style.transform = "translateY(0)";
                    }}
                  >
                    <Link to="/contact" className="flex items-center gap-2">
                      Get Your Free Audit
                      <ArrowRight className="h-4 w-4" />
                    </Link>
                  </Button>
                </div>

                {/* Reassurance line */}
                <p className="mt-4 text-sm text-white/80">
                  Typically responded to within one business day.
                </p>
              </motion.div>

              {/* Right column — trust checklist */}
              <motion.div
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.65, ease: "easeOut", delay: 0.15 }}
              >
                <p className="text-xs uppercase tracking-[0.18em] text-white/80 font-medium mb-6">
                  What you can expect
                </p>
                <ul className="space-y-4">
                  {trustPoints.map((point, i) => (
                    <motion.li
                      key={i}
                      className="flex items-start gap-3"
                      initial={{ opacity: 0, x: 16 }}
                      whileInView={{ opacity: 1, x: 0 }}
                      viewport={{ once: true }}
                      transition={{
                        duration: 0.5,
                        ease: "easeOut",
                        delay: 0.2 + i * 0.08,
                      }}
                    >
                      <CheckCircle
                        className="h-5 w-5 mt-0.5 flex-shrink-0"
                        style={{ color: "hsl(84 74% 58%)" }}
                        aria-hidden="true"
                      />
                      <span className="text-white/90 text-base leading-snug">
                        {point}
                      </span>
                    </motion.li>
                  ))}
                </ul>

                {/* Secondary link */}
                <div className="mt-10 pt-8 border-t border-white/10">
                  <p className="text-sm text-white/80 mb-3">
                    Want to learn more about what the audit covers first?
                  </p>
                  <Button
                    variant="ghost"
                    asChild
                    className="p-0 h-auto text-sm font-medium text-white/90 hover:text-white hover:bg-transparent underline underline-offset-4 decoration-white/30 hover:decoration-white/80 transition-all"
                  >
                    <Link to="/seo-audit">
                      See what&apos;s included in a full SEO audit →
                    </Link>
                  </Button>
                </div>
              </motion.div>

            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

SeoAuditCTA.displayName = "SeoAuditCTA";

export default SeoAuditCTA;
