import React from "react";
import { motion } from "framer-motion";
import { Quote, MapPin, Building2, Section } from "lucide-react";

const testimonials = [
  {
    quote:
      "Gregg transformed our local search presence in under four months. We went from nowhere in the map pack to consistently appearing in the top three for our core search terms in Warrington. The enquiries coming through now are genuinely local — exactly the clients we want.",
    name: "Sarah Thornton",
    role: "Practice Manager",
    businessType: "Private Dental Clinic",
    location: "Warrington, Cheshire",
    image:
      "https://images.unsplash.com/photo-1681500920181-0aff411f8cab?w=400&h=400&fit=crop&crop=face",
  },
  {
    quote:
      "I was sceptical at first — we'd tried SEO before and seen little return. Gregg's approach was completely different: methodical, transparent, and focused on the things that actually move the needle for a local law firm. Our Google Business Profile now drives a steady flow of new client enquiries each week.",
    name: "Marcus Okafor",
    role: "Solicitor and Partner",
    businessType: "Litigation Law Firm",
    location: "Manchester",
    image:
      "https://images.unsplash.com/photo-1633625576932-348e73c45e82?w=400&h=400&fit=crop&crop=face",
  },
  {
    quote:
      "As an independent estate agent competing against national chains, local search visibility is everything. Gregg understood that immediately — no generic recommendations, just precise, considered work on our citations, schema, and on-page signals. Six months in and we're ranking above the nationals for our target postcodes.",
    name: "Claire Whitfield",
    role: "Director",
    businessType: "Independent Estate Agency",
    location: "Liverpool",
    image:
      "https://images.unsplash.com/photo-1710778044102-56a3a6b69a1b?w=400&h=400&fit=crop&crop=face",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.18,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut" },
  },
};

const LocalSeoTestimonials = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="local-seo-testimonials"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
      style={{
        background:
          "linear-gradient(180deg, hsl(225 28% 14%) 0%, hsl(231 9% 16%) 100%)",
      }}
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mb-12 md:mb-16"
        >
          <span className="inline-block text-xs uppercase tracking-[0.22em] text-white/60 mb-4 font-medium">
            Client Testimonials
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-white font-[Sora,sans-serif] max-w-xl">
            What Clients Say
          </h2>
          <p className="mt-3 text-white/80 text-base max-w-prose leading-relaxed">
            Independent feedback from UK businesses I've helped improve their
            local search visibility.
          </p>
        </motion.div>

        {/* Testimonial cards */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8"
        >
          {testimonials.map((t, i) => (
            <motion.div
              key={i}
              variants={cardVariants}
              className="relative flex flex-col rounded-md border border-white/10 bg-white/5 p-7 md:p-8"
              style={{
                backdropFilter: "blur(6px)",
              }}
            >
              {/* Opening quote mark */}
              <Quote
                className="h-7 w-7 text-white/20 mb-5 shrink-0"
                aria-hidden="true"
              />

              {/* Pull quote */}
              <blockquote className="flex-1">
                <p className="text-white/85 text-sm md:text-base leading-relaxed font-light italic">
                  &ldquo;{t.quote}&rdquo;
                </p>
              </blockquote>

              {/* Divider */}
              <div className="mt-6 mb-5 h-px bg-white/10" />

              {/* Attribution */}
              <div className="flex items-center gap-4">
                <img
                  src={t.image}
                  alt={`Portrait of ${t.name}`}
                  width={48}
                  height={48}
                  className="h-12 w-12 rounded-full object-cover shrink-0 ring-2 ring-white/10"
                />
                <div className="min-w-0">
                  <p className="text-white text-sm font-semibold truncate">
                    {t.name}
                  </p>
                  <p className="text-white/70 text-xs mt-0.5 flex items-center gap-1 truncate">
                    <Building2
                      className="h-3 w-3 shrink-0 text-white/50"
                      aria-hidden="true"
                    />
                    {t.role}, {t.businessType}
                  </p>
                  <p className="text-white/60 text-xs mt-0.5 flex items-center gap-1 truncate">
                    <MapPin
                      className="h-3 w-3 shrink-0 text-white/50"
                      aria-hidden="true"
                    />
                    {t.location}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
});

LocalSeoTestimonials.displayName = "LocalSeoTestimonials";

export default LocalSeoTestimonials;
