import React from "react";
import { Building2, TrendingUp, Users, Target, Globe, Zap, Bold, Construction, Section } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const stats = [
  { value: "£14B+", label: "Annual GVA", description: "Liverpool city region economy" },
  { value: "50k+", label: "Businesses", description: "Registered across Merseyside" },
  { value: "1.6M", label: "Population", description: "Liverpool city region" },
  { value: "Top 5", label: "UK City Region", description: "By economic output" },
];

const sectors = [
  {
    icon: Building2,
    title: "Professional Services",
    description: "Law firms, accountants, and consultancies competing for high-value Liverpool clients online.",
  },
  {
    icon: Globe,
    title: "Tourism & Hospitality",
    description: "Hotels, restaurants, and attractions vying for visitors to one of the UK's most visited cities.",
  },
  {
    icon: TrendingUp,
    title: "Retail & E-commerce",
    description: "From Liverpool ONE anchor stores to independent boutiques on Bold Street — fierce search competition.",
  },
  {
    icon: Users,
    title: "Health & Wellness",
    description: "Private clinics, dental practices, and fitness studios competing for local patients and clients.",
  },
  {
    icon: Target,
    title: "Tech & Digital",
    description: "Liverpool's growing tech scene with startups and agencies competing nationally from a Merseyside base.",
  },
  {
    icon: Zap,
    title: "Construction & Trades",
    description: "Builders, electricians, and contractors needing strong local visibility in every Liverpool postcode.",
  },
];

const LiverpoolEcosystem = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="liverpool-ecosystem"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
      aria-label="Liverpool business ecosystem"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-2xl mb-16">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Liverpool Market
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">
            Understanding the Liverpool SEO Landscape
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Liverpool's economy is diverse, competitive, and growing fast. Businesses across every sector are investing in digital presence — which means organic search competition is intensifying. Here's what you're up against, and how we help you win.
          </p>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-16">
          {stats.map((stat) => (
            <div
              key={stat.value}
              className="bg-background rounded-xl p-6 text-center shadow-card border border-border"
            >
              <div className="text-3xl md:text-4xl font-bold text-primary mb-1">{stat.value}</div>
              <div className="text-sm font-semibold text-foreground mb-1">{stat.label}</div>
              <div className="text-xs text-muted-foreground">{stat.description}</div>
            </div>
          ))}
        </div>

        {/* Sectors grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sectors.map((sector) => {
            const Icon = sector.icon;
            return (
              <Card
                key={sector.title}
                className="border border-border bg-background shadow-card hover-lift transition-all duration-300"
              >
                <CardContent className="p-6">
                  <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-4">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">{sector.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">{sector.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Internal link */}
        <div className="mt-12 text-center">
          <p className="text-muted-foreground">
            Serving all Liverpool postcodes.{" "}
            <a href="/locations" className="text-primary font-medium hover:underline">
              See all UK locations →
            </a>
          </p>
        </div>
      </div>
    </section>
  );
});

LiverpoolEcosystem.displayName = "LiverpoolEcosystem";

export default LiverpoolEcosystem;
