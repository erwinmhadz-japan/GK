import React from "react";
import { motion } from "framer-motion";
import { Target, Search, Layers, Lightbulb, SlidersHorizontal, CheckCircle, Cross, Section } from "lucide-react";

const pillars = [
  {
    icon: Search,
    title: "Diagnostic Assessment",
    body:
      "I begin by examining your current organic performance — technical health, keyword positioning, content quality, and competitive landscape. The goal is an honest, evidence-based picture of where you stand.",
  },
  {
    icon: Target,
    title: "Strategic Prioritisation",
    body:
      "Not all SEO work carries equal weight. I translate diagnostic findings into a ranked action plan, focusing effort on the changes most likely to move commercial needles for your specific market.",
  },
  {
    icon: Layers,
    title: "Cross-Channel Recommendations",
    body:
      "Effective SEO intersects with content, UX, technical infrastructure, and off-site authority. Consulting surfaces the full picture — not just isolated fixes — so your investment compounds over time.",
  },
  {
    icon: SlidersHorizontal,
    title: "Implementation Guidance",
    body:
      "Whether you have an in-house developer, a content team, or neither, I work alongside your existing resources to ensure recommendations are executed correctly and with context.",
  },
  {
    icon: Lightbulb,
    title: "Ongoing Strategic Clarity",
    body:
      "Search changes constantly. A consulting relationship keeps your strategy current — I review performance, adjust priorities, and ensure your team always understands the 'why' behind each decision.",
  },
  {
    icon: CheckCircle,
    title: "Accountability & Reporting",
    body:
      "I translate organic data into business language. Regular reporting focuses on meaningful metrics — leads, revenue-generating traffic, and ranking movement for terms that actually matter to your pipeline.",
  },
];

const distinguishers = [
  {
    label: "Consulting vs. Retainer",
    detail:
      "A retainer is ongoing managed SEO work — I execute alongside you each month. Consulting is advisory: I diagnose, strategise, and guide your team without taking on the day-to-day implementation.",
  },
  {
    label: "Consulting vs. Audit",
    detail:
      "An audit is a defined, one-time deliverable capturing your site's current state. Consulting is continuous and adaptive — it begins where an audit ends and evolves with your business objectives.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const SEOConsultingWhatItIs = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seoconsulting-what-it-is"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.65, ease: "easeOut" }}
          className="mb-14 md:mb-18 max-w-2xl"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            What I do
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-5 leading-tight">
            What SEO Consulting Involves
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
            SEO consulting is a strategic, advisory engagement — not a task list. Working
            directly with me as an independent SEO consultant, you gain clarity on where your
            organic performance stands, which priorities genuinely matter for your business, and
            how to execute changes that hold up under algorithm shifts and competitive pressure.
          </p>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed mt-4">
            There are no account managers or juniors involved. Every analysis, every recommendation,
            and every conversation comes directly from me — a specialist with experience across
            competitive UK markets including law, finance, healthcare, and professional services.
          </p>
        </motion.div>

        {/* Pillars grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16 md:mb-20"
        >
          {pillars.map((pillar) => {
            const Icon = pillar.icon;
            return (
              <motion.div
                key={pillar.title}
                variants={itemVariants}
                className="group rounded-md border border-border bg-background p-6 transition-all duration-300 hover:shadow-md hover:-translate-y-0.5"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mb-4">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="text-base font-semibold text-foreground mb-2">
                  {pillar.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {pillar.body}
                </p>
              </motion.div>
            );
          })}
        </motion.div>

        {/* How it differs — editorial prose block */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.65, ease: "easeOut" }}
          className="border-t border-border pt-12 md:pt-16"
        >
          <div className="max-w-3xl">
            <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
              Understanding the difference
            </span>
            <h3 className="text-xl md:text-2xl font-bold text-foreground mb-6">
              Consulting Versus Other Engagements
            </h3>
            <p className="text-base text-muted-foreground leading-relaxed mb-8">
              Clients sometimes ask how consulting sits alongside my other services. The
              distinction matters — both practically and commercially — so it is worth
              stating plainly.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-4xl">
            {distinguishers.map((item, i) => (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, y: 18 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.5, ease: "easeOut", delay: i * 0.1 }}
                className="rounded-md border border-border bg-muted/40 p-6"
              >
                <p className="text-xs uppercase tracking-[0.18em] text-primary font-semibold mb-2">
                  {item.label}
                </p>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {item.detail}
                </p>
              </motion.div>
            ))}
          </div>

          {/* Closing note — no CTA block, just a soft prose anchor */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true, margin: "-40px" }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.2 }}
            className="mt-10 text-sm text-muted-foreground max-w-2xl leading-relaxed"
          >
            If you are unsure which engagement suits your situation, I am happy to discuss
            it. Most conversations start the same way — with an honest look at where your
            SEO currently stands and what a realistic improvement looks like for your
            business. You can{" "}
            <a
              href="#seoconsulting-cta"
              className="text-foreground underline underline-offset-4 hover:text-primary transition-colors duration-200"
            >
              get in touch below
            </a>{" "}
            at no obligation.
          </motion.p>
        </motion.div>
      </div>
    </section>
  );
});

SEOConsultingWhatItIs.displayName = "SEOConsultingWhatItIs";

export default SEOConsultingWhatItIs;
