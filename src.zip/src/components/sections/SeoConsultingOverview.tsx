import React from "react";
import { motion } from "framer-motion";
import { CheckCircle, UserCheck, MessageSquare, Target, Clock, ArrowRight, Shield, TrendingUp, Section } from "lucide-react";
import { Link } from "react-router-dom";

const engagementSteps = [
  {
    number: "01",
    icon: MessageSquare,
    heading: "Initial Consultation",
    body: "Every engagement begins with a direct conversation — no discovery forms or junior account managers. Gregg takes the time to understand your commercial goals, existing SEO position, and competitive landscape before any work begins.",
  },
  {
    number: "02",
    icon: Target,
    heading: "Strategic Diagnosis",
    body: "A structured review of your site's technical health, content quality, authority profile, and search visibility. Findings are mapped to business outcomes, not vanity metrics. You receive a clear picture of where you stand and what the priorities are.",
  },
  {
    number: "03",
    icon: TrendingUp,
    heading: "Consulting Engagement",
    body: "Work progresses directly with you — or alongside your in-house team or developer — with no delegation to junior staff. Scope is defined clearly at the outset, whether that is a one-off audit, a retainer, or a focused technical engagement.",
  },
  {
    number: "04",
    icon: CheckCircle,
    heading: "Measurable Progress",
    body: "Reporting focuses on what matters: organic visibility, qualified traffic, and lead quality. You have direct access to Gregg for questions, updates, and strategic decisions throughout the engagement.",
  },
];

const differentiators = [
  {
    icon: UserCheck,
    label: "Direct access",
    detail: "You work with Gregg directly — not with an account manager relaying messages to a team you never meet.",
  },
  {
    icon: Shield,
    label: "Senior expertise",
    detail: "Every piece of strategic and technical work is carried out at senior level, without delegation or oversight gaps.",
  },
  {
    icon: Clock,
    label: "Clear scope",
    detail: "Engagements are structured and transparent. Scope, deliverables, and timelines are agreed before work begins.",
  },
  {
    icon: Target,
    label: "Commercial focus",
    detail: "The objective is always business growth — not rankings for their own sake. Strategy is shaped by your commercial priorities.",
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay: i * 0.1 },
  }),
};

const SeoConsultingOverview = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seo-consulting-overview"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={fadeUp}
          custom={0}
          className="max-w-2xl mb-16 md:mb-20"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            How it works
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground font-[Sora] leading-tight mb-4">
            A consulting engagement built around your business
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-prose">
            Working with an independent SEO consultant means the engagement is structured around your objectives — not an agency billing model. From the first conversation to ongoing delivery, Gregg works with you directly at every stage.
          </p>
        </motion.div>

        {/* Engagement process steps */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-20 md:mb-28">
          {engagementSteps.map((step, i) => {
            const Icon = step.icon;
            return (
              <motion.div
                key={step.number}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-60px" }}
                variants={fadeUp}
                custom={i + 1}
                className="group relative bg-background border border-border rounded-md p-6 md:p-8 flex gap-5 hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%/0.10),_0_1px_4px_hsl(222_28%_11%/0.05)] transition-shadow duration-300"
              >
                {/* Step number — subtle background */}
                <span
                  aria-hidden="true"
                  className="absolute top-4 right-5 text-4xl font-bold text-muted-foreground/10 select-none font-[Sora] leading-none"
                >
                  {step.number}
                </span>

                {/* Icon */}
                <div className="flex-shrink-0 mt-0.5">
                  <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                </div>

                {/* Content */}
                <div>
                  <h3 className="text-base md:text-lg font-semibold text-foreground mb-2 font-[Sora]">
                    {step.heading}
                  </h3>
                  <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                    {step.body}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Divider */}
        <div className="border-t border-border mb-20 md:mb-28" />

        {/* Independent model vs agency — two-column layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-start mb-20 md:mb-28">

          {/* Left: explanatory copy */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={fadeUp}
            custom={0}
          >
            <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
              The independent model
            </span>
            <h2 className="text-2xl md:text-3xl font-bold text-foreground font-[Sora] leading-tight mb-5">
              What you can expect from an independent consulting engagement
            </h2>
            <div className="space-y-4 text-base text-muted-foreground leading-relaxed">
              <p>
                Agency retainers are built around staffing models. Work is distributed across account managers, executives, and specialists — often without any single person holding full strategic oversight. The senior person you met in the pitch may rarely, if ever, work on your account.
              </p>
              <p>
                An independent consultant operates differently. There is no account management layer, no internal handoffs, and no junior resource carrying out senior-level work. Gregg is the person who audits your site, shapes the strategy, and executes or guides the implementation — directly accountable at every stage.
              </p>
              <p>
                This structure suits UK businesses in competitive sectors where strategic coherence and direct accountability matter: law firms, healthcare providers, financial services, and property businesses, among others.
              </p>
            </div>

            <div className="mt-8">
              <Link
                to="/about"
                className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors duration-200"
              >
                About Gregg King
                <ArrowRight className="h-4 w-4" />
              </Link>
            </div>
          </motion.div>

          {/* Right: differentiator list */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={fadeUp}
            custom={1}
            className="space-y-5"
          >
            {differentiators.map((item, i) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.label}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  variants={fadeUp}
                  custom={i + 2}
                  className="flex gap-4 p-5 bg-background border border-border rounded-md hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%/0.10),_0_1px_4px_hsl(222_28%_11%/0.05)] transition-shadow duration-300"
                >
                  <div className="flex-shrink-0 mt-0.5">
                    <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10">
                      <Icon className="h-4 w-4 text-primary" />
                    </div>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground mb-1 font-[Sora]">{item.label}</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{item.detail}</p>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        </div>

        {/* Outcomes callout — subtle highlight band */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={fadeUp}
          custom={0}
          className="bg-muted border border-border rounded-md px-8 py-10 md:py-12"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-3 font-medium">
                Outcomes
              </span>
              <h3 className="text-xl md:text-2xl font-bold text-foreground font-[Sora] leading-snug">
                What a well-structured SEO engagement delivers
              </h3>
            </div>
            <div className="md:col-span-2 grid grid-cols-1 sm:grid-cols-2 gap-6">
              {[
                {
                  heading: "Sustainable organic growth",
                  body: "Improved rankings built on technical soundness, content quality, and genuine authority — not tactics that degrade over time.",
                },
                {
                  heading: "Qualified search visibility",
                  body: "Visibility for search queries that reflect genuine buyer intent in your sector — not broad traffic that fails to convert.",
                },
                {
                  heading: "Strategic clarity",
                  body: "A coherent SEO roadmap that aligns with your commercial priorities, giving your team clear direction and measurable milestones.",
                },
                {
                  heading: "Reduced dependency on paid channels",
                  body: "A stronger organic presence that reduces the cost-per-acquisition burden of paid search and reduces reliance on platform volatility.",
                },
              ].map((outcome, i) => (
                <div key={outcome.heading} className="flex gap-3">
                  <CheckCircle className="h-4 w-4 text-primary flex-shrink-0 mt-1" />
                  <div>
                    <p className="text-sm font-semibold text-foreground mb-1 font-[Sora]">{outcome.heading}</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{outcome.body}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </motion.div>

      </div>
    </section>
  );
});

SeoConsultingOverview.displayName = "SeoConsultingOverview";

export default SeoConsultingOverview;
