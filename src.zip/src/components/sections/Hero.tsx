import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ImageBackground } from "@/components/ImageBackground";
import { ArrowRight, CheckCircle, Contact, Key, Search } from "lucide-react";

const Hero = React.forwardRef<HTMLElement>((props, ref) => {
  const trustPoints = [
    "Independent consultant — not an agency",
    "Law, finance, healthcare & property specialists",
    "National reach from Warrington, Cheshire",
  ];

  return (
    <ImageBackground
      ref={ref}
      id="hero"
      aria-label="Hero section"
      src="https://images.unsplash.com/photo-1730851357916-3802b6405271?w=1920&h=1080&fit=crop"
      alt="Professional consultant in a suit standing in an office, representing senior independent expertise"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[90vh] md:min-h-screen flex items-center"
    >
      {/* Gradient reinforcement layer — deeper navy tint left-to-right to create panel feel */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "linear-gradient(105deg, hsl(225 28% 8% / 0.82) 0%, hsl(225 28% 14% / 0.60) 55%, hsl(225 28% 18% / 0.30) 100%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10 py-24 md:py-36">
        <div className="max-w-3xl">

          {/* Eyebrow label */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0 }}
          >
            <span
              className="inline-block text-xs uppercase tracking-[0.22em] font-medium mb-5"
              style={{ color: "hsl(var(--green-mid))" }}
            >
              SEO Consultant UK
            </span>
          </motion.div>

          {/* H1 — primary keyword exact */}
          <motion.h1
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.10 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight tracking-tight"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Independent SEO{" "}
            <span
              style={{
                background: "var(--gradient-cta)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              Consultant
            </span>{" "}
            UK
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.20 }}
            className="mt-5 text-lg md:text-xl text-white/90 leading-relaxed max-w-2xl"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Independent{" "}
            <Link
              to="/services"
              className="underline underline-offset-2 decoration-white/40 hover:decoration-white/80 transition-all duration-200"
            >
              SEO consulting services
            </Link>{" "}
            for UK businesses that compete in trust-led, high-value sectors.
          </motion.p>

          {/* Trust points */}
          <motion.ul
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.60, ease: "easeOut", delay: 0.30 }}
            className="mt-7 flex flex-col sm:flex-row flex-wrap gap-x-6 gap-y-2.5"
            aria-label="Key credentials"
          >
            {trustPoints.map((point) => (
              <li
                key={point}
                className="flex items-center gap-2 text-sm text-white/80"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                <CheckCircle
                  className="h-4 w-4 flex-shrink-0"
                  style={{ color: "hsl(var(--green-mid))" }}
                />
                {point}
              </li>
            ))}
          </motion.ul>

          {/* CTA buttons */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.60, ease: "easeOut", delay: 0.40 }}
            className="mt-9 flex flex-col sm:flex-row items-start sm:items-center gap-3"
          >
            {/* Primary CTA — "Contact Me" (verbatim) */}
            <Button
              asChild
              size="lg"
              className="h-12 px-8 text-base font-semibold text-[hsl(var(--primary-foreground))] border-0 transition-all duration-300 hover:opacity-90"
              style={{
                background: "var(--gradient-cta)",
                boxShadow: "var(--shadow-green-glow)",
                fontFamily: "Inter, sans-serif",
              }}
            >
              <Link to="/contact" className="flex items-center gap-2">
                Contact Me
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>

            {/* Secondary CTA — "FREE SEO AUDIT" (verbatim) */}
            <Button
              asChild
              size="lg"
              variant="outline"
              className="h-12 px-8 text-base font-semibold bg-transparent text-white border-white/40 hover:bg-white/10 hover:border-white/70 transition-all duration-300"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              <Link to="/contact">FREE SEO AUDIT</Link>
            </Button>
          </motion.div>

          {/* Contextual site links */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.50 }}
            className="mt-6 flex flex-wrap items-center gap-x-5 gap-y-2"
            aria-label="Quick links"
          >
            <Link
              to="/ai-search-optimisation"
              className="text-xs text-white/55 hover:text-white/90 transition-colors duration-200 flex items-center gap-1"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              <ArrowRight className="h-3 w-3" aria-hidden="true" />
              AI Search Optimisation
            </Link>
            <Link
              to="#industries-cta"
              className="text-xs text-white/55 hover:text-white/90 transition-colors duration-200 flex items-center gap-1"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              <ArrowRight className="h-3 w-3" aria-hidden="true" />
              Industry Sectors
            </Link>
            <Link
              to="/locations"
              className="text-xs text-white/55 hover:text-white/90 transition-colors duration-200 flex items-center gap-1"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              <ArrowRight className="h-3 w-3" aria-hidden="true" />
              UK Locations
            </Link>
          </motion.div>

          {/* Contact details strip */}
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.70, ease: "easeOut", delay: 0.54 }}
            className="mt-10 pt-8 border-t border-white/15 flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-7"
          >
            <a
              href="tel:01925214707"
              className="text-sm text-white/80 hover:text-white transition-colors duration-200 flex items-center gap-2"
              style={{ fontFamily: "Inter, sans-serif" }}
              aria-label="Call Gregg King on 01925 214707"
            >
              <span
                className="text-xs uppercase tracking-widest font-medium"
                style={{ color: "hsl(var(--blue-muted))" }}
              >
                Tel
              </span>
              01925 214707
            </a>
            <span className="hidden sm:block text-white/20" aria-hidden="true">
              /
            </span>
            <a
              href="mailto:gregg@greggking.co.uk"
              className="text-sm text-white/80 hover:text-white transition-colors duration-200 flex items-center gap-2"
              style={{ fontFamily: "Inter, sans-serif" }}
              aria-label="Email Gregg King at gregg@greggking.co.uk"
            >
              <span
                className="text-xs uppercase tracking-widest font-medium"
                style={{ color: "hsl(var(--blue-muted))" }}
              >
                Email
              </span>
              gregg@greggking.co.uk
            </a>
            <span className="hidden sm:block text-white/20" aria-hidden="true">
              /
            </span>
            <span
              className="text-sm text-white/80 flex items-center gap-2"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              <span
                className="text-xs uppercase tracking-widest font-medium"
                style={{ color: "hsl(var(--blue-muted))" }}
              >
                Gregg King
              </span>
              Warrington, Cheshire
            </span>
          </motion.div>
        </div>
      </div>

      {/* Bottom fade-out to page background */}
      <div
        className="absolute bottom-0 left-0 right-0 h-28 pointer-events-none"
        style={{
          background:
            "linear-gradient(to bottom, transparent 0%, hsl(0 0% 99% / 0.04) 100%)",
        }}
        aria-hidden="true"
      />
    </ImageBackground>
  );
});

Hero.displayName = "Hero";

export default Hero;
