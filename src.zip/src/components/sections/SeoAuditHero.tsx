import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { CheckCircle, FileSearch, ArrowRight } from "lucide-react";

const SeoAuditHero = React.forwardRef<HTMLElement>((props, ref) => {
  const auditPoints = [
    "Technical SEO",
    "On-page & content",
    "Authority & backlinks",
    "Schema & entity",
    "AI search visibility",
  ];

  return (
    <section
      ref={ref}
      id="seo-audit-hero"
      className="relative isolate overflow-hidden border-t border-border bg-[hsl(225_28%_14%)]"
      style={{ minHeight: "85vh" }}
      aria-label="SEO Audit hero"
    >
      {/* Subtle dot-grid texture overlay */}
      <div
        aria-hidden="true"
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(214 32% 60% / 0.12) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      {/* Bottom gradient fade to next section */}
      <div
        aria-hidden="true"
        className="absolute bottom-0 left-0 right-0 h-24 pointer-events-none"
        style={{
          background:
            "linear-gradient(to bottom, transparent, hsl(225 28% 14% / 0.6))",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10 flex flex-col justify-center"
        style={{ paddingTop: "clamp(5rem, 12vw, 9rem)", paddingBottom: "clamp(4rem, 10vw, 7rem)" }}
      >
        <div className="max-w-3xl">
          {/* Eyebrow badge */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0 }}
            className="mb-6 flex flex-wrap items-center gap-3"
          >
            <Badge
              variant="outline"
              className="text-xs uppercase tracking-[0.18em] font-medium border-[hsl(119_35%_61%/0.5)] text-[hsl(119_35%_61%)] bg-[hsl(119_35%_61%/0.08)] px-3 py-1"
            >
              FREE GBP AUDIT
            </Badge>
            <span className="text-[hsl(214_32%_60%)] text-xs uppercase tracking-[0.15em] font-medium">
              Independent SEO Consultant UK
            </span>
          </motion.div>

          {/* H1 — owns 'SEO Audit UK' keyword */}
          <motion.h1
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-[1.1] tracking-tight mb-6"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            SEO Audit UK
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.2 }}
            className="text-lg md:text-xl text-[hsl(214_32%_72%)] leading-relaxed mb-8 max-w-2xl"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            A thorough, independent SEO audit that shows exactly where your site is losing visibility — and what to do about it.
          </motion.p>

          {/* Audit scope pills */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
            className="flex flex-wrap gap-2 mb-10"
            aria-label="Audit coverage areas"
          >
            {auditPoints.map((point, i) => (
              <span
                key={point}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-white/80 bg-white/8 border border-white/12 rounded-md px-3 py-1.5"
                style={{ animationDelay: `${0.35 + i * 0.06}s` }}
              >
                <CheckCircle className="h-3.5 w-3.5 text-[hsl(84_74%_60%)] shrink-0" />
                {point}
              </span>
            ))}
          </motion.div>

          {/* CTA row */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.42 }}
            className="flex flex-col sm:flex-row items-start sm:items-center gap-4"
          >
            <Button
              asChild
              size="lg"
              className="h-12 px-8 text-base font-semibold rounded-md transition-all duration-300 hover:shadow-[0_0_32px_hsl(84_74%_58%/0.3)]"
              style={{
                background: "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                color: "hsl(225 28% 14%)",
              }}
            >
              <Link to="/contact">
                Request Your Audit
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>

            <span className="text-sm text-white/80 flex items-center gap-2">
              <FileSearch className="h-4 w-4 text-[hsl(214_32%_60%)] shrink-0" />
              No obligation — just an honest, independent assessment
            </span>
          </motion.div>

          {/* Trust strip */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.7, ease: "easeOut", delay: 0.58 }}
            className="mt-8 text-xs text-white/80 tracking-wide"
          >
            Conducted by Gregg King — independent SEO consultant, Warrington, Cheshire
          </motion.p>
        </div>
      </div>
    </section>
  );
});

SeoAuditHero.displayName = "SeoAuditHero";

export default SeoAuditHero;
