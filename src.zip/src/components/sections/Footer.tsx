import React from "react";
import { Link } from "react-router-dom";
import { Mail, Phone, MapPin, Linkedin, Twitter, Globe, Contact, Search } from "lucide-react";
import { Separator } from "@/components/ui/separator";

const Footer = React.forwardRef<HTMLElement>((props, ref) => {
  const servicesLinks = [
    { label: "SEO Consulting", to: "#seo-consulting-cta" },
    { label: "SEO Audit", to: "/seo-audit" },
    { label: "SEO Retainer", to: "/seo-retainer" },
    { label: "Technical SEO", to: "/technical-seo" },
    { label: "Schema Markup", to: "/schema-markup" },
    { label: "Entity SEO", to: "/entity-seo" },
    { label: "Content Strategy", to: "/content-strategy" },
    { label: "Local SEO", to: "/local-seo" },
    { label: "Digital PR", to: "/digital-pr" },
    { label: "AI Search Optimisation", to: "/ai-search-optimisation" },
  ];

  const companyLinks = [
    { label: "About", to: "/about" },
    { label: "Case Studies", to: "#case-studies-cta" },
    { label: "Insights", to: "#insights-cta" },
    { label: "Contact", to: "/contact" },
  ];

  const locationLinks = [
    { label: "Warrington", to: "/locations" },
    { label: "Manchester", to: "/locations" },
    { label: "Liverpool", to: "/locations" },
    { label: "Birmingham", to: "/locations" },
    { label: "Leeds", to: "/locations" },
    { label: "London", to: "/locations" },
  ];

  return (
    <footer
      ref={ref}
      id="footer"
      className="relative border-t border-border bg-[hsl(225_28%_14%)] text-white"
    >
      {/* Main footer grid */}
      <div className="container max-w-6xl mx-auto px-4 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">

          {/* Brand column */}
          <div className="lg:col-span-1 space-y-4">
            <div>
              <span className="text-lg font-semibold tracking-tight text-white font-[Sora,sans-serif]">
                Gregg King SEO
              </span>
              <p className="mt-1 text-xs text-white/60 uppercase tracking-widest font-medium">
                SEO Consultant UK
              </p>
            </div>
            <p className="text-sm text-white/70 leading-relaxed max-w-xs">
              Independent SEO consultant based in Warrington, Cheshire. I work
              with UK businesses in competitive, trust-led sectors to improve
              organic search visibility and drive qualified enquiries.
            </p>

            {/* Contact details */}
            <ul className="space-y-2 text-sm text-white/70 pt-2">
              <li>
                <a
                  href="tel:01925214707"
                  className="flex items-center gap-2 hover:text-white transition-colors"
                  aria-label="Call 01925 214707"
                >
                  <Phone className="h-4 w-4 text-[hsl(84_74%_60%)] shrink-0" />
                  01925 214707
                </a>
              </li>
              <li>
                <a
                  href="mailto:gregg@greggking.co.uk"
                  className="flex items-center gap-2 hover:text-white transition-colors"
                  aria-label="Email gregg@greggking.co.uk"
                >
                  <Mail className="h-4 w-4 text-[hsl(84_74%_60%)] shrink-0" />
                  gregg@greggking.co.uk
                </a>
              </li>
              <li className="flex items-start gap-2">
                <MapPin className="h-4 w-4 text-[hsl(84_74%_60%)] shrink-0 mt-0.5" />
                <address className="not-italic leading-snug">
                  22 Foxdale Court, Warrington WA4 5BS, Cheshire, GB
                </address>
              </li>
            </ul>

            {/* Social icons */}
            <div className="flex items-center gap-3 pt-1">
              <a
                href="https://www.linkedin.com/in/greggking"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Gregg King on LinkedIn"
                className="text-white/50 hover:text-[hsl(84_74%_60%)] transition-colors"
              >
                <Linkedin className="h-4 w-4" />
              </a>
              <a
                href="https://twitter.com/greggkingseo"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Gregg King on Twitter"
                className="text-white/50 hover:text-[hsl(84_74%_60%)] transition-colors"
              >
                <Twitter className="h-4 w-4" />
              </a>
              <a
                href="https://greggking.co.uk"
                target="_blank"
                rel="noopener noreferrer"
                aria-label="greggking.co.uk"
                className="text-white/50 hover:text-[hsl(84_74%_60%)] transition-colors"
              >
                <Globe className="h-4 w-4" />
              </a>
            </div>
          </div>

          {/* Services column */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-widest text-white/50">
              SEO Services
            </h4>
            <ul className="space-y-2">
              {servicesLinks.map((link) => (
                <li key={link.to + link.label}>
                  <Link
                    to={link.to}
                    className="text-sm text-white/70 hover:text-white transition-colors leading-snug"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Company column */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-widest text-white/50">
              About
            </h4>
            <ul className="space-y-2">
              {companyLinks.map((link) => (
                <li key={link.to + link.label}>
                  <Link
                    to={link.to}
                    className="text-sm text-white/70 hover:text-white transition-colors"
                  >
                    {link.label}
                  </Link>
                </li>
              ))}
            </ul>

            <div className="pt-4 space-y-3">
              <h4 className="text-xs font-semibold uppercase tracking-widest text-white/50">
                Locations
              </h4>
              <ul className="space-y-2">
                {locationLinks.map((link) => (
                  <li key={link.label}>
                    <Link
                      to={link.to}
                      className="text-sm text-white/70 hover:text-white transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Positioning note */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold uppercase tracking-widest text-white/50">
              Working With Me
            </h4>
            <p className="text-sm text-white/70 leading-relaxed">
              I provide senior-level SEO consultancy to UK businesses seeking
              measurable, sustainable organic growth. All work is carried out by
              me — not delegated to a junior team.
            </p>
            <p className="text-sm text-white/70 leading-relaxed">
              Sectors I specialise in: law &amp; legal services, healthcare
              &amp; private providers, finance, property, and other
              trust-critical industries.
            </p>
            <div className="pt-2">
              <Link
                to="/contact"
                className="inline-block text-sm font-medium text-[hsl(84_74%_60%)] hover:text-[hsl(84_74%_70%)] transition-colors underline-offset-4 hover:underline"
              >
                Start an enquiry →
              </Link>
            </div>
          </div>
        </div>

        {/* Bottom bar */}
        <Separator className="my-8 bg-white/10" />

        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 text-xs text-white/40">
          <p>
            © {new Date().getFullYear()} Gregg King SEO. All rights reserved.
            Independent SEO Consultant, Warrington, Cheshire, UK.
          </p>
          <p>
            <a
              href="https://greggking.co.uk"
              target="_blank"
              rel="noopener noreferrer"
              className="hover:text-white/70 transition-colors"
            >
              greggking.co.uk
            </a>
          </p>
        </div>
      </div>
    </footer>
  );
});

Footer.displayName = "Footer";

export default Footer;
