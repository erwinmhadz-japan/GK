import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, FileSearch, CheckCircle, MapPin } from "lucide-react";

const LocalSEOLocalSeoCTA = React.forwardRef<HTMLElement>((props, ref) => {
  const trustPoints = [
    {
      icon: MapPin,
      text: "Independent consultant based in Warrington, Cheshire",
    },
    {
      icon: FileSearch,
      text: "Free audit of your current local search visibility",
    },
    {
      icon: CheckCircle,
      text: "No agency overhead — direct consultancy, singular focus",
    },
  ];

  return (
    <section
      ref={ref}
      id="local-seolocal-seo-cta"
      className="relative py-20 md:py-32 border-t border-border overflow-hidden"
      style={{
        background:
          "linear-gradient(180deg, hsl(225 28% 14%) 0%, hsl(231 9% 16%) 100%)",
      }}
    >
      {/* Subtle dot-grid texture overlay */}
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.04]"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(84 74% 60%) 1px, transparent 1px)",
          backgroundSize: "32px 32px",
        }}
        aria-hidden="true"
      />

      {/* Subtle green glow accent — top right */}
      <div
        className="absolute -top-24 -right-24 w-96 h-96 rounded-full pointer-events-none"
        style={{
          background:
            "radial-gradient(circle, hsl(84 74% 60% / 0.08) 0%, transparent 70%)",
        }}
        aria-hidden="true"
      />

      {/* Subtle green glow accent — bottom left */}
      <div
        className="absolute -bottom-24 -left-24 w-80 h-80 rounded-full pointer-events-none"
        style={{
          background:
            "radial-gradient(circle, hsl(119 35% 61% / 0.07) 0%, transparent 70%)",
        }}
        aria-hidden="true"
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          {/* Eyebrow label */}
          <motion.span
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="inline-block text-xs uppercase tracking-[0.2em] font-medium mb-6"
            style={{ color: "hsl(84 74% 60%)" }}
          >
            Local SEO Consultancy
          </motion.span>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-6"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Ready to Rank Locally?
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.2 }}
            className="text-lg md:text-xl text-white/80 leading-relaxed mb-10 max-w-2xl mx-auto"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Get in touch for a conversation about your local SEO challenges, or
            request a free audit of your local search visibility.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12"
          >
            {/* Primary CTA */}
            <Button
              size="lg"
              asChild
              className="h-12 px-8 text-base font-semibold rounded-md transition-all duration-300 hover:shadow-[0_0_32px_hsl(84_74%_60%/0.35)] hover:scale-[1.02]"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 60%) 0%, hsl(119 35% 61%) 100%)",
                color: "hsl(225 28% 10%)",
                border: "none",
              }}
            >
              <Link to="/contact">
                Enquire About Local SEO
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>

            {/* Secondary CTA */}
            <Button
              size="lg"
              variant="outline"
              asChild
              className="h-12 px-8 text-base font-semibold rounded-md bg-transparent text-white border-white/30 hover:border-white/60 hover:bg-white/8 transition-all duration-300"
            >
              <Link to="/contact">
                <FileSearch className="mr-2 h-5 w-5" />
                Free SEO Audit
              </Link>
            </Button>
          </motion.div>

          {/* Trust reinforcement points */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.45 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-6 sm:gap-8"
          >
            {trustPoints.map((point, index) => {
              const Icon = point.icon;
              return (
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 8 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{
                    duration: 0.5,
                    ease: "easeOut",
                    delay: 0.5 + index * 0.1,
                  }}
                  className="flex items-center gap-2.5 text-sm text-white/80"
                  style={{ fontFamily: "Inter, sans-serif" }}
                >
                  <Icon
                    className="h-4 w-4 flex-shrink-0"
                    style={{ color: "hsl(84 74% 60%)" }}
                  />
                  <span>{point.text}</span>
                </motion.div>
              );
            })}
          </motion.div>
        </div>
      </div>
    </section>
  );
});

LocalSEOLocalSeoCTA.displayName = "LocalSEOLocalSeoCTA";

export default LocalSEOLocalSeoCTA;
