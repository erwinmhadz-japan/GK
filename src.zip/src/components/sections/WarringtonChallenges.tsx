import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowRight, ShieldCheck, Phone } from "lucide-react";

const challenges = [
  {
    number: "01",
    title: "Invisible in the Local Pack",
    detail:
      "Many Warrington businesses have a Google Business Profile but it's poorly optimised — missing categories, thin descriptions, no review strategy. Without these signals, Google won't surface you in the three-pack results where the majority of local clicks land.",
  },
  {
    number: "02",
    title: "Duplicate & Inconsistent Citations",
    detail:
      "NAP (Name, Address, Phone) inconsistencies across directories — Yell, Yelp, Thomson, local Warrington directories — confuse search engines and dilute your local authority. Auditing and correcting citations is a foundational, often overlooked, local SEO task.",
  },
  {
    number: "03",
    title: "Thin or Generic Content",
    detail:
      "Pages that talk about 'great service' without mentioning Warrington, Cheshire, or specific service areas give Google no geographic anchor. Location-specific content is essential for ranking in town-level and neighbourhood-level queries.",
  },
  {
    number: "04",
    title: "Slow Mobile Performance",
    detail:
      "Google's ranking algorithm prioritises Core Web Vitals. A slow, clunky mobile experience doesn't just frustrate users — it actively suppresses your local rankings. Many Warrington SMEs are losing positions due to avoidable technical debt.",
  },
  {
    number: "05",
    title: "No Review Acquisition Strategy",
    detail:
      "Reviews are one of the most powerful local ranking signals. Businesses relying on organic, unsolicited reviews are outcompeted by those with a systematic approach to earning genuine 5-star feedback from Warrington customers.",
  },
  {
    number: "06",
    title: "Competing With National Aggregators",
    detail:
      "Directories like Checkatrade, Bark, and Rated People dominate many local Warrington search categories. A targeted local SEO strategy builds enough authority to compete alongside these aggregators — and win direct-contact conversions.",
  },
];

const WarringtonChallenges = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Sticky header column */}
          <div className="lg:col-span-4 lg:sticky lg:top-24">
            <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
              Common SEO Challenges
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Why Warrington Businesses Struggle to Rank Locally
            </h2>
            <p className="text-base text-muted-foreground leading-relaxed mb-8">
              Most local SEO problems are fixable — but you have to know
              what's causing them. These are the six most common barriers
              holding Warrington businesses back from top local rankings.
            </p>
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold w-full sm:w-auto"
              asChild
            >
              <a href="/contact">
                Diagnose My Site
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <div className="mt-6 flex items-start gap-2.5">
              <ShieldCheck className="h-5 w-5 text-primary shrink-0 mt-0.5" />
              <p className="text-sm text-muted-foreground">
                Free initial SEO audit with every enquiry — no obligation.
              </p>
            </div>
          </div>

          {/* Challenges list */}
          <div className="lg:col-span-8 space-y-5">
            {challenges.map(({ number, title, detail }) => (
              <div
                key={number}
                className="flex gap-5 p-6 rounded-xl border border-border bg-card shadow-soft hover-lift transition-shadow"
              >
                <span className="text-3xl font-bold text-primary/20 leading-none shrink-0 select-none font-mono">
                  {number}
                </span>
                <div>
                  <h3 className="text-base font-semibold text-foreground mb-2">
                    {title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {detail}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
});

WarringtonChallenges.displayName = "WarringtonChallenges";

export default WarringtonChallenges;
