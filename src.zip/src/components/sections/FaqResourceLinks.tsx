import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";
import { ArrowRight, BookOpen, Globe, Search, Target, Zap, Shield, Section } from "lucide-react";

const resources = [
  {
    icon: Search,
    title: "SEO Consulting",
    description:
      "Independent, senior-level SEO consultancy for UK businesses. Strategy, execution, and honest reporting — all in one.",
    href: "#seo-consulting-cta",
    cta: "Explore SEO Consulting",
  },
  {
    icon: Shield,
    title: "Technical SEO",
    description:
      "Comprehensive technical audits and fixes that remove the barriers stopping search engines from crawling and ranking your site.",
    href: "/technical-seo",
    cta: "Explore Technical SEO",
  },
  {
    icon: Globe,
    title: "AI Search Optimisation",
    description:
      "Optimise your brand's visibility in ChatGPT, Perplexity, Google AI Overviews, Gemini, and Copilot.",
    href: "/ai-search-optimisation",
    cta: "Explore AI Search",
  },
  {
    icon: Target,
    title: "Local SEO",
    description:
      "Dominate local search results and Google Maps for your target service areas across the UK.",
    href: "/local-seo",
    cta: "Explore Local SEO",
  },
  {
    icon: Zap,
    title: "Content Strategy",
    description:
      "Research-led content that targets the right keywords, answers the right questions, and builds topical authority.",
    href: "/content-strategy",
    cta: "Explore Content Strategy",
  },
  {
    icon: BookOpen,
    title: "SEO Insights",
    description:
      "Articles, guides, and commentary on the latest developments in SEO and AI search — written for business owners, not techies.",
    href: "#insights-cta",
    cta: "Read the Insights",
  },
];

const FaqResourceLinks = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="faq-resources"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      {/* Subtle decorative accent */}
      <span
        className="absolute top-0 left-0 w-24 h-0.5 bg-[hsl(84_74%_58%)]"
        aria-hidden="true"
      />

      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.55, ease: "easeOut" }}
          className="mb-12"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Further Reading
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 max-w-2xl">
            Explore Services &amp; Resources
          </h2>
          <p className="text-muted-foreground max-w-xl">
            Whether you're looking for hands-on SEO consultancy or want to learn more about a specific topic, these pages go deeper.
          </p>
        </motion.div>

        {/* Resource cards grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {resources.map((resource, idx) => {
            const Icon = resource.icon;
            return (
              <motion.div
                key={resource.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.5, ease: "easeOut", delay: idx * 0.06 }}
              >
                <Card className="h-full bg-card border-border shadow-card hover-lift transition-all duration-200 group">
                  <CardContent className="p-6 flex flex-col h-full">
                    {/* Icon */}
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 mb-4 group-hover:bg-primary/15 transition-colors duration-200">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>

                    {/* Title */}
                    <h3 className="text-base font-semibold text-foreground mb-2">
                      {resource.title}
                    </h3>

                    {/* Description */}
                    <p className="text-sm text-muted-foreground leading-relaxed mb-6 flex-grow">
                      {resource.description}
                    </p>

                    {/* CTA link */}
                    <Link
                      to={resource.href}
                      className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors duration-200 mt-auto"
                    >
                      {resource.cta}
                      <ArrowRight className="h-3.5 w-3.5" />
                    </Link>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Bottom CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.5, ease: "easeOut", delay: 0.35 }}
          className="mt-14 pt-10 border-t border-border flex flex-col sm:flex-row items-start sm:items-center justify-between gap-6"
        >
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-1">
              Still have a question?
            </h3>
            <p className="text-muted-foreground text-sm">
              Get in touch — I'll give you a straight answer, no sales pitch attached.
            </p>
          </div>
          <Button
            size="lg"
            className="h-12 px-8 text-sm tracking-wider font-semibold uppercase bg-[hsl(84_74%_58%)] text-[hsl(222_42%_8%)] hover:bg-[hsl(84_74%_52%)] transition-colors duration-200 rounded-md shadow-none shrink-0"
            asChild
          >
            <Link to="/contact">
              Get in Touch
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
});

FaqResourceLinks.displayName = "FaqResourceLinks";

export default FaqResourceLinks;
