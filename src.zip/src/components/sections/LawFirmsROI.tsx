import React from "react";
import { TrendingUp, Users, MapPin, Award, Percent, Clock, Key, Section } from "lucide-react";

const metrics = [
  {
    icon: TrendingUp,
    stat: "312%",
    label: "Average Organic Traffic Increase",
    detail: "Across law firm clients within 12 months of campaign launch",
  },
  {
    icon: Users,
    stat: "4.7×",
    label: "More Qualified Enquiries",
    detail: "Organic leads convert at higher rates than PPC for legal services",
  },
  {
    icon: MapPin,
    stat: "Top 3",
    label: "Local Pack Positions",
    detail: "Achieved for primary practice areas in target geographic markets",
  },
  {
    icon: Percent,
    stat: "68%",
    label: "Reduction in Cost Per Lead",
    detail:
      "Compared to Google Ads spend for equivalent lead volumes after 6 months",
  },
  {
    icon: Award,
    stat: "#1",
    label: "Rankings for Key Legal Terms",
    detail: "First-page dominance for competitive practice area keywords",
  },
  {
    icon: Clock,
    stat: "6–9 Mo",
    label: "To Measurable Results",
    detail: "Typical time to significant ranking and traffic improvements",
  },
];

const LawFirmsROI = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        {/* Section header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Measurable Returns
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            The ROI of Specialist Law Firm SEO
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Unlike paid advertising, SEO compounds — rankings and authority
            built today continue delivering instructions for years. Here is what
            law firm clients achieve with a focused organic strategy.
          </p>
        </div>

        {/* Metrics grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {metrics.map((m) => {
            const Icon = m.icon;
            return (
              <div
                key={m.label}
                className="bg-card rounded-xl border border-border shadow-card p-8 hover-lift transition-all duration-300"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 mb-5">
                  <Icon className="h-6 w-6 text-primary" />
                </div>
                <p className="text-4xl font-bold text-foreground mb-2 font-sora">
                  {m.stat}
                </p>
                <p className="text-base font-semibold text-foreground mb-2">
                  {m.label}
                </p>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {m.detail}
                </p>
              </div>
            );
          })}
        </div>

        {/* Context note */}
        <p className="mt-10 text-center text-xs text-muted-foreground max-w-lg mx-auto">
          Results vary by firm size, practice areas, and market. Metrics are
          representative of UK law firm campaigns. Individual outcomes depend on
          starting position, competition, and investment duration.
        </p>
      </div>
    </section>
  );
});

LawFirmsROI.displayName = "LawFirmsROI";

export default LawFirmsROI;
