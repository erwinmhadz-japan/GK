import React from "react";
import { Target, FileText, MessageSquare, TrendingUp, Star, Zap, Icon, Link, Search } from "lucide-react";

const practices = [
  {
    icon: Target,
    title: "Answer Questions Directly",
    description:
      "Structure pages around specific questions your audience asks. Use H2/H3 headings that mirror query phrasing. ChatGPT retrieves passages that directly answer a query — long-winded introductions get skipped.",
  },
  {
    icon: FileText,
    title: "Build Topical Authority",
    description:
      "Publish comprehensive, interconnected content that covers an entire topic cluster. AI systems favour sources that demonstrate deep expertise across a subject, not one-off posts. Link between related pages and use entities consistently.",
  },
  {
    icon: Star,
    title: "Earn Third-Party Citations",
    description:
      "ChatGPT's training corpus and browsing index heavily weights content that is linked to and cited by authoritative external sources. Digital PR, expert mentions, and editorial backlinks accelerate citation probability.",
  },
  {
    icon: MessageSquare,
    title: "Use Conversational, Clear Language",
    description:
      "Write at a reading level appropriate for your audience with clear, jargon-free explanations. AI retrieval favours content that matches the natural language of the query — not keyword-stuffed passages.",
  },
  {
    icon: TrendingUp,
    title: "Keep Content Fresh and Accurate",
    description:
      "Regularly updated pages with correct factual claims are prioritised over stale content. Add dateModified to your structured data and refresh statistics, figures, and references at least quarterly.",
  },
  {
    icon: Zap,
    title: "Optimise for Snippet Extraction",
    description:
      "Use short, standalone paragraphs of 40-60 words that make sense without surrounding context. These are the passages ChatGPT is most likely to extract and include verbatim or near-verbatim in its responses.",
  },
];

const AiSearchChatgptBestPractices = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section ref={ref} className="relative py-20 md:py-32 border-t border-border bg-muted">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Best practices
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            How to Appear in ChatGPT Results
          </h2>
          <p className="text-muted-foreground leading-relaxed">
            Technical access is only half the equation. These content and authority strategies determine whether ChatGPT chooses to cite your brand when answering relevant queries.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {practices.map(({ icon: Icon, title, description }) => (
            <div
              key={title}
              className="bg-card border border-border rounded-xl p-7 shadow-card hover-lift flex flex-col gap-4"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10">
                <Icon className="h-5 w-5 text-primary" />
              </div>
              <div>
                <h3 className="text-base font-bold text-foreground mb-2">{title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <a
            href="#ai-search-cta"
            className="inline-flex items-center text-primary font-semibold hover:underline text-sm"
          >
            See all AI Search platforms we optimise for →
          </a>
        </div>
      </div>
    </section>
  );
});

AiSearchChatgptBestPractices.displayName = "AiSearchChatgptBestPractices";
export default AiSearchChatgptBestPractices;
