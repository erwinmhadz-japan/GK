import React from "react";
import { motion } from "framer-motion";
import { MapPin, Globe, Search, Building2, Star, CheckCircle, ArrowRight, Map as MapIcon } from "lucide-react";
import { Link } from "react-router-dom";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (delay: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut", delay },
  }),
};

const concepts = [
  {
    icon: Search,
    title: "The Map Pack",
    body: "The three-listing block that appears at the top of Google search results for location-based queries. Ranking here is arguably more valuable than a page-one organic listing — it sits above standard results and drives direct calls and footfall.",
  },
  {
    icon: Building2,
    title: "Google Business Profile",
    body: "Your primary local presence on Google. A well-optimised GBP — correct categories, service areas, photos, Q&A, and a consistent review strategy — is foundational to map pack visibility and local trust signals.",
  },
  {
    icon: Globe,
    title: "Local Citations",
    body: "Consistent name, address, and phone number (NAP) data across directories such as Yell, Thomson Local, and sector-specific listings. Inconsistencies are a common and easily overlooked ranking drag.",
  },
  {
    icon: MapPin,
    title: "Proximity Signals",
    body: "Google prioritises businesses that appear genuinely relevant and nearby for each searcher. Beyond physical location, this involves on-page geo-signals, localised content, and schema markup that confirms entity context.",
  },
  {
    icon: Star,
    title: "Review Strategy",
    body: "Review volume and recency are confirmed local ranking factors. A structured, compliant approach to generating and responding to reviews builds both algorithmic trust and visitor confidence.",
  },
  {
    icon: CheckCircle,
    title: "Localised Content",
    body: "Generic service pages rarely rank locally. Pages that clearly address a specific town or city, reference local context, and align with how local searchers phrase their queries outperform blanket national content.",
  },
];

const LocalSeoWhatIsIt = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="local-seo-what-is-it"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Header */}
        <div className="max-w-3xl mb-14 md:mb-20">
          <motion.p
            custom={0}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={fadeUp}
            className="text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4"
          >
            Understanding Local SEO
          </motion.p>

          <motion.h2
            custom={0.1}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={fadeUp}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight mb-6"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            What Is Local SEO — and Why Does It Matter?
          </motion.h2>

          <motion.p
            custom={0.2}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={fadeUp}
            className="text-lg md:text-xl text-muted-foreground leading-relaxed"
          >
            Local SEO is the practice of improving a business's visibility in
            geographically relevant search results. If your customers are
            searching in a specific town or city — for a solicitor, a clinic, an
            estate agent, or a financial adviser — local SEO determines whether
            you appear before your competitors.
          </motion.p>
        </div>

        {/* Explainer prose block */}
        <motion.div
          custom={0.3}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={fadeUp}
          className="bg-background border border-border rounded-md p-8 md:p-10 mb-16 md:mb-20 max-w-3xl"
        >
          <p className="text-base md:text-lg text-foreground leading-relaxed mb-6">
            Unlike national SEO — which competes across the entire UK — local
            SEO targets a defined geography. That might be a single town, a
            city, or a cluster of nearby postcodes. The signals Google uses to
            rank businesses locally are meaningfully different from those that
            drive organic rankings for national terms.
          </p>
          <p className="text-base md:text-lg text-foreground leading-relaxed mb-6">
            In competitive local markets — law, healthcare, financial services,
            property — the margin between appearing in the map pack and being
            invisible can be the difference between a steady pipeline of
            enquiries and none at all. Most businesses competing for these terms
            have invested in their local presence to some degree. Ranking
            consistently requires a structured, technically sound approach — not
            just a claimed Google Business Profile.
          </p>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
            This is where specialist input makes the difference. Local SEO has
            its own technical layer, its own content requirements, and its own
            set of common errors. A generalist approach rarely achieves the
            depth of optimisation that competitive local markets demand.
          </p>
        </motion.div>

        {/* Core concepts grid */}
        <div className="mb-16 md:mb-20">
          <motion.h3
            custom={0}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={fadeUp}
            className="text-xl md:text-2xl font-semibold text-foreground mb-10"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            The core components of local search visibility
          </motion.h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {concepts.map((concept, index) => {
              const Icon = concept.icon;
              return (
                <motion.div
                  key={concept.title}
                  custom={0.05 * index}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, margin: "-60px" }}
                  variants={fadeUp}
                  className="bg-background border border-border rounded-md p-6 hover:shadow-md transition-shadow duration-300"
                >
                  <div className="flex items-center justify-center w-10 h-10 rounded-md bg-primary/10 mb-5">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <h4
                    className="text-base font-semibold text-foreground mb-3"
                    style={{ fontFamily: "Sora, sans-serif" }}
                  >
                    {concept.title}
                  </h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {concept.body}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Why it matters in competitive markets */}
        <motion.div
          custom={0}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={fadeUp}
          className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-start"
        >
          <div>
            <h3
              className="text-xl md:text-2xl font-semibold text-foreground mb-5"
              style={{ fontFamily: "Sora, sans-serif" }}
            >
              Why competitive local markets need more than the basics
            </h3>
            <p className="text-base text-muted-foreground leading-relaxed mb-5">
              In less contested local markets, even a modest level of
              optimisation will often be enough to rank. But in sectors where
              multiple well-resourced businesses are actively competing for the
              same local queries — law firms, dental practices, financial
              advisers, estate agents — the bar is considerably higher.
            </p>
            <p className="text-base text-muted-foreground leading-relaxed mb-5">
              Google's local algorithm weighs three primary factors: relevance,
              distance, and prominence. Proximity you cannot change. Relevance
              and prominence — the signals you control — require deliberate,
              technically literate optimisation across your GBP, your website's
              on-page structure, and your wider digital footprint.
            </p>
            <p className="text-base text-muted-foreground leading-relaxed">
              Getting those signals right consistently, and sustaining them as
              competitors adjust their own approach, is an ongoing discipline
              rather than a one-time task.
            </p>
          </div>

          <div className="space-y-4">
            {[
              {
                label: "Relevance",
                description:
                  "How well your business, its categories, and its content match what the searcher is looking for.",
              },
              {
                label: "Distance",
                description:
                  "How close your physical location is to the searcher — or the location implied by their query.",
              },
              {
                label: "Prominence",
                description:
                  "How well-known and authoritative Google considers your business — driven by links, reviews, citations, and online presence.",
              },
              {
                label: "Behavioural signals",
                description:
                  "Click-through rates, calls from GBP, direction requests, and dwell time all feed back into how Google assesses your relevance to local searchers.",
              },
            ].map((item, i) => (
              <motion.div
                key={item.label}
                custom={0.1 * i}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-60px" }}
                variants={fadeUp}
                className="flex gap-4 p-5 bg-background border border-border rounded-md"
              >
                <ArrowRight className="h-4 w-4 text-primary mt-1 shrink-0" />
                <div>
                  <p
                    className="text-sm font-semibold text-foreground mb-1"
                    style={{ fontFamily: "Sora, sans-serif" }}
                  >
                    {item.label}
                  </p>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </motion.div>
            ))}

            <p className="text-xs text-muted-foreground pt-2">
              Explore how I approach local SEO across different service
              components →{" "}
              <Link
                to="/local-seo"
                className="text-primary underline underline-offset-4 hover:opacity-80 transition-opacity"
              >
                Local SEO services
              </Link>
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
});

LocalSeoWhatIsIt.displayName = "LocalSeoWhatIsIt";

export default LocalSeoWhatIsIt;
