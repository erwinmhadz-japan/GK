import React from "react";
import { motion } from "framer-motion";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Shield, Globe, Zap, Search, BarChart2, Target, Users, Section } from "lucide-react";

const categories = [
  {
    label: "General SEO",
    icon: Search,
    faqs: [
      {
        question: "What is SEO and why does my business need it?",
        answer:
          "SEO (Search Engine Optimisation) is the process of improving your website so it appears higher in search engine results when potential customers search for your products or services. In 2025, search is still the primary way people discover businesses online — outranking your competitors in Google means more organic traffic, more leads, and more revenue without paying per click. For UK businesses, a strong organic presence is one of the most cost-effective long-term marketing investments you can make.",
      },
      {
        question: "How long does SEO take to show results?",
        answer:
          "Honest answer: it depends on your starting point, competition level, and the scope of work. Most businesses see meaningful movement within 3–6 months, with significant results typically appearing at 6–12 months. Highly competitive markets (legal, finance, medical) may take 12–18 months to see top-three rankings. Technical fixes and on-page improvements can show results faster; link-building and authority-building take longer. I'll give you realistic timelines based on your specific situation — not overpromised agency forecasts.",
      },
      {
        question: "Is SEO still worth investing in with AI changing search?",
        answer:
          "More than ever, yes. AI-powered search (Google AI Overviews, ChatGPT, Perplexity) still relies heavily on the same quality signals that traditional SEO has always rewarded: authoritative content, strong backlink profiles, clear entity signals, and technical excellence. The difference is that AI search also factors in brand reputation and structured data more heavily. Businesses that invest in solid SEO now are better positioned to win in both traditional Google results and AI-generated answers.",
      },
    ],
  },
  {
    label: "Working With Gregg",
    icon: Users,
    faqs: [
      {
        question: "Why hire an independent SEO consultant rather than an agency?",
        answer:
          "With an agency, your account is typically managed by a junior executive following a template. With me, you work directly with an experienced senior consultant on every piece of work. No account manager layers, no passing your brief down the chain, no junior hand-offs. This means faster decisions, more strategic thinking, and better value for money. I've worked across sectors from law firms and healthcare to e-commerce and B2B — so your strategy is informed by real breadth of experience.",
      },
      {
        question: "What does working with you look like month to month?",
        answer:
          "Every engagement starts with a thorough audit of your current SEO position. From there, I build a prioritised strategy and we work through it together — typically across technical fixes, content development, and authority-building. You receive clear monthly reporting with plain-English explanations, a regular call to review progress and adapt the strategy, and direct access to me via email between calls. No surprises, no jargon-heavy reports that obscure what's actually happening.",
      },
      {
        question: "Do you work with businesses outside of Warrington?",
        answer:
          "Absolutely. While I'm based in Warrington, Cheshire, I work with clients across the UK — from Manchester and Liverpool to London, Birmingham, Leeds, and beyond. All engagements are managed remotely with video calls and clear async communication. Location is no barrier to working together effectively.",
      },
      {
        question: "What size businesses do you work with?",
        answer:
          "I work with SMEs and professional services firms who are serious about growth — typically businesses with an established online presence that want to compete more aggressively in organic search. I don't work with very early-stage startups with no budget, or enterprise businesses with large in-house teams. The sweet spot is founder-led or owner-managed businesses, regional professional practices, and specialist e-commerce brands.",
      },
    ],
  },
  {
    label: "Technical & Strategy",
    icon: BarChart2,
    faqs: [
      {
        question: "What is a technical SEO audit and do I need one?",
        answer:
          "A technical SEO audit is a systematic review of your website's technical health — covering crawlability, indexation, Core Web Vitals, site architecture, duplicate content, structured data, and more. If your site has never had a proper technical review, or if rankings have plateaued or dropped, an audit is almost always the right starting point. It identifies the issues preventing search engines from fully understanding and ranking your site — and gives you a prioritised action plan to fix them.",
      },
      {
        question: "What is entity SEO and why does it matter?",
        answer:
          "Entity SEO is about making sure Google understands who you are as a business — not just what keywords you target. Google's Knowledge Graph stores information about real-world entities (people, businesses, organisations, places, concepts). When Google can confidently identify your business as a legitimate entity with consistent, structured information across the web, it rewards you with higher trust scores and better rankings. Entity signals are also foundational to appearing in AI-generated answers from tools like ChatGPT and Perplexity.",
      },
      {
        question: "What's the difference between local SEO and national SEO?",
        answer:
          "Local SEO focuses on ranking for searches with geographic intent — for example, 'solicitor in Manchester' or 'plumber near me'. It centres on your Google Business Profile, local citations, reviews, and locally relevant content. National SEO targets broader, non-geographic keywords and requires a stronger domain authority, more extensive content programmes, and deeper link-building work. Many UK businesses need both: a strong local presence alongside national topical authority in their sector.",
      },
      {
        question: "How does AI search optimisation differ from traditional SEO?",
        answer:
          "AI search engines like ChatGPT, Perplexity, Google AI Overviews, and Gemini retrieve and synthesise information differently from traditional search. They prioritise sources that are authoritative, well-structured, frequently cited, and consistent in their entity signals. Optimising for AI search involves schema markup, entity disambiguation, digital PR to earn citations, and ensuring your content directly answers the specific questions users are asking AI tools. It complements traditional SEO rather than replacing it — and businesses that ignore it risk losing visibility as AI search grows.",
      },
    ],
  },
  {
    label: "Results & Reporting",
    icon: TrendingUp,
    faqs: [
      {
        question: "How do you measure SEO success?",
        answer:
          "The primary metrics I track are organic traffic growth, keyword ranking improvements for commercially relevant terms, leads or conversions attributed to organic search, and domain authority progress. I use Google Search Console, Google Analytics 4, and third-party ranking tools to provide transparent monthly reporting. I focus on metrics that connect to your actual business goals — not vanity metrics like total keyword count that agencies use to pad reports.",
      },
      {
        question: "Can you guarantee first-page rankings?",
        answer:
          "No — and you should be deeply sceptical of anyone who does. Google's algorithm has hundreds of ranking factors, is constantly updated, and is influenced by your competitors' actions as much as your own. What I can guarantee is rigorous, ethical, best-practice SEO work informed by years of experience — and transparent communication when things take longer than expected or require a change in approach. Consistent, high-quality SEO work delivers results over time; guarantees are a red flag, not a selling point.",
      },
      {
        question: "What's included in your monthly reporting?",
        answer:
          "Each monthly report covers: ranking movements for your tracked keywords, organic traffic trends from Google Search Console, key technical issues identified and resolved, content work completed and its early performance signals, link-building activity and new referring domains, and priorities for the coming month. Reports are written in plain English — I don't hide behind jargon or present data without context. You'll always know exactly what's happening and why.",
      },
    ],
  },
];

const FaqQuestions = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="faq-questions"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.55, ease: "easeOut" }}
          className="text-center mb-14"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Questions &amp; Answers
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Everything You Need to Know
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto">
            Straight answers — no waffle, no upsell, no agency spin.
          </p>
        </motion.div>

        {/* FAQ categories */}
        <div className="space-y-12">
          {categories.map((cat, catIdx) => {
            const CatIcon = cat.icon;
            return (
              <motion.div
                key={cat.label}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.5, ease: "easeOut", delay: catIdx * 0.07 }}
              >
                {/* Category label */}
                <div className="flex items-center gap-2 mb-5">
                  <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/10">
                    <CatIcon className="h-4 w-4 text-primary" />
                  </div>
                  <span className="text-sm font-semibold uppercase tracking-widest text-muted-foreground">
                    {cat.label}
                  </span>
                </div>

                <Accordion type="single" collapsible className="w-full">
                  {cat.faqs.map((faq, faqIdx) => (
                    <AccordionItem
                      key={faqIdx}
                      value={`cat-${catIdx}-item-${faqIdx}`}
                      className="border-border"
                    >
                      <AccordionTrigger className="text-left font-medium text-foreground hover:text-primary transition-colors duration-200 py-5">
                        {faq.question}
                      </AccordionTrigger>
                      <AccordionContent className="text-muted-foreground leading-relaxed pb-5">
                        {faq.answer}
                      </AccordionContent>
                    </AccordionItem>
                  ))}
                </Accordion>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
});

FaqQuestions.displayName = "FaqQuestions";

export default FaqQuestions;
