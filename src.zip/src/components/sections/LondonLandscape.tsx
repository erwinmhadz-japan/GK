import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Building2, Briefcase, Globe, Landmark, Network, Zap, Users, Shield, Cross, Icon, Search, Section, View } from "lucide-react";

const sectors = [
  {
    icon: Landmark,
    title: "Financial Services & FinTech",
    description:
      "Competing for high-value commercial searches in one of the world's leading financial centres. From private equity and asset management to challenger banks and payment platforms, I deliver search authority that wins mandates and investor attention.",
    area: "City of London · Canary Wharf · Mayfair",
  },
  {
    icon: Briefcase,
    title: "Legal & Professional Services",
    description:
      "London's legal market is fiercely contested. I position law firms and professional services practices for category-defining searches — from 'M&A solicitors London' to niche practice area queries that drive high-value client instructions.",
    area: "Legal District · Holborn · Midtown",
  },
  {
    icon: Network,
    title: "B2B Technology & SaaS",
    description:
      "Enterprise software, cybersecurity, and SaaS platforms need content authority and technical SEO rigour to cut through London's saturated tech landscape. I build topical authority that makes your platform the default recommendation for target buyers.",
    area: "Shoreditch · Old Street · King's Cross",
  },
  {
    icon: Globe,
    title: "Management Consulting & Advisory",
    description:
      "Boutique consultancies and Big Four competitors alike need distinctive search presence. I develop thought-leadership content strategies and entity-based SEO that put your firm at the forefront of decision-maker research journeys.",
    area: "Mayfair · St James's · Victoria",
  },
  {
    icon: Building2,
    title: "Commercial Real Estate & PropTech",
    description:
      "London's property market moves fast. I deliver local and national SEO strategies for developers, agents, and PropTech platforms competing for landlord, investor, and occupier search intent across every London postcode.",
    area: "Nine Elms · City of London · West End",
  },
  {
    icon: Users,
    title: "Recruitment & Executive Search",
    description:
      "London's talent market is intensely competitive. I help recruitment firms and executive search practices dominate sector-specific hiring searches, building brand authority that attracts both clients and the best candidates.",
    area: "EC1 · WC1 · SW1 · Greater London",
  },
];

const LondonLandscape = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="london-landscape"
      aria-label="London's competitive SEO landscape"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-3xl mb-14">
          <Badge variant="outline" className="mb-4 text-primary border-primary/40">
            <Zap className="h-3 w-3 mr-1" />
            London's Competitive Landscape
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            London Operates at a Different Level — Your SEO Strategy Must Too
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            The capital's premium and enterprise markets are among the most contested search
            environments in the UK. Every sector has sophisticated competitors investing heavily in
            organic search. I work with London firms that need to lead their category — not follow it.
          </p>
        </div>

        {/* Sectors grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {sectors.map(({ icon: Icon, title, description, area }) => (
            <Card
              key={title}
              className="group border border-border bg-card hover-lift shadow-card hover:shadow-card-hover transition-all duration-300"
            >
              <CardHeader className="pb-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-3 group-hover:bg-primary/20 transition-colors">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <CardTitle className="text-lg text-foreground leading-tight">{title}</CardTitle>
                <span className="text-xs text-muted-foreground font-medium tracking-wide">
                  {area}
                </span>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Bottom CTA row */}
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4 p-6 rounded-xl bg-muted border border-border">
          <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
            <Shield className="h-5 w-5 text-primary" />
          </div>
          <div className="flex-1">
            <p className="font-semibold text-foreground text-sm">
              Not seeing your sector? London's market diversity is exactly why I take a bespoke approach.
            </p>
            <p className="text-xs text-muted-foreground mt-0.5">
              Every engagement starts with a detailed competitive analysis of your London market position.
            </p>
          </div>
          <Button variant="outline" size="sm" className="shrink-0" asChild>
            <a href="/services-seo-audit">View All Services</a>
          </Button>
        </div>
      </div>
    </section>
  );
});

LondonLandscape.displayName = "LondonLandscape";

export default LondonLandscape;
