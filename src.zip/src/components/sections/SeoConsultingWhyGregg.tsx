import React from "react";
import { motion } from "framer-motion";
import { UserCheck, ShieldCheck, MapPin, TrendingUp, Target, Briefcase, Copy, Section, Text } from "lucide-react";

const differentiators = [
  {
    icon: UserCheck,
    heading: "Senior expertise, every engagement",
    body:
      "You work directly with Gregg — a practitioner with over a decade of UK SEO experience. There are no account managers, no handoffs, and no junior team members managing your project.",
  },
  {
    icon: ShieldCheck,
    heading: "Direct accountability",
    body:
      "As an independent consultant, Gregg's reputation rests entirely on client outcomes. There is no agency layer to absorb responsibility. Every recommendation is made with your business's interests at the centre.",
  },
  {
    icon: MapPin,
    heading: "UK-based, Warrington & Cheshire",
    body:
      "Gregg is based in Warrington, Cheshire and works with businesses across the UK. Engagements are grounded in the realities of the British search landscape — not imported frameworks or US-market defaults.",
  },
  {
    icon: Target,
    heading: "Strategy without delegation",
    body:
      "Every audit, strategy document, and recommendation is produced by Gregg personally. You receive considered, bespoke work — not templated outputs assembled by a team of generalists.",
  },
  {
    icon: TrendingUp,
    heading: "Commercial focus, not vanity metrics",
    body:
      "SEO consulting is only valuable when it drives measurable business outcomes. Engagements are shaped around your revenue objectives, pipeline, and competitive landscape — not keyword rankings for their own sake.",
  },
  {
    icon: Briefcase,
    heading: "Sector-aware, trust-led approach",
    body:
      "Gregg works with UK businesses in law, healthcare, finance, and property — sectors where credibility and compliance matter. Copy, content, and technical recommendations reflect the standards these industries require.",
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay: i * 0.1 },
  }),
};

const SeoConsultingWhyGregg = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seo-consulting-why-gregg"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          className="max-w-2xl mb-14 md:mb-16"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <span className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium">
            Independent consultancy
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground font-[Sora] leading-snug mb-4">
            Why choose an independent SEO consultant
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
            Working with an independent practitioner is a fundamentally different
            engagement to hiring an agency. There is no bureaucracy, no delegation, and no
            diluted expertise — only direct, senior-level input applied to your business.
          </p>
        </motion.div>

        {/* Differentiator grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {differentiators.map((item, index) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.heading}
                custom={index}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                className="group rounded-md border border-border bg-background p-6 md:p-7 shadow-[0_4px_24px_-6px_hsl(222_28%_11%_/_0.10),_0_1px_4px_hsl(222_28%_11%_/_0.05)] transition-shadow duration-300 hover:shadow-[0_8px_40px_-8px_hsl(222_28%_11%_/_0.16),_0_2px_8px_hsl(222_28%_11%_/_0.08)]"
              >
                {/* Icon container */}
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mb-5 transition-colors duration-300 group-hover:bg-primary/20">
                  <Icon className="h-5 w-5 text-primary" />
                </div>

                {/* Text */}
                <h3 className="text-base md:text-lg font-semibold text-foreground font-[Sora] mb-2 leading-snug">
                  {item.heading}
                </h3>
                <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                  {item.body}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Closing trust statement */}
        <motion.div
          className="mt-14 md:mt-16 border-t border-border pt-10 md:pt-12 max-w-3xl"
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55, ease: "easeOut", delay: 0.2 }}
        >
          <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
            Gregg King is an independent SEO consultant based in Warrington, Cheshire,
            working with UK businesses that require expert-led, accountable SEO
            consulting — not an agency contract or a managed service. Engagements are
            bespoke, structured around your objectives, and delivered personally.
          </p>
        </motion.div>
      </div>
    </section>
  );
});

SeoConsultingWhyGregg.displayName = "SeoConsultingWhyGregg";

export default SeoConsultingWhyGregg;
