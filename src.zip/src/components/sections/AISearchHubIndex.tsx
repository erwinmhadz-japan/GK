import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight, Bot, Brain, Globe, Sparkles, Cpu, BookOpen, Compass, Search, Section } from "lucide-react";

const platforms = [
  {
    name: "ChatGPT Visibility",
    slug: "/chatgpt-visibility",
    tag: "OpenAI",
    icon: Bot,
    role: "Informational guide",
    summary:
      "How ChatGPT selects and cites sources — and what UK businesses need to understand about their presence in OpenAI's conversational answer environment.",
  },
  {
    name: "Perplexity Visibility",
    slug: "/perplexity-visibility",
    tag: "Perplexity AI",
    icon: Globe,
    role: "Informational guide",
    summary:
      "How Perplexity's real-time citation model works, why structured and authoritative content is rewarded, and what factors determine whether your brand is surfaced.",
  },
  {
    name: "Google AI Overviews",
    slug: "/google-ai-overviews",
    tag: "Google",
    icon: Brain,
    role: "Informational guide",
    summary:
      "An explanation of how AI Overviews appear in UK search results, which sources Google draws on, and why topical clarity increasingly determines organic visibility.",
  },
  {
    name: "Gemini Visibility",
    slug: "/gemini-visibility",
    tag: "Google DeepMind",
    icon: Sparkles,
    role: "Informational guide",
    summary:
      "How Gemini integrates across Google's ecosystem — Search, Workspace, and Android — and why its answer logic is closely tied to existing quality and entity signals.",
  },
  {
    name: "Copilot Visibility",
    slug: "/copilot-visibility",
    tag: "Microsoft",
    icon: Cpu,
    role: "Informational guide",
    summary:
      "How Microsoft Copilot draws on Bing's index and surfaces answers across Microsoft 365 and Edge — an often-overlooked AI discovery surface for B2B audiences.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: { staggerChildren: 0.08 },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: "easeOut" },
  },
};

const AISearchHubIndex = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="aisearch-hub-index"
      className="relative py-20 md:py-28 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.55, ease: "easeOut" }}
          className="max-w-2xl mb-12"
        >
          <div className="flex items-center gap-2 mb-4">
            <Compass className="h-4 w-4 text-primary" aria-hidden="true" />
            <span className="text-xs uppercase tracking-[0.18em] text-muted-foreground font-medium">
              Hub navigation
            </span>
          </div>

          <h2
            className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground leading-snug mb-4"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            What's in This Hub
          </h2>

          <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
            This hub is an{" "}
            <span className="text-foreground font-medium">informational reference</span>{" "}
            — not a sales page. Each guide below explains how a specific AI platform works, how it
            surfaces answers, and what factors influence brand visibility within it. The pages are
            intended to help UK business owners and marketing teams understand the AI search
            landscape before making decisions about their strategy.
          </p>

          <p className="mt-4 text-sm text-muted-foreground leading-relaxed">
            If you are looking to act on this knowledge through structured consultancy, see the{" "}
            <Link
              to="/ai-search-optimisation"
              className="text-foreground font-medium underline underline-offset-4 decoration-primary/60 hover:decoration-primary transition-colors duration-200"
            >
              AI Search Optimisation service
            </Link>
            .
          </p>
        </motion.div>

        {/* Platform index list */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          className="flex flex-col divide-y divide-border border border-border rounded-md overflow-hidden"
        >
          {platforms.map((platform, index) => {
            const Icon = platform.icon;
            return (
              <motion.div key={platform.slug} variants={itemVariants}>
                <Link
                  to={platform.slug}
                  className="group flex flex-col sm:flex-row sm:items-start gap-4 sm:gap-6 px-6 py-6 bg-background hover:bg-muted transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/60 focus-visible:ring-inset"
                  aria-label={`Read the ${platform.name} guide`}
                >
                  {/* Index number + icon */}
                  <div className="flex items-center gap-3 sm:flex-col sm:items-center sm:gap-1 sm:w-14 sm:shrink-0 sm:pt-0.5">
                    <span className="text-xs font-mono text-muted-foreground w-5 text-center select-none">
                      {String(index + 1).padStart(2, "0")}
                    </span>
                    <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10 group-hover:bg-primary/20 transition-colors duration-200 shrink-0">
                      <Icon className="h-[18px] w-[18px] text-primary" />
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex flex-wrap items-center gap-2 mb-1.5">
                      <h3
                        className="text-base font-semibold text-foreground leading-snug group-hover:text-primary transition-colors duration-200"
                        style={{ fontFamily: "Sora, sans-serif" }}
                      >
                        {platform.name}
                      </h3>
                      <span className="inline-block text-[10px] uppercase tracking-widest text-muted-foreground border border-border rounded px-1.5 py-0.5 font-medium">
                        {platform.tag}
                      </span>
                      <span className="inline-flex items-center gap-1 text-[10px] uppercase tracking-widest text-primary/80 font-medium">
                        <BookOpen className="h-2.5 w-2.5" aria-hidden="true" />
                        {platform.role}
                      </span>
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {platform.summary}
                    </p>
                  </div>

                  {/* Arrow */}
                  <div className="hidden sm:flex items-center self-center shrink-0 pl-2">
                    <ArrowRight className="h-4 w-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all duration-200" />
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Footer note */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3, ease: "easeOut" }}
          className="mt-8 text-xs text-muted-foreground max-w-xl"
        >
          Each platform guide is independent — read them in any order. All five cover distinct AI
          systems with different indexing logic, citation behaviour, and relevance signals.
        </motion.p>
      </div>
    </section>
  );
});

AISearchHubIndex.displayName = "AISearchHubIndex";

export default AISearchHubIndex;
