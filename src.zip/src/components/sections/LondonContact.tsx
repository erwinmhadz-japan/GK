import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Phone, Mail, ArrowRight, Book, House, View } from "lucide-react";

// LocalBusiness + Organization JSON-LD with London address
const localBusinessJsonLd = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": ["LocalBusiness", "ProfessionalService"],
      "@id": "https://greggcoppen.com/#london-location",
      name: "Gregg Coppen SEO Consultant — London",
      description:
        "Independent SEO consultant serving London businesses across all 33 boroughs. Specialising in local SEO, technical SEO, and competitive search strategies for the London market.",
      url: "https://greggcoppen.com/locations/london",
      telephone: "+44-20-XXXX-XXXX",
      email: "hello@greggcoppen.com",
      address: {
        "@type": "PostalAddress",
        streetAddress: "Kemp House, 160 City Road",
        addressLocality: "London",
        addressRegion: "England",
        postalCode: "EC1V 2NX",
        addressCountry: "GB",
      },
      geo: {
        "@type": "GeoCoordinates",
        latitude: 51.5268,
        longitude: -0.0886,
      },
      areaServed: [
        { "@type": "City", name: "London" },
        { "@type": "AdministrativeArea", name: "Greater London" },
      ],
      openingHoursSpecification: [
        {
          "@type": "OpeningHoursSpecification",
          dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
          opens: "09:00",
          closes: "18:00",
        },
      ],
      priceRange: "££",
      sameAs: [
        "https://www.linkedin.com/in/greggcoppen",
        "https://twitter.com/greggcoppen",
      ],
    },
    {
      "@type": "Organization",
      "@id": "https://greggcoppen.com/#organization",
      name: "Gregg Coppen SEO Consulting",
      url: "https://greggcoppen.com",
      logo: {
        "@type": "ImageObject",
        url: "https://greggcoppen.com/logo.png",
      },
      contactPoint: {
        "@type": "ContactPoint",
        telephone: "+44-20-XXXX-XXXX",
        contactType: "customer service",
        areaServed: "GB",
        availableLanguage: "English",
      },
    },
  ],
};

const contactDetails = [
  {
    icon: MapPin,
    label: "London Office",
    value: "Kemp House, 160 City Road, London EC1V 2NX",
  },
  {
    icon: Phone,
    label: "Phone",
    value: "+44 (0)20 XXXX XXXX",
  },
  {
    icon: Mail,
    label: "Email",
    value: "hello@greggcoppen.com",
  },
];

const LondonContact = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="london-contact"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      {/* LocalBusiness + Organization JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(localBusinessJsonLd) }}
      />

      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left — contact info */}
          <div>
            <Badge variant="outline" className="mb-4 text-primary border-primary/30">
              Get in Touch — London
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Ready to Grow Your London Business?
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed mb-8">
              Book a free 30-minute discovery call to discuss your London SEO goals, your
              current challenges, and what a tailored strategy could achieve for your business.
              No jargon. No sales pitch. Just straight-talking advice.
            </p>

            <div className="space-y-5 mb-8">
              {contactDetails.map((detail) => {
                const Icon = detail.icon;
                return (
                  <div key={detail.label} className="flex items-start gap-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 shrink-0">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider mb-0.5">
                        {detail.label}
                      </p>
                      <p className="text-foreground font-medium">{detail.value}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="flex flex-wrap gap-4">
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold" asChild>
                <a href="/contact">
                  Book a Free Discovery Call
                  <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="/services">View SEO Services</a>
              </Button>
            </div>
          </div>

          {/* Right — visual panel */}
          <div className="relative rounded-2xl overflow-hidden shadow-card-hover">
            <img
              src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&h=600&fit=crop"
              alt="London SEO consultant team meeting in a modern office"
              width="800"
              height="600"
              loading="lazy"
              className="w-full h-auto object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-8">
              <p className="text-white font-semibold text-lg">Serving all 33 London Boroughs</p>
              <p className="text-white/80 text-sm mt-1">
                Also covering the wider South East — Surrey, Essex, Kent & Hertfordshire
              </p>
            </div>
          </div>
        </div>

        {/* Internal links */}
        <div className="mt-14 pt-8 border-t border-border flex flex-wrap gap-4 justify-center text-sm text-muted-foreground">
          <a href="/locations" className="text-primary font-medium hover:underline">
            ← All UK Locations
          </a>
          <span className="text-border">|</span>
          <a href="/local-seo" className="text-primary font-medium hover:underline">
            Local SEO Services
          </a>
          <span className="text-border">|</span>
          <a href="#case-studies-cta" className="text-primary font-medium hover:underline">
            Case Studies
          </a>
        </div>
      </div>
    </section>
  );
});

LondonContact.displayName = "LondonContact";
export default LondonContact;
