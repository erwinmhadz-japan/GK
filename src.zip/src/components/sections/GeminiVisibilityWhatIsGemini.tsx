import React from "react";
import { motion } from "framer-motion";
import { Brain, Globe, Search, Layers, Sparkles, MessageSquare, Key, Section } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (delay: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut", delay },
  }),
};

const keyPoints = [
  {
    icon: Brain,
    heading: "A multimodal AI model",
    body: "Gemini is Google's most capable AI model family, built to process and reason across text, images, audio, and code. It powers a growing share of Google's own products — including Search.",
  },
  {
    icon: Search,
    heading: "The engine behind AI Overviews",
    body: "In the UK and internationally, Google's AI Overviews feature draws on Gemini to synthesise answers at the top of search results pages. When a user asks a complex question, Gemini decides what sources to cite and how to present the answer.",
  },
  {
    icon: Globe,
    heading: "A distinct platform, not just another chatbot",
    body: "Unlike standalone AI assistants such as ChatGPT or Perplexity, Gemini operates inside Google's search infrastructure. Its responses are shaped by Google's existing trust signals: E-E-A-T, PageRank, structured data, and entity authority.",
  },
  {
    icon: Layers,
    heading: "Increasingly present across Google products",
    body: "Gemini is also embedded in Google Workspace, Google Assistant, and the Gemini app itself. As the model matures, its reach extends beyond search — making brand and entity visibility across the wider Google ecosystem more important than ever.",
  },
  {
    icon: MessageSquare,
    heading: "Conversational search, reimagined",
    body: "Gemini enables users to ask multi-step, nuanced queries and receive synthesised responses rather than a list of ten blue links. This shift changes how users interact with search — and which businesses earn visibility.",
  },
  {
    icon: Sparkles,
    heading: "Why it differs from earlier AI search features",
    body: "Google's earlier AI experiments such as Search Generative Experience were experimental. Gemini-powered AI Overviews are a core, expanding feature. Optimising for Gemini is no longer optional for businesses competing in high-intent UK sectors.",
  },
];

const GeminiVisibilityWhatIsGemini = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="gemini-visibility-what-is-gemini"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          className="max-w-3xl mx-auto text-center mb-16 md:mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
        >
          <motion.span
            variants={fadeUp}
            custom={0}
            className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium"
          >
            Explainer
          </motion.span>
          <motion.h2
            variants={fadeUp}
            custom={0.1}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight mb-6"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            What Is Google Gemini and Why Does It Matter for SEO?
          </motion.h2>
          <motion.p
            variants={fadeUp}
            custom={0.2}
            className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl mx-auto"
          >
            Google Gemini is not simply a chatbot. It is the AI model now embedded in Google Search itself — quietly reshaping which businesses appear in answers and which do not. Understanding what Gemini is and how it works is the first step toward building visibility within it.
          </motion.p>
        </motion.div>

        {/* Editorial intro block */}
        <motion.div
          className="max-w-3xl mx-auto mb-16 md:mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
        >
          <motion.div
            variants={fadeUp}
            custom={0}
            className="border-l-2 border-primary pl-6 md:pl-8"
          >
            <p className="text-base md:text-lg text-foreground leading-relaxed mb-4">
              Launched in late 2023 and steadily integrated into Google's core products throughout 2024, Gemini represents Google's most significant rearchitecting of search since the Hummingbird update. Where Hummingbird improved understanding of natural language, Gemini can generate language — constructing novel, synthesised responses from across the web rather than simply ranking documents.
            </p>
            <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
              For UK businesses operating in competitive sectors — law, finance, healthcare, property — this shift is material. A site that ranks well in organic search may still be absent from the AI-generated answer that now occupies the top of the results page. Conversely, a well-structured, authoritative site may earn citation in Gemini responses without holding a traditional top-ten ranking.
            </p>
          </motion.div>
        </motion.div>

        {/* Key points grid */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 mb-16 md:mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
        >
          {keyPoints.map((point, index) => {
            const Icon = point.icon;
            return (
              <motion.div
                key={point.heading}
                variants={fadeUp}
                custom={index * 0.08}
                className="bg-card border border-border rounded-md p-6 md:p-7 hover:shadow-md transition-shadow duration-300"
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10 flex-shrink-0">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3
                    className="text-sm font-semibold text-foreground leading-snug"
                    style={{ fontFamily: "Sora, sans-serif" }}
                  >
                    {point.heading}
                  </h3>
                </div>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {point.body}
                </p>
              </motion.div>
            );
          })}
        </motion.div>

        {/* SEO implications block */}
        <motion.div
          className="max-w-3xl mx-auto"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
        >
          <motion.div
            variants={fadeUp}
            custom={0}
            className="bg-muted/40 border border-border rounded-md p-8 md:p-10"
          >
            <h3
              className="text-xl md:text-2xl font-bold text-foreground mb-5 leading-snug"
              style={{ fontFamily: "Sora, sans-serif" }}
            >
              What this means for organic search in the UK
            </h3>
            <div className="space-y-4 text-base text-muted-foreground leading-relaxed">
              <p>
                Traditional SEO optimised for document ranking — getting a page into the top ten results for a given query. Gemini-era SEO requires a broader frame: ensuring your business is understood, trusted, and cited as an authoritative entity across the signals that Gemini uses to construct its answers.
              </p>
              <p>
                Those signals include structured data and schema markup, which help Gemini parse what your business is, what it does, and who it serves. They include E-E-A-T signals — demonstrable expertise, authoritativeness, and trustworthiness in your content and backlink profile. And they include entity associations: whether Gemini understands your brand as a coherent, credible entity within its knowledge model.
              </p>
              <p>
                For businesses in sectors where trust is a primary buying criterion — legal services, healthcare, financial advice, property — these signals are not incidental. They are the same foundations that have always mattered for organic search. The difference is that Gemini now acts on them more directly, filtering and selecting sources based on these signals at the point of answer generation.
              </p>
              <p>
                Understanding what Gemini is — and separating it clearly from other AI search platforms — is essential before attempting to optimise for it. The technical approach to earning Gemini visibility differs in important ways from approaches relevant to ChatGPT or Perplexity, as those platforms operate outside Google's infrastructure and draw on different data sources and trust models.
              </p>
            </div>
          </motion.div>
        </motion.div>

      </div>
    </section>
  );
});

GeminiVisibilityWhatIsGemini.displayName = "GeminiVisibilityWhatIsGemini";

export default GeminiVisibilityWhatIsGemini;
