import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { BadgeCheck, Briefcase, Gavel, HeartPulse, Building2, TrendingUp, ArrowRight, Section } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay: i * 0.1 },
  }),
};

const sectors = [
  {
    icon: Gavel,
    label: "Law firms & solicitors",
    href: "#law-firms-cta",
  },
  {
    icon: HeartPulse,
    label: "Healthcare & private clinics",
    href: "#healthcare-cta",
  },
  {
    icon: Building2,
    label: "Estate agents & property",
    href: "#estate-agents-cta",
  },
  {
    icon: TrendingUp,
    label: "Financial services",
    href: "#financial-services-cta",
  },
  {
    icon: Briefcase,
    label: "B2B professional services",
    href: "#",
  },
];

const differentiators = [
  {
    title: "No account managers",
    body: "You work directly with Gregg King — the same person who handles your strategy, your audit, and your reporting. Nothing is delegated to a junior.",
  },
  {
    title: "No agency overhead",
    body: "Independent consulting means your budget goes into the work, not into paying for office space, sales teams, or layers of middle management.",
  },
  {
    title: "Senior expertise on every brief",
    body: "Every engagement is handled at senior level. There is no handoff point at which a less experienced person takes over the day-to-day.",
  },
];

const HomeTrust = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="home-trust"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <div className="max-w-3xl mb-14 md:mb-20">
          <motion.span
            custom={0}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium"
          >
            The independent model
          </motion.span>

          <motion.h2
            custom={1}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            className="text-3xl md:text-4xl lg:text-5xl font-bold tracking-tight text-foreground leading-tight mb-6"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Why work with an independent consultant?
          </motion.h2>

          <motion.p
            custom={2}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl"
          >
            Agencies employ account managers, business developers, and junior practitioners. What they
            sell you and who actually does the work are rarely the same person. With an independent
            consultant, that gap does not exist.
          </motion.p>
        </div>

        {/* Two-column layout: differentiators + pull quote */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 md:gap-16 mb-16 md:mb-24">

          {/* Left: differentiator list */}
          <div className="space-y-8">
            {differentiators.map((item, i) => (
              <motion.div
                key={item.title}
                custom={i + 3}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-60px" }}
                variants={fadeUp}
                className="flex gap-4"
              >
                <div className="flex-shrink-0 mt-0.5">
                  <div
                    className="flex h-7 w-7 items-center justify-center rounded-md bg-primary/10"
                  >
                    <BadgeCheck className="h-4 w-4 text-primary" />
                  </div>
                </div>
                <div>
                  <h3
                    className="text-base md:text-lg font-semibold text-foreground mb-1.5"
                    style={{ fontFamily: "Sora, sans-serif" }}
                  >
                    {item.title}
                  </h3>
                  <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                    {item.body}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>

          {/* Right: dark panel pull quote */}
          <motion.div
            custom={6}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            className="relative rounded-md overflow-hidden"
            style={{
              background:
                "linear-gradient(160deg, hsl(222 42% 8%) 0%, hsl(222 35% 18%) 60%, hsl(214 40% 22%) 100%)",
            }}
          >
            {/* Subtle green accent line */}
            <div
              className="absolute top-0 left-0 h-0.5 w-full"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
              }}
            />

            <div className="p-8 md:p-10">
              <p
                className="text-xl md:text-2xl font-semibold leading-snug text-white mb-6"
                style={{ fontFamily: "Sora, sans-serif" }}
              >
                "When you hire an independent consultant, you are hiring a senior practitioner — not
                a brand name."
              </p>

              <div className="border-t border-white/10 pt-6">
                <p className="text-sm text-white/80 leading-relaxed mb-2">
                  Gregg King is an independent SEO consultant based in Warrington, Cheshire,
                  working with UK businesses in sectors where credibility and precision matter.
                </p>
                <p className="text-xs text-white/60 uppercase tracking-widest font-medium">
                  Gregg King — SEO Consultant UK
                </p>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Sectors */}
        <motion.div
          custom={7}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={fadeUp}
        >
          <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-6 font-medium">
            Sectors served
          </p>

          <div className="flex flex-wrap gap-3">
            {sectors.map((sector, i) => {
              const Icon = sector.icon;
              return (
                <motion.div
                  key={sector.label}
                  custom={8 + i}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, margin: "-60px" }}
                  variants={fadeUp}
                >
                  <Link
                    to={sector.href}
                    className="flex items-center gap-2.5 px-4 py-2.5 rounded-md border border-border bg-background text-foreground text-sm font-medium shadow-[var(--shadow-soft)] hover:border-primary/40 hover:text-primary transition-colors duration-200"
                    aria-label={`SEO for ${sector.label}`}
                  >
                    <Icon className="h-4 w-4 text-primary flex-shrink-0" />
                    <span>{sector.label}</span>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

      </div>
    </section>
  );
});

HomeTrust.displayName = "HomeTrust";

export default HomeTrust;
