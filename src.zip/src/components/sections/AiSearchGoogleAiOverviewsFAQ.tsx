import React, { useEffect } from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { HelpCircle } from "lucide-react";

const faqs = [
  {
    question: "What are Google AI Overviews and how are they different from featured snippets?",
    answer:
      "Google AI Overviews are AI-generated summaries powered by Google's Gemini model that appear at the top of search results pages. Unlike featured snippets, which pull a single passage from one page, AI Overviews synthesise information from multiple sources and cite them collectively. They are also significantly longer and appear in a collapsible panel, making them a more prominent placement than a traditional featured snippet.",
  },
  {
    question: "How do I get my website featured in Google AI Overviews?",
    answer:
      "There is no direct way to 'submit' content for AI Overview inclusion. Google selects sources algorithmically from pages already performing well in organic search. To improve your chances: rank in the top 10 for your target queries, demonstrate strong EEAT signals through expert authorship and authoritative backlinks, implement structured data markup (especially FAQ, Article, and HowTo schema), and ensure your pages load quickly and are fully crawlable.",
  },
  {
    question: "What EEAT signals matter most for AI Overview visibility?",
    answer:
      "While all four pillars — Experience, Expertise, Authoritativeness, and Trustworthiness — contribute, Trustworthiness is now weighted as the most foundational. Beyond trust, Authoritativeness (measured largely through your backlink profile and brand mentions) and Expertise (evidenced through named authors with verifiable credentials) have the greatest practical impact on AI Overview citation rates in competitive niches.",
  },
  {
    question: "Does schema markup help with Google AI Overviews?",
    answer:
      "Yes. Structured data makes it easier for Google's AI to parse the entities, relationships, and facts within your content. FAQ schema, Article schema with author markup, and Organisation/Person schema are particularly impactful. When Google can unambiguously identify what your content is about and who produced it, citation probability increases — especially in YMYL sectors where trust verification is critical.",
  },
  {
    question: "Can I appear in AI Overviews if I don't rank on page one?",
    answer:
      "In practice, the vast majority of AI Overview citations come from pages ranking in positions 1–10 for the queried term. While Google has cited pages from deeper in the SERP on rare occasions, a page-one organic ranking should be treated as a prerequisite for meaningful AI Overview inclusion. AI Overview optimisation should be built on a strong foundational organic SEO programme, not treated as a shortcut around it.",
  },
  {
    question: "How long does it take to start appearing in Google AI Overviews?",
    answer:
      "There is no fixed timeline — it depends on your existing domain authority, competitive landscape, and how quickly you can build EEAT signals. In our experience, businesses that are already ranking on page one can begin appearing in AI Overviews within 60–120 days of implementing a comprehensive EEAT and technical optimisation programme. More competitive sectors or lower-authority domains may take six to twelve months of sustained effort.",
  },
  {
    question: "Do Google AI Overviews affect organic click-through rates?",
    answer:
      "Research suggests mixed results. For informational queries where AI Overviews fully answer the question, organic CTR can decrease for results below the AI panel. However, cited sources within the AI Overview often see increased click-through rates compared to their equivalent organic positions. The goal of AI Overview optimisation is not to preserve traditional CTR but to ensure your brand is visible and cited within the AI-generated answer itself.",
  },
];

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((faq) => ({
    "@type": "Question",
    name: faq.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: faq.answer,
    },
  })),
};

const AiSearchGoogleAiOverviewsFAQ = React.forwardRef<HTMLElement>((props, ref) => {
  useEffect(() => {
    const existingScript = document.getElementById("faq-json-ld-ai-overviews");
    if (existingScript) return;
    const script = document.createElement("script");
    script.id = "faq-json-ld-ai-overviews";
    script.type = "application/ld+json";
    script.textContent = JSON.stringify(faqSchema);
    document.head.appendChild(script);
    return () => {
      const el = document.getElementById("faq-json-ld-ai-overviews");
      if (el) document.head.removeChild(el);
    };
  }, []);

  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Common Questions
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">
            Frequently Asked Questions
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Everything you need to know about Google AI Overviews, EEAT requirements,
            and how to improve your visibility in AI-generated search results.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="border-border bg-background rounded-lg mb-3 px-6 shadow-soft"
              >
                <AccordionTrigger className="text-left font-semibold text-foreground py-5 hover:no-underline">
                  <span className="flex items-start gap-3">
                    <HelpCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    {faq.question}
                  </span>
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed pb-5">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
});

AiSearchGoogleAiOverviewsFAQ.displayName = "AiSearchGoogleAiOverviewsFAQ";

export default AiSearchGoogleAiOverviewsFAQ;
