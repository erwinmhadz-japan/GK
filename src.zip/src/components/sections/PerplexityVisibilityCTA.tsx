import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, ScanSearch, ChevronRight, Contact, Search } from "lucide-react";

const PerplexityVisibilityCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="perplexity-visibility-cta"
      className="relative py-20 md:py-28 border-t border-border bg-muted overflow-hidden"
      style={{
        background: "hsl(225 28% 14%)",
        borderTopColor: "hsl(225 28% 22%)",
      }}
    >
      {/* Subtle dot-grid texture */}
      <div
        className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(84 74% 60%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
        aria-hidden="true"
      />

      {/* Subtle green ambient glow — far top-right */}
      <div
        className="absolute -top-32 right-0 w-[480px] h-[480px] rounded-full pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse at center, hsl(84 74% 60% / 0.07) 0%, transparent 70%)",
        }}
        aria-hidden="true"
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-10 md:gap-16">
          {/* Left — copy block */}
          <motion.div
            className="flex-1 max-w-xl"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.65, ease: "easeOut" }}
          >
            {/* Eyebrow */}
            <div className="flex items-center gap-2 mb-5">
              <ScanSearch
                className="h-4 w-4 flex-shrink-0"
                style={{ color: "hsl(84 74% 60%)" }}
                aria-hidden="true"
              />
              <span
                className="text-xs uppercase tracking-[0.2em] font-medium"
                style={{ color: "hsl(84 74% 60%)" }}
              >
                Perplexity AI Visibility
              </span>
            </div>

            {/* Headline */}
            <h2 className="text-3xl md:text-4xl font-bold text-white leading-tight max-w-lg">
              Want to Appear in Perplexity&rsquo;s Answers?
            </h2>

            {/* Sub-headline */}
            <p className="mt-4 text-base md:text-lg leading-relaxed" style={{ color: "hsl(214 32% 78%)" }}>
              Discuss your AI search visibility with an independent SEO consultant who understands how Perplexity sources its results.
            </p>

            {/* Supporting note */}
            <p className="mt-3 text-sm" style={{ color: "hsl(214 32% 60%)" }}>
              Independent advice. No agency overhead. Based in Warrington, Cheshire.
            </p>
          </motion.div>

          {/* Right — CTA block */}
          <motion.div
            className="flex flex-col items-start md:items-end gap-4"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.15 }}
          >
            {/* Primary CTA */}
            <Button
              size="lg"
              asChild
              className="group h-12 px-8 text-sm font-semibold rounded-md transition-all duration-300"
              style={{
                background: "linear-gradient(135deg, hsl(84 74% 60%), hsl(119 35% 61%))",
                color: "hsl(225 28% 10%)",
                boxShadow: "0 0 0 0 hsl(84 74% 60% / 0)",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.boxShadow =
                  "0 0 32px hsl(84 74% 60% / 0.28)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.boxShadow =
                  "0 0 0 0 hsl(84 74% 60% / 0)";
              }}
            >
              <Link to="/contact">
                Contact Me
                <ArrowRight
                  className="ml-2 h-4 w-4 transition-transform duration-200 group-hover:translate-x-1"
                  aria-hidden="true"
                />
              </Link>
            </Button>

            {/* Secondary CTA */}
            <Button
              size="lg"
              variant="outline"
              asChild
              className="group h-12 px-8 text-sm font-medium rounded-md transition-all duration-300"
              style={{
                borderColor: "hsl(225 28% 32%)",
                color: "hsl(214 32% 80%)",
                background: "transparent",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.borderColor =
                  "hsl(84 74% 60% / 0.5)";
                (e.currentTarget as HTMLElement).style.color =
                  "hsl(84 74% 60%)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.borderColor =
                  "hsl(225 28% 32%)";
                (e.currentTarget as HTMLElement).style.color =
                  "hsl(214 32% 80%)";
              }}
            >
              <Link to="/contact">
                Free SEO Audit
                <ChevronRight
                  className="ml-1.5 h-4 w-4 transition-transform duration-200 group-hover:translate-x-0.5"
                  aria-hidden="true"
                />
              </Link>
            </Button>

            {/* Trust note */}
            <p
              className="text-xs tracking-wide"
              style={{ color: "hsl(214 32% 48%)" }}
            >
              No commitment required &mdash; initial conversations are free.
            </p>
          </motion.div>
        </div>

        {/* Bottom hairline divider + related links */}
        <motion.div
          className="mt-12 pt-8 flex flex-wrap gap-x-6 gap-y-2 items-center"
          style={{ borderTop: "1px solid hsl(225 28% 22%)" }}
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.6, ease: "easeOut", delay: 0.25 }}
        >
          <span
            className="text-xs uppercase tracking-[0.15em]"
            style={{ color: "hsl(214 32% 40%)" }}
          >
            Related services
          </span>
          {[
            { label: "AI Search Optimisation", to: "/ai-search-optimisation" },
            { label: "Schema Markup", to: "/schema-markup" },
            { label: "Entity SEO", to: "/entity-seo" },
            { label: "ChatGPT Visibility", to: "/chatgpt-visibility" },
          ].map((link) => (
            <Link
              key={link.to}
              to={link.to}
              className="text-xs transition-colors duration-200"
              style={{ color: "hsl(214 32% 60%)" }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.color =
                  "hsl(84 74% 60%)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.color =
                  "hsl(214 32% 60%)";
              }}
            >
              {link.label}
            </Link>
          ))}
        </motion.div>
      </div>
    </section>
  );
});

PerplexityVisibilityCTA.displayName = "PerplexityVisibilityCTA";

export default PerplexityVisibilityCTA;
