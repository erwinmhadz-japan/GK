import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Sparkles, Brain, Globe, Search, Zap, Icon } from "lucide-react";
import { ImageBackground } from "@/components/ImageBackground";

/* ─────────────────────────────────────────────
   AI platform signals displayed as trust pills
───────────────────────────────────────────── */
const aiPlatforms = [
  { label: "ChatGPT", icon: Brain },
  { label: "Perplexity", icon: Search },
  { label: "Google AI Overviews", icon: Globe },
  { label: "Gemini", icon: Sparkles },
  { label: "Microsoft Copilot", icon: Zap },
];

const AISearchOptimisationHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="aisearch-optimisation-hero"
      aria-label="AI Search Optimisation Hero"
      src="https://images.unsplash.com/photo-1573496528298-f0e9d3c7ce55?w=1920&h=1080&fit=crop"
      alt="Professional consultant working at a desktop computer"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center"
    >
      {/* ── overlay tinted toward deep navy (brand-aligned) ── */}
      <div className="absolute inset-0 bg-gradient-to-br from-[hsl(225_28%_8%/0.92)] via-[hsl(225_28%_14%/0.88)] to-[hsl(214_32%_20%/0.82)] pointer-events-none" />

      {/* ── content ── */}
      <div className="container max-w-6xl mx-auto px-4 relative z-10 py-24 md:py-32">
        <div className="max-w-3xl">

          {/* eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.05 }}
            className="mb-5"
          >
            <Badge
              variant="outline"
              className="inline-flex items-center gap-1.5 border-[hsl(84_74%_58%/0.45)] bg-[hsl(84_74%_58%/0.08)] text-[hsl(84_74%_70%)] text-xs uppercase tracking-[0.18em] font-medium py-1.5 px-3"
            >
              <Sparkles className="h-3 w-3" />
              AI Search Optimisation · Specialist Service
            </Badge>
          </motion.div>

          {/* H1 */}
          <motion.h1
            initial={{ opacity: 0, y: 22 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.12 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-[1.08] tracking-tight mb-5"
          >
            AI Search Optimisation{" "}
            <span className="text-[hsl(84_74%_62%)]">Consultant UK</span>
          </motion.h1>

          {/* subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.22 }}
            className="text-lg md:text-xl text-white/90 leading-relaxed max-w-2xl mb-8"
          >
            Get found in ChatGPT, Perplexity, Google AI Overviews, and Gemini
            — before your competitors are.
          </motion.p>

          {/* AI platform trust pills */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.32 }}
            className="flex flex-wrap gap-2 mb-10"
          >
            {aiPlatforms.map(({ label, icon: Icon }) => (
              <span
                key={label}
                className="inline-flex items-center gap-1.5 rounded-md border border-white/15 bg-white/6 px-3 py-1.5 text-xs font-medium text-white/80 backdrop-blur-sm"
              >
                <Icon className="h-3 w-3 text-[hsl(84_74%_62%)]" />
                {label}
              </span>
            ))}
          </motion.div>

          {/* CTA row */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.42 }}
            className="flex flex-col sm:flex-row gap-3 sm:gap-4"
          >
            {/* Primary CTA */}
            <Button
              size="lg"
              className="h-12 px-8 text-base font-semibold bg-[hsl(84_74%_58%)] hover:bg-[hsl(84_74%_52%)] text-[hsl(225_28%_10%)] border-0 shadow-none transition-all duration-200 hover:shadow-[0_0_28px_hsl(84_74%_58%/0.38)]"
              asChild
            >
              <Link to="/contact">
                Enquire Now
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>

            {/* Secondary CTA */}
            <Button
              size="lg"
              variant="outline"
              className="h-12 px-8 text-base font-medium bg-transparent border-white/30 text-white hover:bg-white/10 hover:border-white/50 transition-all duration-200"
              asChild
            >
              <Link to="/contact">
                Free SEO Audit
              </Link>
            </Button>
          </motion.div>

          {/* trust note */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, ease: "easeOut", delay: 0.56 }}
            className="mt-5 text-sm text-white/80"
          >
            Independent UK SEO consultant · Warrington, Cheshire · No obligation
          </motion.p>
        </div>

        {/* ── floating context panel ── */}
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.7, ease: "easeOut", delay: 0.45 }}
          className="hidden lg:block absolute right-0 top-1/2 -translate-y-1/2 w-72 xl:w-80"
        >
          <div className="rounded-lg border border-white/10 bg-[hsl(225_28%_10%/0.75)] backdrop-blur-md p-6 space-y-4">
            <p className="text-xs uppercase tracking-[0.18em] text-white/50 font-medium">
              Why AI search matters now
            </p>
            <ul className="space-y-3">
              {[
                "AI answers now appear above organic results",
                "Brand citations in LLMs drive zero-click trust",
                "Entity authority is the new ranking signal",
                "Early movers gain compounding visibility",
              ].map((point, i) => (
                <li
                  key={i}
                  className="flex items-start gap-2.5 text-sm text-white/85 leading-snug"
                >
                  <span className="mt-0.5 flex-shrink-0 h-4 w-4 rounded-full bg-[hsl(84_74%_58%/0.2)] flex items-center justify-center">
                    <span className="h-1.5 w-1.5 rounded-full bg-[hsl(84_74%_62%)]" />
                  </span>
                  {point}
                </li>
              ))}
            </ul>
            <div className="pt-2 border-t border-white/10">
              <p className="text-xs text-white/50 leading-relaxed">
                I help UK businesses in law, healthcare, finance, and property
                build genuine visibility in the AI search layer.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </ImageBackground>
  );
});

AISearchOptimisationHero.displayName = "AISearchOptimisationHero";

export default AISearchOptimisationHero;
