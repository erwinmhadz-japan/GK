import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowRight, Clock, Building, Download, Search, Section } from "lucide-react";

const guides = [
  {
    category: "Technical SEO",
    badge: "Popular",
    title: "The Complete Technical SEO Audit Checklist",
    description:
      "A step-by-step framework covering crawlability, indexation, Core Web Vitals, structured data, and site architecture. Used by leading brands across the UK.",
    readTime: "12 min read",
    href: "/seo-audit",
    image: "https://images.unsplash.com/photo-1633537065985-c65a413f5961?w=800&h=600&fit=crop",
  },
  {
    category: "AI Search",
    badge: "New",
    title: "How to Get Cited by ChatGPT & AI Overviews",
    description:
      "As AI assistants replace traditional search for many queries, learn the entity and content signals that earn your brand citations in AI-generated answers.",
    readTime: "10 min read",
    href: "/ai-search-optimisation",
    image: "https://images.unsplash.com/photo-1633537066002-336ea0ff2a16?w=800&h=600&fit=crop",
  },
  {
    category: "Content Strategy",
    badge: "Guide",
    title: "Building a Topic Cluster Strategy That Ranks",
    description:
      "Understand how pillar pages, cluster content, and internal linking work together to signal topical authority to Google and next-generation AI search engines.",
    readTime: "9 min read",
    href: "/content-strategy",
    image: "https://images.unsplash.com/photo-1685492259744-f42597aac776?w=800&h=600&fit=crop",
  },
  {
    category: "Local SEO",
    badge: "Guide",
    title: "Local SEO for Professional Services Firms",
    description:
      "Accountants, solicitors, consultants — here's how to dominate local search and Google Business Profile rankings in your target city or region.",
    readTime: "8 min read",
    href: "/local-seo",
    image: "https://images.unsplash.com/photo-1568649704650-a6ab20e84311?w=800&h=600&fit=crop",
  },
  {
    category: "Entity SEO",
    badge: "Advanced",
    title: "Entity SEO: Building Your Knowledge Graph Presence",
    description:
      "Discover how Google's Knowledge Graph works, how to create a verified entity, and why entity-based SEO is the foundation of AI search visibility.",
    readTime: "11 min read",
    href: "/entity-seo",
    image: "https://images.unsplash.com/photo-1633537066070-94bccfa10f05?w=800&h=600&fit=crop",
  },
  {
    category: "Digital PR",
    badge: "Guide",
    title: "Digital PR That Earns Authority Links (Not Just Coverage)",
    description:
      "Learn how to pitch data-led stories, secure top-tier UK press coverage, and convert media mentions into high-authority backlinks that move rankings.",
    readTime: "7 min read",
    href: "/digital-pr",
    image: "https://images.unsplash.com/photo-1559659386-5b78a2a4290c?w=800&h=600&fit=crop",
  },
];

const badgeVariantMap: Record<string, "default" | "secondary" | "outline" | "destructive"> = {
  Popular: "default",
  New: "secondary",
  Guide: "outline",
  Advanced: "destructive",
};

const containerVariants = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.1 } },
};

const cardVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
};

const Page4Guides = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="guides"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-2xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground font-medium mb-4">
            Free Guides & Frameworks
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
            Practical SEO Knowledge,{" "}
            <span className="text-gradient-green">No Fluff</span>
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Every guide is written from direct consultancy experience — not recycled
            blog content. Download, bookmark, or share with your team.
          </p>
        </div>

        {/* Guide cards grid */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
        >
          {guides.map((guide) => (
            <motion.div key={guide.title} variants={cardVariants} className="hover-lift">
              <Card className="h-full overflow-hidden border border-border shadow-card group">
                {/* Card image */}
                <div className="relative h-44 overflow-hidden bg-muted">
                  <img
                    src={guide.image}
                    alt={guide.title}
                    width={800}
                    height={600}
                    loading="lazy"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute top-3 left-3">
                    <Badge variant={badgeVariantMap[guide.badge] ?? "outline"}>
                      {guide.badge}
                    </Badge>
                  </div>
                </div>

                <CardHeader className="pb-2">
                  <div className="flex items-center gap-2 mb-2">
                    <span className="text-xs font-medium uppercase tracking-wider text-primary">
                      {guide.category}
                    </span>
                    <span className="text-muted-foreground/40">·</span>
                    <span className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {guide.readTime}
                    </span>
                  </div>
                  <CardTitle className="text-lg leading-snug text-foreground group-hover:text-primary transition-colors">
                    {guide.title}
                  </CardTitle>
                </CardHeader>

                <CardContent className="pt-0">
                  <CardDescription className="text-muted-foreground leading-relaxed mb-5">
                    {guide.description}
                  </CardDescription>
                  <Button variant="ghost" size="sm" className="px-0 text-primary hover:bg-transparent hover:text-primary/80 font-semibold" asChild>
                    <a href={guide.href}>
                      Read Guide
                      <ArrowRight className="ml-1 h-3.5 w-3.5" />
                    </a>
                  </Button>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
});

Page4Guides.displayName = "Page4Guides";

export default Page4Guides;
