import React from "react";
import { motion, Variants } from "framer-motion";
import { ScanSearch, Network, FileText, GitBranch, Target, BookOpen, ArrowRight, Heading } from "lucide-react";
import { Link } from "react-router-dom";

const pillars = [
  {
    icon: ScanSearch,
    title: "Topic Modelling",
    description:
      "I map the full topical landscape of your niche — identifying the clusters, sub-topics, and supporting content your site needs to establish genuine authority in the eyes of search engines.",
  },
  {
    icon: Network,
    title: "Entity Coverage Analysis",
    description:
      "Content that ranks in competitive sectors must demonstrate entity-level relevance. I identify the entities, relationships, and semantic signals your content must address to be treated as authoritative by Google.",
  },
  {
    icon: ScanSearch,
    title: "Content Gap Analysis",
    description:
      "I audit your current content against the competitive landscape to surface gaps — pages that do not exist, topics handled too thinly, and keyword opportunities you are leaving for competitors to own.",
  },
  {
    icon: GitBranch,
    title: "Editorial Planning",
    description:
      "Strategy without a plan is just theory. I translate the research into a structured editorial calendar that sequences content logically, prioritises by commercial impact, and aligns with your business objectives.",
  },
  {
    icon: Target,
    title: "Keyword Clustering",
    description:
      "Individual keywords do not win rankings — logical page groupings do. I cluster keywords by intent and topic so each page serves a distinct role and the architecture reinforces authority, not cannibalisation.",
  },
  {
    icon: BookOpen,
    title: "Internal Linking Strategy",
    description:
      "A content strategy that ignores internal linking is incomplete. I design the linking architecture that distributes authority between pages, reinforces keyword ownership, and guides users through logical journeys.",
  },
];

const fadeUp: Variants = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay: i * 0.1 },
  }),
};

const ContentStrategyOverview = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="content-strategy-overview"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Eyebrow + Heading block */}
        <div className="max-w-3xl mb-14 md:mb-20">
          <motion.span
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium"
          >
            What content strategy actually means
          </motion.span>

          <motion.h2
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.08 }}
            className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground leading-tight mb-6"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Strategic consultancy — not content production
          </motion.h2>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.15 }}
            className="space-y-4"
          >
            <p className="text-base md:text-lg text-foreground leading-relaxed max-w-2xl">
              Content strategy is one of the most misunderstood services in SEO. Most businesses associate it with copywriting, blog posts, or content production. That is not what I do.
            </p>
            <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl">
              When UK businesses in competitive sectors — law firms, healthcare providers, financial services, property — commission a content strategy engagement with me, they receive a structured analytical framework: a rigorous, research-led plan that tells them what to publish, why, in what order, and how it connects. The writing is done by your team or agency, guided by my strategy.
            </p>
            <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl">
              This distinction matters enormously. Strategy without execution is incomplete, but execution without strategy is wasted effort. I focus on the part that requires genuine SEO expertise: the thinking, the architecture, and the research.
            </p>
          </motion.div>
        </div>

        {/* Two-column prose + pillars grid */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-start mb-16">

          {/* Left column — prose context */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
            className="space-y-6"
          >
            <div className="border-l-2 border-primary pl-5 py-1">
              <p className="text-base text-foreground leading-relaxed font-medium">
                "A content strategy engagement begins with understanding where your site stands in relation to topical authority — then building a precise plan to close the gap."
              </p>
              <p className="text-sm text-muted-foreground mt-3">
                Gregg King, independent SEO consultant, Warrington
              </p>
            </div>

            <div className="space-y-4">
              <h3
                className="text-lg md:text-xl font-semibold text-foreground"
                style={{ fontFamily: "Sora, sans-serif" }}
              >
                Who this is for
              </h3>
              <p className="text-base text-muted-foreground leading-relaxed">
                Content strategy consultancy is best suited to established UK businesses with an existing web presence, operating in sectors where expertise signals matter — professional services, healthcare, legal, financial, and B2B. You likely have content already; the challenge is that it lacks cohesion, keyword logic, or topical depth.
              </p>
              <p className="text-base text-muted-foreground leading-relaxed">
                It is also suited to businesses preparing to invest significantly in content production and wanting to ensure that investment is directed correctly before commissioning any writing.
              </p>
            </div>

            <div className="space-y-4">
              <h3
                className="text-lg md:text-xl font-semibold text-foreground"
                style={{ fontFamily: "Sora, sans-serif" }}
              >
                How it differs from an SEO audit
              </h3>
              <p className="text-base text-muted-foreground leading-relaxed">
                An{" "}
                <Link
                  to="/seo-audit"
                  className="text-foreground underline underline-offset-2 hover:text-primary transition-colors"
                >
                  SEO audit
                </Link>{" "}
                tells you what is wrong with your existing site. A content strategy tells you what to build next. The two are complementary — many clients undertake an audit first, then commission a content strategy to act on the findings.
              </p>
              <p className="text-base text-muted-foreground leading-relaxed">
                Similarly, content strategy pairs naturally with{" "}
                <Link
                  to="/entity-seo"
                  className="text-foreground underline underline-offset-2 hover:text-primary transition-colors"
                >
                  entity SEO
                </Link>{" "}
                and{" "}
                <Link
                  to="/technical-seo"
                  className="text-foreground underline underline-offset-2 hover:text-primary transition-colors"
                >
                  technical SEO
                </Link>{" "}
                — all three address different layers of the same authority-building challenge.
              </p>
            </div>

            <div className="pt-2">
              <Link
                to="#seo-consulting-cta"
                className="inline-flex items-center gap-2 text-sm font-medium text-foreground hover:text-primary transition-colors group"
              >
                Learn about my SEO consulting approach
                <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
              </Link>
            </div>
          </motion.div>

          {/* Right column — pillars grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {pillars.map((pillar, i) => {
              const Icon = pillar.icon;
              return (
                <motion.div
                  key={pillar.title}
                  custom={i}
                  variants={fadeUp}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  className="group bg-background border border-border rounded-md p-5 hover:border-primary/40 hover:shadow-sm transition-all duration-300"
                >
                  <div className="flex items-center gap-3 mb-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/10 shrink-0">
                      <Icon className="h-4 w-4 text-primary" />
                    </div>
                    <h3
                      className="text-sm font-semibold text-foreground leading-snug"
                      style={{ fontFamily: "Sora, sans-serif" }}
                    >
                      {pillar.title}
                    </h3>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {pillar.description}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Bottom context strip */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
          className="border border-border rounded-md bg-background p-6 md:p-8"
        >
          <div className="flex flex-col md:flex-row md:items-start md:gap-12">
            <div className="mb-6 md:mb-0 md:w-1/3 shrink-0">
              <div className="flex items-center gap-3 mb-2">
                <FileText className="h-5 w-5 text-primary" />
                <span
                  className="text-sm font-semibold text-foreground uppercase tracking-wider"
                  style={{ fontFamily: "Sora, sans-serif" }}
                >
                  Independent consultancy
                </span>
              </div>
              <p className="text-xs text-muted-foreground">
                All strategy work is carried out by me personally. You receive direct access to my thinking — not a junior team member or templated process.
              </p>
            </div>
            <div className="border-t md:border-t-0 md:border-l border-border pt-6 md:pt-0 md:pl-12 flex-1">
              <p className="text-sm text-muted-foreground leading-relaxed">
                I work with a small number of UK businesses at any one time to ensure each engagement receives proper attention. Content strategy is not a quick deliverable — it requires time, rigour, and a deep understanding of your sector. If you are considering commissioning a content strategy, the best first step is to{" "}
                <Link
                  to="/contact"
                  className="text-foreground underline underline-offset-2 hover:text-primary transition-colors"
                >
                  get in touch
                </Link>{" "}
                with a brief overview of your site, your sector, and what you are trying to achieve. I will tell you honestly whether a content strategy is the right engagement for your situation, or whether{" "}
                <Link
                  to="/seo-audit"
                  className="text-foreground underline underline-offset-2 hover:text-primary transition-colors"
                >
                  an audit
                </Link>{" "}
                or{" "}
                <Link
                  to="/seo-retainer"
                  className="text-foreground underline underline-offset-2 hover:text-primary transition-colors"
                >
                  an ongoing retainer
                </Link>{" "}
                would serve you better.
              </p>
            </div>
          </div>
        </motion.div>

      </div>
    </section>
  );
});

ContentStrategyOverview.displayName = "ContentStrategyOverview";

export default ContentStrategyOverview;
