import React from "react";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, Users, Building2, Globe, Search, BarChart } from "lucide-react";

const stats = [
  {
    value: "1.1M+",
    label: "City population",
    icon: Users,
  },
  {
    value: "£26B",
    label: "Regional GVA",
    icon: BarChart,
  },
  {
    value: "Top 5",
    label: "Most competitive UK SEO markets",
    icon: TrendingUp,
  },
  {
    value: "70%+",
    label: "Local searches with commercial intent",
    icon: Search,
  },
];

const dynamics = [
  {
    icon: Building2,
    title: "Dense Business Ecosystem",
    body:
      "Birmingham hosts over 87,000 businesses — from SMEs in Digbeth and Jewellery Quarter to national corporates in Brindleyplace. Organic search is one of the highest-ROI channels to stand out in this dense market.",
  },
  {
    icon: Globe,
    title: "Hyper-Local Search Intent",
    body:
      "Searches like 'solicitor Birmingham city centre' and 'accountant Edgbaston' are high-volume, high-intent queries. Optimising for Birmingham's neighbourhoods and postcodes captures buyers at the moment they're ready to act.",
  },
  {
    icon: TrendingUp,
    title: "Rising AI Search Visibility",
    body:
      "Google's AI Overviews and tools like ChatGPT now answer local queries directly. Businesses with strong entity authority, schema markup, and local citations are referenced first — I ensure you're one of them.",
  },
];

const BirminghamMarket: React.FC = () => {
  return (
    <section className="relative py-20 md:py-32 border-t border-border bg-background">
      <div className="container">
        {/* Header */}
        <div className="max-w-2xl mb-14">
          <Badge variant="secondary" className="mb-4 text-xs uppercase tracking-widest">
            Birmingham SEO Market
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Why Birmingham SEO Demands a Different Approach
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            The West Midlands' digital economy is expanding fast. Understanding
            Birmingham's unique competitive landscape, local search behaviour, and
            AI-driven results is the foundation of any effective SEO campaign here.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="bg-muted rounded-xl p-6 text-center shadow-soft hover-lift"
            >
              <stat.icon className="h-6 w-6 text-primary mx-auto mb-3" />
              <div className="text-3xl font-bold text-foreground mb-1">{stat.value}</div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>

        {/* Dynamics cards */}
        <div className="grid md:grid-cols-3 gap-8">
          {dynamics.map((item) => (
            <div
              key={item.title}
              className="bg-card border border-border rounded-xl p-7 shadow-card hover-lift"
            >
              <div className="flex items-center justify-center h-12 w-12 rounded-lg bg-primary/10 mb-5">
                <item.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-3">{item.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{item.body}</p>
            </div>
          ))}
        </div>

        {/* Internal link */}
        <p className="mt-10 text-sm text-muted-foreground">
          Explore how local search can transform your visibility:{" "}
          <a href="/local-seo" className="text-primary font-medium hover:underline">
            Local SEO Services →
          </a>
        </p>
      </div>
    </section>
  );
};

export default BirminghamMarket;
