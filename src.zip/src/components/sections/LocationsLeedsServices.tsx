import React from "react";
import { Search, MapPin, Globe, Target, TrendingUp, Star, Building, Icon } from "lucide-react";
import { Button } from "@/components/ui/button";

const services = [
  {
    icon: MapPin,
    title: "Local SEO for Leeds",
    description:
      "Dominate Google's local pack and Maps results for searches like 'accountant Leeds' or 'plumber West Yorkshire'. We optimise your Google Business Profile, build authoritative local citations, and craft geo-targeted content that places you in front of Leeds customers at the exact moment they're ready to buy.",
    link: "/local-seo",
  },
  {
    icon: Search,
    title: "Technical SEO Audits",
    description:
      "Leeds businesses often lose rankings to technical issues they're unaware of. We audit crawlability, site speed, Core Web Vitals, structured data, and mobile performance — then fix what's holding you back with a clear, prioritised action plan.",
    link: "/services",
  },
  {
    icon: Globe,
    title: "Content Strategy & Authority Building",
    description:
      "We develop topic clusters and editorial content that establishes your Leeds business as the definitive expert in your niche. From long-form guides to landing pages targeting Leeds-specific queries, every piece is built around real search intent.",
    link: "/services",
  },
  {
    icon: Target,
    title: "Entity SEO & Schema Markup",
    description:
      "Google's understanding of your brand entity directly impacts how it ranks you. We implement organisation, LocalBusiness, FAQ, and service schema to ensure Leeds-based businesses are correctly interpreted by search engines and AI assistants.",
    link: "/services",
  },
  {
    icon: TrendingUp,
    title: "SEO Retainer & Ongoing Optimisation",
    description:
      "Leeds's SEO landscape shifts constantly. Our retainer service provides continuous monitoring, monthly reporting, link-building outreach, and strategic pivots — so your rankings compound over time rather than stagnate.",
    link: "/services",
  },
  {
    icon: Star,
    title: "AI Search Optimisation",
    description:
      "More Leeds customers are using AI tools like ChatGPT, Perplexity, and Google AI Overviews to find businesses. We ensure your brand appears confidently in AI-generated recommendations — the next frontier of search visibility.",
    link: "/ai-search-optimisation",
  },
];

const coverageAreas = [
  "Leeds City Centre",
  "Headingley",
  "Roundhay",
  "Morley",
  "Pudsey",
  "Horsforth",
  "Garforth",
  "Wetherby",
  "Bradford",
  "Harrogate",
  "Wakefield",
  "Huddersfield",
];

const LocationsLeedsServices = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="max-w-3xl mb-12">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-3">
            Leeds SEO Services
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground">
            Local & Regional SEO Services for Leeds Businesses
          </h2>
          <p className="mt-4 text-lg text-muted-foreground leading-relaxed">
            Every Leeds business has different needs. Whether you're a sole
            trader in Headingley or a multi-site business covering West
            Yorkshire, our SEO services are built around your goals — not
            generic templates.
          </p>
        </div>

        {/* Services grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {services.map(({ icon: Icon, title, description, link }) => (
            <div
              key={title}
              className="group bg-card border border-border rounded-xl p-6 flex flex-col hover-lift"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-4">
                <Icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">
                {title}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed flex-1">
                {description}
              </p>
              <a
                href={link}
                className="mt-4 text-sm text-primary font-medium underline underline-offset-4 hover:text-primary/80 transition-colors"
              >
                Learn more →
              </a>
            </div>
          ))}
        </div>

        {/* Coverage */}
        <div className="bg-card border border-border rounded-2xl p-8 md:p-10">
          <div className="flex items-center gap-3 mb-6">
            <MapPin className="h-6 w-6 text-primary" />
            <h3 className="text-xl font-bold text-foreground">
              Service Coverage — Leeds & West Yorkshire
            </h3>
          </div>
          <p className="text-muted-foreground mb-6 leading-relaxed">
            We serve businesses across Leeds and the wider West Yorkshire
            region. Whether your customers are local to the city or spread
            across the county, we build SEO strategies that match your
            geographic footprint.
          </p>
          <div className="flex flex-wrap gap-2 mb-6">
            {coverageAreas.map((area) => (
              <span
                key={area}
                className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-primary/10 text-primary text-sm font-medium"
              >
                <MapPin className="h-3 w-3" />
                {area}
              </span>
            ))}
          </div>
          <div className="flex flex-wrap gap-3">
            <Button asChild>
              <a href="/contact">Discuss Your Coverage Needs</a>
            </Button>
            <Button variant="outline" asChild>
              <a href="/locations">See All Locations</a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
});

LocationsLeedsServices.displayName = "LocationsLeedsServices";
export default LocationsLeedsServices;
