import React from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight, FileText, Users, Building, Icon } from "lucide-react";

const ctaLinks = [
  {
    icon: ArrowRight,
    label: "Get a Free Financial SEO Audit",
    description: "Identify your biggest YMYL and technical opportunities",
    href: "/contact",
    primary: true,
  },
  {
    icon: FileText,
    label: "Explore Case Studies",
    description: "See how we've grown financial services brands organically",
    href: "#case-studies-cta",
    primary: false,
  },
  {
    icon: Users,
    label: "Browse All Industries",
    description: "We serve healthcare, legal, e-commerce, and more",
    href: "#industries-cta",
    primary: false,
  },
];

const FinServCTA: React.FC = () => {
  return (
    <section className="relative py-20 md:py-32 border-t border-border bg-muted">
      <div className="container">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-12">
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-3">
              Ready to Grow?
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Start Building Financial SEO Authority Today
            </h2>
            <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl mx-auto">
              Whether you're a wealth manager, mortgage broker, fintech startup, or
              established bank — our tailored approach to financial services SEO
              delivers compliant, sustainable organic growth.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {ctaLinks.map(({ icon: Icon, label, description, href, primary }) => (
              <a
                key={label}
                href={href}
                className={`group flex flex-col items-center text-center p-8 rounded-xl border transition-all hover-lift ${
                  primary
                    ? "bg-primary border-primary/20 shadow-green-glow"
                    : "bg-card border-border shadow-card hover:border-primary/30"
                }`}
              >
                <div
                  className={`flex h-12 w-12 items-center justify-center rounded-full mb-4 ${
                    primary ? "bg-white/20" : "bg-primary/10"
                  }`}
                >
                  <Icon
                    className={`h-6 w-6 ${primary ? "text-white" : "text-primary"}`}
                  />
                </div>
                <p
                  className={`font-bold text-lg mb-2 ${
                    primary ? "text-primary-foreground" : "text-foreground"
                  }`}
                >
                  {label}
                </p>
                <p
                  className={`text-sm leading-relaxed ${
                    primary ? "text-primary-foreground/80" : "text-muted-foreground"
                  }`}
                >
                  {description}
                </p>
              </a>
            ))}
          </div>

          {/* Secondary text links */}
          <div className="mt-10 text-center flex flex-wrap justify-center gap-6 text-sm">
            <a href="/entity-seo" className="text-muted-foreground hover:text-primary transition-colors">
              Entity SEO →
            </a>
            <a href="/schema-markup" className="text-muted-foreground hover:text-primary transition-colors">
              Schema Markup →
            </a>
            <a href="/technical-seo" className="text-muted-foreground hover:text-primary transition-colors">
              Technical SEO →
            </a>
            <a href="#industries-cta" className="text-muted-foreground hover:text-primary transition-colors">
              All Industries →
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FinServCTA;
