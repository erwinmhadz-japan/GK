import React from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, ArrowRight, Group, Image, Phone, Section, View } from "lucide-react";

const solutions = [
  {
    eyebrow: "Local SEO",
    href: "/local-seo",
    title: "Hyperlocal SEO That Owns Your Patch",
    description:
      "Your buyers and vendors start their journey on Google. A comprehensive local SEO strategy places your agency prominently in Google's Local Pack and organic results for every neighbourhood you operate in.",
    points: [
      "Google Business Profile optimisation for each branch",
      "Postcode and neighbourhood keyword mapping",
      "Location landing pages with unique local authority signals",
      "Citation building across property and business directories",
      "Local link acquisition from area-specific publishers",
      "Geo-targeted content strategy for seasonal demand spikes",
    ],
    cta: "Explore Local SEO",
    ctaHref: "/local-seo",
    image: "https://images.unsplash.com/photo-1633537065982-712792c23798?w=800&h=600&fit=crop",
    imageAlt: "Modern city buildings representing local property markets",
    tag: "Foundation Service",
  },
  {
    eyebrow: "Schema Markup",
    href: "/schema-markup",
    title: "Schema Markup That Makes Listings Stand Out",
    description:
      "Structured data tells Google exactly what your content means — turning property listings, branch details, and agent profiles into rich results that earn more clicks without more rankings.",
    points: [
      "RealEstateListing schema for individual property pages",
      "LocalBusiness and BrokerageService schema for branches",
      "FAQ schema for vendor and buyer guide content",
      "Review and AggregateRating schema for trust signals",
      "BreadcrumbList schema for clear site architecture",
      "Event schema for property viewings and open days",
    ],
    cta: "View Schema Services",
    ctaHref: "/schema-markup",
    image: "https://images.unsplash.com/photo-1633537066002-336ea0ff2a16?w=800&h=600&fit=crop",
    imageAlt: "Tall brick building representing real estate schema structured data",
    tag: "Technical Edge",
  },
  {
    eyebrow: "Entity SEO",
    href: "/entity-seo",
    title: "Build Your Agent Brand as a Trusted Entity",
    description:
      "Google's Knowledge Graph rewards agents whose personal and business brands are clearly defined across the web. Entity SEO establishes your name as a trusted, authoritative figure in your local property market.",
    points: [
      "Agent knowledge panel optimisation and verification",
      "Named entity disambiguation across the web",
      "Wikipedia and Wikidata entity building (where eligible)",
      "Brand mention acquisition on property and local media",
      "Consistent NAP (Name, Address, Phone) across all platforms",
      "Author entity building for thought leadership content",
    ],
    cta: "Learn About Entity SEO",
    ctaHref: "/entity-seo",
    image: "https://images.unsplash.com/photo-1568649704650-a6ab20e84311?w=800&h=600&fit=crop",
    imageAlt: "Group of people walking near buildings representing community trust",
    tag: "Brand Authority",
  },
];

const EstateAgentsSolutions = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="estate-agents-solutions"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-2xl mb-16">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            SEO Solutions for Estate Agents
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-5">
            Three Pillars of Property Market SEO
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            A winning estate agent SEO strategy sits on three interconnected
            pillars — local presence, technical authority, and brand entity.
            Each reinforces the others to create compounding organic growth.
          </p>
        </div>

        {/* Solutions — alternating layout */}
        <div className="space-y-20">
          {solutions.map((sol, idx) => (
            <div
              key={sol.eyebrow}
              className={`grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center ${
                idx % 2 === 1 ? "lg:flex-row-reverse" : ""
              }`}
            >
              {/* Image side */}
              <div className={idx % 2 === 1 ? "lg:order-2" : ""}>
                <div className="relative rounded-2xl overflow-hidden shadow-card-hover">
                  <img
                    src={sol.image}
                    alt={sol.imageAlt}
                    width={800}
                    height={600}
                    loading="lazy"
                    className="w-full h-64 md:h-80 object-cover"
                  />
                  <div className="absolute top-4 left-4">
                    <Badge className="bg-primary text-primary-foreground font-semibold">
                      {sol.tag}
                    </Badge>
                  </div>
                </div>
              </div>

              {/* Content side */}
              <div className={idx % 2 === 1 ? "lg:order-1" : ""}>
                <a
                  href={sol.href}
                  className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-3 hover:underline"
                >
                  {sol.eyebrow}
                </a>
                <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4 leading-snug">
                  {sol.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed mb-6">
                  {sol.description}
                </p>

                <ul className="space-y-3 mb-8">
                  {sol.points.map((point) => (
                    <li key={point} className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                      <span className="text-sm text-foreground">{point}</span>
                    </li>
                  ))}
                </ul>

                <Button asChild variant="default" size="lg">
                  <a href={sol.ctaHref} className="group">
                    {sol.cta}
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </a>
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
});

EstateAgentsSolutions.displayName = "EstateAgentsSolutions";

export default EstateAgentsSolutions;
