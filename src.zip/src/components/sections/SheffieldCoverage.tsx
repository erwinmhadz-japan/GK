import React from "react";
import { MapPin, View } from "lucide-react";

const areas = [
  "Sheffield City Centre",
  "Kelham Island",
  "Attercliffe",
  "Hillsborough",
  "Ecclesall Road",
  "Broomhill",
  "Nether Edge",
  "Rotherham",
  "Doncaster",
  "Barnsley",
  "Chesterfield",
  "Worksop",
  "Bakewell",
  "Stocksbridge",
  "Chapeltown",
  "Meadowhall",
];

const SheffieldCoverage = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left column */}
          <div>
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-3">
              Service Areas
            </span>
            <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">
              Covering Sheffield & the South Yorkshire Region
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed mb-6">
              Based in the UK, I work with businesses across Sheffield and the wider South Yorkshire region — from the creative studios of Kelham Island to manufacturing firms in Rotherham, professional services in Barnsley, and retail businesses throughout Doncaster.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Remote collaboration means geography is no barrier. I also work with Sheffield-headquartered businesses that have national reach — helping them rank both locally and across the UK.
            </p>
            <div className="flex flex-wrap gap-3">
              <a
                href="/locations"
                className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline"
              >
                <MapPin className="h-4 w-4" />
                View all UK locations
              </a>
            </div>
          </div>

          {/* Right column — area tags */}
          <div>
            <div className="bg-background rounded-2xl p-8 border border-border shadow-card">
              <h3 className="text-lg font-bold text-foreground mb-6">
                Areas Served
              </h3>
              <div className="flex flex-wrap gap-2">
                {areas.map((area) => (
                  <span
                    key={area}
                    className="inline-flex items-center gap-1 px-3 py-1.5 rounded-full bg-muted text-sm text-muted-foreground border border-border font-medium"
                  >
                    <MapPin className="h-3 w-3 text-primary" />
                    {area}
                  </span>
                ))}
              </div>
              <div className="mt-6 pt-6 border-t border-border">
                <p className="text-sm text-muted-foreground">
                  Not listed above?{" "}
                  <a
                    href="/contact"
                    className="text-primary font-semibold hover:underline"
                  >
                    Get in touch
                  </a>{" "}
                  — I work across the whole of the UK.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

SheffieldCoverage.displayName = "SheffieldCoverage";
export default SheffieldCoverage;
