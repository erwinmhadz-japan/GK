import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles, CheckCircle, Search, Contact, View } from "lucide-react";

const proof = [
  "Independent SEO consultant — not an agency",
  "Specialist in Google AI Overviews & AI search visibility",
  "Working with UK businesses in competitive sectors",
];

const GoogleAIOverviewsCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="google-aioverviews-cta"
      className="relative py-20 md:py-32 border-t border-border bg-muted overflow-hidden"
    >
      {/* Subtle background texture */}
      <div
        className="absolute inset-0 pointer-events-none opacity-30"
        aria-hidden="true"
        style={{
          backgroundImage:
            "radial-gradient(circle at 20% 50%, hsl(84 74% 60% / 0.08) 0%, transparent 50%), radial-gradient(circle at 80% 20%, hsl(119 35% 61% / 0.06) 0%, transparent 45%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">

          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut" }}
            className="flex items-center justify-center gap-2 mb-6"
          >
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="text-xs uppercase tracking-[0.2em] font-medium text-muted-foreground">
              AI Search Optimisation
            </span>
            <Sparkles className="h-4 w-4 text-primary" />
          </motion.div>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.08 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold tracking-tight text-foreground leading-tight max-w-2xl mx-auto"
          >
            Need Help Appearing in{" "}
            <span className="text-primary">
              Google AI Overviews?
            </span>
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.16 }}
            className="mt-5 text-base md:text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed"
          >
            Gregg King provides specialist AI search optimisation for UK businesses
            seeking greater visibility in AI-generated results. As an independent
            consultant based in Warrington, Cheshire, I work directly with clients
            — no account managers, no outsourcing.
          </motion.p>

          {/* Proof points */}
          <motion.ul
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.24 }}
            className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3 sm:gap-6"
          >
            {proof.map((point) => (
              <li key={point} className="flex items-center gap-2 text-sm text-muted-foreground">
                <CheckCircle className="h-4 w-4 text-primary flex-shrink-0" />
                <span>{point}</span>
              </li>
            ))}
          </motion.ul>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.32 }}
            className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Button
              size="lg"
              className="h-12 px-8 text-base font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-md transition-all duration-200 group"
              asChild
            >
              <Link to="/contact">
                Contact Me
                <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform duration-200" />
              </Link>
            </Button>

            <Button
              size="lg"
              variant="outline"
              className="h-12 px-8 text-base font-medium border-border bg-transparent text-foreground hover:bg-accent hover:text-accent-foreground transition-all duration-200 group"
              asChild
            >
              <Link to="/contact">
                <Search className="mr-2 h-4 w-4" />
                Free SEO Audit
              </Link>
            </Button>
          </motion.div>

          {/* Commercial AI service page nudge */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.42 }}
            className="mt-6 text-sm text-muted-foreground"
          >
            Looking for a full AI search strategy?{" "}
            <Link
              to="/services-ai-search-optimisation"
              className="text-primary underline underline-offset-4 hover:text-primary/80 transition-colors duration-150 font-medium"
            >
              View AI Search Optimisation service
            </Link>
          </motion.p>

        </div>
      </div>
    </section>
  );
});

GoogleAIOverviewsCTA.displayName = "GoogleAIOverviewsCTA";

export default GoogleAIOverviewsCTA;
