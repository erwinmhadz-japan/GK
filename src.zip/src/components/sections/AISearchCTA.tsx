import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles, CheckCircle, Key, Search } from "lucide-react";

const trustPoints = [
  "Independent consultant — not an agency",
  "UK-based, working with national clients",
  "Specialist in AI search visibility signals",
];

const AISearchCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="aisearch-cta"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      {/* Subtle dot-grid texture overlay — decorative only */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(84 74% 60%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">

          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut" }}
          >
            <span className="inline-flex items-center gap-2 text-xs md:text-sm uppercase tracking-[0.2em] font-medium text-muted-foreground mb-6">
              <Sparkles className="h-4 w-4 text-primary" aria-hidden="true" />
              AI Search Optimisation
            </span>
          </motion.div>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.08 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold tracking-tight text-foreground leading-[1.15] max-w-2xl mx-auto"
          >
            Ready to Be Found in AI&nbsp;Search?
          </motion.h2>

          {/* Sub-headline */}
          <motion.p
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.16 }}
            className="mt-5 text-base md:text-lg text-muted-foreground max-w-xl mx-auto leading-relaxed"
          >
            Enquire today for a no-obligation conversation about your AI search visibility.
          </motion.p>

          {/* Trust points */}
          <motion.ul
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.24 }}
            className="mt-8 flex flex-col sm:flex-row flex-wrap items-center justify-center gap-3 sm:gap-6"
            aria-label="Key reasons to enquire"
          >
            {trustPoints.map((point) => (
              <li
                key={point}
                className="flex items-center gap-2 text-sm text-muted-foreground"
              >
                <CheckCircle
                  className="h-4 w-4 shrink-0 text-primary"
                  aria-hidden="true"
                />
                {point}
              </li>
            ))}
          </motion.ul>

          {/* CTA buttons */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.32 }}
            className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            {/* Primary CTA */}
            <Button
              size="lg"
              asChild
              className="h-12 px-8 text-base font-semibold rounded-md"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 60%), hsl(119 35% 61%))",
                color: "hsl(225 28% 14%)",
              }}
            >
              <Link to="/contact">
                Enquire Now
                <ArrowRight className="ml-2 h-4 w-4" aria-hidden="true" />
              </Link>
            </Button>

            {/* Secondary CTA */}
            <Button
              size="lg"
              variant="outline"
              asChild
              className="h-12 px-8 text-base font-semibold rounded-md border-border text-foreground hover:bg-muted transition-colors"
            >
              <Link to="/contact">Free SEO Audit</Link>
            </Button>
          </motion.div>

          {/* Reassurance note */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.42 }}
            className="mt-6 text-xs text-muted-foreground"
          >
            No obligation. No sales pressure. A straightforward conversation about your visibility goals.
          </motion.p>
        </div>
      </div>
    </section>
  );
});

AISearchCTA.displayName = "AISearchCTA";

export default AISearchCTA;
