import React from "react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { Brain, Globe, Database, Fingerprint, TrendingUp, ArrowRight, Component, Search, Section, View } from "lucide-react";

// ─── Data ────────────────────────────────────────────────────────────────────

const factors = [
  {
    number: "01",
    icon: Fingerprint,
    title: "Entity Recognition",
    body: "ChatGPT's training data includes a vast corpus of text from across the web. Businesses that are consistently named, described, and categorised across authoritative sources are more likely to be recognised as distinct entities — rather than generic keyword matches. Strong entity definition, ideally reinforced by structured data and Wikipedia or Wikidata presence, significantly improves recognition.",
  },
  {
    number: "02",
    icon: TrendingUp,
    title: "Topical Authority",
    body: "ChatGPT tends to surface brands associated with clear subject-matter depth. If a business has published consistently on a focused topic — and earned citations, links, and mentions from credible sources within that topic area — it is more likely to appear in relevant responses. Breadth without depth rarely achieves the same effect.",
  },
  {
    number: "03",
    icon: Globe,
    title: "Mentions Across Trusted Sources",
    body: "The model draws on text from news publications, trade press, professional directories, academic sources, and high-authority websites. A brand that appears across multiple independent, credible sources carries more weight than one whose mentions are concentrated on its own domain. Earned media, digital PR, and third-party editorial coverage all contribute to this signal.",
  },
  {
    number: "04",
    icon: Database,
    title: "Structured Data & Semantic Clarity",
    body: "Schema markup — including Organisation, LocalBusiness, Person, and Service schemas — helps search engines and AI systems parse the precise nature of a business, its location, its services, and its key attributes. While ChatGPT is not a search engine, its training corpus includes content indexed by Google, making structured data an indirect but meaningful input.",
  },
  {
    number: "05",
    icon: Link,
    title: "Brand Signals & Backlink Profile",
    body: "A well-established backlink profile from reputable domains reinforces brand legitimacy. Citations from professional bodies, industry associations, regional business directories, and authoritative press outlets all strengthen the signal that a brand is genuine, established, and relevant to specific queries. Link quality matters far more than link volume.",
  },
  {
    number: "06",
    icon: Brain,
    title: "Consistency of Brand Information",
    body: "Inconsistent or contradictory information about a business — differing addresses, multiple trading names, varying descriptions — can reduce the confidence with which a model attributes information to a specific entity. Consistent name, address, phone, and service description across all online touchpoints reinforces entity coherence and trustworthiness.",
  },
];

// ─── Animation Variants ───────────────────────────────────────────────────────

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const headingVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" },
  },
};

// ─── Component ────────────────────────────────────────────────────────────────

const ChatgptVisibilityHowItWorks = React.forwardRef<HTMLElement>(
  (props, ref) => {
    return (
      <section
        ref={ref}
        id="chatgpt-visibility-how-it-works"
        className="relative py-20 md:py-32 border-t border-border bg-muted"
      >
        <div className="container max-w-6xl mx-auto px-4">

          {/* Section header */}
          <motion.div
            className="max-w-3xl mb-14 md:mb-20"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={containerVariants}
          >
            <motion.div variants={headingVariants}>
              <Badge
                variant="outline"
                className="mb-4 text-xs uppercase tracking-widest font-medium border-border text-muted-foreground"
              >
                How It Works
              </Badge>
            </motion.div>

            <motion.h2
              variants={headingVariants}
              className="text-2xl md:text-3xl lg:text-4xl font-semibold text-foreground leading-snug mb-5"
              style={{ fontFamily: "Sora, sans-serif" }}
            >
              What determines whether ChatGPT mentions your business?
            </motion.h2>

            <motion.p
              variants={headingVariants}
              className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl"
            >
              ChatGPT does not crawl the web in real time. It draws on
              training data assembled from billions of documents — and the
              brands that appear in its responses are those that have
              established a clear, consistent presence across that corpus.
              Understanding the underlying factors is the starting point for
              improving visibility.
            </motion.p>
          </motion.div>

          {/* Factors grid */}
          <motion.div
            className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={containerVariants}
          >
            {factors.map((factor) => {
              const Icon = factor.icon;
              return (
                <motion.div
                  key={factor.number}
                  variants={itemVariants}
                  className="group relative bg-background border border-border rounded-md p-6 md:p-8 transition-all duration-300 hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%_/_0.10),_0_1px_4px_hsl(222_28%_11%_/_0.05)]"
                >
                  {/* Number + Icon row */}
                  <div className="flex items-start justify-between mb-5">
                    <span
                      className="text-xs font-semibold tracking-[0.18em] uppercase text-muted-foreground"
                      aria-hidden="true"
                    >
                      {factor.number}
                    </span>
                    <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10">
                      <Icon className="h-4 w-4 text-primary" />
                    </div>
                  </div>

                  {/* Title */}
                  <h3
                    className="text-base md:text-lg font-semibold text-foreground mb-3 leading-snug"
                    style={{ fontFamily: "Sora, sans-serif" }}
                  >
                    {factor.title}
                  </h3>

                  {/* Body */}
                  <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                    {factor.body}
                  </p>
                </motion.div>
              );
            })}
          </motion.div>

          {/* Contextual note */}
          <motion.div
            className="mt-14 md:mt-20 border-t border-border pt-10"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          >
            <div className="max-w-3xl">
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-4">
                It is worth noting that no business can directly instruct
                ChatGPT to include or exclude itself from responses — the
                model's outputs are probabilistic, not deterministic. What
                can be influenced is the underlying signal landscape: the
                quality and reach of brand mentions, the clarity of
                structured data, and the depth of topical coverage across
                trusted sources.
              </p>
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                These same signals also support visibility across Perplexity,
                Google AI Overviews, Gemini, and Microsoft Copilot — making
                the approach generalisable across the broader AI search
                landscape rather than platform-specific.
              </p>

              {/* Subtle text link — not a CTA block */}
              <Link
                to="/ai-search-optimisation"
                className="inline-flex items-center gap-1.5 mt-6 text-sm font-medium text-primary hover:underline underline-offset-4 transition-colors"
              >
                View the AI Search Optimisation service
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>
          </motion.div>

        </div>
      </section>
    );
  }
);

ChatgptVisibilityHowItWorks.displayName = "ChatgptVisibilityHowItWorks";

export default ChatgptVisibilityHowItWorks;
