import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Phone, Mail, MapPin, ArrowRight, Contact, Send, View } from "lucide-react";
const FORM_UUID = "aefdd459-da63-48be-9c34-2da20b672cf0"; // Auto-injected — backend registration
const FORM_ACTION = `${import.meta.env.VITE_FORM_SUBMIT_URL || ''}/api/forms/${FORM_UUID}/submit/`;


const WarringtonCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      src="https://images.unsplash.com/photo-1730851357916-3802b6405271?w=1920&h=1080&fit=crop"
      alt="Professional consultant in a smart office environment"
      imgProps={{ loading: "lazy" }}
      className="py-24 md:py-36"
    >
      <div className="container relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-14 items-start">
          {/* Left: CTA copy + contact details */}
          <div>
            <span className="inline-block text-xs uppercase tracking-[0.2em] text-white/80 font-medium mb-4">
              Get Started Today
            </span>
            <h2 className="text-3xl md:text-5xl font-bold text-white leading-tight">
              Ready to Grow Your Warrington Business Through SEO?
            </h2>
            <p className="mt-5 text-lg text-white/90 leading-relaxed">
              Get a free, no-obligation consultation. I'll review your current
              search visibility, identify your biggest opportunities, and outline
              an approach tailored to the Warrington market — no jargon, no
              hard sell.
            </p>

            <div className="mt-8 space-y-4">
              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10">
                  <Phone
                    className="h-4 w-4 text-white"
                    aria-hidden="true"
                  />
                </div>
                <div>
                  <p className="text-xs text-white/80 uppercase tracking-wide">
                    Phone
                  </p>
                  <a
                    href="tel:+441925000000"
                    className="text-white font-medium hover:text-white/80 transition-colors"
                  >
                    +44 (0)1925 000 000
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10">
                  <Mail
                    className="h-4 w-4 text-white"
                    aria-hidden="true"
                  />
                </div>
                <div>
                  <p className="text-xs text-white/80 uppercase tracking-wide">
                    Email
                  </p>
                  <a
                    href="mailto:hello@greggseo.com"
                    className="text-white font-medium hover:text-white/80 transition-colors"
                  >
                    hello@greggseo.com
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-3">
                <div className="flex h-9 w-9 items-center justify-center rounded-full bg-white/10">
                  <MapPin
                    className="h-4 w-4 text-white"
                    aria-hidden="true"
                  />
                </div>
                <div>
                  <p className="text-xs text-white/80 uppercase tracking-wide">
                    Location
                  </p>
                  <p className="text-white font-medium">
                    Centre Park, Warrington, WA1 1QG
                  </p>
                </div>
              </div>
            </div>

            <div className="mt-10 flex flex-wrap gap-4">
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
                asChild
              >
                <a href="/contact">
                  Full Contact Page
                  <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="bg-transparent text-white border-white hover:bg-white/10"
                asChild
              >
                <a href="/services">View All Services</a>
              </Button>
            </div>
          </div>

          {/* Right: quick enquiry form */}
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-8">
            <h3 className="text-xl font-bold text-white mb-6">
              Quick Warrington Enquiry
            </h3>
            <form
              className="space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
              }}
            >
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-1.5">
                  <Label htmlFor="w-name" className="text-white/90 text-sm">
                    Name
                  </Label>
                  <Input
                    id="w-name"
                    type="text"
                    placeholder="Your name"
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-primary"
                    required
                  />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="w-email" className="text-white/90 text-sm">
                    Email
                  </Label>
                  <Input
                    id="w-email"
                    type="email"
                    placeholder="you@company.com"
                    className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-primary"
                    required
                  />
                </div>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="w-website" className="text-white/90 text-sm">
                  Website URL
                </Label>
                <Input
                  id="w-website"
                  type="url"
                  placeholder="https://yourwarringtonbusiness.co.uk"
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-primary"
                />
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="w-message" className="text-white/90 text-sm">
                  What are your main SEO goals?
                </Label>
                <Textarea
                  id="w-message"
                  placeholder="Tell me about your business, current challenges, and what you'd like to achieve..."
                  className="bg-white/10 border-white/20 text-white placeholder:text-white/50 focus:border-primary min-h-[100px]"
                />
              </div>

              <Button
                type="submit"
                size="lg"
                className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
              >
                Send Enquiry
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>

              <p className="text-xs text-white/80 text-center">
                I typically respond within 1 business day. No spam, ever.
              </p>
            </form>
          </div>
        </div>
      </div>
    </ImageBackground>
  );
});

WarringtonCTA.displayName = "WarringtonCTA";

export default WarringtonCTA;
