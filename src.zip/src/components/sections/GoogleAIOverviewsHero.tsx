import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { Brain, ChevronRight, Info, Search } from "lucide-react";

const GoogleAIOverviewsHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="google-aioverviews-hero"
      className="relative py-20 md:py-32 border-t border-border bg-background"
      aria-label="Google AI Overviews Visibility hero"
    >
      {/* Subtle background texture — dot grid */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.035]"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(225 28% 14%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl">

          {/* Eyebrow label */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0 }}
            className="mb-6 flex items-center gap-3 flex-wrap"
          >
            <Badge
              variant="secondary"
              className="inline-flex items-center gap-1.5 text-xs uppercase tracking-widest font-medium px-3 py-1 border border-border bg-muted text-muted-foreground"
            >
              <Info className="h-3 w-3" />
              Informational Guide
            </Badge>
            <span className="text-xs text-muted-foreground tracking-wide uppercase">
              AI Search Series
            </span>
          </motion.div>

          {/* H1 */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.08 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-foreground leading-[1.1] max-w-3xl"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Google AI Overviews{" "}
            <span className="block mt-1 text-[hsl(119_35%_46%)]">
              Visibility
            </span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.16 }}
            className="mt-6 text-lg md:text-xl text-muted-foreground leading-relaxed max-w-2xl"
          >
            Understand how Google&rsquo;s AI-generated summaries work — and how
            to ensure your website earns a place in them.
          </motion.p>

          {/* Informational context note */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.24 }}
            className="mt-5 flex items-start gap-2.5 max-w-xl"
          >
            <Brain
              className="h-5 w-5 shrink-0 mt-0.5 text-[hsl(119_35%_46%)]"
              aria-hidden="true"
            />
            <p className="text-sm text-muted-foreground leading-relaxed">
              This guide explains what Google AI Overviews are, how they are
              generated, and what factors influence whether your content appears
              — written from the perspective of an independent SEO consultant
              working with UK businesses.
            </p>
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.32 }}
            className="mt-10 flex flex-wrap items-center gap-4"
          >
            <Button
              asChild
              size="lg"
              className="inline-flex items-center gap-2 bg-[hsl(84_74%_60%)] hover:bg-[hsl(84_74%_54%)] text-[hsl(225_28%_10%)] font-semibold px-7 py-3 rounded-md transition-all duration-200 shadow-none hover:shadow-[0_0_24px_hsl(84_74%_58%/0.28)]"
            >
              <Link to="/ai-search-optimisation">
                Explore AI Search Optimisation
                <ChevronRight className="h-4 w-4" />
              </Link>
            </Button>

            <Button
              asChild
              variant="ghost"
              size="lg"
              className="inline-flex items-center gap-2 text-foreground hover:text-[hsl(119_35%_46%)] hover:bg-transparent px-0 font-medium transition-colors duration-200"
            >
              <Link to="/contact">
                Speak to Gregg
                <ChevronRight className="h-4 w-4" />
              </Link>
            </Button>
          </motion.div>

          {/* Trust footnote — verbatim text */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.5, ease: "easeOut", delay: 0.44 }}
            className="mt-6 text-xs text-muted-foreground tracking-wide"
          >
            FREE GBP AUDIT available with every consultation enquiry.
          </motion.p>
        </div>

        {/* Decorative aside — keyword intent signals */}
        <motion.aside
          initial={{ opacity: 0, x: 24 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.7, ease: "easeOut", delay: 0.38 }}
          aria-label="What this guide covers"
          className="hidden lg:block absolute right-0 top-1/2 -translate-y-1/2 max-w-[260px] mr-4"
        >
          <div className="rounded-md border border-border bg-muted/60 px-5 py-5 space-y-3.5">
            <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">
              What this covers
            </p>
            {[
              "What are Google AI Overviews?",
              "How are summaries generated?",
              "Which queries trigger them?",
              "How to appear in AI Overviews",
              "EEAT & entity clarity signals",
            ].map((item, i) => (
              <div key={i} className="flex items-start gap-2.5">
                <span className="mt-1 h-1.5 w-1.5 rounded-full shrink-0 bg-[hsl(84_74%_60%)]" />
                <span className="text-sm text-foreground leading-snug">
                  {item}
                </span>
              </div>
            ))}
            <div className="pt-1 border-t border-border">
              <p className="text-xs text-muted-foreground leading-relaxed">
                Part of Gregg King&rsquo;s AI Search series — informational
                guides for UK businesses navigating AI-powered search.
              </p>
            </div>
          </div>
        </motion.aside>
      </div>
    </section>
  );
});

GoogleAIOverviewsHero.displayName = "GoogleAIOverviewsHero";

export default GoogleAIOverviewsHero;
