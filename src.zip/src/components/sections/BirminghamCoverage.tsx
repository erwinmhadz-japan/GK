import React from "react";
import { Badge } from "@/components/ui/badge";
import { MapPin, ChevronRight, View } from "lucide-react";

const areas = [
  "Birmingham City Centre",
  "Edgbaston",
  "Harborne",
  "Sutton Coldfield",
  "Jewellery Quarter",
  "Digbeth",
  "Erdington",
  "Solihull",
  "Moseley",
  "Kings Heath",
  "Brindleyplace",
  "Aston",
  "Handsworth",
  "Smethwick",
  "West Bromwich",
  "Wolverhampton (WM)",
];

const BirminghamCoverage: React.FC = () => {
  return (
    <section className="relative py-20 md:py-32 border-t border-border bg-background">
      <div className="container">
        <div className="grid md:grid-cols-2 gap-12 items-start">
          {/* Left: text */}
          <div>
            <Badge variant="secondary" className="mb-4 text-xs uppercase tracking-widest">
              Coverage Areas
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-5">
              Serving Birmingham and the Wider West Midlands
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed mb-6">
              Based in the UK and working remotely, I support Birmingham businesses
              across every district and postcode. From city-centre professionals in B1
              and B2, to suburban businesses in B15 Edgbaston and B72 Sutton Coldfield
              — local SEO strategy is built around your specific geography.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-6">
              I also support businesses operating across the wider West Midlands region,
              including Solihull, Wolverhampton, and Coventry. If your customers search
              locally, I help you show up.
            </p>
            <a
              href="/locations"
              className="inline-flex items-center gap-1 text-primary font-medium hover:underline text-sm"
            >
              View all locations I serve
              <ChevronRight className="h-4 w-4" />
            </a>
          </div>

          {/* Right: areas grid */}
          <div>
            <div className="bg-muted rounded-2xl p-7 border border-border">
              <h3 className="text-base font-semibold text-foreground mb-5 flex items-center gap-2">
                <MapPin className="h-5 w-5 text-primary" />
                Areas Covered
              </h3>
              <ul className="grid grid-cols-2 gap-y-3 gap-x-4">
                {areas.map((area) => (
                  <li
                    key={area}
                    className="flex items-center gap-2 text-sm text-muted-foreground"
                  >
                    <span className="h-1.5 w-1.5 rounded-full bg-primary shrink-0" />
                    {area}
                  </li>
                ))}
              </ul>
              <p className="mt-5 text-xs text-muted-foreground border-t border-border pt-4">
                Don't see your area?{" "}
                <a href="/contact" className="text-primary hover:underline font-medium">
                  Get in touch
                </a>{" "}
                — I work with businesses across the UK.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BirminghamCoverage;
