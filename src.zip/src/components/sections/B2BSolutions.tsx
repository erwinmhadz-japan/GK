import React from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight, Network, BookOpen, Layers, Link2, View } from "lucide-react";

const solutions = [
  {
    icon: Network,
    label: "Entity SEO for Service Authority",
    heading: "Build Recognised Entity Status for Your Firm",
    body: "Google's Knowledge Graph powers modern search. We structure your firm as a verified entity — with comprehensive schema markup, consistent NAP signals, Wikipedia/Wikidata presence, and authoritative content clusters — so Google and AI tools confidently associate your brand with your specialisms.",
    link: "/entity-seo",
    linkLabel: "Explore Entity SEO →",
  },
  {
    icon: BookOpen,
    label: "Content Strategy for Thought Leadership",
    heading: "Content That Converts the Entire Buying Committee",
    body: "We map content to every stage of the B2B buyer's journey and every persona in the decision-making unit. From top-of-funnel awareness articles to deep technical guides and case-study-led service pages, every piece earns topical authority and moves prospects through your funnel.",
    link: "/content-strategy",
    linkLabel: "Explore Content Strategy →",
  },
  {
    icon: Layers,
    label: "Schema Markup for Organisations",
    heading: "Structured Data That Signals Professional Credibility",
    body: "Service, ProfessionalService, Organization, FAQPage, and Person schema — implemented correctly — unlock rich results and give AI models the structured facts they need to cite your firm. We go beyond basic markup to build a complete structured-data architecture around your business.",
    link: "/schema-markup",
    linkLabel: "Explore Schema Markup →",
  },
  {
    icon: Link2,
    label: "Digital PR Integration",
    heading: "Earn the Authority Backlinks Your Competitors Have",
    body: "Links from industry publications, association sites, and credible news outlets remain a cornerstone of B2B authority. Our Digital PR programme targets the exact domains that matter in your sector, building the off-page signals that reinforce your on-page expertise.",
    link: "/digital-pr",
    linkLabel: "Explore Digital PR →",
  },
];

const B2BSolutions = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="b2b-solutions"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
      aria-label="B2B SEO solutions"
    >
      <div className="container">
        {/* Header */}
        <div className="max-w-2xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            Our B2B SEO Solutions
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-5">
            Four Pillars of B2B Organic Growth
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Each pillar is designed specifically for professional services
            firms where authority, trust, and expertise drive every ranking
            decision. Explore the services underpinning this strategy.
          </p>
        </div>

        {/* Solutions */}
        <div className="space-y-12">
          {solutions.map((sol, index) => {
            const Icon = sol.icon;
            const isEven = index % 2 === 0;
            return (
              <div
                key={index}
                className={`flex flex-col ${
                  isEven ? "md:flex-row" : "md:flex-row-reverse"
                } gap-8 md:gap-12 items-center`}
              >
                {/* Icon panel */}
                <div className="flex-shrink-0 w-full md:w-72 bg-card rounded-2xl border border-border p-10 flex flex-col items-center justify-center gap-4 shadow-soft">
                  <div className="flex h-16 w-16 items-center justify-center rounded-xl bg-primary/10">
                    <Icon className="h-8 w-8 text-primary" />
                  </div>
                  <span className="text-xs uppercase tracking-widest text-muted-foreground text-center font-medium">
                    {sol.label}
                  </span>
                </div>

                {/* Content */}
                <div className="flex-1">
                  <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                    {sol.heading}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed mb-6">
                    {sol.body}
                  </p>
                  <a
                    href={sol.link}
                    className="inline-flex items-center text-primary font-semibold hover:underline underline-offset-4 transition-colors"
                  >
                    {sol.linkLabel}
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* Bottom CTAs */}
        <div className="mt-16 flex flex-wrap gap-4">
          <Button size="lg" asChild>
            <a href="/contact">
              Start Your B2B SEO Strategy
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Button>
          <Button size="lg" variant="outline" asChild>
            <a href="#industries-cta">View All Industries</a>
          </Button>
        </div>
      </div>
    </section>
  );
});

B2BSolutions.displayName = "B2BSolutions";

export default B2BSolutions;
