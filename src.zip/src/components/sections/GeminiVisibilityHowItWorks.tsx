import React from "react";
import { motion } from "framer-motion";
import { Brain, Tags, FileText, Shield, CheckCircle, Search, Cross, Phone, Section, Signal } from "lucide-react";

interface Signal {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  body: string;
  detail: string[];
}

const signals: Signal[] = [
  {
    icon: Brain,
    title: "Entity Recognition",
    body: "Gemini is built on Google's Knowledge Graph infrastructure, which means it reasons about the world through entities — named people, organisations, places, products, and concepts — rather than raw keyword matches.",
    detail: [
      "Your brand must exist as a recognised entity in Google's knowledge ecosystem",
      "Structured entity data helps Gemini classify and contextualise your expertise",
      "Named entities linked across authoritative sources carry far greater weight than keyword-optimised copy alone",
    ],
  },
  {
    icon: Search,
    title: "Authoritative Content Signals",
    body: "Gemini evaluates whether a source demonstrates real expertise on a subject. Thin, generic content rarely surfaces in AI-generated responses — what gets cited tends to be in-depth, specific, and evidently written by someone with genuine subject knowledge.",
    detail: [
      "Long-form, topic-comprehensive content outperforms shallow cluster articles",
      "First-hand experience and opinion signals matter — Gemini recognises content depth",
      "Topical authority built across a coherent site architecture reinforces individual page strength",
    ],
  },
  {
    icon: Tags,
    title: "Structured Data and Schema Markup",
    body: "Schema markup gives Gemini machine-readable context it can reliably interpret. Without it, even well-written content may be misclassified or overlooked in favour of pages with cleaner semantic signals.",
    detail: [
      "Organisation, Person, and Service schema reinforce entity identity",
      "FAQ, HowTo, and Article schema increase the likelihood of citation in conversational AI responses",
      "Breadcrumb and SiteLinks schema help Gemini map your site's content hierarchy",
    ],
  },
  {
    icon: Shield,
    title: "E-E-A-T Signals",
    body: "Experience, Expertise, Authoritativeness, and Trustworthiness are the criteria by which Google's quality raters — and by extension Gemini — assess whether a source should be cited. These signals are built over time and across your entire digital presence, not just on-page.",
    detail: [
      "Author credentials and bylines establish individual expertise",
      "External citations and backlinks from credible domains build authoritativeness",
      "Consistency between your Google Business Profile, website, and third-party mentions reinforces trust",
    ],
  },
  {
    icon: FileText,
    title: "Content Freshness and Factual Accuracy",
    body: "Gemini favours sources that are accurate, up to date, and consistent with what it can verify across multiple corroborating references. Outdated statistics, contradictory claims, or factual inaccuracies reduce citation probability.",
    detail: [
      "Regular content audits to maintain accuracy across published pages",
      "Citing primary sources and linking to verifiable data builds factual credibility",
      "Date-stamped content with clear last-updated metadata signals active maintenance",
    ],
  },
  {
    icon: CheckCircle,
    title: "Cross-Platform Entity Consistency",
    body: "Gemini cross-references what it finds across the web. If your brand description, services, location, and credentials differ between your website, Google Business Profile, LinkedIn, and third-party directories, those discrepancies erode trust and reduce citation likelihood.",
    detail: [
      "NAP (Name, Address, Phone) consistency across all platforms",
      "Consistent brand positioning language across your site, social profiles, and press mentions",
      "Unified entity identity signals help Gemini confidently attribute responses to your source",
    ],
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const GeminiVisibilityHowItWorks = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="gemini-visibility-how-it-works"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="max-w-3xl mb-16 md:mb-20"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            The Mechanics
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight mb-6">
            How Google Gemini Selects and Cites Sources
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Appearing in Gemini's AI-generated responses isn't a matter of gaming an algorithm —
            it's the result of building the kind of authoritative, well-structured digital presence
            that Gemini is specifically designed to recognise and cite. Below are the core signals
            I focus on when optimising for Gemini visibility.
          </p>
        </motion.div>

        {/* Signals grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="space-y-6"
        >
          {signals.map((signal, index) => {
            const Icon = signal.icon;
            const isEven = index % 2 === 0;

            return (
              <motion.div
                key={signal.title}
                variants={itemVariants}
                className={`rounded-md border border-border ${
                  isEven
                    ? "bg-background"
                    : "bg-[hsl(var(--card))]"
                } p-8 md:p-10`}
              >
                <div className="grid md:grid-cols-[1fr_2fr] gap-8 md:gap-12 items-start">

                  {/* Left: icon + title */}
                  <div>
                    <div className="flex items-start gap-4 mb-4">
                      <div className="flex-shrink-0 flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <span className="text-xs uppercase tracking-[0.18em] text-muted-foreground font-medium mb-1 block">
                          Signal {String(index + 1).padStart(2, "0")}
                        </span>
                        <h3 className="text-xl md:text-2xl font-semibold text-foreground leading-snug">
                          {signal.title}
                        </h3>
                      </div>
                    </div>
                  </div>

                  {/* Right: body + detail list */}
                  <div>
                    <p className="text-base text-muted-foreground leading-relaxed mb-6">
                      {signal.body}
                    </p>
                    <ul className="space-y-3">
                      {signal.detail.map((point) => (
                        <li key={point} className="flex items-start gap-3">
                          <span
                            className="flex-shrink-0 mt-1 h-1.5 w-1.5 rounded-full bg-primary"
                            aria-hidden="true"
                          />
                          <span className="text-sm text-muted-foreground leading-relaxed">
                            {point}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Closing editorial note */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.55, ease: "easeOut" }}
          className="mt-16 md:mt-20 border-l-2 border-primary pl-6 max-w-2xl"
        >
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
            My work in{" "}
            <span className="text-foreground font-medium">entity SEO</span> and{" "}
            <span className="text-foreground font-medium">schema markup</span> is directly
            aligned with what Gemini needs to confidently cite a source. These are not
            separate disciplines — they are the same underlying task of making your expertise
            legible to machines that reason about the world the way Gemini does.
          </p>
        </motion.div>
      </div>
    </section>
  );
});

GeminiVisibilityHowItWorks.displayName = "GeminiVisibilityHowItWorks";

export default GeminiVisibilityHowItWorks;
