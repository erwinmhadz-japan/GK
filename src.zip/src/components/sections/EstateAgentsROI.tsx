import React from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { DollarSign, TrendingUp, Target, Shield, ArrowRight, CheckCircle } from "lucide-react";

const roiStats = [
  {
    icon: TrendingUp,
    value: "3–6×",
    label: "Average ROI vs portal spend",
    description:
      "Estate agents who invest in SEO typically generate 3–6× the return compared with equivalent spend on portal premium listings.",
  },
  {
    icon: Target,
    value: "73%",
    label: "Of buyers start on Google",
    description:
      "Before visiting any property portal, the majority of buyers and vendors use Google to research estate agents and locations — making organic search the highest-intent channel.",
  },
  {
    icon: DollarSign,
    value: "£0",
    label: "Cost-per-click once ranked",
    description:
      "Unlike paid search, organic rankings drive traffic indefinitely. Each page that ranks is a permanent lead generation asset — with zero incremental spend per visit.",
  },
  {
    icon: Shield,
    value: "18 mo",
    label: "Average payback period",
    description:
      "Most estate agent SEO investment reaches full payback within 12–18 months, after which organic leads represent pure margin — not an ongoing cost.",
  },
];

const whyChoose = [
  "Deep understanding of property market search behaviour",
  "Transparent monthly reporting with lead attribution",
  "No long-term contracts — results earn your retention",
  "Specialist schema markup for property listing pages",
  "Entity SEO to establish agent brand authority",
  "Proven local SEO methodology for multi-branch agencies",
];

const EstateAgentsROI = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="estate-agents-roi"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          {/* Left — ROI argument */}
          <div>
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
              Lead Generation ROI
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
              SEO Is the Highest-ROI Channel for Estate Agents
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-10">
              Portal spend is unavoidable — but it is also a treadmill. Every
              lead costs money, and the moment you stop paying, the leads
              stop. Organic SEO builds compounding lead generation assets
              that appreciate in value over time, reducing your blended
              cost-per-instruction quarter by quarter.
            </p>

            {/* ROI stat grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              {roiStats.map((stat) => {
                const Icon = stat.icon;
                return (
                  <div
                    key={stat.value}
                    className="bg-card border border-border rounded-xl p-5 shadow-soft hover-lift"
                  >
                    <div className="flex items-center gap-3 mb-3">
                      <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10">
                        <Icon className="h-4 w-4 text-primary" />
                      </div>
                      <span className="text-2xl font-bold text-primary">
                        {stat.value}
                      </span>
                    </div>
                    <p className="text-sm font-semibold text-foreground mb-1.5">
                      {stat.label}
                    </p>
                    <p className="text-xs text-muted-foreground leading-relaxed">
                      {stat.description}
                    </p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right — Why choose + CTAs */}
          <div>
            <div className="bg-card border border-border rounded-2xl p-7 shadow-card mb-6">
              <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
                Why Work With a Specialist
              </Badge>
              <h3 className="text-xl font-bold text-foreground mb-5">
                Estate Agent SEO Done Right Requires Sector Expertise
              </h3>
              <ul className="space-y-3 mb-7">
                {whyChoose.map((point) => (
                  <li key={point} className="flex items-start gap-3">
                    <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                    <span className="text-sm text-foreground">{point}</span>
                  </li>
                ))}
              </ul>

              <div className="flex flex-col sm:flex-row gap-3">
                <Button size="lg" className="flex-1 font-semibold" asChild>
                  <a href="/contact">
                    Start Your Property SEO Strategy
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </a>
                </Button>
              </div>
            </div>

            {/* Secondary CTA card */}
            <div className="bg-gradient-hero-panel rounded-2xl p-6 text-white">
              <p className="text-sm text-white/80 mb-2 uppercase tracking-wider font-medium">
                Quick Win
              </p>
              <h4 className="text-lg font-bold mb-3">
                Free Local SEO Audit for Estate Agents
              </h4>
              <p className="text-sm text-white/80 mb-5 leading-relaxed">
                Discover exactly where your local competitors are outranking
                you and the specific actions needed to close the gap —
                delivered within 48 hours.
              </p>
              <Button
                size="sm"
                variant="outline"
                className="bg-transparent text-white border-white/40 hover:bg-white/10 font-semibold"
                asChild
              >
                <a href="/contact">Request Free Audit</a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

EstateAgentsROI.displayName = "EstateAgentsROI";

export default EstateAgentsROI;
