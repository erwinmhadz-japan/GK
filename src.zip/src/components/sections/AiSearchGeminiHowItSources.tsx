import React from "react";
import { Search, Database, FileText, CheckCircle, Globe, Layers, Grid, Presentation } from "lucide-react";

const steps = [
  {
    icon: Search,
    step: "01",
    title: "Query Interpretation",
    description:
      "Gemini receives a natural-language query and breaks it into semantic concepts — understanding intent, entities, and context rather than literal keywords.",
  },
  {
    icon: Globe,
    step: "02",
    title: "Web Retrieval",
    description:
      "For up-to-date topics, Gemini accesses Google's live index via real-time retrieval — pulling from indexed, crawlable pages to ground its answers in current content.",
  },
  {
    icon: Database,
    step: "03",
    title: "Knowledge Graph Reference",
    description:
      "Gemini cross-references Google's Knowledge Graph to verify entities, facts, and relationships — reinforcing answers with structured knowledge about organisations, people, and concepts.",
  },
  {
    icon: FileText,
    step: "04",
    title: "Source Synthesis",
    description:
      "Retrieved content is synthesised into a coherent response. Gemini weights sources by authority, recency, and relevance — not simply by ranking position.",
  },
  {
    icon: CheckCircle,
    step: "05",
    title: "Citation & Attribution",
    description:
      "When Gemini surfaces information from specific pages, it attributes sources with clickable citations — driving branded awareness and targeted referral traffic.",
  },
  {
    icon: Layers,
    step: "06",
    title: "Response Presentation",
    description:
      "The final answer is formatted for conversational clarity — often structured as a direct paragraph, followed by supporting points, links, and follow-up prompts.",
  },
];

const AiSearchGeminiHowItSources = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="how-gemini-sources"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
      aria-labelledby="how-gemini-sources-heading"
    >
      <div className="container">
        {/* Header */}
        <div className="max-w-2xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            How Gemini Sources Information
          </span>
          <h2
            id="how-gemini-sources-heading"
            className="text-3xl md:text-5xl font-bold text-foreground mb-5"
          >
            From Query to Citation: How Gemini Builds Its Answers
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Understanding Gemini's retrieval and synthesis process is the first step
            to ensuring your content gets picked up, cited, and recommended.
            Gemini doesn't simply repeat the top search result — it evaluates,
            synthesises, and presents information from authoritative sources.
          </p>
        </div>

        {/* Steps Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {steps.map((step) => {
            const Icon = step.icon;
            return (
              <div
                key={step.step}
                className="bg-card border border-border rounded-xl p-6 relative hover-lift shadow-soft"
              >
                <span className="absolute top-4 right-5 text-3xl font-bold text-border select-none">
                  {step.step}
                </span>
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-4">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="text-base font-semibold text-foreground mb-2 pr-8">
                  {step.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {step.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Internal link block */}
        <div className="mt-12 p-6 bg-background border border-border rounded-xl flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="flex-1">
            <p className="text-sm font-semibold text-foreground mb-1">
              Related: How Google AI Overviews Work
            </p>
            <p className="text-sm text-muted-foreground">
              Gemini powers Google AI Overviews. Understanding the overlap helps you
              build a unified AI visibility strategy across both surfaces.
            </p>
          </div>
          <a
            href="/google-ai-overviews"
            className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline shrink-0"
          >
            Learn about AI Overviews →
          </a>
        </div>
      </div>
    </section>
  );
});

AiSearchGeminiHowItSources.displayName = "AiSearchGeminiHowItSources";

export default AiSearchGeminiHowItSources;
