import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Bot, ScanSearch, BrainCircuit, Globe, Waypoints, ArrowRight, Cross, Search } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (delay: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut", delay },
  }),
};

const pillars = [
  {
    icon: BrainCircuit,
    title: "Entity understanding",
    body:
      "Schema markup gives AI systems an unambiguous, machine-readable signal about who you are, what you do, and how your content relates to real-world entities. That clarity directly influences how language models classify and represent your brand.",
  },
  {
    icon: Globe,
    title: "Knowledge panel eligibility",
    body:
      "Organisation, Person, and LocalBusiness schema — implemented correctly — strengthens the signals that inform Google's Knowledge Graph. A well-formed entity footprint increases your eligibility for knowledge panels in both traditional and AI-augmented search.",
  },
  {
    icon: ScanSearch,
    title: "Rich result surfaces",
    body:
      "Structured data unlocks eligibility for rich results: FAQ answers, How-To steps, review stars, and product data. These formats appear in standard SERPs but are equally consumed by AI systems drawing on structured web content.",
  },
  {
    icon: Bot,
    title: "Citation in AI Overviews and ChatGPT",
    body:
      "Google's AI Overviews, ChatGPT Browse, and Perplexity all draw on structured content signals when selecting sources to cite. Schema markup improves the coherence and trustworthiness of your content from an AI perspective.",
  },
  {
    icon: Waypoints,
    title: "Cross-platform consistency",
    body:
      "Structured data ensures that the same factual signals — your name, address, service offering, accreditations — are surfaced consistently across Google Search, Bing, Perplexity, and emerging AI-powered answer engines.",
  },
];

const SchemamarkupWhyItMatters = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="schemamarkup-why-it-matters"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Header */}
        <div className="max-w-3xl mb-14 md:mb-20">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={0}
          >
            <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground font-medium mb-4">
              Schema Markup &amp; AI Search
            </span>
          </motion.div>

          <motion.h2
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={0.08}
            className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground font-[Sora,sans-serif] leading-tight mb-5"
          >
            Structured Data in the Age of AI Search
          </motion.h2>

          <motion.p
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={0.16}
            className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl"
          >
            Schema markup has always mattered for search visibility. In the era of AI-powered answer
            engines, it matters even more. Structured data is how you communicate the facts about your
            business to systems that cannot infer meaning from prose alone — and that increasingly
            decide which sources are cited, surfaced, and trusted.
          </motion.p>
        </div>

        {/* Pillar grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {pillars.map((pillar, index) => {
            const Icon = pillar.icon;
            return (
              <motion.div
                key={pillar.title}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                custom={0.06 * index}
                className="group bg-background border border-border rounded-md p-6 transition-all duration-300 hover:shadow-[var(--shadow-card-hover)]"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mb-4">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="text-base font-semibold text-foreground font-[Sora,sans-serif] mb-2">
                  {pillar.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{pillar.body}</p>
              </motion.div>
            );
          })}

          {/* Closing editorial card — spans remaining column */}
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={0.3}
            className="md:col-span-2 lg:col-span-1 bg-[hsl(var(--navy-deep))] border border-[hsl(var(--navy-mid))] rounded-md p-6 flex flex-col justify-between"
          >
            <div>
              <Badge
                variant="secondary"
                className="text-xs mb-4 bg-primary/20 text-primary border-0"
              >
                AI Search Ready
              </Badge>
              <h3 className="text-base font-semibold text-white font-[Sora,sans-serif] mb-3">
                The competitive advantage is implementation
              </h3>
              <p className="text-sm text-white/80 leading-relaxed">
                Most websites have incomplete, inconsistent, or technically incorrect structured
                data. A properly implemented schema strategy — aligned with your entity graph and
                content architecture — is still a meaningful differentiator in both traditional and
                AI-augmented search.
              </p>
            </div>
          </motion.div>
        </div>

        {/* Inline context block */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          custom={0.1}
          className="border border-border rounded-md bg-background p-6 md:p-8 max-w-4xl"
        >
          <h3 className="text-sm font-semibold text-foreground font-[Sora,sans-serif] uppercase tracking-wide mb-4">
            How schema connects to AI search visibility
          </h3>
          <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-4">
            AI-powered systems such as Google AI Overviews, ChatGPT, Perplexity, and Gemini all
            process structured web content as part of their source evaluation. Whilst no schema type
            guarantees citation, the presence of coherent, technically valid structured data
            improves the machine-readability of your content — and that clarity is a prerequisite
            for being considered a trustworthy source.
          </p>
          <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-6">
            Schema implementation works in concert with entity SEO and broader content authority. It
            is one layer of a structured approach to making your business legible and credible across
            the full landscape of search surfaces — not a standalone quick fix.
          </p>

          {/* Cross-links */}
          <div className="flex flex-col sm:flex-row gap-4">
            <Link
              to="/ai-search-optimisation"
              className="inline-flex items-center gap-2 text-sm text-primary font-medium hover:underline underline-offset-4 transition-colors"
            >
              AI Search Optimisation service
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              to="#ai-search-cta"
              className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground font-medium hover:underline underline-offset-4 transition-colors"
            >
              Understanding AI search
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </motion.div>

      </div>
    </section>
  );
});

SchemamarkupWhyItMatters.displayName = "SchemamarkupWhyItMatters";

export default SchemamarkupWhyItMatters;
