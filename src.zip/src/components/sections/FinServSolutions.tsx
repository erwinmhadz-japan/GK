import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Building2, BarChart, BookOpen, Settings, ChevronRight, Icon } from "lucide-react";

const solutions = [
  {
    icon: Building2,
    badge: "Entity SEO",
    title: "Entity SEO for Brand Authority",
    description:
      "We establish your firm as a recognised entity in Google's Knowledge Graph. By structuring your brand, services, and key personnel as authoritative entities, we help Google understand exactly who you are — boosting branded search, reducing reliance on third-party comparison sites, and strengthening your E-E-A-T profile.",
    href: "/entity-seo",
    stat: "3× increase in branded impressions",
  },
  {
    icon: BarChart,
    badge: "Schema Markup",
    title: "Schema Markup for Financial Products",
    description:
      "Rich results and enhanced listings are critical in financial search. We implement FinancialProduct, FAQPage, BreadcrumbList, and Organisation schema to communicate product details directly to Google, earning rich snippets that increase click-through rates on competitive SERPs.",
    href: "/schema-markup",
    stat: "Up to 30% uplift in organic CTR",
  },
  {
    icon: BookOpen,
    badge: "Content Strategy",
    title: "Regulatory-Compliant Content Strategy",
    description:
      "Our content team understands FCA, MiFID II, and broader compliance requirements. We build topic clusters around high-value commercial and informational queries — crafting content that is approved by compliance teams without sacrificing search performance or reader engagement.",
    href: "/content-strategy",
    stat: "Content pipelines that clear compliance",
  },
  {
    icon: Settings,
    badge: "Technical SEO",
    title: "Technical SEO for Complex Financial Sites",
    description:
      "Large financial institutions often have legacy architectures, duplicate product pages, and hreflang complexities. We audit and resolve crawl inefficiencies, page speed bottlenecks, Core Web Vitals failures, and indexation issues — ensuring every page that should rank, does.",
    href: "/technical-seo",
    stat: "Average 40% improvement in crawl efficiency",
  },
];

const FinServSolutions: React.FC = () => {
  return (
    <section className="relative py-20 md:py-32 border-t border-border bg-muted">
      <div className="container">
        <div className="max-w-2xl mx-auto text-center mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-3">
            Our Solutions
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            A Full-Stack SEO Approach Built for Finance
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
            Every service is calibrated for the regulatory, reputational, and competitive
            realities of financial services — no generic playbooks.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {solutions.map(({ icon: Icon, badge, title, description, href, stat }) => (
            <div
              key={title}
              className="bg-card border border-border rounded-xl p-8 hover-lift shadow-card flex flex-col"
            >
              <div className="flex items-start gap-4 mb-4">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                  <Icon className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <Badge variant="secondary" className="mb-2 text-xs">
                    {badge}
                  </Badge>
                  <h3 className="text-xl font-bold text-foreground leading-snug">
                    {title}
                  </h3>
                </div>
              </div>
              <p className="text-muted-foreground leading-relaxed mb-5 flex-1">
                {description}
              </p>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-primary">{stat}</span>
                <a
                  href={href}
                  className="inline-flex items-center gap-1 text-sm font-medium text-foreground hover:text-primary transition-colors"
                >
                  Learn more <ChevronRight className="h-4 w-4" />
                </a>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-muted-foreground mb-4">
            Not sure where to start?{" "}
            <a href="#industries-cta" className="text-primary font-medium hover:underline">
              Explore all industries we serve →
            </a>
          </p>
          <Button size="lg" asChild>
            <a href="/contact">Discuss Your Financial SEO Strategy</a>
          </Button>
        </div>
      </div>
    </section>
  );
};

export default FinServSolutions;
