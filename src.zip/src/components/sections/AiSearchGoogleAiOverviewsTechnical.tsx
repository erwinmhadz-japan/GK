import React from "react";
import { Cpu, FileText, Layers, Network, Search, Zap } from "lucide-react";

const technicalRequirements = [
  {
    icon: Zap,
    title: "Core Web Vitals",
    body:
      "Google's indexing pipeline weighs page experience signals. Pages with poor LCP, CLS, or INP scores are less likely to surface in AI Overviews, regardless of content quality. Achieving 'Good' thresholds is a prerequisite.",
  },
  {
    icon: FileText,
    title: "Schema Markup & Structured Data",
    body:
      "Schema.org markup helps Google parse your content into machine-readable entities. FAQ, HowTo, Article, Person, and Organisation schema all provide explicit signals that improve the likelihood of citation.",
  },
  {
    icon: Layers,
    title: "Crawlability & Indexation",
    body:
      "AI Overviews can only cite indexed pages. Regular crawl audits, an accurate XML sitemap, clean internal linking, and a coherent robots.txt file ensure Google can discover and re-crawl your best content consistently.",
  },
  {
    icon: Network,
    title: "Site Architecture & Internal Links",
    body:
      "A well-structured content hub — with clear category pages, topic clusters, and contextual internal links — distributes PageRank efficiently and signals topical depth to Google's crawlers and the AI model alike.",
  },
  {
    icon: Cpu,
    title: "Mobile-First Rendering",
    body:
      "Google uses mobile-first indexing across the board. If your site renders differently on mobile — hiding content, blocking scripts, or delivering a degraded experience — the mobile version is what Google evaluates for AI Overviews.",
  },
  {
    icon: Search,
    title: "Canonical & Duplicate Content",
    body:
      "Duplicate or near-duplicate pages dilute crawl budget and confuse Google's content selection process. Clean canonicalisation ensures your strongest, most authoritative page on each topic is the one considered for citation.",
  },
];

const AiSearchGoogleAiOverviewsTechnical = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Technical SEO Requirements
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">
            Technical SEO for AI Overview Visibility
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Content quality alone isn't enough. Google AI Overviews cite sources from
            technically sound websites — here are the six technical requirements that
            underpin any AI Overview optimisation programme.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {technicalRequirements.map((req) => (
            <div
              key={req.title}
              className="rounded-xl border border-border bg-background p-7 shadow-soft hover-lift"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 mb-5">
                <req.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-bold text-foreground mb-3">{req.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{req.body}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <p className="text-muted-foreground mb-4">
            Need a full technical health check?
          </p>
          <a
            href="/technical-seo"
            className="inline-flex items-center gap-2 text-primary font-semibold underline hover:no-underline text-sm"
          >
            Explore our Technical SEO services
          </a>
        </div>
      </div>
    </section>
  );
});

AiSearchGoogleAiOverviewsTechnical.displayName = "AiSearchGoogleAiOverviewsTechnical";

export default AiSearchGoogleAiOverviewsTechnical;
