import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Star, Quote, MapPin, ArrowRight, Gift, Stars, View } from "lucide-react";

const testimonials = [
  {
    quote:
      "We're a precision engineering firm in Attercliffe and SEO wasn't on our radar. After six months of targeted work, we're ranking page one for our core manufacturing terms and generating genuine B2B enquiries from companies we'd never reached before.",
    name: "Mark D.",
    role: "MD, Sheffield Precision Components",
    avatar:
      "https://images.unsplash.com/photo-1733625576932-348e73c45e82?w=400&h=400&fit=crop&crop=face",
    location: "Attercliffe, Sheffield",
  },
  {
    quote:
      "Our law firm had been in Sheffield for 20 years but we were invisible online. The local SEO strategy transformed our enquiry pipeline — we now rank in the top three for all our primary search terms across the S1–S10 postcodes.",
    name: "Claire W.",
    role: "Partner, South Yorkshire Legal",
    avatar:
      "https://images.unsplash.com/photo-1710778044102-56a3a6b69a1b?w=400&h=400&fit=crop&crop=face",
    location: "Sheffield City Centre",
  },
  {
    quote:
      "As an independent retailer on Ecclesall Road, competing against national chains seemed impossible. The local SEO work has delivered a 120% increase in organic store visits within a year. The ROI is exceptional.",
    name: "James P.",
    role: "Owner, The Sheffield Gift Co.",
    avatar:
      "https://images.unsplash.com/photo-1734830268394-6c4a1f165af1?w=400&h=400&fit=crop&crop=face",
    location: "Ecclesall Road, Sheffield",
  },
];

const SheffieldTestimonials = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="sheffield-testimonials"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      {/* Subtle background dot grid */}
      <div
        className="pointer-events-none absolute inset-0 bg-dot-grid opacity-40"
        aria-hidden="true"
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="text-center max-w-2xl mx-auto mb-14"
        >
          <div className="flex items-center justify-center gap-2 mb-4">
            <Star className="h-4 w-4 text-primary flex-shrink-0" aria-hidden="true" />
            <span className="text-xs uppercase tracking-[0.2em] font-medium text-muted-foreground">
              Sheffield client success stories
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-[1.15] mb-4 tracking-tight">
            Results Delivered for{" "}
            <span className="text-gradient-green">Sheffield Businesses</span>
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Real outcomes from real Sheffield companies — manufacturers, professionals,
            and independent retailers across South Yorkshire.
          </p>
        </motion.div>

        {/* Testimonial cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {testimonials.map(({ quote, name, role, avatar, location }, i) => (
            <motion.div
              key={name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.55, delay: i * 0.1, ease: "easeOut" }}
              className="relative rounded-2xl border border-border bg-card shadow-card p-6 flex flex-col"
            >
              {/* Quote icon */}
              <Quote
                className="h-6 w-6 text-primary/30 mb-4 flex-shrink-0"
                aria-hidden="true"
              />

              {/* Stars */}
              <div className="flex gap-0.5 mb-4" aria-label="5 out of 5 stars">
                {[...Array(5)].map((_, j) => (
                  <Star
                    key={j}
                    className="h-4 w-4 text-primary fill-primary"
                    aria-hidden="true"
                  />
                ))}
              </div>

              {/* Quote text */}
              <blockquote className="text-sm text-muted-foreground leading-relaxed italic flex-1 mb-6">
                "{quote}"
              </blockquote>

              {/* Author */}
              <div className="flex items-center gap-3 border-t border-border pt-4">
                <img
                  src={avatar}
                  alt={`${name} headshot`}
                  width={40}
                  height={40}
                  loading="lazy"
                  className="h-10 w-10 rounded-full object-cover flex-shrink-0"
                />
                <div>
                  <p className="text-sm font-semibold text-foreground">{name}</p>
                  <p className="text-xs text-muted-foreground">{role}</p>
                </div>
                <div className="ml-auto flex items-center gap-1 text-xs text-muted-foreground">
                  <MapPin className="h-3 w-3 flex-shrink-0" aria-hidden="true" />
                  <span>{location}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="text-center"
        >
          <Button size="lg" asChild>
            <Link to="#case-studies-cta">
              View Full Case Studies
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
});

SheffieldTestimonials.displayName = "SheffieldTestimonials";

export default SheffieldTestimonials;
