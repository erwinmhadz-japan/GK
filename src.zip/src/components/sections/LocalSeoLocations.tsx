import React from "react";
import { motion } from "framer-motion";
import { MapPin, ArrowRight, Globe, Badge, Home, Icon, Section, View } from "lucide-react";
import { Link } from "react-router-dom";

interface LocationCard {
  city: string;
  descriptor: string;
  note: string;
  href: string;
  isBase?: boolean;
}

const locations: LocationCard[] = [
  {
    city: "Warrington",
    descriptor: "Home base",
    note: "Based in Warrington, Cheshire — providing on-the-ground local SEO for businesses across the borough and surrounding areas.",
    href: "/locations",
    isBase: true,
  },
  {
    city: "Manchester",
    descriptor: "Greater Manchester",
    note: "Helping Manchester businesses compete in one of the UK's most competitive local search markets — from the city centre to Salford and beyond.",
    href: "/locations",
  },
  {
    city: "Liverpool",
    descriptor: "Merseyside",
    note: "Supporting Liverpool-based businesses in local SEO — map pack visibility, Google Business Profile optimisation, and localised content strategy.",
    href: "/locations",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const headingVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" },
  },
};

const LocalSeoLocations = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="local-seo-locations"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={headingVariants}
          className="mb-12 md:mb-16"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Coverage
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground max-w-2xl leading-snug">
            Local SEO Coverage Across the UK
          </h2>
          <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
            I work with businesses across the UK — from my base in Warrington, Cheshire, to Manchester, Liverpool, and beyond. Independent, consistent, consultant-led.
          </p>
        </motion.div>

        {/* Location cards — exactly 3 */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={containerVariants}
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          {locations.map((loc) => (
            <motion.div
              key={loc.city}
              variants={cardVariants}
              className={[
                "group relative flex flex-col rounded-md border p-6 md:p-7 transition-all duration-300",
                "hover:shadow-[0_4px_24px_0_rgba(35,40,65,0.10)] hover:-translate-y-1",
                loc.isBase
                  ? "bg-[hsl(225_28%_14%)] border-[hsl(214_32%_60%/0.22)] text-white"
                  : "bg-[hsl(231_9%_16%)] border-[hsl(214_32%_60%/0.16)] text-white",
              ].join(" ")}
            >
              {/* Badge */}
              {loc.isBase && (
                <span className="inline-flex items-center gap-1.5 text-[10px] uppercase tracking-[0.18em] font-semibold text-[hsl(84_74%_60%)] mb-4 w-fit">
                  <span className="inline-block w-1.5 h-1.5 rounded-full bg-[hsl(84_74%_60%)]" />
                  Base location
                </span>
              )}

              {/* Icon + city */}
              <div className="flex items-start gap-3 mb-4">
                <div className="flex-shrink-0 mt-0.5 w-8 h-8 rounded flex items-center justify-center bg-[hsl(214_32%_60%/0.12)]">
                  <MapPin className="h-4 w-4 text-[hsl(214_32%_60%)]" />
                </div>
                <div>
                  <h3 className="text-lg font-semibold text-white leading-tight">
                    {loc.city}
                  </h3>
                  <p className="text-xs text-white/60 mt-0.5 uppercase tracking-wide font-medium">
                    {loc.descriptor}
                  </p>
                </div>
              </div>

              {/* Description */}
              <p className="text-sm text-white/75 leading-relaxed flex-1">
                {loc.note}
              </p>

              {/* Link */}
              <Link
                to={loc.href}
                className="inline-flex items-center gap-1.5 mt-5 text-xs font-medium text-[hsl(214_32%_60%)] hover:text-[hsl(84_74%_60%)] transition-colors duration-200 group/link"
              >
                View location details
                <ArrowRight className="h-3.5 w-3.5 transition-transform duration-200 group-hover/link:translate-x-0.5" />
              </Link>
            </motion.div>
          ))}
        </motion.div>

        {/* Broader UK signal */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.55, ease: "easeOut", delay: 0.3 }}
          className="mt-10 flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-5 p-5 rounded-md border border-border bg-muted/40"
        >
          <div className="flex-shrink-0 w-9 h-9 rounded flex items-center justify-center bg-background border border-border">
            <Globe className="h-4 w-4 text-muted-foreground" />
          </div>
          <p className="text-sm text-muted-foreground leading-relaxed">
            <span className="font-semibold text-foreground">Remote-first, UK-wide.</span>{" "}
            I work with clients across Birmingham, Leeds, Sheffield, London, and elsewhere in the UK. Local expertise, delivered remotely — or in person when it matters.
          </p>
          <Link
            to="/locations"
            className="flex-shrink-0 inline-flex items-center gap-1.5 text-xs font-medium text-foreground hover:text-primary transition-colors duration-200 underline-offset-2 hover:underline sm:ml-auto"
          >
            All locations
            <ArrowRight className="h-3.5 w-3.5" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
});

LocalSeoLocations.displayName = "LocalSeoLocations";

export default LocalSeoLocations;
