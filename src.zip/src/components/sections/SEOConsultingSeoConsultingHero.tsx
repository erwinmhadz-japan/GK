import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, CheckCircle, MapPin, ChevronRight, Home, Key, Section, View } from "lucide-react";
import { Link } from "react-router-dom";

const trustSignals = [
  "Independent consultant — no junior teams",
  "Direct senior expertise on every engagement",
  "UK-based, Warrington, Cheshire",
];

const SEOConsultingSeoConsultingHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seoconsulting-seo-consulting-hero"
      className="relative py-20 md:py-32 border-t border-border bg-background overflow-hidden"
    >
      {/* Subtle decorative background element */}
      <div
        className="pointer-events-none absolute inset-0 overflow-hidden"
        aria-hidden="true"
      >
        {/* Faint green glow top-right */}
        <div className="absolute -top-32 right-0 w-[480px] h-[480px] rounded-full bg-[hsl(84_74%_58%/0.06)] blur-3xl" />
        {/* Faint navy band bottom-left */}
        <div className="absolute bottom-0 -left-24 w-[360px] h-[320px] rounded-full bg-[hsl(222_42%_8%/0.05)] blur-2xl" />
      </div>

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        {/* Breadcrumb */}
        <nav aria-label="Breadcrumb" className="mb-8">
          <ol className="flex items-center gap-1 text-xs text-muted-foreground flex-wrap">
            <li>
              <Link to="/" className="hover:text-foreground transition-colors">Home</Link>
            </li>
            <li aria-hidden="true"><ChevronRight className="h-3 w-3 text-muted-foreground/50" /></li>
            <li>
              <Link to="/services" className="hover:text-foreground transition-colors">Services</Link>
            </li>
            <li aria-hidden="true"><ChevronRight className="h-3 w-3 text-muted-foreground/50" /></li>
            <li className="text-foreground font-medium" aria-current="page">SEO Consulting</li>
          </ol>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left column — text content */}
          <div className="space-y-7">
            {/* Eyebrow label */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, ease: "easeOut", delay: 0 }}
            >
              <Badge
                variant="outline"
                className="inline-flex items-center gap-1.5 text-xs font-medium uppercase tracking-widest border-border text-muted-foreground px-3 py-1"
              >
                <MapPin className="h-3 w-3 text-[hsl(84_74%_58%)]" />
                SEO Consultant UK · Warrington, Cheshire
              </Badge>
            </motion.div>

            {/* H1 headline */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-foreground font-[Sora,sans-serif] leading-[1.08] max-w-xl"
            >
              SEO Consulting{" "}
              <span className="relative inline-block">
                for UK Businesses
                {/* Green underline accent */}
                <span
                  className="absolute -bottom-1 left-0 w-full h-[3px] rounded-full"
                  style={{
                    background:
                      "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                  }}
                  aria-hidden="true"
                />
              </span>
            </motion.h1>

            {/* Subheadline */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.2 }}
              className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-lg"
            >
              Strategic, independent SEO consulting from a senior UK practitioner — no account managers, no junior teams.
            </motion.p>

            {/* Trust signal checklist */}
            <motion.ul
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
              className="space-y-2.5"
              aria-label="Key differentiators"
            >
              {trustSignals.map((signal) => (
                <li key={signal} className="flex items-start gap-2.5">
                  <CheckCircle
                    className="h-5 w-5 mt-0.5 shrink-0"
                    style={{ color: "hsl(84 74% 58%)" }}
                    aria-hidden="true"
                  />
                  <span className="text-sm md:text-base text-foreground">{signal}</span>
                </li>
              ))}
            </motion.ul>

            {/* CTA row */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.4 }}
              className="flex flex-col sm:flex-row gap-3 pt-1"
            >
              <Button
                size="lg"
                asChild
                className="group h-12 px-8 text-base font-semibold text-[hsl(222_42%_8%)] border-0"
                style={{
                  background:
                    "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                }}
              >
                <Link to="/contact">
                  Enquire Now
                  <ArrowRight
                    className="ml-2 h-4 w-4 transition-transform duration-200 group-hover:translate-x-1"
                    aria-hidden="true"
                  />
                </Link>
              </Button>

              <Button
                size="lg"
                variant="outline"
                asChild
                className="h-12 px-8 text-base font-medium border-border text-foreground hover:bg-muted transition-colors"
              >
                <Link to="/services">
                  View Services
                </Link>
              </Button>
            </motion.div>

            {/* Micro trust note */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.7, ease: "easeOut", delay: 0.55 }}
              className="text-xs text-muted-foreground pt-1"
            >
              Prefer email?{" "}
              <a
                href="mailto:gregg@greggking.co.uk"
                className="underline underline-offset-2 hover:text-foreground transition-colors"
              >
                gregg@greggking.co.uk
              </a>
            </motion.p>
          </div>

          {/* Right column — visual panel */}
          <motion.div
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, ease: "easeOut", delay: 0.25 }}
            className="relative hidden lg:block"
            aria-hidden="true"
          >
            {/* Dark card panel */}
            <div
              className="relative rounded-md overflow-hidden p-8 shadow-[0_8px_40px_-8px_hsl(222_28%_11%/0.16),0_2px_8px_hsl(222_28%_11%/0.08)]"
              style={{
                background:
                  "linear-gradient(160deg, hsl(222 42% 8%) 0%, hsl(222 35% 18%) 60%, hsl(214 40% 22%) 100%)",
              }}
            >
              {/* Section label inside panel */}
              <p className="text-xs uppercase tracking-[0.18em] text-white/50 mb-6 font-medium">
                Consulting Engagement
              </p>

              {/* Engagement model bullets */}
              <ul className="space-y-5">
                {[
                  {
                    label: "Discovery & Audit",
                    desc: "A structured review of your current SEO position, identifying priority opportunities.",
                  },
                  {
                    label: "Strategy & Roadmap",
                    desc: "A clear, prioritised action plan aligned to your commercial objectives.",
                  },
                  {
                    label: "Ongoing Oversight",
                    desc: "Regular consulting sessions to drive implementation and monitor progress.",
                  },
                  {
                    label: "Direct Access",
                    desc: "Work directly with Gregg King — no account managers or handoffs.",
                  },
                ].map((item, i) => (
                  <li key={item.label} className="flex items-start gap-3">
                    <span
                      className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full text-xs font-bold mt-0.5"
                      style={{
                        background:
                          "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                        color: "hsl(222 42% 8%)",
                      }}
                    >
                      {i + 1}
                    </span>
                    <div>
                      <p className="text-sm font-semibold text-white">{item.label}</p>
                      <p className="text-xs text-white/60 leading-relaxed mt-0.5">
                        {item.desc}
                      </p>
                    </div>
                  </li>
                ))}
              </ul>

              {/* Bottom tag row */}
              <div className="mt-8 pt-6 border-t border-white/10 flex flex-wrap gap-2">
                {["Independent", "UK-Based", "Senior-Level", "No Delegation"].map((tag) => (
                  <span
                    key={tag}
                    className="text-xs px-2.5 py-1 rounded-sm font-medium text-white/70 border border-white/12"
                    style={{ backgroundColor: "hsl(222 42% 14% / 0.7)" }}
                  >
                    {tag}
                  </span>
                ))}
              </div>

              {/* Subtle green accent line at top */}
              <div
                className="absolute top-0 left-0 right-0 h-[3px]"
                style={{
                  background:
                    "linear-gradient(90deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                }}
              />
            </div>

            {/* Floating decorative blob behind the card */}
            <div
              className="absolute -bottom-10 -right-10 w-64 h-64 rounded-full blur-3xl -z-0"
              style={{ backgroundColor: "hsl(84 74% 58% / 0.08)" }}
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
});

SEOConsultingSeoConsultingHero.displayName = "SEOConsultingSeoConsultingHero";

export default SEOConsultingSeoConsultingHero;
