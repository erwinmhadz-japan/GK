import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { TrendingUp, Building2, Users, Briefcase, Target, BarChart, Icon, Search } from "lucide-react";

const stats = [
  { value: "800K+", label: "Population in Leeds city region", icon: Users },
  { value: "£75bn", label: "Leeds city region GVA annually", icon: BarChart },
  { value: "Top 3", label: "Fastest-growing UK city economies", icon: TrendingUp },
  { value: "30%+", label: "Rise in Leeds business searches (5yr)", icon: Target },
];

const sectors = [
  {
    icon: Building2,
    title: "Financial & Professional Services",
    description:
      "Leeds is the UK's second-largest financial centre outside London, home to HSBC, First Direct, and hundreds of law firms — all competing for the same high-value search terms.",
  },
  {
    icon: Briefcase,
    title: "Retail, Hospitality & Leisure",
    description:
      "Kirkgate Market, the Trinity Leeds shopping centre, and a booming restaurant quarter make Leeds a prime destination for local commercial search intent.",
  },
  {
    icon: Users,
    title: "Tech, Digital & Creative",
    description:
      "Leeds' digital sector is expanding rapidly, with a growing cluster of agencies, SaaS companies, and scale-ups creating fierce competition for organic visibility.",
  },
];

const LeedsMarket = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="leeds-market"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="max-w-2xl mb-14"
        >
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="h-4 w-4 text-primary flex-shrink-0" aria-hidden="true" />
            <span className="text-xs uppercase tracking-[0.2em] font-medium text-muted-foreground">
              Leeds market context
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-[1.15] mb-4 tracking-tight">
            Leeds Is Growing — And So Is the{" "}
            <span className="text-gradient-green">Search Competition</span>
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Leeds has transformed over the past decade into one of the UK's most dynamic
            business cities. That growth brings real opportunity — and intensifying
            competition for the organic search positions that deliver customers.
          </p>
        </motion.div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {stats.map(({ value, label, icon: Icon }, i) => (
            <motion.div
              key={value}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.55, delay: i * 0.08, ease: "easeOut" }}
              className="rounded-xl border border-border bg-card p-6 text-center shadow-soft"
            >
              <div className="flex justify-center mb-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
                </div>
              </div>
              <div className="text-2xl md:text-3xl font-bold text-foreground mb-1 tracking-tight">
                {value}
              </div>
              <div className="text-sm text-muted-foreground leading-snug">{label}</div>
            </motion.div>
          ))}
        </div>

        {/* Sector cards */}
        <div className="grid md:grid-cols-3 gap-6">
          {sectors.map(({ icon: Icon, title, description }, i) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.55, delay: i * 0.1, ease: "easeOut" }}
              className="rounded-xl border border-border bg-card p-6 shadow-soft hover-lift"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-4">
                <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">{title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
            </motion.div>
          ))}
        </div>

        {/* Internal link to services */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="mt-10 text-sm text-muted-foreground"
        >
          Explore the full range of{" "}
          <Link
            to="/services"
            className="text-primary font-medium underline underline-offset-4 hover:text-primary/80 transition-colors"
          >
            SEO services available to Leeds businesses →
          </Link>
        </motion.p>
      </div>
    </section>
  );
});

LeedsMarket.displayName = "LeedsMarket";

export default LeedsMarket;
