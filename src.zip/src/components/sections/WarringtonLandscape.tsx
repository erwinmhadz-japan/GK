import React from "react";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, TrendingUp, Users, Building, Construction, Icon, Key, Radius } from "lucide-react";

const stats = [
  { value: "220k+", label: "Warrington residents", icon: Users },
  { value: "Top 15", label: "UK logistics hub", icon: Building },
  { value: "£12bn+", label: "Local economy GVA", icon: TrendingUp },
  { value: "High", label: "SME density vs. UK avg", icon: CheckCircle },
];

const industries = [
  "Logistics & Distribution",
  "Manufacturing",
  "Professional Services",
  "Retail & E-commerce",
  "Healthcare & Dental",
  "Legal & Financial",
  "Hospitality & Leisure",
  "Construction & Trades",
];

const WarringtonLandscape = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-start">
          {/* Left: narrative */}
          <div>
            <span className="inline-block text-xs uppercase tracking-[0.2em] text-primary font-semibold mb-3">
              The Warrington Market
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">
              A Competitive Business Landscape That Rewards Visibility
            </h2>
            <div className="mt-6 space-y-4 text-muted-foreground leading-relaxed">
              <p>
                Warrington sits at the heart of the North West economy — uniquely
                positioned between Manchester and Liverpool, with excellent
                motorway access (M6, M56, M62) that draws businesses across
                logistics, manufacturing, professional services, and retail.
              </p>
              <p>
                That connectivity is a double-edged sword. Customers in Warrington
                don't just compare you to local competitors — they're also
                searching across Greater Manchester and Merseyside. Without strong
                local SEO, your Warrington business is invisible at the very
                moment buyers are ready to act.
              </p>
              <p>
                Key business clusters — Birchwood Business Park, Lingley Mere,
                Gemini Retail Park, and the town centre — generate intense
                competition in categories from logistics tech to dental practices.
                Ranking on page one isn't optional; it's the difference between a
                full pipeline and an empty calendar.
              </p>
              <p>
                I work with Warrington businesses to understand their specific
                competitive context — which rivals dominate local search, what
                content gaps exist, and where quick wins are available — then
                build a strategy that compounds over time.
              </p>
            </div>

            <div className="mt-8">
              <p className="text-sm font-semibold text-foreground mb-3">
                Industries I serve in Warrington:
              </p>
              <div className="flex flex-wrap gap-2">
                {industries.map((industry) => (
                  <Badge
                    key={industry}
                    variant="secondary"
                    className="text-xs py-1 px-3"
                  >
                    {industry}
                  </Badge>
                ))}
              </div>
            </div>

            <div className="mt-8">
              <a
                href="/locations"
                className="text-primary font-medium hover:underline text-sm"
              >
                ← Back to all locations
              </a>
            </div>
          </div>

          {/* Right: stats + coverage areas */}
          <div>
            <div className="grid grid-cols-2 gap-4 mb-8">
              {stats.map(({ value, label, icon: Icon }) => (
                <div
                  key={label}
                  className="bg-card border border-border rounded-xl p-5 shadow-soft"
                >
                  <div className="flex items-center gap-2 mb-2">
                    <Icon
                      className="h-4 w-4 text-primary"
                      aria-hidden="true"
                    />
                    <span className="text-xs text-muted-foreground uppercase tracking-wide">
                      {label}
                    </span>
                  </div>
                  <p className="text-2xl font-bold text-foreground">{value}</p>
                </div>
              ))}
            </div>

            {/* Coverage map visual */}
            <div className="bg-card border border-border rounded-xl p-6 shadow-soft">
              <p className="text-sm font-semibold text-foreground mb-4">
                Coverage Areas — Warrington & Surrounding
              </p>
              <div className="relative bg-muted rounded-lg overflow-hidden">
                <img
                  src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=800&h=400&fit=crop"
                  alt="Team working on local SEO strategy for Warrington businesses"
                  width="800"
                  height="400"
                  className="w-full h-44 object-cover opacity-30"
                  loading="lazy"
                />
                <div className="absolute inset-0 flex flex-col items-center justify-center p-4">
                  <p className="text-xs font-medium text-muted-foreground mb-3 uppercase tracking-wide">
                    Service Radius
                  </p>
                  <div className="flex flex-wrap gap-2 justify-center">
                    {[
                      "Warrington (WA1–WA5)",
                      "Runcorn",
                      "Widnes",
                      "Newton-le-Willows",
                      "Lymm",
                      "Northwich",
                      "Knutsford",
                      "Wigan",
                      "St Helens",
                    ].map((area) => (
                      <span
                        key={area}
                        className="px-2 py-1 rounded bg-background border border-border text-xs font-medium text-foreground"
                      >
                        {area}
                      </span>
                    ))}
                  </div>
                </div>
              </div>
              <p className="mt-3 text-xs text-muted-foreground">
                Remote-first with in-person meetings available across Cheshire &amp; North West.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

WarringtonLandscape.displayName = "WarringtonLandscape";

export default WarringtonLandscape;
