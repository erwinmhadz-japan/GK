import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin, Shield, Target, TrendingUp, Search, Globe, Building } from "lucide-react";

const challenges = [
  {
    icon: Shield,
    title: "SRA Advertising Compliance",
    description:
      "Legal advertising is tightly regulated by the Solicitors Regulation Authority. Every piece of SEO content — from meta descriptions to blog posts — must avoid misleading claims, prohibited outcome guarantees, and comparative advertising rules. Getting this wrong doesn't just hurt rankings; it risks regulatory action.",
    link: "/content-strategy",
    linkLabel: "Compliant Content Strategy",
  },
  {
    icon: MapPin,
    title: "Hyper-Local Visibility",
    description:
      "Most clients searching for solicitors want someone local — 'family solicitor Manchester' or 'conveyancing solicitor Bristol'. Law firms that don't dominate local pack results and Google Business Profile rankings lose high-value enquiries to nearby competitors daily.",
    link: "/local-seo",
    linkLabel: "Local SEO for Law Firms",
  },
  {
    icon: Target,
    title: "Fiercely Competitive Keywords",
    description:
      "Terms like 'personal injury solicitor', 'divorce lawyer', and 'conveyancing solicitor' attract enormous competition and sky-high PPC costs. Winning organically requires deep expertise in keyword strategy, content authority, and backlink acquisition that most generalist SEO agencies can't deliver.",
    link: "/entity-seo",
    linkLabel: "Entity & Authority SEO",
  },
  {
    icon: TrendingUp,
    title: "Building Trust & Authority Online",
    description:
      "Google applies stricter quality evaluation to legal sites under YMYL (Your Money Your Life) guidelines. Law firms must demonstrate genuine E-E-A-T (Experience, Expertise, Authoritativeness, Trustworthiness) through structured content, verifiable credentials, and authoritative links.",
    link: "/entity-seo",
    linkLabel: "Entity SEO & E-E-A-T",
  },
  {
    icon: Search,
    title: "Practice Area Discoverability",
    description:
      "Firms offering multiple practice areas face complex internal architecture challenges. Without clear silo structure and optimised landing pages for each area — from employment law to wills and probate — potential clients can't find the right service, and neither can Google.",
    link: "/content-strategy",
    linkLabel: "Content Strategy",
  },
  {
    icon: Globe,
    title: "AI Search & Featured Snippets",
    description:
      "As AI-powered search (Google AI Overviews, ChatGPT, Perplexity) increasingly answers legal queries directly in SERPs, law firms must optimise for question-based content, structured data, and entity signals to appear in these high-visibility positions.",
    link: "/ai-search-optimisation",
    linkLabel: "AI Search Optimisation",
  },
];

const LawFirmsChallenges = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
      aria-label="SEO challenges for law firms"
    >
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            The Legal SEO Landscape
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
            Why SEO for Law Firms Is Uniquely Complex
          </h2>
          <p className="text-lg text-muted-foreground">
            Legal services SEO sits at the intersection of strict regulation, fierce
            competition, and high client expectation. These are the core challenges
            every UK law firm and solicitor practice faces online.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {challenges.map((challenge) => {
            const Icon = challenge.icon;
            return (
              <Card
                key={challenge.title}
                className="border border-border bg-card shadow-card hover-lift transition-shadow"
              >
                <CardHeader className="pb-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 mb-4">
                    <Icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-lg text-foreground leading-snug">
                    {challenge.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-sm leading-relaxed mb-4">
                    {challenge.description}
                  </p>
                  <a
                    href={challenge.link}
                    className="text-primary font-medium text-sm hover:underline underline-offset-4"
                  >
                    {challenge.linkLabel} →
                  </a>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
});

LawFirmsChallenges.displayName = "LawFirmsChallenges";

export default LawFirmsChallenges;
