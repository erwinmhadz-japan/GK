import React from "react";
import { Users, Globe, Zap, Monitor, Brain, BarChart2, Search } from "lucide-react";

const stats = [
  { value: "1B+", label: "Windows active devices Copilot is integrated into" },
  { value: "400M+", label: "Microsoft 365 subscribers with Copilot access" },
  { value: "70%", label: "Of enterprise AI queries now routed through Copilot" },
];

const integrations = [
  {
    icon: Monitor,
    title: "Windows OS",
    desc: "Copilot is embedded directly into Windows 11, surfacing answers for everyday user queries from the desktop.",
  },
  {
    icon: Globe,
    title: "Microsoft Edge",
    desc: "The Edge browser sidebar gives users instant Copilot access to summarise pages and answer questions while browsing.",
  },
  {
    icon: Users,
    title: "Microsoft 365",
    desc: "Integrated into Word, Outlook, Teams, and more — used by enterprise professionals to research, draft, and decide.",
  },
  {
    icon: Brain,
    title: "Bing Search",
    desc: "Copilot powers Bing's AI-driven answer layer, mixing web results with generative AI responses in a single interface.",
  },
  {
    icon: Zap,
    title: "Azure OpenAI Services",
    desc: "Enterprise businesses build Copilot-powered internal tools, extending Copilot's reach into proprietary workflows.",
  },
  {
    icon: BarChart2,
    title: "Copilot Studio",
    desc: "Organisations create custom Copilot agents for sales, support, and HR — all drawing on publicly sourced content.",
  },
];

const AiSearchCopilotWhatIs = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="what-is-copilot"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start mb-16">
          <div>
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
              What is Microsoft Copilot?
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
              Microsoft's AI Assistant With Unprecedented Reach
            </h2>
            <p className="text-muted-foreground text-base md:text-lg leading-relaxed mb-4">
              Microsoft Copilot is an AI assistant powered by OpenAI's language models and tightly integrated across Microsoft's entire product ecosystem — from Windows and Edge to Microsoft 365 and Bing. Unlike standalone AI chat tools, Copilot is embedded into the software billions of people use every day.
            </p>
            <p className="text-muted-foreground text-base md:text-lg leading-relaxed mb-4">
              When users ask Copilot a question — whether they're searching in Bing, browsing in Edge, or working in Word — Copilot synthesises responses by drawing from web content it has indexed and ranked as authoritative. Businesses whose content is not indexed or well-structured for Copilot's retrieval system are simply not cited.
            </p>
            <p className="text-muted-foreground text-base md:text-lg leading-relaxed">
              Optimising for Copilot visibility means ensuring your site is crawlable, semantically structured, and consistently signals authority — so Copilot chooses to cite your brand when it matters.
            </p>
          </div>
          <div className="space-y-5">
            {stats.map((stat) => (
              <div
                key={stat.value}
                className="flex items-start gap-5 p-5 rounded-xl bg-muted/60 border border-border hover-lift"
              >
                <div className="text-3xl md:text-4xl font-bold text-primary shrink-0">{stat.value}</div>
                <p className="text-muted-foreground text-sm leading-relaxed pt-1">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>

        <div>
          <h3 className="text-xl md:text-2xl font-bold text-foreground mb-8 text-center">
            Where Copilot Reaches Your Audience
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {integrations.map((item) => (
              <div
                key={item.title}
                className="p-6 rounded-xl bg-card border border-border hover-lift shadow-card"
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-4">
                  <item.icon className="h-5 w-5 text-primary" />
                </div>
                <h4 className="font-semibold text-foreground mb-2">{item.title}</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
});

AiSearchCopilotWhatIs.displayName = "AiSearchCopilotWhatIs";
export default AiSearchCopilotWhatIs;
