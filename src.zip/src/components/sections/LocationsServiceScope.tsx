import React from "react";
import { motion } from "framer-motion";
import { Briefcase, FileSearch, BarChart, Monitor, Layers, Shield, FileText, MapPin, Megaphone, Bot, Building, Search, Section, Text, View } from "lucide-react";
import { Link } from "react-router-dom";

// Exactly 10 services — hard contract per expected_count constraint
const services = [
  {
    icon: Briefcase,
    label: "SEO Consulting",
    route: "/seo-consulting",
    description:
      "Strategic SEO direction delivered personally — no junior account managers, no hand-offs, no agency middlemen.",
  },
  {
    icon: FileSearch,
    label: "SEO Audit",
    route: "/seo-audit",
    description:
      "A thorough, actionable audit covering technical health, on-page signals, and organic ranking potential.",
  },
  {
    icon: BarChart,
    label: "SEO Retainer",
    route: "/seo-retainer",
    description:
      "Ongoing consultancy on a retained basis — consistent focus, measurable progress, and direct access throughout.",
  },
  {
    icon: Monitor,
    label: "Technical SEO",
    route: "/technical-seo",
    description:
      "Crawlability, indexation, Core Web Vitals, and site architecture — diagnosed and resolved with precision.",
  },
  {
    icon: Layers,
    label: "Schema Markup",
    route: "/schema-markup",
    description:
      "Structured data implementation to improve how your pages are understood and surfaced in search results.",
  },
  {
    icon: Shield,
    label: "Entity SEO",
    route: "/entity-seo",
    description:
      "Building topical authority and entity associations so your brand ranks with confidence and clarity.",
  },
  {
    icon: FileText,
    label: "Content Strategy",
    route: "/content-strategy",
    description:
      "An editorially rigorous approach to content — mapped to search intent, topical authority, and conversion.",
  },
  {
    icon: MapPin,
    label: "Local SEO",
    route: "/local-seo",
    description:
      "Visibility for city-specific and near-me searches via Google Business Profile, citations, and local signals.",
  },
  {
    icon: Megaphone,
    label: "Digital PR",
    route: "/digital-pr",
    description:
      "Earned media and link acquisition strategies that build domain authority through genuine editorial coverage.",
  },
  {
    icon: Bot,
    label: "AI Search Optimisation",
    route: "/ai-search-optimisation",
    description:
      "Optimising your presence across AI-generated answers — ChatGPT, Perplexity, Google AI Overviews, Gemini, and Copilot.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.07,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 18 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: "easeOut" },
  },
};

const LocationsServiceScope = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="locations-service-scope"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section heading block */}
        <motion.div
          className="mb-12 md:mb-16 max-w-2xl"
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.55, ease: "easeOut" }}
        >
          <span className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium">
            Services Available Across All Locations
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground mb-4 leading-snug">
            The Same Consultancy, Wherever You Are
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-prose">
            Every engagement is delivered directly by Gregg King — an
            independent SEO consultant based in Warrington, Cheshire. The full
            scope of services is available to businesses across all locations
            listed on this page.
          </p>
        </motion.div>

        {/* Service grid — exactly 10 items, 2-column layout on md+ */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-px bg-border rounded-md overflow-hidden"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          variants={containerVariants}
        >
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.label}
                variants={itemVariants}
                className="bg-background hover:bg-muted transition-colors duration-200"
              >
                <Link
                  to={service.route}
                  className="group flex items-start gap-4 px-6 py-6 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-inset"
                >
                  {/* Icon container */}
                  <div className="flex-shrink-0 mt-0.5">
                    <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10">
                      <Icon className="h-4 w-4 text-primary" />
                    </div>
                  </div>

                  {/* Text */}
                  <div className="min-w-0">
                    <p className="text-sm font-semibold text-foreground mb-1 group-hover:text-primary transition-colors duration-200">
                      {service.label}
                    </p>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {service.description}
                    </p>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Footer note — reinforces independent consultant positioning */}
        <motion.div
          className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-3 text-center"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.4, ease: "easeOut" }}
        >
          <p className="text-xs text-muted-foreground">
            All consultancy work is undertaken personally by Gregg King — not
            outsourced, not delegated to a team.
          </p>
          <span className="hidden sm:block h-3 w-px bg-border" aria-hidden="true" />
          <Link
            to="/services"
            className="text-xs text-primary hover:underline underline-offset-4 font-medium transition-colors duration-200"
          >
            View all services →
          </Link>
        </motion.div>
      </div>
    </section>
  );
});

LocationsServiceScope.displayName = "LocationsServiceScope";

export default LocationsServiceScope;
