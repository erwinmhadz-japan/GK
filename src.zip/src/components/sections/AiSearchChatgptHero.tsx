import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bot, ArrowRight, Sparkles, Search } from "lucide-react";

const AiSearchChatgptHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      src="https://images.unsplash.com/photo-1573496528298-f0e9d3c7ce55?w=1920&h=1080&fit=crop"
      alt="Professional working at computer on AI search optimisation"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center py-24"
    >
      <div className="container relative z-10">
        <div className="max-w-3xl">
          <Badge className="mb-6 bg-primary/20 text-primary border-primary/30 backdrop-blur-sm">
            <Bot className="h-3.5 w-3.5 mr-1.5" />
            AI Search Visibility
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold text-white leading-tight mb-6">
            ChatGPT Visibility &{" "}
            <span className="text-gradient-green">AI Search Indexing</span>
          </h1>
          <p className="text-xl text-white/90 leading-relaxed mb-4">
            Millions of people use ChatGPT every day to find answers, evaluate businesses, and make purchasing decisions. Is your brand being cited — or invisible?
          </p>
          <p className="text-lg text-white/80 mb-10">
            This guide covers exactly how ChatGPT sources and surfaces information, the technical requirements for visibility, and the best practices that get you cited in AI-generated answers.
          </p>
          <div className="flex flex-wrap gap-4">
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold" asChild>
              <a href="/services-ai-search-optimisation">
                Get AI Search Optimisation
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white/50 hover:bg-white/10 hover:border-white"
              asChild
            >
              <a href="/contact">Talk to Gregg</a>
            </Button>
          </div>
          <div className="flex flex-wrap items-center gap-6 mt-10">
            <div className="flex items-center gap-2 text-white/80 text-sm">
              <Sparkles className="h-4 w-4 text-primary" />
              <span>ChatGPT &amp; AI Search specialists</span>
            </div>
            <div className="flex items-center gap-2 text-white/80 text-sm">
              <Sparkles className="h-4 w-4 text-primary" />
              <span>Technical &amp; content-level optimisation</span>
            </div>
            <div className="flex items-center gap-2 text-white/80 text-sm">
              <Sparkles className="h-4 w-4 text-primary" />
              <span>Proven citation strategies</span>
            </div>
          </div>
        </div>
      </div>
    </ImageBackground>
  );
});

AiSearchChatgptHero.displayName = "AiSearchChatgptHero";
export default AiSearchChatgptHero;
