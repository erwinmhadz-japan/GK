import React from "react";
import { motion } from "framer-motion";
import { TrendingUp, Factory, Users, Target, BarChart, Building2, Icon, Search } from "lucide-react";

const stats = [
  { value: "584K+", label: "Population in Sheffield city", icon: Users },
  { value: "£14bn", label: "Sheffield city region GVA annually", icon: BarChart },
  { value: "Top 10", label: "UK cities for manufacturing output", icon: Factory },
  { value: "40%+", label: "Rise in Sheffield business searches (5yr)", icon: Target },
];

const sectors = [
  {
    icon: Factory,
    title: "Advanced Manufacturing & Engineering",
    description:
      "Sheffield remains the UK's steel and advanced manufacturing capital, home to firms including Boeing, McLaren Automotive, and hundreds of precision engineering SMEs — all competing for specialist B2B search terms.",
  },
  {
    icon: Building2,
    title: "Professional & Business Services",
    description:
      "A growing cluster of legal firms, accountants, and consultancies serving the South Yorkshire market has intensified competition for high-value professional search keywords across the S1–S35 postcode range.",
  },
  {
    icon: Users,
    title: "Retail, Hospitality & Digital",
    description:
      "Meadowhall, the independent retail quarter on Ecclesall Road, and a booming hospitality scene mean local commercial search intent is significant — and businesses that rank win real footfall.",
  },
];

const SheffieldMarket = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="sheffield-market"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="max-w-2xl mb-14"
        >
          <div className="flex items-center gap-2 mb-4">
            <TrendingUp className="h-4 w-4 text-primary flex-shrink-0" aria-hidden="true" />
            <span className="text-xs uppercase tracking-[0.2em] font-medium text-muted-foreground">
              Sheffield market context
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-[1.15] mb-4 tracking-tight">
            Sheffield Is Reinventing Itself — And So Is the{" "}
            <span className="text-gradient-green">Search Landscape</span>
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            The Steel City's economic renaissance — from advanced manufacturing and
            knowledge industries to thriving independent retail and hospitality — has
            created a fiercely competitive local search environment. Businesses that
            invest in SEO now are securing the rankings that matter before competitors
            catch on.
          </p>
        </motion.div>

        {/* Stats grid */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {stats.map(({ value, label, icon: Icon }, i) => (
            <motion.div
              key={value}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.55, delay: i * 0.08, ease: "easeOut" }}
              className="rounded-xl border border-border bg-card p-6 text-center shadow-soft"
            >
              <div className="flex justify-center mb-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
                </div>
              </div>
              <p className="text-2xl md:text-3xl font-bold text-foreground mb-1">{value}</p>
              <p className="text-xs text-muted-foreground leading-snug">{label}</p>
            </motion.div>
          ))}
        </div>

        {/* Sectors */}
        <div className="grid md:grid-cols-3 gap-6">
          {sectors.map(({ icon: Icon, title, description }, i) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.55, delay: i * 0.1, ease: "easeOut" }}
              className="rounded-xl border border-border bg-card p-6 shadow-soft hover-lift"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-4">
                <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
              </div>
              <h3 className="text-base font-semibold text-foreground mb-2">{title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
});

SheffieldMarket.displayName = "SheffieldMarket";

export default SheffieldMarket;
