import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle, View } from "lucide-react";

const IndustriesHero = React.forwardRef<HTMLElement>((props, ref) => {
  const highlights = [
    "Sector-specific keyword strategy",
    "Industry-authoritative content",
    "Regulated market expertise",
  ];

  return (
    <ImageBackground
      ref={ref}
      src="https://images.unsplash.com/photo-1573496130141-209d200cebd8?w=1920&h=1080&fit=crop"
      alt="Two women in suits standing beside wall — professional industry expertise"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center py-24 md:py-32"
    >
      <div className="container relative z-10">
        <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4 font-medium">
          Industry-Specific SEO
        </span>
        <h1 className="text-4xl md:text-6xl font-bold text-white mt-2 max-w-4xl">
          SEO That Speaks Your{" "}
          <span className="text-gradient-green">Industry's Language</span>
        </h1>
        <p className="text-lg md:text-xl text-white/90 mt-6 max-w-2xl leading-relaxed">
          Generic SEO doesn't cut through in competitive professional sectors. I deliver
          specialist search strategies tailored to the compliance requirements, buyer journeys,
          and competitive dynamics of your specific industry vertical.
        </p>
        <ul className="mt-8 flex flex-col sm:flex-row flex-wrap gap-x-8 gap-y-3">
          {highlights.map((item) => (
            <li key={item} className="flex items-center gap-2 text-white/90 text-sm font-medium">
              <CheckCircle className="h-4 w-4 text-primary shrink-0" />
              {item}
            </li>
          ))}
        </ul>
        <div className="flex flex-wrap gap-4 mt-10">
          <Button size="lg" className="bg-gradient-cta text-foreground font-semibold hover:opacity-90 transition-opacity" asChild>
            <a href="/contact">
              Discuss Your Industry
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-transparent text-white border-white hover:bg-white/10"
            asChild
          >
            <a href="/services">View All Services</a>
          </Button>
        </div>
      </div>
    </ImageBackground>
  );
});

IndustriesHero.displayName = "IndustriesHero";

export default IndustriesHero;
