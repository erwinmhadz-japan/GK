import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Globe, TrendingUp, MapPin, Network, ArrowRight, Icon, Search } from "lucide-react";

const expansionSteps = [
  {
    step: "01",
    icon: MapPin,
    title: "London Market Dominance First",
    description:
      "Before expanding nationally, we lock down London search authority. I ensure your brand owns the high-value commercial searches in your sector across Greater London — the foundation from which national campaigns launch with credibility and domain strength.",
  },
  {
    step: "02",
    icon: Network,
    title: "Multi-Location Keyword Architecture",
    description:
      "I build a scalable location-page architecture that targets UK cities and regions without cannibalising your London rankings. Each location page is uniquely researched, locally relevant, and technically optimised — not templated content that Google ignores.",
  },
  {
    step: "03",
    icon: TrendingUp,
    title: "National Content Authority",
    description:
      "Expanding beyond London requires content that establishes subject matter expertise at scale. I develop editorial strategies that earn natural backlinks and brand mentions across UK trade publications — amplifying national reach through genuine authority signals.",
  },
  {
    step: "04",
    icon: Globe,
    title: "International Search Expansion",
    description:
      "For London enterprises pursuing international growth, I implement hreflang architecture, geo-targeted content strategies, and international link building programmes that translate London's search authority into new market visibility across Europe and beyond.",
  },
];

const locations = [
  "Manchester", "Birmingham", "Leeds", "Edinburgh",
  "Bristol", "Glasgow", "Liverpool", "Sheffield",
  "Cardiff", "Belfast", "Newcastle", "Nottingham",
];

const LondonExpansion = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="london-expansion"
      aria-label="Multi-location and national expansion SEO from London"
      className="relative isolate py-24 md:py-36"
    >
      {/* Layer 1 — image */}
      <img
        src="https://images.unsplash.com/photo-1568649704650-a6ab20e84311?w=1920&h=1080&fit=crop"
        alt="People walking near modern London buildings, representing national expansion"
        className="absolute inset-0 w-full h-full object-cover"
        loading="lazy"
        width="1920"
        height="1080"
      />
      {/* Layer 2 — brand tint overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/80 via-primary/55 to-accent/60 pointer-events-none" />

      {/* Layer 3 — content */}
      <div className="container relative z-10">
        <div className="max-w-3xl mb-12">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4">
            National &amp; International Expansion
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-5">
            From London HQ to UK-Wide Search Authority
          </h2>
          <p className="text-lg text-white/90 leading-relaxed">
            Many of London's most ambitious businesses use the capital as a launchpad for UK-wide
            and international growth. I build SEO programmes that scale with your expansion — creating
            a connected network of location authority that compounds over time.
          </p>
        </div>

        {/* Steps */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {expansionSteps.map(({ step, icon: Icon, title, description }) => (
            <div
              key={step}
              className="flex gap-5 p-6 rounded-xl bg-white/10 border border-white/20 backdrop-blur-sm"
            >
              <div className="shrink-0">
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-white/15 border border-white/25">
                  <Icon className="h-5 w-5 text-white" />
                </div>
              </div>
              <div>
                <div className="text-xs font-bold text-white/80 uppercase tracking-widest mb-1">
                  Step {step}
                </div>
                <h3 className="font-semibold text-white text-base mb-2">{title}</h3>
                <p className="text-sm text-white/80 leading-relaxed">{description}</p>
              </div>
            </div>
          ))}
        </div>

        {/* UK locations badge cloud */}
        <div className="mb-10">
          <p className="text-xs uppercase tracking-widest text-white/80 mb-4 font-medium">
            UK Cities Covered from London Base
          </p>
          <div className="flex flex-wrap gap-2">
            {locations.map((city) => (
              <Badge
                key={city}
                className="bg-white/15 text-white border border-white/25 hover:bg-white/25 transition-colors text-xs"
              >
                <MapPin className="h-3 w-3 mr-1" />
                {city}
              </Badge>
            ))}
            <Badge className="bg-white/15 text-white border border-white/25 text-xs">
              + More
            </Badge>
          </div>
        </div>

        <div className="flex flex-wrap gap-4">
          <Button
            size="lg"
            className="bg-white text-primary hover:bg-white/90 font-semibold"
            asChild
          >
            <a href="/local-seo">
              Explore Local SEO Services
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-transparent text-white border-white hover:bg-white/10"
            asChild
          >
            <a href="/contact">Discuss National Expansion</a>
          </Button>
        </div>
      </div>
    </section>
  );
});

LondonExpansion.displayName = "LondonExpansion";

export default LondonExpansion;
