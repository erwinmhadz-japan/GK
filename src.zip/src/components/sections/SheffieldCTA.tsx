import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, MapPin, ChevronRight, Book, View } from "lucide-react";
import { ImageBackground } from "@/components/ImageBackground";

const SheffieldCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="sheffield-cta"
      src="https://images.unsplash.com/photo-1685492259744-f42597aac776?w=1920&h=1080&fit=crop"
      alt="Sheffield commercial district buildings at dusk"
      imgProps={{ fetchpriority: "low", loading: "lazy" }}
      className="py-24 md:py-36"
    >
      <div className="container relative z-10 max-w-4xl mx-auto px-4 text-center">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          {/* Eyebrow */}
          <div className="flex items-center justify-center gap-2 mb-6">
            <MapPin className="h-4 w-4 text-primary flex-shrink-0" aria-hidden="true" />
            <span className="text-sm uppercase tracking-[0.2em] font-medium text-white/80">
              Ready to dominate Sheffield search?
            </span>
          </div>

          <h2 className="text-3xl md:text-5xl font-bold text-white leading-[1.1] mb-6 tracking-tight">
            Start Ranking in Sheffield{" "}
            <span className="text-gradient-green">Before Your Competitors Do</span>
          </h2>

          <p className="text-lg md:text-xl text-white/90 leading-relaxed mb-10 max-w-2xl mx-auto">
            Book a free Sheffield SEO audit and discover exactly where your business
            sits in local search rankings — and the specific steps to climb above the
            competition across South Yorkshire.
          </p>

          {/* CTA buttons */}
          <div className="flex flex-wrap gap-4 justify-center mb-10">
            <Button
              size="lg"
              asChild
              className="bg-primary text-primary-foreground font-semibold hover:bg-primary/90"
            >
              <Link to="/contact">
                Book Your Free Sheffield Audit
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              asChild
              className="bg-transparent text-white border-white hover:bg-white/10"
            >
              <Link to="#">View Local SEO Services</Link>
            </Button>
          </div>

          {/* Internal links */}
          <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2 text-sm text-white/80">
            <Link
              to="/services"
              className="flex items-center gap-1 hover:text-white transition-colors"
            >
              <ChevronRight className="h-3.5 w-3.5" aria-hidden="true" />
              All SEO Services
            </Link>
            <Link
              to="#case-studies-cta"
              className="flex items-center gap-1 hover:text-white transition-colors"
            >
              <ChevronRight className="h-3.5 w-3.5" aria-hidden="true" />
              Case Studies
            </Link>
            <Link
              to="/locations"
              className="flex items-center gap-1 hover:text-white transition-colors"
            >
              <ChevronRight className="h-3.5 w-3.5" aria-hidden="true" />
              Leeds SEO Services
            </Link>
          </div>

          <p className="mt-8 text-sm text-white/80">
            No setup fees · No long-term contracts · Transparent monthly reporting
          </p>
        </motion.div>
      </div>
    </ImageBackground>
  );
});

SheffieldCTA.displayName = "SheffieldCTA";

export default SheffieldCTA;
