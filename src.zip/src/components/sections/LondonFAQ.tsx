import React from "react";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { HelpCircle, Contact } from "lucide-react";

const faqs = [
  {
    question: "How competitive is SEO in London compared to other UK cities?",
    answer:
      "London is by far the most competitive SEO market in the UK. With over a million registered businesses and a concentration of global brands, major law firms, financial institutions, and tech companies, search results for London-targeted keywords are fiercely contested. This means that generic SEO tactics that might work in smaller UK cities often fall flat in London — you need a more sophisticated approach that includes stronger technical foundations, deeper topical authority, and more targeted local signals.",
  },
  {
    question: "How long does SEO take to show results for a London business?",
    answer:
      "For most London businesses, meaningful organic visibility improvements typically appear within 3–6 months, with significant ranking gains by months 6–12 for moderately competitive terms. Highly competitive terms (e.g. 'solicitor London' or 'accountant City of London') may take 12–18 months. Quick wins — like fixing technical issues, improving existing page rankings, and optimising your Google Business Profile — can often be achieved in the first 30–60 days. London's competitive landscape rewards sustained, expert-led effort over shortcuts.",
  },
  {
    question: "Do you work with businesses across all London boroughs?",
    answer:
      "Yes — we work with clients across all 33 London boroughs, from the City of London and Westminster through to outer boroughs such as Bromley, Croydon, and Havering. Each area has distinct search demand patterns, and our strategies are tailored accordingly. Whether you're a City firm targeting high-net-worth clients or a local service business in South London, we build a strategy that matches your specific geographic targets.",
  },
  {
    question: "What industries do you specialise in for London SEO?",
    answer:
      "We work across a wide range of industries common in London's business ecosystem, including legal and professional services, financial services and fintech, property and real estate, healthcare and private medical, hospitality and restaurants, retail and e-commerce, SaaS and technology, and creative agencies. Our experience across these sectors means we understand the nuances of London's competitive verticals — particularly the E-E-A-T requirements for finance, legal, and health sectors.",
  },
  {
    question: "Can you help with both local London SEO and national SEO simultaneously?",
    answer:
      "Absolutely. Many London businesses need to rank both locally (e.g. 'accountant Canary Wharf') and nationally (e.g. 'UK corporate tax advice'). We build strategies that address both simultaneously — using technical SEO, content architecture, and link authority to achieve local prominence while also building the national visibility needed for growth beyond the capital. We also handle multi-location SEO for businesses with offices in London and across the UK.",
  },
];

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((faq) => ({
    "@type": "Question",
    name: faq.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: faq.answer,
    },
  })),
};

const LondonFAQ = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="london-faq"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      {/* FAQ JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />

      <div className="container">
        <div className="max-w-2xl mx-auto text-center mb-12">
          <Badge variant="outline" className="mb-4 text-primary border-primary/30">
            London SEO FAQs
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Frequently Asked Questions
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Common questions from London businesses about SEO, timelines, and what to expect
            from working with an independent specialist in the capital.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full space-y-3">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="border border-border rounded-lg bg-card px-6 shadow-soft"
              >
                <AccordionTrigger className="text-left font-medium text-foreground hover:no-underline py-5">
                  <span className="flex items-center gap-3">
                    <HelpCircle className="h-4 w-4 shrink-0 text-primary" />
                    {faq.question}
                  </span>
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground text-sm leading-relaxed pb-5">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          <div className="mt-8 text-center text-sm text-muted-foreground">
            Have a different question?{" "}
            <a href="/contact" className="text-primary font-medium hover:underline">
              Contact us directly
            </a>
          </div>
        </div>
      </div>
    </section>
  );
});

LondonFAQ.displayName = "LondonFAQ";
export default LondonFAQ;
