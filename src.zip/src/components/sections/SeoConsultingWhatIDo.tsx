import React from "react";
import { motion } from "framer-motion";
import { ScanSearch, Workflow, Layers, Eye, MessageSquare, ChevronRight, Section } from "lucide-react";
import { Link } from "react-router-dom";

const phases = [
  {
    step: "01",
    icon: ScanSearch,
    title: "Diagnostic Audit",
    description:
      "Every engagement begins with a thorough audit of your site's technical foundations, content architecture, and competitive landscape. I need to understand exactly where you stand before recommending anything.",
  },
  {
    step: "02",
    icon: Workflow,
    title: "Strategy & Prioritisation",
    description:
      "From the audit findings, I build a clear, prioritised action plan. Not a generic list of recommendations — a structured strategy grounded in your specific market, sector, and growth objectives.",
  },
  {
    step: "03",
    icon: Layers,
    title: "Implementation Oversight",
    description:
      "Whether you have an in-house development team, a freelancer, or no technical resource at all, I oversee implementation directly. I write briefs, review changes, and ensure recommendations are executed correctly.",
  },
  {
    step: "04",
    icon: Eye,
    title: "Ongoing Advisory",
    description:
      "SEO isn't a project with a fixed end date. I provide regular strategic reviews, performance analysis, and adaptive guidance as algorithms, competitors, and your business evolve over time.",
  },
  {
    step: "05",
    icon: MessageSquare,
    title: "Direct Communication",
    description:
      "You work with me directly — not an account manager or a junior analyst. Every recommendation, every update, every question is handled by the same person who knows your site inside out.",
  },
];

const distinctions = [
  {
    label: "Not an agency retainer",
    body:
      "A consulting relationship is not a monthly retainer sold on activity. You get strategic direction and accountability, not a spreadsheet of tasks completed.",
  },
  {
    label: "Not a deliverables-only service",
    body:
      "Consulting is advisory by nature. I'm engaged in your results, not just in producing reports. The work evolves with what the data shows.",
  },
  {
    label: "Not a hands-off audit",
    body:
      "An audit without implementation support is often wasted. I stay involved through to execution, so that insights actually turn into rankings.",
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay: i * 0.1 },
  }),
};

const SeoConsultingWhatIDo = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seo-consulting-what-ido"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          className="max-w-2xl mb-14 md:mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          custom={0}
          variants={fadeUp}
        >
          <span className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium">
            The engagement model
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight mb-5">
            What SEO Consulting Looks Like in Practice
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-xl">
            Consulting isn't a product you buy off the shelf. It's a working
            relationship built around your specific situation — your site, your
            market, your ambitions. Here's how I typically work with clients.
          </p>
        </motion.div>

        {/* Process phases */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16 md:mb-24">
          {phases.map((phase, i) => {
            const Icon = phase.icon;
            return (
              <motion.div
                key={phase.step}
                custom={i + 1}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-40px" }}
                variants={fadeUp}
                className="group relative rounded-md border border-border bg-card p-6 md:p-7 flex flex-col gap-4 transition-all duration-300 hover:shadow-[0_4px_24px_0_rgba(26,31,46,0.10)] hover:-translate-y-0.5"
              >
                {/* Step number — decorative */}
                <span className="absolute top-5 right-6 text-[2.5rem] font-bold leading-none text-border select-none pointer-events-none">
                  {phase.step}
                </span>

                {/* Icon */}
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 shrink-0">
                  <Icon className="h-5 w-5 text-primary" />
                </div>

                {/* Content */}
                <div className="flex flex-col gap-2">
                  <h3 className="text-base font-semibold text-foreground leading-snug">
                    {phase.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {phase.description}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Divider */}
        <motion.hr
          className="border-border mb-16 md:mb-20"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        />

        {/* What it is NOT — distinctions block */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-start">
          {/* Left: explanatory prose */}
          <motion.div
            custom={0}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-40px" }}
            variants={fadeUp}
          >
            <span className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium">
              Consulting vs. everything else
            </span>
            <h2 className="text-2xl md:text-3xl font-bold text-foreground leading-tight mb-5">
              What a consulting relationship is — and isn't
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-5">
              A lot of what's sold as SEO consulting is, in practice, either a
              thinly rebranded agency retainer or a one-off audit report with
              no follow-through. Neither delivers the kind of sustained,
              measurable growth that serious UK businesses need.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-6">
              My consulting model is different because it combines strategic
              advice, hands-on audit and research, implementation oversight,
              and long-term advisory in a single, coherent relationship. There
              is no team behind me handing your account between departments.
              It's just me — which means continuity, accountability, and a
              clear line of responsibility for results.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              This matters particularly in competitive, trust-led sectors — law
              firms, healthcare providers, financial services, and property —
              where the margin between page one and page two is significant, and
              where clients cannot afford to rebuild momentum every six months
              because an agency rotated their account team.
            </p>
          </motion.div>

          {/* Right: distinction list */}
          <motion.div
            custom={1}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-40px" }}
            variants={fadeUp}
            className="flex flex-col gap-4"
          >
            {distinctions.map((item, i) => (
              <motion.div
                key={item.label}
                custom={i + 2}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-20px" }}
                variants={fadeUp}
                className="rounded-md border border-border bg-muted/40 p-5 flex gap-4"
              >
                <div className="mt-0.5 shrink-0">
                  <span className="block h-2 w-2 rounded-full bg-primary mt-2" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground mb-1">
                    {item.label}
                  </p>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {item.body}
                  </p>
                </div>
              </motion.div>
            ))}

            {/* Contextual link — subtle, not a CTA block */}
            <div className="mt-2">
              <Link
                to="#seo-consulting-cta"
                className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors"
              >
                See how the independent model works
                <ChevronRight className="h-4 w-4" />
              </Link>
            </div>
          </motion.div>
        </div>

      </div>
    </section>
  );
});

SeoConsultingWhatIDo.displayName = "SeoConsultingWhatIDo";

export default SeoConsultingWhatIDo;
