import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, CheckCircle, Server, Code, Globe, Layers, Icon } from "lucide-react";

const trustPoints = [
  { icon: Server, label: "Crawlability & Indexation" },
  { icon: Code, label: "Core Web Vitals" },
  { icon: Globe, label: "Site Architecture" },
  { icon: Layers, label: "Structured Data" },
];

const TechnicalSEOHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="technical-seohero"
      className="relative isolate overflow-hidden bg-[hsl(225_28%_14%)] border-t border-[hsl(225_28%_20%)]"
    >
      {/* Subtle dot-grid texture overlay */}
      <div
        aria-hidden="true"
        className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(214 32% 60%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      {/* Top gradient fade */}
      <div
        aria-hidden="true"
        className="absolute inset-x-0 top-0 h-48 pointer-events-none"
        style={{
          background:
            "linear-gradient(to bottom, hsl(225 28% 10% / 0.6), transparent)",
        }}
      />

      {/* Accent glow — bottom-left */}
      <div
        aria-hidden="true"
        className="absolute -bottom-32 -left-32 w-96 h-96 rounded-full pointer-events-none"
        style={{
          background:
            "radial-gradient(circle, hsl(84 74% 58% / 0.08) 0%, transparent 70%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 py-24 md:py-36 relative z-10">
        <div className="max-w-3xl">
          {/* Eyebrow badge */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0 }}
          >
            <Badge
              variant="outline"
              className="mb-6 inline-flex items-center gap-1.5 border-[hsl(214_32%_60%/0.35)] text-[hsl(214_32%_68%)] bg-[hsl(214_32%_60%/0.08)] text-xs tracking-widest uppercase font-medium px-3 py-1"
            >
              <CheckCircle className="h-3 w-3 text-[hsl(84_74%_58%)]" />
              Independent Technical SEO Specialist
            </Badge>
          </motion.div>

          {/* H1 */}
          <motion.h1
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-[1.1] tracking-tight"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Technical SEO
            <br />
            <span
              className="inline-block"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 60%) 0%, hsl(119 35% 61%) 100%)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              Consultant UK
            </span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.2 }}
            className="mt-6 text-lg md:text-xl text-[hsl(214_32%_72%)] leading-relaxed max-w-2xl"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Fixing the structural issues that prevent your site from ranking —
            crawlability, indexation, Core Web Vitals, and architecture, handled
            by an independent specialist.
          </motion.p>

          {/* CTA buttons */}
          <motion.div
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.3 }}
            className="mt-8 flex flex-wrap gap-4 items-center"
          >
            <Button
              asChild
              size="lg"
              className="h-12 px-8 text-sm font-semibold text-[hsl(225_28%_10%)] border-0 shadow-none transition-all duration-300 hover:shadow-[0_0_32px_hsl(84_74%_58%/0.28)] hover:scale-[1.02]"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 60%) 0%, hsl(119 35% 61%) 100%)",
              }}
            >
              <Link to="/contact">
                Enquire Now
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>

            <Button
              asChild
              size="lg"
              variant="outline"
              className="h-12 px-8 text-sm font-medium bg-transparent text-white border-[hsl(214_32%_60%/0.4)] hover:border-[hsl(84_74%_58%/0.6)] hover:bg-[hsl(84_74%_58%/0.06)] hover:text-white transition-all duration-300"
            >
              <Link to="/contact">Free SEO Audit</Link>
            </Button>
          </motion.div>

          {/* Trust — disciplines covered */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.42 }}
            className="mt-12 pt-10 border-t border-[hsl(225_28%_22%)]"
          >
            <p
              className="text-xs uppercase tracking-widest text-[hsl(214_32%_52%)] mb-5"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              Technical disciplines covered
            </p>
            <div className="flex flex-wrap gap-3">
              {trustPoints.map(({ icon: Icon, label }, idx) => (
                <motion.div
                  key={label}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    duration: 0.4,
                    ease: "easeOut",
                    delay: 0.48 + idx * 0.07,
                  }}
                  className="flex items-center gap-2 rounded-md px-3 py-2 border border-[hsl(225_28%_24%)] bg-[hsl(225_28%_18%/0.5)]"
                >
                  <Icon className="h-4 w-4 text-[hsl(84_74%_58%)]" />
                  <span
                    className="text-sm text-[hsl(214_32%_72%)]"
                    style={{ fontFamily: "Inter, sans-serif" }}
                  >
                    {label}
                  </span>
                </motion.div>
              ))}
            </div>
          </motion.div>

          {/* Reassurance note */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.72 }}
            className="mt-6 text-sm text-[hsl(214_32%_50%)]"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Independent consultant. Direct access to the specialist doing the
            work — no account managers, no agency overhead.
          </motion.p>
        </div>
      </div>

      {/* Bottom fade to next section */}
      <div
        aria-hidden="true"
        className="absolute inset-x-0 bottom-0 h-20 pointer-events-none"
        style={{
          background:
            "linear-gradient(to bottom, transparent, hsl(225 28% 14% / 0.4))",
        }}
      />
    </section>
  );
});

TechnicalSEOHero.displayName = "TechnicalSEOHero";

export default TechnicalSEOHero;
