import React from "react";
import { motion } from "framer-motion";
import { ArrowRight, MessageCircle, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ImageBackground } from "@/components/ImageBackground";

const AiSearchPerplexityCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="perplexity-cta"
      aria-label="Perplexity visibility — get optimised CTA"
      src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1920&h=1080&fit=crop"
      alt="Team collaborating on digital strategy in a modern office"
      imgProps={{ loading: "lazy" }}
      className="py-24 md:py-36 border-t border-border"
    >
      <div className="container max-w-4xl mx-auto px-4 relative z-10 text-center">
        <motion.span
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.45 }}
          className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4"
        >
          Get Cited by Perplexity AI
        </motion.span>

        <motion.h2
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55, delay: 0.08 }}
          className="text-3xl md:text-5xl font-bold text-white mb-6"
        >
          Ready to Appear in Perplexity's Answers?
        </motion.h2>

        <motion.p
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55, delay: 0.15 }}
          className="text-lg text-white/90 mb-10 max-w-2xl mx-auto leading-relaxed"
        >
          Perplexity is rewriting how your audience finds information. Our AI search optimisation service builds the technical foundation, content authority, and entity signals your site needs to be selected as a trusted citation.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55, delay: 0.22 }}
          className="flex flex-wrap justify-center gap-4"
        >
          <Button
            size="lg"
            className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold shadow-green-glow"
            asChild
          >
            <a href="/services-ai-search-optimisation">
              Explore AI Search Optimisation
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-transparent text-white border-white hover:bg-white/10"
            asChild
          >
            <a href="/contact">
              <MessageCircle className="mr-2 h-4 w-4" />
              Get in Touch
            </a>
          </Button>
        </motion.div>

        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.35 }}
          className="mt-8 text-sm text-white/80"
        >
          No long-term tie-ins · Strategy-first approach · UK-based SEO specialist
        </motion.p>
      </div>
    </ImageBackground>
  );
});

AiSearchPerplexityCTA.displayName = "AiSearchPerplexityCTA";

export default AiSearchPerplexityCTA;
