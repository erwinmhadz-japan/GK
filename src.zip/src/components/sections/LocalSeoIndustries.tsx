import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";

const industries = [
  {
    number: "01",
    name: "Law Firms & Solicitors",
    keyword: "SEO for solicitors",
    body:
      "Legal services are high-competition, high-trust search territory. Prospective clients searching for a local solicitor rely heavily on proximity signals and verified reviews. Local SEO places your practice in front of high-intent queries — 'solicitors near me', 'family law firm [city]' — at the exact moment they matter.",
    link: "/services-local-seo",
    linkLabel: "Local SEO for law firms",
  },
  {
    number: "02",
    name: "Healthcare & Private Clinics",
    keyword: "SEO for private healthcare",
    body:
      "Private clinics, dentists, physiotherapists, and specialist consultants compete for geographically-bound patients who need to act quickly. Google Business Profile prominence, accurate local citations, and structured data for healthcare entities translate directly into appointment bookings.",
    link: "/services-local-seo",
    linkLabel: "Local SEO for clinics",
  },
  {
    number: "03",
    name: "Estate Agents & Property Services",
    keyword: "SEO for estate agents",
    body:
      "Property search is inherently local. Buyers and sellers start with a neighbourhood or postcode in mind. Ranking for hyper-local terms — '[area] estate agent', 'houses for sale [town]' — requires precisely managed local signals, neighbourhood-level content, and map pack visibility.",
    link: "/services-local-seo",
    linkLabel: "Local SEO for property",
  },
  {
    number: "04",
    name: "Financial Services",
    keyword: "SEO for financial advisers",
    body:
      "IFAs, mortgage brokers, and accountants operate in a sector where trust and credentials are everything. Local SEO builds topical authority and geographic relevance simultaneously — capturing clients searching for regulated, local expertise rather than a faceless national provider.",
    link: "/services-local-seo",
    linkLabel: "Local SEO for finance",
  },
  {
    number: "05",
    name: "B2B Professional Services",
    keyword: "SEO for professional services",
    body:
      "Consultants, IT service providers, architects, and other B2B firms often underestimate local search. But decision-makers frequently add location modifiers when sourcing specialist suppliers. Targeted local SEO captures these commercial queries before competitors with larger budgets.",
    link: "/services-local-seo",
    linkLabel: "Local SEO for B2B",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const headingVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" },
  },
};

const LocalSeoIndustries = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="local-seo-industries"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={headingVariants}
          className="mb-14 md:mb-16 max-w-2xl"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] font-medium text-muted-foreground mb-4">
            Industry Focus
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-semibold text-foreground leading-snug">
            Sectors That Benefit Most from Local SEO
          </h2>
          <p className="mt-4 text-base md:text-lg text-muted-foreground leading-relaxed max-w-xl">
            Local search has the highest commercial impact in sectors where trust, proximity, and
            urgency drive the buying decision. These are the industries where I focus my local SEO
            expertise.
          </p>
        </motion.div>

        {/* Industry cards */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={containerVariants}
          className="grid grid-cols-1 md:grid-cols-2 gap-0 border border-border rounded-md overflow-hidden"
        >
          {industries.map((industry, index) => (
            <motion.article
              key={industry.number}
              variants={cardVariants}
              className={[
                "group relative flex flex-col p-8 md:p-10 bg-background",
                "border-b border-border",
                "md:border-r",
                // Remove right border from even items (right column) to avoid double borders
                index % 2 === 1 ? "md:border-r-0" : "",
                // Remove bottom border from last two items on md+ to avoid double with container border
                index >= industries.length - 2 ? "md:border-b-0" : "",
                // Keep bottom border on last odd item (the lone item)
                index === industries.length - 1 && industries.length % 2 === 1
                  ? "md:col-span-2 md:border-b-0 md:border-r-0"
                  : "",
                "hover:bg-[hsl(84_74%_60%/0.04)] transition-colors duration-300",
              ]
                .filter(Boolean)
                .join(" ")}
            >
              {/* Number + keyword pill row */}
              <div className="flex items-center justify-between mb-5">
                <span
                  className="text-xs font-mono font-medium tracking-widest text-muted-foreground"
                  aria-hidden="true"
                >
                  {industry.number}
                </span>
                <span className="text-xs font-medium tracking-wide text-[hsl(119_35%_45%)] bg-[hsl(119_35%_61%/0.12)] px-2.5 py-1 rounded-sm">
                  {industry.keyword}
                </span>
              </div>

              {/* Industry name */}
              <h3 className="text-lg md:text-xl font-semibold text-foreground mb-3 leading-snug">
                {industry.name}
              </h3>

              {/* Body copy */}
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed flex-1">
                {industry.body}
              </p>

              {/* Subtle inline link */}
              <div className="mt-6 pt-5 border-t border-border/60">
                <Link
                  to={industry.link}
                  className="text-sm font-medium text-foreground group-hover:text-[hsl(119_35%_45%)] transition-colors duration-200 inline-flex items-center gap-1.5"
                  aria-label={`${industry.linkLabel} — learn more`}
                >
                  {industry.linkLabel}
                  <span
                    className="inline-block translate-x-0 group-hover:translate-x-0.5 transition-transform duration-200"
                    aria-hidden="true"
                  >
                    →
                  </span>
                </Link>
              </div>
            </motion.article>
          ))}
        </motion.div>

        {/* Footer note */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3, ease: "easeOut" }}
          className="mt-10 text-sm text-muted-foreground text-center max-w-xl mx-auto"
        >
          I work across all sectors, but these five represent the highest concentration of local
          search intent.{" "}
          <Link
            to="/services-local-seo"
            className="underline underline-offset-2 hover:text-foreground transition-colors duration-200"
          >
            See how local SEO works in your industry →
          </Link>
        </motion.p>
      </div>
    </section>
  );
});

LocalSeoIndustries.displayName = "LocalSeoIndustries";

export default LocalSeoIndustries;
