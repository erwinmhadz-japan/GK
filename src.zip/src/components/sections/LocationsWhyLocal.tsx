import React from "react";
import { motion } from "framer-motion";
import { MapPin, Search, Globe, Target, CheckCircle, TrendingUp, Grid } from "lucide-react";

const reasons = [
  {
    icon: MapPin,
    title: "Local Search Intent",
    body:
      "When someone searches 'SEO consultant Manchester' or 'SEO agency Birmingham', Google returns results based on proximity and local relevance — not just domain authority. I optimise specifically for that intent.",
  },
  {
    icon: Search,
    title: "Google Business Profile",
    body:
      "A well-optimised Google Business Profile is one of the strongest local ranking signals available. I audit, rebuild, and manage GBP listings so your business appears where local buyers are looking.",
  },
  {
    icon: Globe,
    title: "Proximity Signals",
    body:
      "Google weights physical proximity when returning local results. Structured data, NAP consistency, and local citations all contribute — and each city requires its own tailored approach.",
  },
  {
    icon: Target,
    title: "Regional Competitor Landscape",
    body:
      "The competitive landscape in Leeds is different from London. I research the specific SERP environment in your city before building any strategy — so you're outranking the right competitors.",
  },
  {
    icon: TrendingUp,
    title: "City-Specific Keyword Targeting",
    body:
      "National keyword strategies miss localised buying intent. I build keyword maps around city-level queries with genuine commercial demand, not generic terms that drive irrelevant traffic.",
  },
  {
    icon: CheckCircle,
    title: "Independent, Not a Call Centre",
    body:
      "Working with me means working with me — not an account manager passing notes to a junior. Every local SEO campaign I run benefits from my direct input, start to finish.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" },
  },
};

const headingVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.65, ease: "easeOut" } },
};

const LocationsWhyLocal = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="locations-why-local"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <motion.div
          className="max-w-2xl mb-14 md:mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={containerVariants}
        >
          <motion.span
            variants={headingVariants}
            className="inline-block text-xs uppercase tracking-[0.2em] font-medium text-muted-foreground mb-4"
          >
            Why location matters
          </motion.span>

          <motion.h2
            variants={headingVariants}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight mb-6 max-w-xl"
          >
            Why Local SEO Expertise Matters
          </motion.h2>

          <motion.p
            variants={headingVariants}
            className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-prose"
          >
            A national SEO strategy rarely translates cleanly into local results. City-specific
            search intent, proximity signals, and regional competitor landscapes all demand a
            tailored approach — not a template rolled out across postcodes. As an independent
            consultant based in Warrington, I work with businesses across the UK who need local
            SEO that actually reflects how people in their city search and buy.
          </motion.p>
        </motion.div>

        {/* Reasons Grid */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={containerVariants}
        >
          {reasons.map((reason) => {
            const Icon = reason.icon;
            return (
              <motion.div
                key={reason.title}
                variants={itemVariants}
                className="group relative bg-card border border-border rounded-md p-6 md:p-7 hover:border-primary/40 hover:shadow-md transition-all duration-300"
              >
                {/* Icon */}
                <div className="flex items-center justify-center w-10 h-10 rounded-md bg-primary/10 mb-5 group-hover:bg-primary/20 transition-colors duration-300">
                  <Icon className="h-5 w-5 text-primary" />
                </div>

                {/* Title */}
                <h3 className="text-base md:text-lg font-semibold text-foreground mb-3 leading-snug">
                  {reason.title}
                </h3>

                {/* Body */}
                <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                  {reason.body}
                </p>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Closing note */}
        <motion.div
          className="mt-14 md:mt-20 border-t border-border pt-10 md:pt-12 max-w-2xl"
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.65, ease: "easeOut" }}
        >
          <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
            Every city I serve gets its own SEO strategy — built around local search demand,
            real competitor data, and the specific trust signals that matter in that market.
            Whether you're a law firm in Manchester, a healthcare provider in Birmingham, or a
            professional services business in London, the approach is tailored to where you
            actually need to rank.
          </p>
        </motion.div>
      </div>
    </section>
  );
});

LocationsWhyLocal.displayName = "LocationsWhyLocal";

export default LocationsWhyLocal;
