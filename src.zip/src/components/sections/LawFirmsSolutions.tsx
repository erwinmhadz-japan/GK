import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Check, MapPin, BookOpen, FileText, Building2, Search } from "lucide-react";

const solutions = [
  {
    icon: MapPin,
    badge: "Local SEO",
    title: "Dominate Local Search in Your Practice Area",
    description:
      "We optimise your Google Business Profile, build consistent local citations, and create geo-targeted landing pages for every location you serve. From 'solicitor near me' to practice-specific local terms, we put your firm at the top of the local pack where high-intent clients are searching.",
    points: [
      "Google Business Profile optimisation & management",
      "Local citation building across legal directories",
      "Geo-targeted practice area landing pages",
      "LocalBusiness & LegalService schema markup",
    ],
    link: "/local-seo",
    linkLabel: "Explore Local SEO",
    image:
      "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=800&h=600&fit=crop",
    imageAlt: "Team of professionals working on local SEO strategy",
    reversed: false,
  },
  {
    icon: BookOpen,
    badge: "Content Marketing",
    title: "Authority Content That Ranks & Converts",
    description:
      "We research and produce in-depth legal guides, practice area pages, and blog content that satisfies Google's E-E-A-T requirements for legal sites. Every piece is written to attract organic traffic and guide potential clients to enquire — all fully compliant with SRA advertising rules.",
    points: [
      "Practice area pages optimised for target keywords",
      "Long-form legal guides & FAQ content",
      "SRA-compliant copywriting throughout",
      "Internal linking strategy across service silos",
    ],
    link: "/content-strategy",
    linkLabel: "Content Strategy for Law Firms",
    image:
      "https://images.unsplash.com/photo-1499750310107-5fef28a66643?w=800&h=600&fit=crop",
    imageAlt: "Professional writing content on a laptop",
    reversed: true,
  },
  {
    icon: FileText,
    badge: "Technical SEO",
    title: "Technical Foundations Built for Legal Sites",
    description:
      "Legal websites often suffer from slow load speeds, duplicate practice area content, and poor crawlability. We audit and fix the technical issues holding your site back — ensuring Google can crawl, index, and rank every service page and location page you need to grow.",
    points: [
      "Core Web Vitals & page speed optimisation",
      "Practice area silo architecture & URL structure",
      "Canonicalisation & duplicate content resolution",
      "Secure HTTPS & mobile-first performance",
    ],
    link: "/technical-seo",
    linkLabel: "Technical SEO Services",
    image:
      "https://images.unsplash.com/photo-1571677246347-5040036b95cc?w=800&h=600&fit=crop",
    imageAlt: "Technical SEO work on a laptop",
    reversed: false,
  },
  {
    icon: Building2,
    badge: "Schema & Entity SEO",
    title: "Schema Markup & Entity Authority for Legal Sites",
    description:
      "We implement LegalService, Attorney, and LocalBusiness schema to help search engines understand exactly what your firm does and where you operate. Combined with entity SEO that builds your firm's knowledge graph presence, this drives rich results and AI-powered search visibility.",
    points: [
      "LegalService & Attorney schema implementation",
      "FAQ JSON-LD for practice area pages",
      "Entity building across authoritative legal directories",
      "Google Knowledge Panel optimisation",
    ],
    link: "/entity-seo",
    linkLabel: "Entity & Schema SEO",
    image:
      "https://images.unsplash.com/photo-1637606346315-d23ed32a6cfc?w=800&h=600&fit=crop",
    imageAlt: "SEO strategy blocks representing schema and entity work",
    reversed: true,
  },
];

const LawFirmsSolutions = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
      aria-label="SEO solutions tailored to law firms"
    >
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            Our Approach
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
            SEO Solutions Tailored to Law Firms
          </h2>
          <p className="text-lg text-muted-foreground">
            A comprehensive, specialist SEO strategy designed around the unique
            demands of legal services — driving qualified enquiries, not just traffic.
          </p>
        </div>

        <div className="space-y-20">
          {solutions.map((solution) => {
            const Icon = solution.icon;
            return (
              <div
                key={solution.title}
                className={`grid grid-cols-1 lg:grid-cols-2 gap-10 items-center ${
                  solution.reversed ? "lg:flex-row-reverse" : ""
                }`}
              >
                <div className={solution.reversed ? "lg:order-2" : ""}>
                  <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
                    <Icon className="h-3.5 w-3.5 mr-1.5" />
                    {solution.badge}
                  </Badge>
                  <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                    {solution.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed mb-6">
                    {solution.description}
                  </p>
                  <ul className="space-y-3 mb-8">
                    {solution.points.map((point) => (
                      <li key={point} className="flex items-start gap-3 text-sm">
                        <div className="flex h-5 w-5 shrink-0 items-center justify-center rounded-full bg-primary/10 mt-0.5">
                          <Check className="h-3 w-3 text-primary" />
                        </div>
                        <span className="text-foreground">{point}</span>
                      </li>
                    ))}
                  </ul>
                  <Button variant="outline" className="border-primary text-primary hover:bg-primary/5" asChild>
                    <a href={solution.link}>{solution.linkLabel}</a>
                  </Button>
                </div>

                <div className={`relative ${solution.reversed ? "lg:order-1" : ""}`}>
                  <div className="rounded-2xl overflow-hidden shadow-card aspect-[4/3]">
                    <img
                      src={solution.image}
                      alt={solution.imageAlt}
                      width={800}
                      height={600}
                      loading="lazy"
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="absolute -bottom-4 -right-4 w-24 h-24 rounded-full bg-primary/10 blur-2xl pointer-events-none" />
                </div>
              </div>
            );
          })}
        </div>

        <div className="mt-16 text-center">
          <p className="text-muted-foreground mb-4">
            Need a full-service approach? Explore our{" "}
            <a href="#industries-cta" className="text-primary hover:underline underline-offset-4">
              other industry specialisms
            </a>{" "}
            or{" "}
            <a href="/contact" className="text-primary hover:underline underline-offset-4">
              book a free discovery call
            </a>
            .
          </p>
        </div>
      </div>
    </section>
  );
});

LawFirmsSolutions.displayName = "LawFirmsSolutions";

export default LawFirmsSolutions;
