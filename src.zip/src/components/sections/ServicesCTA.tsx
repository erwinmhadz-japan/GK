import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, Search, Contact } from "lucide-react";

const ServicesCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="services-cta"
      className="relative py-20 md:py-32 border-t border-border bg-muted overflow-hidden"
    >
      {/* Subtle dot-grid texture overlay */}
      <div
        className="absolute inset-0 pointer-events-none opacity-30"
        aria-hidden="true"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(var(--border)) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      {/* Green accent glow — top-left ambient */}
      <div
        className="absolute -top-24 -left-24 w-80 h-80 rounded-full pointer-events-none"
        aria-hidden="true"
        style={{
          background:
            "radial-gradient(circle, hsl(84 74% 58% / 0.12) 0%, transparent 70%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-2xl mx-auto text-center">
          {/* Eyebrow */}
          <motion.span
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-5 font-medium"
          >
            Independent SEO Consulting
          </motion.span>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.08 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold tracking-tight text-foreground mb-5"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Not Sure Which Service Fits?
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.16 }}
            className="text-base md:text-lg text-muted-foreground leading-relaxed mb-10 max-w-xl mx-auto"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Get in touch and I'll identify exactly where your SEO needs
            attention — with no obligation and no agency overhead.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.24 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            {/* Primary CTA — Contact */}
            <Button
              asChild
              size="lg"
              className="w-full sm:w-auto h-12 px-8 text-sm font-semibold rounded-md"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                color: "hsl(225 28% 14%)",
                border: "none",
              }}
            >
              <Link to="/contact" className="flex items-center gap-2">
                Contact Gregg
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>

            {/* Secondary CTA — Free SEO Audit */}
            <Button
              asChild
              size="lg"
              variant="outline"
              className="w-full sm:w-auto h-12 px-8 text-sm font-semibold rounded-md border-border bg-transparent text-foreground hover:bg-accent/40 hover:text-foreground transition-colors"
            >
              <Link to="/seo-audit" className="flex items-center gap-2">
                <Search className="h-4 w-4" />
                Free SEO Audit
              </Link>
            </Button>
          </motion.div>

          {/* Trust note */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease: "easeOut", delay: 0.34 }}
            className="mt-8 text-xs text-muted-foreground"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Independent consultant · Based in Warrington, Cheshire · UK
            businesses only
          </motion.p>
        </div>
      </div>
    </section>
  );
});

ServicesCTA.displayName = "ServicesCTA";

export default ServicesCTA;
