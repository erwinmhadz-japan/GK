import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, MapPin, Building2, TrendingUp, Icon, View } from "lucide-react";

const IndustriesPropertyHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      src="https://images.unsplash.com/photo-1573496130141-209d200cebd8?w=1920&h=1080&fit=crop"
      alt="Two women in suits standing beside wall — estate agency professionals"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center"
    >
      <div className="container relative z-10 py-24 md:py-32">
        <div className="max-w-3xl">
          <Badge className="mb-5 bg-primary/20 text-primary border-primary/30 backdrop-blur-sm">
            SEO for Estate Agents &amp; Property Services
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Win More Property Instructions with Smarter SEO
          </h1>
          <p className="text-lg md:text-xl text-white/90 mb-8 leading-relaxed max-w-2xl">
            In one of the UK's most competitive local markets, your agency's online visibility
            determines your pipeline. We help estate agents, letting agencies, and property
            service providers rank prominently for the searches that drive vendor instructions,
            landlord acquisitions, and buyer enquiries.
          </p>

          <div className="flex flex-wrap gap-4 mb-10">
            <Button size="lg" asChild className="bg-primary text-primary-foreground hover:bg-primary/90">
              <a href="/contact">
                Get a Free Property SEO Audit
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              asChild
              className="bg-transparent text-white border-white hover:bg-white/10"
            >
              <a href="#case-studies-cta">View Case Studies</a>
            </Button>
          </div>

          <div className="flex flex-wrap gap-6">
            {[
              { icon: MapPin, label: "Local search dominance" },
              { icon: Building2, label: "Property listing visibility" },
              { icon: TrendingUp, label: "More vendor instructions" },
            ].map(({ icon: Icon, label }) => (
              <div key={label} className="flex items-center gap-2 text-white/80">
                <Icon className="h-5 w-5 text-primary" />
                <span className="text-sm font-medium">{label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </ImageBackground>
  );
});

IndustriesPropertyHero.displayName = "IndustriesPropertyHero";
export default IndustriesPropertyHero;
