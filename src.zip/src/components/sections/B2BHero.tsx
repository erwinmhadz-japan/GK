import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Briefcase, View } from "lucide-react";

const B2BHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="b2b-hero"
      aria-label="B2B Professional Services SEO Hero"
      src="https://images.unsplash.com/photo-1573496130141-209d200cebd8?w=1920&h=1080&fit=crop"
      alt="Two women in suits standing in a professional office environment"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[88vh] md:min-h-screen flex items-center"
    >
      <div className="container relative z-10 py-24 md:py-36">
        <div className="max-w-3xl">
          <Badge className="mb-6 bg-primary/20 text-primary border-primary/30 backdrop-blur-sm">
            <Briefcase className="h-3.5 w-3.5 mr-1.5" />
            B2B &amp; Professional Services SEO
          </Badge>

          <h1 className="text-4xl md:text-6xl font-bold text-white leading-tight mb-6">
            SEO for B2B &amp;{" "}
            <span className="text-gradient-green">Professional Services</span>{" "}
            Firms
          </h1>

          <p className="text-lg md:text-xl text-white/90 max-w-2xl mb-8 leading-relaxed">
            Long sales cycles, multiple decision-makers, and technical content
            that must rank — B2B SEO demands a specialist approach. We build
            entity authority, thought leadership content, and structured data
            that earns trust at every stage of the buying journey.
          </p>

          <div className="flex flex-wrap gap-4">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
              asChild
            >
              <a href="/contact">
                Get a B2B SEO Strategy
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10"
              asChild
            >
              <a href="#case-studies-cta">View Case Studies</a>
            </Button>
          </div>

          <p className="mt-6 text-sm text-white/80">
            Trusted by consulting firms, law practices, accountancies &amp; SaaS
            businesses
          </p>
        </div>
      </div>
    </ImageBackground>
  );
});

B2BHero.displayName = "B2BHero";

export default B2BHero;
