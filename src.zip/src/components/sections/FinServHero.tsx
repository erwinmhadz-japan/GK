import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ShieldCheck, TrendingUp, Landmark, Icon, View } from "lucide-react";

const trustBadges = [
  { icon: ShieldCheck, label: "YMYL Compliant Strategy" },
  { icon: Landmark, label: "Regulatory Content Experts" },
  { icon: TrendingUp, label: "Proven Financial SEO" },
];

const FinServHero: React.FC = () => {
  return (
    <ImageBackground
      src="https://images.unsplash.com/photo-1573496528298-f0e9d3c7ce55?w=1920&h=1080&fit=crop"
      alt="Financial professional working at desk with multiple screens"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center"
    >
      <div className="container relative z-10 py-24 md:py-36">
        <div className="max-w-3xl">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4">
            Financial Services SEO
          </span>
          <h1 className="text-4xl md:text-6xl font-bold text-white leading-tight mb-6">
            SEO for{" "}
            <span className="text-gradient-green">Financial Services</span>{" "}
            That Builds Trust &amp; Rankings
          </h1>
          <p className="text-lg md:text-xl text-white/90 mb-8 leading-relaxed max-w-2xl">
            Financial services websites face the strictest scrutiny from Google's quality
            raters. We specialise in YMYL-compliant SEO strategies that establish
            authority, satisfy regulators, and win competitive keywords for banks,
            advisers, and fintech brands.
          </p>
          <div className="flex flex-wrap gap-4 mb-10">
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90" asChild>
              <a href="/contact">Get a Financial SEO Audit</a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10"
              asChild
            >
              <a href="#case-studies-cta">View Case Studies</a>
            </Button>
          </div>
          <div className="flex flex-wrap gap-6">
            {trustBadges.map(({ icon: Icon, label }) => (
              <div key={label} className="flex items-center gap-2">
                <Icon className="h-5 w-5 text-primary" />
                <span className="text-sm text-white/80">{label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </ImageBackground>
  );
};

export default FinServHero;
