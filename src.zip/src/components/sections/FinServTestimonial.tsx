import React from "react";
import { Quote, TrendingUp, ShieldCheck, Star } from "lucide-react";

const stats = [
  { value: "+187%", label: "Organic traffic in 12 months" },
  { value: "Top 3", label: "Rankings for 40+ target keywords" },
  { value: "4.2×", label: "Return on SEO investment" },
];

const FinServTestimonial: React.FC = () => {
  return (
    <section className="relative isolate py-24 md:py-36">
      {/* Layer 1 — image */}
      <img
        src="https://images.unsplash.com/photo-1573496130141-209d200cebd8?w=1920&h=1080&fit=crop"
        alt="Two financial professionals in suits reviewing documents"
        className="absolute inset-0 w-full h-full object-cover"
        loading="lazy"
        width="1920"
        height="1080"
      />
      {/* Layer 2 — brand tint overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/80 via-primary/55 to-accent/60 pointer-events-none" />
      {/* Layer 3 — content */}
      <div className="container relative z-10">
        <div className="max-w-3xl mx-auto">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-6">
            Client Case Study
          </span>

          {/* Testimonial card */}
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-8 md:p-12 mb-10">
            <Quote className="h-10 w-10 text-white/60 mb-6" />
            <blockquote className="text-xl md:text-2xl font-medium text-white leading-relaxed mb-8">
              "We'd been trying to rank for 'independent financial adviser London' for years.
              Within eight months of working with Gregg, we were on page one for that term
              and eleven other high-value commercial queries. The YMYL audit alone
              uncovered issues we'd never have found ourselves — and fixing them moved
              the needle almost immediately."
            </blockquote>
            <div className="flex items-center gap-4">
              <img
                src="https://images.unsplash.com/photo-1681500920181-0aff411f8cab?w=400&h=400&fit=crop&crop=face"
                alt="Claire Harrington, Head of Digital at Meridian Wealth Partners"
                width="56"
                height="56"
                className="h-14 w-14 rounded-full object-cover border-2 border-white/30"
              />
              <div>
                <p className="font-semibold text-white">Claire Harrington</p>
                <p className="text-sm text-white/80">
                  Head of Digital — Meridian Wealth Partners
                </p>
                <div className="flex gap-1 mt-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="h-3.5 w-3.5 fill-primary text-primary" />
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Stats row */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {stats.map(({ value, label }) => (
              <div
                key={label}
                className="text-center bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl px-6 py-5"
              >
                <p className="text-3xl md:text-4xl font-bold text-white mb-1">{value}</p>
                <p className="text-sm text-white/80">{label}</p>
              </div>
            ))}
          </div>

          <div className="mt-10 text-center">
            <a
              href="#case-studies-cta"
              className="inline-flex items-center gap-2 bg-white text-primary font-semibold px-6 py-3 rounded-lg hover:bg-white/90 transition-colors"
            >
              Read the Full Case Study
            </a>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FinServTestimonial;
