import React from "react";
import { motion } from "framer-motion";
import { BrainCircuit, Globe, Search, Layers, Eye, MessageSquare, Sparkles, ArrowRight, Heading, Key, Section } from "lucide-react";
import { Link } from "react-router-dom";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (delay: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut", delay },
  }),
};

const points = [
  {
    icon: BrainCircuit,
    heading: "A language model, not a search index",
    body: "ChatGPT generates responses by predicting contextually appropriate text based on patterns in its training data. It does not crawl the web in real time. Instead, it draws on a vast corpus of text from across the internet, including news sites, directories, forums, academic publications, and business listings.",
  },
  {
    icon: Globe,
    heading: "Brand mentions across trusted sources",
    body: "The model learns which businesses are credible through repeated, consistent mentions across authoritative sources. A business discussed in industry publications, cited in professional directories, referenced on credible news outlets, or described coherently across multiple independent sources builds a stronger presence in the model's understanding.",
  },
  {
    icon: Layers,
    heading: "Entity recognition and structured context",
    body: "ChatGPT associates businesses and individuals with specific attributes: their sector, location, services, credentials, and reputation. This entity-level understanding is shaped by how clearly and consistently your brand is described across the web — in schema markup, in third-party content, and in your own structured publishing.",
  },
  {
    icon: Search,
    heading: "Topical authority and depth of coverage",
    body: "When a model encounters a topic repeatedly in authoritative sources, it builds a richer internal representation of that domain. A business that publishes considered, original content on its specialist area — and earns citations from credible sources — is more likely to be surfaced when a user asks a relevant question.",
  },
  {
    icon: Eye,
    heading: "Perception of credibility and trust signals",
    body: "Unlike traditional search engines, ChatGPT cannot directly assess domain authority metrics. It infers credibility from the nature of the sources that mention a brand: regulatory bodies, professional associations, established media, and peer-reviewed content all carry greater implicit weight than directories or low-authority blogs.",
  },
  {
    icon: MessageSquare,
    heading: "The difference from traditional search",
    body: "In traditional search, a well-optimised page can rank through on-page signals and link equity. In ChatGPT, visibility depends on the breadth and quality of your brand's footprint across the broader information ecosystem. The signals overlap with SEO — but the mechanism, and therefore the strategy, is distinct.",
  },
];

const ChatgptVisibilityWhatIs = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="chatgpt-visibility-what-is"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <div className="max-w-3xl mb-14 md:mb-20">
          <motion.span
            custom={0}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUp}
            className="inline-block text-xs uppercase tracking-[0.2em] font-medium text-muted-foreground mb-4"
          >
            Understanding the landscape
          </motion.span>

          <motion.h2
            custom={0.08}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUp}
            className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground font-[Sora,sans-serif] leading-snug mb-5"
          >
            What is ChatGPT visibility — and how does it work?
          </motion.h2>

          <motion.p
            custom={0.16}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            variants={fadeUp}
            className="text-base md:text-lg text-muted-foreground leading-relaxed"
          >
            When someone asks ChatGPT to recommend a solicitor in Manchester, identify a specialist healthcare consultant, or name a credible SEO consultant in the UK, the model generates a response based on what it has learned — not what it finds at that moment. Understanding how those responses are shaped is the starting point for any meaningful visibility strategy.
          </motion.p>
        </div>

        {/* Introductory pull-quote block */}
        <motion.div
          custom={0.22}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUp}
          className="relative border border-border rounded-md bg-muted/40 px-6 py-7 md:px-10 md:py-8 mb-14 md:mb-20 max-w-3xl"
        >
          <span className="absolute -top-3 left-6 md:left-10 px-3 py-0.5 bg-background border border-border rounded text-[10px] uppercase tracking-widest font-medium text-muted-foreground">
            Key distinction
          </span>
          <p className="text-base md:text-[1.05rem] text-foreground leading-relaxed">
            ChatGPT does not rank pages. It reflects an understanding of the world assembled from the text it was trained on. For UK businesses operating in competitive, trust-led sectors, that distinction shapes everything about how you approach visibility in AI-generated responses.
          </p>
          <div className="mt-4 flex items-center gap-2 text-sm text-muted-foreground">
            <Sparkles className="h-4 w-4 text-primary flex-shrink-0" />
            <span>AI-generated responses draw on training data, not live web crawls</span>
          </div>
        </motion.div>

        {/* Six-point explanatory grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {points.map((point, index) => {
            const Icon = point.icon;
            return (
              <motion.div
                key={point.heading}
                custom={0.1 + index * 0.07}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={fadeUp}
                className="group flex flex-col gap-4 border border-border rounded-md bg-background p-6 hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%/0.10),0_1px_4px_hsl(222_28%_11%/0.05)] transition-shadow duration-300"
              >
                {/* Icon */}
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                  <Icon className="h-5 w-5 text-primary" />
                </div>

                {/* Heading */}
                <h3 className="text-base font-semibold text-foreground font-[Sora,sans-serif] leading-snug">
                  {point.heading}
                </h3>

                {/* Body */}
                <p className="text-sm text-muted-foreground leading-relaxed flex-1">
                  {point.body}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Contextual note — strategic framing without selling */}
        <motion.div
          custom={0.3}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          variants={fadeUp}
          className="mt-14 md:mt-20 max-w-3xl"
        >
          <p className="text-base text-muted-foreground leading-relaxed mb-4">
            For businesses in sectors where trust is a prerequisite — law, healthcare, finance, property — the implications are significant. ChatGPT may be the first point at which a prospective client forms a perception of your firm, based on whether and how you appear in a generated response.
          </p>
          <p className="text-base text-muted-foreground leading-relaxed mb-8">
            The sections below explore the specific factors that influence ChatGPT responses and what a structured approach to AI search visibility looks like in practice.
          </p>

          {/* Subtle text link — no CTA block */}
          <Link
            to="/ai-search-optimisation"
            className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:text-primary/80 transition-colors duration-200 group"
          >
            Explore the commercial strategy for AI search visibility
            <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform duration-200" />
          </Link>
        </motion.div>

      </div>
    </section>
  );
});

ChatgptVisibilityWhatIs.displayName = "ChatgptVisibilityWhatIs";

export default ChatgptVisibilityWhatIs;
