import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, Lock, MapPin, Shield, Users, FileText, Building, Search, Section } from "lucide-react";

const painPoints = [
  {
    icon: AlertTriangle,
    title: "YMYL Sensitivity & Google Scrutiny",
    description:
      "Health content falls under Google's 'Your Money or Your Life' guidelines, demanding the highest standards of Expertise, Authoritativeness, and Trustworthiness (E-E-A-T). Generic SEO approaches fail clinics because Google evaluates medical content against strict quality criteria. We build content architectures that satisfy both patients and algorithm requirements.",
    stat: "94%",
    statLabel: "of patients research symptoms online before booking",
  },
  {
    icon: MapPin,
    title: "Intense Local Search Competition",
    description:
      "The 'best GP near me' or 'private dentist in [city]' search results are fiercely contested. NHS and private providers compete for the same local intent queries, while aggregator directories often dominate Page 1. Our hyper-local SEO strategies ensure your clinic appears where prospective patients are actively searching.",
    stat: "76%",
    statLabel: "of local health searches result in a clinic visit within 24 hrs",
  },
  {
    icon: Lock,
    title: "Regulatory & Compliance Constraints",
    description:
      "Healthcare marketing is governed by ASA guidelines, CQC registration requirements, and GDPR data obligations. Claims must be substantiated; testimonials must be managed carefully. We understand the regulatory landscape and create SEO content that drives performance without exposing your practice to compliance risk.",
    stat: "3×",
    statLabel: "higher conversion rate with compliant, trust-forward copy",
  },
  {
    icon: Users,
    title: "Low Online Visibility for Specialists",
    description:
      "Specialist clinics — physiotherapists, dermatologists, sports medicine providers — often lack the content depth to compete against large hospital networks. Building topical authority through structured content strategies is essential for private providers to appear for high-intent specialist searches.",
    stat: "67%",
    statLabel: "of private patients compare at least 3 providers online",
  },
  {
    icon: FileText,
    title: "Content That Patients & Google Both Trust",
    description:
      "Medical content must be accurate, empathetic, and clearly authored by qualified professionals. Google's Medic Update rewarded clinics that demonstrated clear authorship and clinical credentials. We integrate author schema, medical credentials, and evidence-based content that earns rankings and patient confidence simultaneously.",
    stat: "2.4×",
    statLabel: "more organic clicks with expert-authored healthcare content",
  },
  {
    icon: Shield,
    title: "Reputation Management in a High-Stakes Sector",
    description:
      "A single negative review or a poorly rated profile can deter dozens of prospective patients. Healthcare providers need a proactive approach to review generation, structured data for aggregate ratings, and consistent NAP signals across directories to protect and enhance their online reputation.",
    stat: "88%",
    statLabel: "of patients trust online reviews as much as personal referrals",
  },
];

const HealthcareClinicsPainPoints = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="healthcare-pain-points"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-2xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4 font-semibold">
            Healthcare SEO Challenges
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            The Unique Obstacles Healthcare Clinics Face in Search
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Healthcare SEO is not like any other sector. From YMYL scrutiny to local
            competition and compliance constraints — these are the pain points we solve
            every day for private medical providers.
          </p>
        </div>

        {/* Pain points grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {painPoints.map((point) => {
            const Icon = point.icon;
            return (
              <Card
                key={point.title}
                className="bg-card border-border shadow-card hover-lift transition-all duration-300 flex flex-col"
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start gap-4">
                    <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <CardTitle className="text-base font-semibold text-foreground leading-snug">
                      {point.title}
                    </CardTitle>
                  </div>
                </CardHeader>
                <CardContent className="flex flex-col gap-4 flex-1">
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {point.description}
                  </p>
                  <div className="mt-auto pt-3 border-t border-border">
                    <div className="flex items-baseline gap-2">
                      <span className="text-2xl font-bold text-primary">
                        {point.stat}
                      </span>
                      <span className="text-xs text-muted-foreground leading-tight">
                        {point.statLabel}
                      </span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
});

HealthcareClinicsPainPoints.displayName = "HealthcareClinicsPainPoints";

export default HealthcareClinicsPainPoints;
