import React from "react";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Search, Globe, Zap, Target, BarChart, Shield, Section } from "lucide-react";

const services = [
  {
    icon: Search,
    title: "Local SEO for Warrington",
    description:
      "Dominate local search results for queries like 'SEO agency Warrington' and '[your service] near me'. I optimise your Google Business Profile, build local citations, and earn geo-relevant links from Cheshire and North West directories.",
    href: "/local-seo",
  },
  {
    icon: Zap,
    title: "Technical SEO",
    description:
      "Full technical audits covering Core Web Vitals, crawlability, site architecture, and indexation. Many Warrington businesses lose rankings due to technical debt — I find and fix it quickly.",
    href: "/technical-seo",
  },
  {
    icon: Globe,
    title: "AI Search Optimisation",
    description:
      "Ensure your Warrington business appears in ChatGPT, Google AI Overviews, and Perplexity results. AI-generated answers are reshaping how local customers find services — be there first.",
    href: "/ai-search-optimisation",
  },
  {
    icon: Target,
    title: "SEO Consulting & Strategy",
    description:
      "Bespoke SEO roadmaps built around your Warrington market position, competitors, and growth targets. Ideal for in-house teams that need expert direction without a full retainer.",
    href: "#seo-consulting-cta",
  },
  {
    icon: BarChart,
    title: "Content Strategy",
    description:
      "Data-driven content plans that address what Warrington customers actually search for. From service pages to authoritative guides, I build content that ranks and converts.",
    href: "/content-strategy",
  },
  {
    icon: Shield,
    title: "SEO Audits",
    description:
      "Comprehensive site audits that reveal exactly why your Warrington business isn't ranking as well as it should. Receive a prioritised action plan you can implement immediately.",
    href: "/seo-audit",
  },
];

const WarringtonServices = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-2xl mb-14">
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-primary font-semibold mb-3">
            SEO Services in Warrington
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">
            Everything Your Warrington Business Needs to Rank
          </h2>
          <p className="mt-4 text-muted-foreground text-lg leading-relaxed">
            From foundational technical work to cutting-edge AI search
            optimisation, I offer the full spectrum of SEO services — all
            delivered with deep knowledge of the Warrington and wider North West
            market.
          </p>
          <div className="mt-4 flex gap-4 text-sm">
            <a
              href="/services"
              className="text-primary font-medium hover:underline"
            >
              All Services →
            </a>
            <a
              href="/local-seo"
              className="text-primary font-medium hover:underline"
            >
              Local SEO →
            </a>
          </div>
        </div>

        {/* Services grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <Card
                key={service.title}
                className="border border-border hover-lift shadow-card bg-card"
              >
                <CardHeader className="pb-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-3">
                    <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
                  </div>
                  <CardTitle className="text-lg text-foreground">
                    {service.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {service.description}
                  </p>
                  <a
                    href={service.href}
                    className="inline-flex items-center mt-4 text-sm font-medium text-primary hover:underline"
                  >
                    Learn more →
                  </a>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="mt-12 flex flex-wrap gap-4 justify-center">
          <Button size="lg" asChild>
            <a href="/contact">Start Your Warrington SEO Project</a>
          </Button>
          <Button size="lg" variant="outline" asChild>
            <a href="/seo-audit">Request a Free Audit</a>
          </Button>
        </div>
      </div>
    </section>
  );
});

WarringtonServices.displayName = "WarringtonServices";

export default WarringtonServices;
