import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, ArrowRight, Laptop } from "lucide-react";

const solutions = [
  {
    badge: "Local SEO",
    href: "/local-seo",
    title: "Local SEO for Estate Agents",
    description:
      "We build the local search foundations that get your agency discovered when vendors and buyers search in your area. This includes Google Business Profile optimisation, citation consistency across all major directories, postcode-level keyword targeting, and geo-specific landing pages for every area you serve.",
    points: [
      "Google Business Profile optimisation and Q&A management",
      "NAP consistency across 60+ property and local directories",
      "Postcode and neighbourhood-level landing pages",
      "Review acquisition and management strategy",
    ],
  },
  {
    badge: "Schema Markup",
    href: "/schema-markup",
    title: "Schema Markup for Property Listings",
    description:
      "Structured data transforms how Google understands and presents your listings. We implement RealEstateAgent, LocalBusiness, and Property schema so your agency earns rich results in search — including star ratings, address details, and opening hours — giving you a visual edge over unstructured competitor listings.",
    points: [
      "RealEstateAgent and LocalBusiness JSON-LD implementation",
      "Property listing schema for individual homes",
      "FAQ schema to capture featured snippet placements",
      "BreadcrumbList and SiteLinks schema for navigation depth",
    ],
  },
  {
    badge: "Entity SEO",
    href: "/entity-seo",
    title: "Entity SEO for Agency Brand Authority",
    description:
      "Google increasingly ranks entities it understands and trusts, not just pages that contain keywords. We build the knowledge graph signals that establish your agency as the authoritative property entity in your area — so Google recommends you in AI-generated answers, local packs, and branded searches.",
    points: [
      "Knowledge panel establishment and optimisation",
      "Entity disambiguation across Google, Wikidata, and Bing",
      "Brand mention and co-citation strategy",
      "Topical authority mapping for property market content",
    ],
  },
  {
    badge: "Content Strategy",
    href: "/content-strategy",
    title: "Content Strategy for Market Insights",
    description:
      "Vendors and landlords instruct the agent they perceive as the local expert. A targeted content strategy — quarterly market reports, neighbourhood guides, buy-to-let advice, and seasonal moving guides — positions your agency as the go-to source of property intelligence in your patch.",
    points: [
      "Monthly local property market reports and commentary",
      "Neighbourhood guides targeting 'best area for...' searches",
      "Buy-to-let and landlord advice content clusters",
      "First-time buyer guides capturing top-of-funnel traffic",
    ],
  },
];

const IndustriesPropertySolutions = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        <div className="max-w-2xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            Our Solutions
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-5">
            SEO Built for the Property Market
          </h2>
          <p className="text-lg text-muted-foreground">
            A joined-up strategy covering local search, structured data, brand authority,
            and content — each pillar engineered specifically for estate agents and
            property service providers.
          </p>
        </div>

        <div className="space-y-12">
          {solutions.map((solution, index) => (
            <div
              key={solution.title}
              className={`grid grid-cols-1 lg:grid-cols-2 gap-10 items-center ${
                index % 2 === 1 ? "lg:flex-row-reverse" : ""
              }`}
            >
              {/* Content */}
              <div className={index % 2 === 1 ? "lg:order-2" : ""}>
                <a href={solution.href}>
                  <Badge className="mb-4 bg-primary/10 text-primary border-primary/20 hover:bg-primary/20 transition-colors cursor-pointer">
                    {solution.badge}
                  </Badge>
                </a>
                <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4">
                  {solution.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed mb-6">
                  {solution.description}
                </p>
                <ul className="space-y-3">
                  {solution.points.map((point) => (
                    <li key={point} className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                      <span className="text-muted-foreground text-sm">{point}</span>
                    </li>
                  ))}
                </ul>
                <Button asChild className="mt-8" variant="outline">
                  <a href={solution.href}>
                    Learn more
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </a>
                </Button>
              </div>

              {/* Visual panel */}
              <div className={`${index % 2 === 1 ? "lg:order-1" : ""}`}>
                <div className="relative rounded-2xl overflow-hidden shadow-card aspect-[4/3]">
                  <img
                    src={`https://images.unsplash.com/photo-${
                      [
                        "1519389950473-47ba0277781c",
                        "1637606346315-d23ed32a6cfc",
                        "1499951360447-b19be8fe80f5",
                        "1571677246347-5040036b95cc",
                      ][index]
                    }?w=800&h=600&fit=crop`}
                    alt={[
                      "Team working on local SEO strategy for property clients",
                      "SEO building blocks representing property schema markup work",
                      "MacBook showing property content strategy and market insights",
                      "Laptop displaying property SEO analytics and entity data",
                    ][index]}
                    width="800"
                    height="600"
                    loading="lazy"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 via-transparent to-transparent pointer-events-none" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
});

IndustriesPropertySolutions.displayName = "IndustriesPropertySolutions";
export default IndustriesPropertySolutions;
