import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { HelpCircle, Book, Search, User, View } from "lucide-react";

const faqs = [
  {
    question: "How does ChatGPT decide which websites to cite?",
    answer:
      "ChatGPT cites sources based on a combination of factors: the training data weight of the domain (how frequently it was referenced and cited in the pre-training corpus), the relevance of the retrieved passage to the query, the structural clarity of the content (how well it answers the specific question), and — when Browse is active — how recently the page was crawled and indexed by Bing. Authoritative, well-structured, frequently cited content consistently wins citations.",
  },
  {
    question: "Do I need to block GPTBot to protect my content?",
    answer:
      "Blocking GPTBot means OpenAI's systems cannot crawl your site, which prevents your content from appearing in ChatGPT Browse results and reduces your probability of citation in AI-generated answers. Unless you have a specific legal or commercial reason to restrict crawling, allowing GPTBot is strongly recommended for AI Search visibility. Add 'User-agent: GPTBot / Allow: /' to your robots.txt to ensure access.",
  },
  {
    question: "Does ChatGPT use Google's index?",
    answer:
      "ChatGPT's Browse feature uses Bing's search index — not Google's — to retrieve live web content. This means Bing crawlability and Bing indexing also matter for ChatGPT visibility, not just Google. Submitting your sitemap to Bing Webmaster Tools and ensuring Bingbot is not blocked are both important steps alongside GPTBot access.",
  },
  {
    question: "What structured data schema types matter most for ChatGPT?",
    answer:
      "FAQPage schema is the highest-impact structured data type for AI Search visibility, as it directly maps question-answer pairs that AI systems are designed to extract. Article and BlogPosting schema with author entity markup signal content credibility. LocalBusiness or Organization schema establishes entity clarity. HowTo schema helps with instructional queries. All should be implemented as JSON-LD, the format preferred by both Google and AI crawlers.",
  },
  {
    question: "How long does it take to appear in ChatGPT results after optimising?",
    answer:
      "Timelines vary depending on your domain's existing authority, how recently GPTBot was allowed access, and the frequency of ChatGPT's browsing crawls. In our experience, technical changes (GPTBot access, schema, crawlability fixes) can produce measurable citation improvements within 2-6 weeks. Content restructuring and authority-building take longer — typically 2-4 months for consistent, high-frequency citation in competitive topics.",
  },
  {
    question: "Is ChatGPT visibility separate from AI Overviews on Google?",
    answer:
      "Yes — they are distinct systems. ChatGPT (OpenAI) and Google AI Overviews (Google/Gemini) use different crawlers, different training data, and different retrieval mechanisms. Optimisation strategies overlap significantly — both reward structured data, clear content, and technical hygiene — but Google AI Overviews specifically uses Googlebot and Google's existing index, while ChatGPT uses GPTBot and Bing's index for Browse. We optimise for both channels as part of a comprehensive AI Search programme.",
  },
];

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map(({ question, answer }) => ({
    "@type": "Question",
    name: question,
    acceptedAnswer: {
      "@type": "Answer",
      text: answer,
    },
  })),
};

const AiSearchChatgptFAQ = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section ref={ref} className="relative py-20 md:py-32 border-t border-border bg-background">
      {/* FAQ JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />

      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="flex justify-center mb-5">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
              <HelpCircle className="h-6 w-6 text-primary" />
            </div>
          </div>
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Common questions
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            ChatGPT Visibility FAQ
          </h2>
          <p className="text-muted-foreground leading-relaxed">
            Answers to the most common questions about how ChatGPT indexes, sources, and cites web content.
          </p>
        </div>

        <div className="max-w-3xl mx-auto mb-14">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`}>
                <AccordionTrigger className="text-left font-semibold text-foreground py-5">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed pb-5">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        {/* Dual CTA */}
        <div className="grid sm:grid-cols-2 gap-6 max-w-2xl mx-auto">
          <div className="bg-card border border-border rounded-xl p-7 text-center shadow-card">
            <h3 className="text-lg font-bold text-foreground mb-2">Ready to get cited by ChatGPT?</h3>
            <p className="text-sm text-muted-foreground mb-5">
              Our AI Search Optimisation service covers every layer — technical, content, and authority.
            </p>
            <Button className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-semibold" asChild>
              <a href="/services-ai-search-optimisation">View AI Search Services</a>
            </Button>
          </div>
          <div className="bg-card border border-border rounded-xl p-7 text-center shadow-card">
            <h3 className="text-lg font-bold text-foreground mb-2">Talk through your situation</h3>
            <p className="text-sm text-muted-foreground mb-5">
              Not sure where to start? Book a free consultation and we will assess your current ChatGPT visibility.
            </p>
            <Button variant="outline" className="w-full font-semibold" asChild>
              <a href="/contact">Get in Touch</a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
});

AiSearchChatgptFAQ.displayName = "AiSearchChatgptFAQ";
export default AiSearchChatgptFAQ;
