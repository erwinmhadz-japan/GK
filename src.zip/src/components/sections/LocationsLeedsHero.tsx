import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { MapPin, TrendingUp, Search, View } from "lucide-react";

const LocationsLeedsHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      src="https://images.unsplash.com/photo-1573496528298-f0e9d3c7ce55?w=1920&h=1080&fit=crop"
      alt="Professional working at a computer in a modern Leeds office"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center"
      id="leeds-hero"
    >
      {/* JSON-LD: LocalBusiness + Organization */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify([
            {
              "@context": "https://schema.org",
              "@type": "LocalBusiness",
              name: "Gregg SEO Consulting – Leeds",
              url: "https://greggseo.com/locations/leeds",
              telephone: "+44 113 000 0000",
              email: "leeds@greggseo.com",
              address: {
                "@type": "PostalAddress",
                streetAddress: "1 Park Row",
                addressLocality: "Leeds",
                addressRegion: "West Yorkshire",
                postalCode: "LS1 5AB",
                addressCountry: "GB",
              },
              geo: {
                "@type": "GeoCoordinates",
                latitude: "53.7997",
                longitude: "-1.5492",
              },
              areaServed: [
                "Leeds",
                "West Yorkshire",
                "Bradford",
                "Harrogate",
                "Wakefield",
                "Huddersfield",
              ],
              serviceType: "SEO Consulting",
              priceRange: "££",
              openingHours: "Mo-Fr 09:00-18:00",
              image:
                "https://images.unsplash.com/photo-1573496528298-f0e9d3c7ce55?w=800&h=600&fit=crop",
            },
            {
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "Gregg SEO Consulting",
              url: "https://greggseo.com",
              logo: "https://greggseo.com/logo.png",
              contactPoint: {
                "@type": "ContactPoint",
                telephone: "+44 113 000 0000",
                contactType: "customer service",
                areaServed: "GB",
                availableLanguage: "English",
              },
            },
          ]),
        }}
      />
      <div className="container relative z-10 py-24 md:py-32">
        <div className="flex items-center gap-2 mb-4">
          <MapPin className="h-4 w-4 text-primary" />
          <span className="text-white/80 text-sm uppercase tracking-[0.2em]">
            Leeds, West Yorkshire
          </span>
        </div>
        <h1 className="text-4xl md:text-6xl font-bold text-white max-w-3xl leading-tight">
          SEO Consulting for{" "}
          <span className="text-gradient-green">Leeds Businesses</span>
        </h1>
        <p className="mt-6 text-lg md:text-xl text-white/90 max-w-2xl leading-relaxed">
          Leeds is one of the UK's most competitive digital markets. We help
          Leeds businesses cut through the noise — ranking higher in local
          search, winning organic traffic, and converting visitors into
          customers.
        </p>
        <div className="mt-8 flex flex-wrap gap-4">
          <div className="flex items-center gap-2 text-white/80 text-sm">
            <TrendingUp className="h-4 w-4 text-primary" />
            <span>Proven local rankings</span>
          </div>
          <div className="flex items-center gap-2 text-white/80 text-sm">
            <Search className="h-4 w-4 text-primary" />
            <span>Leeds-specific SEO strategy</span>
          </div>
        </div>
        <div className="mt-10 flex flex-wrap gap-4">
          <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90" asChild>
            <a href="/contact">Get a Free Leeds SEO Audit</a>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-transparent text-white border-white hover:bg-white/10"
            asChild
          >
            <a href="/services">View Our Services</a>
          </Button>
        </div>
      </div>
    </ImageBackground>
  );
});

LocationsLeedsHero.displayName = "LocationsLeedsHero";
export default LocationsLeedsHero;
