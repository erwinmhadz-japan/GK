import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle, Contact } from "lucide-react";

const trustPoints = [
  "Independent UK SEO consultant, not an agency",
  "Specialist in entity-based search and Knowledge Graph optimisation",
  "Working with UK businesses in competitive, trust-led sectors",
];

const EntitySeoCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="entity-seo-cta"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
      style={{
        background:
          "linear-gradient(180deg, hsl(225 28% 10%) 0%, hsl(231 9% 14%) 100%)",
      }}
    >
      {/* Subtle dot-grid texture overlay */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(84 74% 60%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
        aria-hidden="true"
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          {/* Eyebrow */}
          <motion.span
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut" }}
            className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] font-medium mb-6"
            style={{ color: "hsl(84 74% 60%)" }}
          >
            Entity SEO Consultancy
          </motion.span>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.08 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-6 max-w-2xl mx-auto"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Ready to Build Your Entity Authority?
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.16 }}
            className="text-base md:text-lg text-white/80 leading-relaxed mb-10 max-w-xl mx-auto"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Work with an independent UK SEO consultant who specialises in
            entity-based search and semantic authority.
          </motion.p>

          {/* Trust points */}
          <motion.ul
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.24 }}
            className="flex flex-col sm:flex-row sm:flex-wrap sm:justify-center gap-3 mb-10"
            aria-label="Why work with Gregg King"
          >
            {trustPoints.map((point) => (
              <li
                key={point}
                className="flex items-center gap-2 text-sm text-white/80 sm:px-2"
              >
                <CheckCircle
                  className="h-4 w-4 shrink-0"
                  style={{ color: "hsl(119 35% 61%)" }}
                  aria-hidden="true"
                />
                <span>{point}</span>
              </li>
            ))}
          </motion.ul>

          {/* CTA buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.32 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
          >
            {/* Primary CTA */}
            <Button
              size="lg"
              className="w-full sm:w-auto h-12 px-8 text-base font-semibold border-0 text-white hover:opacity-90 transition-opacity duration-200"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                color: "hsl(225 28% 10%)",
                fontFamily: "Inter, sans-serif",
              }}
              asChild
            >
              <Link to="/contact">
                Contact Me
                <ArrowRight className="ml-2 h-4 w-4" aria-hidden="true" />
              </Link>
            </Button>

            {/* Secondary CTA */}
            <Button
              size="lg"
              variant="outline"
              className="w-full sm:w-auto h-12 px-8 text-base font-semibold bg-transparent border-white/30 text-white hover:bg-white/10 hover:border-white/50 transition-all duration-200"
              style={{ fontFamily: "Inter, sans-serif" }}
              asChild
            >
              <Link to="/contact">
                FREE SEO Audit
              </Link>
            </Button>
          </motion.div>

          {/* Reassurance note */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.44 }}
            className="mt-8 text-sm text-white/80"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            No obligation. I&rsquo;ll respond within one business day.
          </motion.p>
        </div>
      </div>
    </section>
  );
});

EntitySeoCTA.displayName = "EntitySeoCTA";

export default EntitySeoCTA;
