import React from "react";
import { Award, ShieldCheck, Star, CheckCircle, Building, Signal } from "lucide-react";

const eatPillars = [
  {
    icon: Star,
    title: "Experience",
    colour: "bg-amber-50 border-amber-200",
    iconColour: "text-amber-500",
    description:
      "Google now explicitly rewards first-hand experience. Content written by people who have directly done, tested, or researched the topic is prioritised over generic third-party summaries.",
    signals: [
      "Author bios with relevant credentials",
      "Case studies with verifiable results",
      "Original data, research, or client examples",
      "Real-world product or service testing",
    ],
  },
  {
    icon: Award,
    title: "Expertise",
    colour: "bg-blue-50 border-blue-200",
    iconColour: "text-blue-500",
    description:
      "Expertise signals tell Google that the content creator has the knowledge required to speak authoritatively on the subject — particularly important in YMYL (Your Money Your Life) categories.",
    signals: [
      "Named authors with demonstrable qualifications",
      "Topical depth across a content cluster",
      "Referenced and cited sources",
      "Professional association memberships",
    ],
  },
  {
    icon: ShieldCheck,
    title: "Authoritativeness",
    colour: "bg-green-50 border-green-200",
    iconColour: "text-green-600",
    description:
      "Authority is built through recognition — backlinks from trusted domains, brand mentions, press citations, and industry directories all contribute to how authoritative Google perceives your domain to be.",
    signals: [
      "High-quality backlink profile",
      "Digital PR and brand mentions",
      "Listed in industry directories",
      "Guest contributions to authoritative publications",
    ],
  },
  {
    icon: ShieldCheck,
    title: "Trustworthiness",
    colour: "bg-purple-50 border-purple-200",
    iconColour: "text-purple-500",
    description:
      "Trust is the foundation on which all other EEAT signals rest. Transparent ownership, accurate contact information, clear privacy policies, and honest content all contribute to a trustworthy domain.",
    signals: [
      "Clear authorship and editorial standards",
      "Accurate and up-to-date information",
      "Transparent pricing, policies, and T&Cs",
      "Positive reviews and third-party validation",
    ],
  },
];

const AiSearchGoogleAiOverviewsEEAT = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Google's Trust Framework
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">
            EEAT Signals — The Factors Google Considers
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Experience, Expertise, Authoritativeness, and Trustworthiness (EEAT) are
            the four pillars Google's Quality Raters use to evaluate content. AI
            Overviews overwhelmingly cite sources that score highly across all four.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-16">
          {eatPillars.map((pillar) => (
            <div
              key={pillar.title}
              className={`rounded-xl border p-8 shadow-soft hover-lift ${pillar.colour}`}
            >
              <div className="flex items-center gap-3 mb-4">
                <pillar.icon className={`h-7 w-7 ${pillar.iconColour}`} />
                <h3 className="text-xl font-bold text-foreground">{pillar.title}</h3>
              </div>
              <p className="text-muted-foreground leading-relaxed mb-5">
                {pillar.description}
              </p>
              <ul className="space-y-2">
                {pillar.signals.map((signal) => (
                  <li key={signal} className="flex items-start gap-2 text-sm text-foreground">
                    <CheckCircle className="h-4 w-4 text-green-500 mt-0.5 shrink-0" />
                    <span>{signal}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="rounded-xl border border-border bg-secondary text-secondary-foreground p-8 max-w-3xl mx-auto text-center">
          <p className="font-semibold text-lg mb-3">EEAT Is Not a Ranking Factor — It's a Signal System</p>
          <p className="text-secondary-foreground/80 leading-relaxed">
            Google does not have a single "EEAT score," but it uses hundreds of signals
            that collectively reflect these principles. Building EEAT requires a
            long-term, joined-up approach — combining{" "}
            <a href="/entity-seo" className="text-primary underline hover:no-underline">
              entity SEO
            </a>
            ,{" "}
            <a href="/technical-seo" className="text-primary underline hover:no-underline">
              technical SEO
            </a>
            , content strategy, and digital PR into a single, cohesive programme.
          </p>
        </div>
      </div>
    </section>
  );
});

AiSearchGoogleAiOverviewsEEAT.displayName = "AiSearchGoogleAiOverviewsEEAT";

export default AiSearchGoogleAiOverviewsEEAT;
