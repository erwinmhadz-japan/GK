import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Network, Brain, Fingerprint, CheckCircle, Layers, Database, Infinity as InfinityIcon, Key } from "lucide-react";

const EntitySeoHero = React.forwardRef<HTMLElement>((props, ref) => {
  const keyPoints = [
    "Knowledge Graph optimisation",
    "Entity disambiguation",
    "Structured identity signals",
  ];

  return (
    <section
      ref={ref}
      id="entity-seo-hero"
      className="relative isolate overflow-hidden border-t border-border"
      style={{ background: "hsl(225 28% 14%)" }}
    >
      {/* Subtle dot-grid texture overlay */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(214 32% 60% / 0.08) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      {/* Gradient glow — top-left accent */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-40 -left-40 h-[520px] w-[520px] rounded-full"
        style={{
          background:
            "radial-gradient(circle, hsl(84 74% 58% / 0.10) 0%, transparent 70%)",
        }}
      />

      {/* Gradient glow — bottom-right accent */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-32 -right-32 h-[420px] w-[420px] rounded-full"
        style={{
          background:
            "radial-gradient(circle, hsl(214 32% 60% / 0.08) 0%, transparent 70%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10 py-24 md:py-36">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">

          {/* ── Left column: editorial copy ── */}
          <div>
            {/* Eyebrow label */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, ease: "easeOut", delay: 0 }}
            >
              <Badge
                variant="outline"
                className="mb-6 text-xs uppercase tracking-[0.18em] bg-transparent px-3 py-1"
                style={{
                  borderColor: "hsl(214 32% 60% / 0.4)",
                  color: "hsl(214 32% 70%)",
                }}
              >
                Entity SEO
              </Badge>
            </motion.div>

            {/* H1 — primary keyword */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, ease: "easeOut", delay: 0.1 }}
              className="text-3xl md:text-4xl lg:text-5xl font-bold leading-[1.12] tracking-tight text-white max-w-xl"
              style={{ fontFamily: "Sora, sans-serif" }}
            >
              Entity SEO{" "}
              <span
                className="inline-block"
                style={{
                  background:
                    "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
              >
                Consultant UK
              </span>
            </motion.h1>

            {/* Subheadline */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, ease: "easeOut", delay: 0.2 }}
              className="mt-5 text-base md:text-lg leading-relaxed text-white/80 max-w-lg"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              Build semantic authority and help search engines understand exactly
              who you are and what you do. I work with UK businesses in competitive
              sectors to establish a clear, structured entity presence — from
              Knowledge Graph optimisation to brand entity consolidation.
            </motion.p>

            {/* Key-point list */}
            <motion.ul
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
              className="mt-7 space-y-2.5"
              aria-label="Entity SEO capabilities"
            >
              {keyPoints.map((point) => (
                <li key={point} className="flex items-center gap-2.5">
                  <CheckCircle
                    className="h-4 w-4 shrink-0"
                    style={{ color: "hsl(84 74% 58%)" }}
                    aria-hidden="true"
                  />
                  <span
                    className="text-sm text-white/80"
                    style={{ fontFamily: "Inter, sans-serif" }}
                  >
                    {point}
                  </span>
                </li>
              ))}
            </motion.ul>

            {/* CTA row */}
            <motion.div
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.4 }}
              className="mt-9 flex flex-wrap items-center gap-4"
            >
              <Button
                asChild
                size="lg"
                className="text-sm font-semibold px-7 rounded-md hover:opacity-90 transition-all duration-200"
                style={{
                  background:
                    "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                  color: "hsl(225 28% 10%)",
                  boxShadow: "0 0 24px hsl(84 74% 58% / 0.22)",
                }}
              >
                <Link to="/contact">
                  Get in Touch
                  <ArrowRight className="ml-2 h-4 w-4" aria-hidden="true" />
                </Link>
              </Button>

              <Button
                asChild
                size="lg"
                variant="outline"
                className="text-sm font-medium px-7 rounded-md bg-transparent text-white transition-all duration-200"
                style={{
                  borderColor: "hsl(0 0% 100% / 0.25)",
                }}
              >
                <Link to="/contact">FREE SEO Audit</Link>
              </Button>
            </motion.div>

            {/* Trust note */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.55 }}
              className="mt-5 text-xs text-white/80"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              Independent consultant · Based in Warrington, Cheshire · Serving UK
              businesses
            </motion.p>
          </div>

          {/* ── Right column: abstract entity-graph visual ── */}
          <motion.div
            initial={{ opacity: 0, x: 32 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.75, ease: "easeOut", delay: 0.25 }}
            className="hidden lg:flex items-center justify-center"
            aria-hidden="true"
          >
            <div className="relative w-80 h-80">

              {/* Connector lines — rendered behind nodes */}
              <svg
                className="absolute inset-0 w-full h-full"
                viewBox="0 0 320 320"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                {/* Centre = 160,160; corner nodes ≈ 55,55 | 265,55 | 55,265 | 265,265 */}
                <line x1="160" y1="160" x2="55"  y2="55"  stroke="hsl(214 32% 60% / 0.22)" strokeWidth="1" strokeDasharray="4 5" />
                <line x1="160" y1="160" x2="265" y2="55"  stroke="hsl(214 32% 60% / 0.22)" strokeWidth="1" strokeDasharray="4 5" />
                <line x1="160" y1="160" x2="55"  y2="265" stroke="hsl(214 32% 60% / 0.22)" strokeWidth="1" strokeDasharray="4 5" />
                <line x1="160" y1="160" x2="265" y2="265" stroke="hsl(214 32% 60% / 0.22)" strokeWidth="1" strokeDasharray="4 5" />
                {/* Ambient rings */}
                <circle cx="160" cy="160" r="90"  stroke="hsl(84 74% 58% / 0.08)"  strokeWidth="1" />
                <circle cx="160" cy="160" r="124" stroke="hsl(214 32% 60% / 0.06)" strokeWidth="1" />
              </svg>

              {/* Central node — Brain (entity intelligence) */}
              <div
                className="absolute flex items-center justify-center w-24 h-24 rounded-2xl shadow-lg"
                style={{
                  top: "50%",
                  left: "50%",
                  transform: "translate(-50%, -50%)",
                  background:
                    "linear-gradient(135deg, hsl(84 74% 58% / 0.18), hsl(119 35% 61% / 0.10))",
                  border: "1px solid hsl(84 74% 58% / 0.30)",
                }}
              >
                <Brain
                  className="h-10 w-10"
                  style={{ color: "hsl(84 74% 60%)" }}
                />
              </div>

              {/* Orbiting node 1 — top-left: Knowledge Graph */}
              <motion.div
                animate={{ y: [0, -6, 0] }}
                transition={{ duration: 4.5, repeat: Infinity, ease: "easeInOut" }}
                className="absolute top-8 left-8 w-14 h-14 rounded-xl flex items-center justify-center"
                style={{
                  background: "hsl(231 9% 16%)",
                  border: "1px solid hsl(214 32% 60% / 0.25)",
                }}
              >
                <Network className="h-6 w-6" style={{ color: "hsl(214 32% 68%)" }} />
              </motion.div>

              {/* Orbiting node 2 — top-right: Identity / Fingerprint */}
              <motion.div
                animate={{ y: [0, 6, 0] }}
                transition={{ duration: 5, repeat: Infinity, ease: "easeInOut", delay: 0.8 }}
                className="absolute top-8 right-8 w-14 h-14 rounded-xl flex items-center justify-center"
                style={{
                  background: "hsl(231 9% 16%)",
                  border: "1px solid hsl(214 32% 60% / 0.25)",
                }}
              >
                <Fingerprint className="h-6 w-6" style={{ color: "hsl(214 32% 68%)" }} />
              </motion.div>

              {/* Orbiting node 3 — bottom-left: Structured layers */}
              <motion.div
                animate={{ y: [0, 5, 0] }}
                transition={{ duration: 4, repeat: Infinity, ease: "easeInOut", delay: 1.4 }}
                className="absolute bottom-8 left-8 w-14 h-14 rounded-xl flex items-center justify-center"
                style={{
                  background: "hsl(231 9% 16%)",
                  border: "1px solid hsl(214 32% 60% / 0.25)",
                }}
              >
                <Layers className="h-6 w-6" style={{ color: "hsl(214 32% 68%)" }} />
              </motion.div>

              {/* Orbiting node 4 — bottom-right: Structured data / Database */}
              <motion.div
                animate={{ y: [0, -5, 0] }}
                transition={{ duration: 5.5, repeat: Infinity, ease: "easeInOut", delay: 0.4 }}
                className="absolute bottom-8 right-8 w-14 h-14 rounded-xl flex items-center justify-center"
                style={{
                  background: "hsl(231 9% 16%)",
                  border: "1px solid hsl(214 32% 60% / 0.25)",
                }}
              >
                <Database className="h-6 w-6" style={{ color: "hsl(214 32% 68%)" }} />
              </motion.div>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
});

EntitySeoHero.displayName = "EntitySeoHero";
export default EntitySeoHero;
