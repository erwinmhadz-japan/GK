import React from "react";
import { motion } from "framer-motion";

const steps = [
  {
    number: "01",
    title: "Discovery & Diagnostics",
    description:
      "I begin with a structured conversation about your business, your commercial objectives, and where organic search currently sits in your overall growth strategy. Before making any recommendations, I carry out a thorough technical and content audit to understand exactly what is holding your site back — and what genuine opportunity exists.",
    detail: "Typically completed within the first two weeks of engagement.",
  },
  {
    number: "02",
    title: "Strategy & Recommendations",
    description:
      "Based on my findings, I produce a clear, prioritised SEO strategy aligned to your specific business goals. This is not a templated report — it is a considered set of recommendations built around your market, your competitors, and the keywords that will drive meaningful commercial value for your sector.",
    detail: "Delivered as a working document you can action independently or with my ongoing support.",
  },
  {
    number: "03",
    title: "Execution Support & Reporting",
    description:
      "I work alongside your team — or independently — to implement agreed actions: technical fixes, content direction, link acquisition, and schema or entity work where relevant. You receive regular, plain-English reporting on progress, with direct access to me for questions. No intermediaries, no account managers.",
    detail: "Monthly reporting with quarterly strategy reviews as standard.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.18,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut" },
  },
};

const SEOConsultingProcess = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seoconsulting-process"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.65, ease: "easeOut" }}
          className="mb-14 md:mb-20"
        >
          <span
            className="inline-block text-xs uppercase tracking-[0.22em] font-medium mb-4"
            style={{ color: "hsl(214 32% 60%)" }}
          >
            How I Work
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground max-w-2xl leading-tight">
            How the Consulting Process Works
          </h2>
          <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
            Every engagement is structured to give you clarity, direction, and
            measurable progress — delivered directly by me, without layers of
            account management.
          </p>
        </motion.div>

        {/* Steps */}
        <motion.ol
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="relative flex flex-col gap-0"
        >
          {/* Vertical connector line (desktop) */}
          <div
            aria-hidden="true"
            className="hidden md:block absolute left-[2.75rem] top-10 bottom-10 w-px"
            style={{ background: "hsl(214 32% 60% / 0.18)" }}
          />

          {steps.map((step, index) => (
            <motion.li
              key={step.number}
              variants={itemVariants}
              className={`relative flex flex-col md:flex-row gap-6 md:gap-10 ${
                index < steps.length - 1 ? "pb-12 md:pb-14" : ""
              }`}
            >
              {/* Step number badge */}
              <div className="flex-shrink-0 flex items-start md:items-start">
                <div
                  className="relative z-10 flex items-center justify-center w-[3.5rem] h-[3.5rem] rounded-md font-bold text-sm tracking-wider select-none"
                  style={{
                    background: "hsl(225 28% 14%)",
                    color: "hsl(214 32% 60%)",
                    border: "1px solid hsl(214 32% 60% / 0.25)",
                    fontFamily: "var(--font-body, Inter, sans-serif)",
                    letterSpacing: "0.08em",
                  }}
                >
                  {step.number}
                </div>
              </div>

              {/* Content */}
              <div className="flex-1 pt-1">
                <h3 className="text-lg md:text-xl font-semibold text-foreground mb-3 leading-snug">
                  {step.title}
                </h3>
                <p className="text-base text-muted-foreground leading-relaxed max-w-prose mb-4">
                  {step.description}
                </p>
                <p
                  className="text-sm font-medium"
                  style={{ color: "hsl(214 32% 60%)" }}
                >
                  {step.detail}
                </p>
              </div>
            </motion.li>
          ))}
        </motion.ol>

        {/* Closing note */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
          className="mt-14 md:mt-16 pt-10 border-t border-border"
        >
          <p className="text-sm md:text-base text-muted-foreground max-w-2xl leading-relaxed">
            Engagements are scoped to your specific requirements — whether you
            need a one-off strategic review, hands-on implementation support, or
            an ongoing SEO retainer. I work with UK businesses across law,
            healthcare, finance, property, and professional services where
            organic visibility directly supports commercial growth.
          </p>
        </motion.div>
      </div>
    </section>
  );
});

SEOConsultingProcess.displayName = "SEOConsultingProcess";

export default SEOConsultingProcess;
