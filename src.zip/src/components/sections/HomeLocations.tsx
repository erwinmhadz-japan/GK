import React from "react";
import { motion } from "framer-motion";
import { MapPin, ArrowRight, ChevronRight, Home, Icon, Tag, View } from "lucide-react";
import { Link } from "react-router-dom";

const locations = [
  {
    label: "SEO Consultant Warrington",
    city: "Warrington",
    href: "/locations-warrington",
    descriptor:
      "Gregg King is based in Warrington, Cheshire — working directly with local and national businesses from a single point of contact.",
    tag: "Home base",
  },
  {
    label: "SEO Consultant Manchester",
    city: "Manchester",
    href: "/locations-manchester",
    descriptor:
      "Supporting Manchester businesses in competitive sectors — law, finance, property, and professional services — where strong search visibility matters.",
    tag: "Greater Manchester",
  },
  {
    label: "SEO Consultant Liverpool",
    city: "Liverpool",
    href: "/locations-liverpool",
    descriptor:
      "Working with Liverpool-based businesses seeking independent, expert SEO without agency overhead or account-management layers.",
    tag: "Merseyside",
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay: i * 0.12 },
  }),
};

const HomeLocations = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="home-locations"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mb-14 md:mb-16"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground font-medium mb-4">
            Based in Warrington, Cheshire
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground tracking-tight max-w-2xl">
            UK SEO Consultant —{" "}
            <span className="text-primary">National Reach</span>
          </h2>
          <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-xl leading-relaxed">
            Based in Warrington, Cheshire. Working with businesses across the UK.
          </p>
        </motion.div>

        {/* Location Cards — exactly 3 */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {locations.map((loc, i) => (
            <motion.div
              key={loc.city}
              custom={i}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              variants={fadeUp}
            >
              <Link
                to={loc.href}
                className="group flex flex-col h-full rounded-md border border-border bg-background hover:border-primary/60 hover:shadow-[0_4px_24px_0_rgba(0,0,0,0.08)] transition-all duration-300 p-6 md:p-8"
                aria-label={loc.label}
              >
                {/* Tag + Icon row */}
                <div className="flex items-center justify-between mb-5">
                  <span className="inline-flex items-center gap-1.5 text-xs uppercase tracking-widest text-muted-foreground font-medium">
                    <MapPin className="h-3.5 w-3.5 text-primary" aria-hidden="true" />
                    {loc.tag}
                  </span>
                </div>

                {/* City heading */}
                <h3 className="text-lg md:text-xl font-semibold text-foreground mb-3 group-hover:text-primary transition-colors duration-200">
                  {loc.label}
                </h3>

                {/* Descriptor */}
                <p className="text-sm text-muted-foreground leading-relaxed flex-1">
                  {loc.descriptor}
                </p>

                {/* Link indicator */}
                <div className="mt-6 flex items-center gap-1 text-xs font-medium text-primary opacity-0 group-hover:opacity-100 translate-y-1 group-hover:translate-y-0 transition-all duration-200">
                  <span>View location page</span>
                  <ChevronRight className="h-3.5 w-3.5" aria-hidden="true" />
                </div>
              </Link>
            </motion.div>
          ))}
        </div>

        {/* Address + All Locations link */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55, ease: "easeOut", delay: 0.4 }}
          className="mt-12 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6 pt-8 border-t border-border"
        >
          {/* Structured address — shown for LocalBusiness schema context */}
          <address className="not-italic flex items-start gap-2.5 text-sm text-muted-foreground">
            <MapPin className="h-4 w-4 text-muted-foreground shrink-0 mt-0.5" aria-hidden="true" />
            <span>
              22 Foxdale Court, Warrington WA4 5BS, Cheshire, GB
            </span>
          </address>

          {/* Subtle text link to /locations hub */}
          <Link
            to="/locations"
            className="inline-flex items-center gap-1.5 text-sm font-medium text-foreground hover:text-primary transition-colors duration-200 whitespace-nowrap"
          >
            All UK locations
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
});

HomeLocations.displayName = "HomeLocations";

export default HomeLocations;
