import React from "react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { MapPin, Building2, Star, MessageSquare, Tag, BarChart2, Map as MapIcon, Globe, Search, FileText, Building, Link, Phone, Section, Text } from "lucide-react";

interface LocalSeoService {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  description: string;
}

const services: LocalSeoService[] = [
  {
    icon: Building2,
    label: "Google Business Profile Audit",
    description:
      "A thorough review of your GBP listing — completeness, category accuracy, photo quality, service areas, and spam filter exposure.",
  },
  {
    icon: Search,
    label: "Google Business Profile Optimisation",
    description:
      "Hands-on optimisation of your GBP to maximise map-pack visibility, including attributes, Q&A, posts, and product/service listings.",
  },
  {
    icon: MapPin,
    label: "Local Citation Building",
    description:
      "Structured citation placement across UK-relevant directories to reinforce NAP consistency and strengthen local authority signals.",
  },
  {
    icon: BarChart2,
    label: "NAP Consistency Audit",
    description:
      "Identification and correction of inconsistent Name, Address, and Phone data across the web — a foundational local ranking factor.",
  },
  {
    icon: Star,
    label: "Review Strategy",
    description:
      "A practical, compliant strategy for generating genuine customer reviews on Google and sector-specific platforms to build trust signals.",
  },
  {
    icon: Tag,
    label: "Local Schema Markup",
    description:
      "Implementation of LocalBusiness, Service, and Review schema to help search engines and AI platforms understand your geographic relevance.",
  },
  {
    icon: FileText,
    label: "Local Content Strategy",
    description:
      "Development of location-specific content targeting city- and area-level search queries to build topical authority in your target market.",
  },
  {
    icon: Map,
    label: "Map Pack Ranking Strategy",
    description:
      "A structured approach to improving your position in the local three-pack — covering proximity signals, prominence, and relevance factors.",
  },
  {
    icon: Globe,
    label: "Local Link Building",
    description:
      "Acquisition of geographically relevant backlinks from local press, directories, business associations, and community organisations.",
  },
  {
    icon: MessageSquare,
    label: "Competitor Local Audit",
    description:
      "Analysis of what your local competitors are doing well — identifying gaps and opportunities in your local SEO position relative to them.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.07,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: "easeOut" },
  },
};

const headingVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" },
  },
};

const LocalSEOLocalSeoServices = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="local-seolocal-seo-services"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={headingVariants}
          className="mb-12 md:mb-16"
        >
          <Badge
            variant="outline"
            className="mb-4 text-xs uppercase tracking-widest border-border text-muted-foreground"
          >
            What I Deliver
          </Badge>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground max-w-2xl">
            Local SEO Services
          </h2>
          <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
            These are the specific deliverables I work through with local SEO
            clients. Each one is designed to improve visibility in map-pack
            results and local organic search — not a template checklist, but a
            considered set of activities tailored to your market.
          </p>
        </motion.div>

        {/* Services grid — exactly 10 items in a 2-column layout */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={containerVariants}
          className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-5"
        >
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.label}
                variants={itemVariants}
                className="group flex items-start gap-4 rounded-md border border-border bg-background p-5 shadow-sm transition-shadow duration-300 hover:shadow-md"
              >
                {/* Icon */}
                <div
                  className="mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-md"
                  style={{
                    background:
                      "hsl(225 28% 14% / 0.07)",
                    border: "1px solid hsl(225 28% 14% / 0.12)",
                  }}
                >
                  <Icon
                    className="h-5 w-5"
                    style={{ color: "hsl(225 28% 14%)" }}
                  />
                </div>

                {/* Text */}
                <div className="min-w-0">
                  <p
                    className="text-sm font-semibold leading-snug"
                    style={{ color: "hsl(225 28% 14%)" }}
                  >
                    {service.label}
                  </p>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                    {service.description}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Subtle foot note — no CTA per spec */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3, ease: "easeOut" }}
          className="mt-10 text-sm text-muted-foreground max-w-xl"
        >
          Scope varies by client and market. I work with each business to
          prioritise the activities that will have the greatest impact on their
          specific local ranking position.
        </motion.p>
      </div>
    </section>
  );
});

LocalSEOLocalSeoServices.displayName = "LocalSEOLocalSeoServices";

export default LocalSEOLocalSeoServices;
