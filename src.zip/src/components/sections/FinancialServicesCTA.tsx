import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { CheckCircle } from "lucide-react";

const trust = [
  "Specialist financial services SEO",
  "FCA compliance-aware content strategy",
  "E-E-A-T & entity authority building",
  "No long-term contracts required",
];

const FinancialServicesCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="financial-services-cta"
      aria-label="Financial Services SEO Call to Action"
      src="https://images.unsplash.com/photo-1559659386-5b78a2a4290c?w=1920&h=1080&fit=crop"
      alt="Architectural view of a brown financial district building"
      imgProps={{ fetchpriority: "auto", loading: "lazy" }}
      className="py-24 md:py-36"
    >
      <div className="container relative z-10">
        <div className="max-w-2xl mx-auto text-center">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4">
            Get Started Today
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 leading-tight">
            Ready to Build Lasting Organic Authority in Financial Services?
          </h2>
          <p className="text-white/90 text-lg leading-relaxed mb-8">
            Speak with a specialist who understands both the SEO landscape and the regulatory
            environment your firm operates in. We'll audit your current organic performance and
            identify the highest-impact opportunities for sustainable growth.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-10">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold px-8"
              asChild
            >
              <a href="/contact">Start a Conversation</a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10 font-semibold px-8"
              asChild
            >
              <a href="/services-seo-audit">Explore SEO Consulting</a>
            </Button>
          </div>

          <ul className="flex flex-col sm:flex-row gap-4 justify-center">
            {trust.map((item, index) => (
              <li key={index} className="flex items-center gap-2 justify-center sm:justify-start">
                <CheckCircle className="h-4 w-4 text-primary shrink-0" />
                <span className="text-white/80 text-sm">{item}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </ImageBackground>
  );
});

FinancialServicesCTA.displayName = "FinancialServicesCTA";

export default FinancialServicesCTA;
