import React from "react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ArrowRight, TrendingUp, BarChart, Building2, MapPin, Briefcase, FileText, Phone, Search, Section } from "lucide-react";
import { Link } from "react-router-dom";

interface CaseStudy {
  id: string;
  sector: string;
  sectorIcon: React.ComponentType<{ className?: string }>;
  service: string;
  client: string;
  location: string;
  challenge: string;
  approach: string;
  outcome: string;
  metric: string;
  metricLabel: string;
  image: string;
  imageAlt: string;
  serviceHref: string;
  industryHref: string;
}

const caseStudies: CaseStudy[] = [
  {
    id: "law-firm-technical-seo",
    sector: "Law & Solicitors",
    sectorIcon: Briefcase,
    service: "Technical SEO",
    client: "Regional Commercial Law Firm",
    location: "Manchester",
    challenge:
      "A mid-sized commercial law firm was losing organic visibility to national directories despite producing high-quality content. Core Web Vitals failures and crawl inefficiencies were suppressing ranking potential.",
    approach:
      "Conducted a comprehensive technical SEO audit identifying 340+ indexation issues, duplicate canonical conflicts, and JavaScript rendering blocks. Rebuilt site architecture around practice area silos with structured internal linking.",
    outcome:
      "Achieved first-page rankings for 14 core commercial law terms within six months. Organic enquiry volume increased substantially, with measurable improvement in qualified lead quality.",
    metric: "+62%",
    metricLabel: "Organic Sessions",
    image:
      "https://images.unsplash.com/photo-1559659386-5b78a2a4290c?w=800&h=600&fit=crop",
    imageAlt: "Modern law firm office building facade",
    serviceHref: "/services/technical-seo",
    industryHref: "/industries/law-solicitors",
  },
  {
    id: "private-clinic-local-seo",
    sector: "Healthcare & Private Clinics",
    sectorIcon: Building2,
    service: "Local SEO",
    client: "Private Dermatology Clinic",
    location: "Liverpool",
    challenge:
      "A private dermatology clinic struggled to appear in local search results despite a strong clinical reputation. Competitors with inferior services dominated Google's local pack and map listings.",
    approach:
      "Overhauled Google Business Profile with structured service categories, clinical photography, and citation signals. Built a localised content programme targeting high-intent treatment queries with a clear geographic focus.",
    outcome:
      "Local pack visibility secured for 11 primary treatment terms. Phone enquiries from organic search increased month-on-month following the initial three-month programme.",
    metric: "+84%",
    metricLabel: "Local Enquiries",
    image:
      "https://images.unsplash.com/photo-1571120245989-c2878f4c89b9?w=800&h=600&fit=crop",
    imageAlt: "Contemporary healthcare clinic interior with clean modern design",
    serviceHref: "/services/local-seo",
    industryHref: "/industries/healthcare-private-clinics",
  },
  {
    id: "estate-agent-content-strategy",
    sector: "Estate Agents & Property",
    sectorIcon: MapPin,
    service: "Content Strategy",
    client: "Independent Estate Agency",
    location: "Warrington",
    challenge:
      "An independent estate agent was publishing regular blog content with minimal organic return. Content was not mapped to search intent, lacked topical authority, and cannibalised existing service pages.",
    approach:
      "Rebuilt the content architecture around a topic cluster model, separating buyer, seller, and landlord journeys. Created a 12-month editorial calendar aligned to seasonal demand signals and local area pages.",
    outcome:
      "Organic traffic to property listing pages increased significantly. The agency became the top-ranking local result for several neighbourhood-level property queries within the target area.",
    metric: "+48%",
    metricLabel: "Organic Traffic",
    image:
      "https://images.unsplash.com/photo-1568649704650-a6ab20e84311?w=800&h=600&fit=crop",
    imageAlt: "People walking near commercial buildings in a city centre",
    serviceHref: "/services/content-strategy",
    industryHref: "/industries/estate-agents-property",
  },
  {
    id: "financial-services-schema",
    sector: "Financial Services",
    sectorIcon: BarChart,
    service: "Schema Markup",
    client: "Independent Financial Adviser",
    location: "Manchester",
    challenge:
      "An IFA firm had strong domain authority but poor click-through rates from search results pages. Rich result eligibility was missed entirely due to absent structured data, and SERP real estate was underutilised.",
    approach:
      "Implemented a full structured data programme covering Organisation, LocalBusiness, FAQPage, and Service schema types. Mapped entity relationships to support Knowledge Panel authority signals and E-E-A-T reinforcement.",
    outcome:
      "Rich snippets appeared for FAQ entries within eight weeks. CTR improved measurably across high-competition financial planning terms, driving incremental qualified traffic.",
    metric: "+31%",
    metricLabel: "Click-Through Rate",
    image:
      "https://images.unsplash.com/photo-1685492259744-f42597aac776?w=800&h=600&fit=crop",
    imageAlt: "Modern financial district buildings reflecting against sky",
    serviceHref: "/services/schema-markup",
    industryHref: "/industries/financial-services",
  },
  {
    id: "b2b-ai-search-optimisation",
    sector: "B2B Professional Services",
    sectorIcon: TrendingUp,
    service: "AI Search Optimisation",
    client: "B2B SaaS Consultancy",
    location: "Manchester",
    challenge:
      "A B2B consultancy noticed that prospective clients were arriving with answers already sourced from ChatGPT and Perplexity, often citing competitors. The firm was invisible in AI-generated responses despite strong traditional SEO.",
    approach:
      "Conducted an AI citation audit across major LLM platforms. Restructured key service pages around entity clarity, authoritative source attribution, and the conversational query patterns used by AI search interfaces.",
    outcome:
      "Brand citations in AI-generated responses increased materially over four months. Lead quality improved as prospects arrived with pre-qualified understanding of the firm's positioning.",
    metric: "+3.4×",
    metricLabel: "AI Citation Rate",
    image:
      "https://images.unsplash.com/photo-1633537065982-712792c23798?w=800&h=600&fit=crop",
    imageAlt: "Contemporary glass office tower reflecting sky and surrounding buildings",
    serviceHref: "/ai-search",
    industryHref: "/industries/b2b-professional-services",
  },
  {
    id: "healthcare-entity-seo",
    sector: "Healthcare & Private Clinics",
    sectorIcon: FileText,
    service: "Entity SEO",
    client: "Private Physiotherapy Practice",
    location: "Liverpool",
    challenge:
      "A specialist physiotherapy practice had excellent clinical credibility offline but lacked entity recognition in Google's Knowledge Graph. Search visibility was limited to branded queries, missing all unbranded treatment intent.",
    approach:
      "Built a structured entity programme: claimed and disambiguated the practice's Knowledge Panel, established consistent entity signals across structured data, Wikipedia-adjacent citations, and authoritative third-party mentions.",
    outcome:
      "Entity establishment in Google's Knowledge Graph within three months. Unbranded organic impressions grew substantially as the practice became a recognised entity for targeted treatment terms.",
    metric: "+91%",
    metricLabel: "Unbranded Impressions",
    image:
      "https://images.unsplash.com/photo-1633537065980-5ec9245c0b0b?w=800&h=600&fit=crop",
    imageAlt: "Architectural metal structures against overcast sky — abstract modern building detail",
    serviceHref: "/services/entity-seo",
    industryHref: "/industries/healthcare-private-clinics",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const CaseStudiesGrid = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="case-studies-grid"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.55, ease: "easeOut" }}
          className="mb-12 md:mb-16"
        >
          <span className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground font-medium mb-4">
            Independent SEO Consultancy
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground max-w-2xl leading-tight">
            Results Across Sectors and Services
          </h2>
          <p className="mt-4 text-base text-muted-foreground max-w-xl leading-relaxed">
            A selection of client engagements spanning technical SEO, local
            search, content strategy, schema markup, entity SEO, and AI search
            optimisation — delivered as an independent consultant.
          </p>
        </motion.div>

        {/* Case study cards */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8"
        >
          {caseStudies.map((study) => {
            const SectorIcon = study.sectorIcon;
            return (
              <motion.div key={study.id} variants={cardVariants}>
                <Card className="group overflow-hidden border border-border bg-background hover:border-primary/40 transition-all duration-300 hover:shadow-[var(--shadow-card-hover)] h-full flex flex-col">
                  {/* Card image */}
                  <div className="relative h-44 overflow-hidden bg-[hsl(var(--navy-mid))]">
                    <img
                      src={study.image}
                      alt={study.imageAlt}
                      width={800}
                      height={600}
                      loading="lazy"
                      className="w-full h-full object-cover opacity-60 group-hover:opacity-70 group-hover:scale-105 transition-all duration-500"
                    />
                    {/* Overlay */}
                    <div className="absolute inset-0 bg-gradient-to-t from-[hsl(var(--navy-deep))/90] via-[hsl(var(--navy-deep))/40] to-transparent pointer-events-none" />

                    {/* Metric badge — top right */}
                    <div className="absolute top-4 right-4 bg-[hsl(var(--navy-deep))/90] border border-primary/30 rounded-md px-3 py-2 text-center">
                      <p className="text-base font-bold text-primary leading-none">
                        {study.metric}
                      </p>
                      <p className="text-[10px] text-white/70 uppercase tracking-wide mt-0.5">
                        {study.metricLabel}
                      </p>
                    </div>

                    {/* Location — bottom left */}
                    <div className="absolute bottom-3 left-4 flex items-center gap-1.5">
                      <MapPin className="h-3.5 w-3.5 text-white/60" />
                      <span className="text-xs text-white/70">{study.location}</span>
                    </div>
                  </div>

                  <CardContent className="flex flex-col flex-1 p-6">
                    {/* Taxonomy row */}
                    <div className="flex flex-wrap gap-2 mb-4">
                      <Badge
                        variant="secondary"
                        className="text-xs flex items-center gap-1 font-medium"
                      >
                        <SectorIcon className="h-3 w-3" />
                        {study.sector}
                      </Badge>
                      <Badge
                        variant="outline"
                        className="text-xs font-medium border-primary/30 text-primary bg-primary/5"
                      >
                        {study.service}
                      </Badge>
                    </div>

                    {/* Client label */}
                    <p className="text-xs uppercase tracking-[0.15em] text-muted-foreground mb-2 font-medium">
                      {study.client}
                    </p>

                    {/* Three-part editorial breakdown */}
                    <div className="space-y-3 flex-1">
                      <div>
                        <p className="text-[11px] uppercase tracking-widest text-muted-foreground font-semibold mb-0.5">
                          Challenge
                        </p>
                        <p className="text-sm text-foreground leading-relaxed">
                          {study.challenge}
                        </p>
                      </div>
                      <div>
                        <p className="text-[11px] uppercase tracking-widest text-muted-foreground font-semibold mb-0.5">
                          Approach
                        </p>
                        <p className="text-sm text-foreground leading-relaxed">
                          {study.approach}
                        </p>
                      </div>
                      <div>
                        <p className="text-[11px] uppercase tracking-widest text-muted-foreground font-semibold mb-0.5">
                          Outcome
                        </p>
                        <p className="text-sm text-foreground leading-relaxed">
                          {study.outcome}
                        </p>
                      </div>
                    </div>

                    {/* Footer links */}
                    <div className="mt-5 pt-4 border-t border-border flex items-center justify-between gap-3">
                      <div className="flex gap-3">
                        <Link
                          to={study.serviceHref}
                          className="text-xs text-muted-foreground hover:text-primary transition-colors duration-200 flex items-center gap-1"
                        >
                          {study.service}
                          <ArrowRight className="h-3 w-3" />
                        </Link>
                        <Link
                          to={study.industryHref}
                          className="text-xs text-muted-foreground hover:text-primary transition-colors duration-200 flex items-center gap-1"
                        >
                          {study.sector}
                          <ArrowRight className="h-3 w-3" />
                        </Link>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Subtle footer note */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3, ease: "easeOut" }}
          className="mt-12 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border-t border-border pt-8"
        >
          <p className="text-sm text-muted-foreground max-w-md">
            All results reflect independent client engagements managed directly
            by Gregg King. Specific client names are withheld to preserve
            confidentiality.
          </p>
          <Button variant="outline" size="default" asChild className="shrink-0">
            <Link to="/contact" className="flex items-center gap-2">
              Discuss your project
              <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
});

CaseStudiesGrid.displayName = "CaseStudiesGrid";

export default CaseStudiesGrid;
