import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { ArrowRight, Phone, Book, Search, View } from "lucide-react";

const EstateAgentsCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="estate-agents-cta"
      aria-label="Estate agent SEO call to action"
      src="https://images.unsplash.com/photo-1633537066070-94bccfa10f05?w=1920&h=1080&fit=crop"
      alt="Modern tall building representing property market ambition"
      imgProps={{ loading: "lazy" }}
      className="py-24 md:py-36"
    >
      <div className="container relative z-10 text-center">
        <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-5">
          Ready to Own Local Search?
        </span>
        <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 max-w-3xl mx-auto leading-tight">
          Let's Build an SEO Strategy That Wins More Instructions
        </h2>
        <p className="text-lg text-white/90 mb-10 max-w-xl mx-auto leading-relaxed">
          Whether you're a single-office independent or a multi-branch
          regional agency, a specialist property SEO strategy can transform
          your organic lead flow within months.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            size="lg"
            className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold text-base px-8"
            asChild
          >
            <a href="/contact">
              Book a Free Discovery Call
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-transparent text-white border-white hover:bg-white/10 font-semibold text-base px-8"
            asChild
          >
            <a href="/local-seo">
              <Phone className="mr-2 h-4 w-4" />
              View Local SEO Services
            </a>
          </Button>
        </div>

        <p className="mt-8 text-sm text-white/80">
          No long-term contracts · Transparent reporting · Results-first approach
        </p>
      </div>
    </ImageBackground>
  );
});

EstateAgentsCTA.displayName = "EstateAgentsCTA";

export default EstateAgentsCTA;
