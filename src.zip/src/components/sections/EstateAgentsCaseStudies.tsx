import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { TrendingUp, MapPin, Star, Quote, Image, Section, Tags } from "lucide-react";

const caseStudies = [
  {
    agency: "Independent Regional Agency",
    location: "South East England",
    image: "https://images.unsplash.com/photo-1633537065985-c65a413f5961?w=800&h=600&fit=crop",
    imageAlt: "Red and white modern residential building in South East England",
    challenge:
      "A 3-branch independent agency was losing market share to a national chain dominating Google's Local Pack. They were paying Rightmove's highest listing tier but generating minimal organic leads.",
    solution:
      "Implemented branch-specific local SEO, rebuilt Google Business Profiles with accurate categories and service areas, developed neighbourhood landing pages for every postcode cluster they covered, and added structured data across all property pages.",
    results: [
      { metric: "247%", label: "Organic traffic increase in 9 months" },
      { metric: "#1", label: "Google Local Pack in 3 key towns" },
      { metric: "68%", label: "Reduction in cost-per-lead vs portal spend" },
    ],
    quote:
      "We went from invisible online to appearing above Rightmove in local searches. The pipeline has transformed — we're now turning away instructions.",
    author: "Branch Director",
    stars: 5,
    tags: ["Local SEO", "Schema Markup"],
  },
  {
    agency: "Luxury Property Specialist",
    location: "Prime Central London",
    image: "https://images.unsplash.com/photo-1571120245989-c2878f4c89b9?w=800&h=600&fit=crop",
    imageAlt: "High-end building interior with large windows representing luxury property",
    challenge:
      "A boutique luxury agency with a strong reputation had virtually no online presence. Their affluent vendors were finding competitor agents through Google searches for their name — because those agents had built entity profiles that their firm lacked.",
    solution:
      "Entity SEO campaign to establish the principal's personal brand and the agency as a recognised Google entity. Knowledge panel acquisition, named entity across property media, and a content strategy positioning them as the authority for prime property in their postcodes.",
    results: [
      { metric: "190%", label: "Branded search impressions in 6 months" },
      { metric: "4.2×", label: "Increase in direct organic enquiries" },
      { metric: "£2.1M+", label: "Average instruction value from organic leads" },
    ],
    quote:
      "Our clients are high-net-worth individuals who search carefully. Appearing as the clear authority online has made a tangible difference to the quality of instructions we receive.",
    author: "Managing Director",
    stars: 5,
    tags: ["Entity SEO", "Brand Authority"],
  },
  {
    agency: "Letting & Sales Agency",
    location: "Northern England",
    image: "https://images.unsplash.com/photo-1559659386-5b78a2a4290c?w=800&h=600&fit=crop",
    imageAlt: "Brown brick building representing northern UK residential property",
    challenge:
      "A combined lettings and sales agency with 7 offices had separate websites that were cannibalising each other's rankings. Thin, duplicated location pages meant none of the offices ranked well individually.",
    solution:
      "Site architecture overhaul with consolidated domain strategy, unique location page content for each office area, branch-level schema markup, and a hyperlocal content programme covering area guides, school catchments, and transport links for every location served.",
    results: [
      { metric: "312%", label: "Increase in location page organic sessions" },
      { metric: "Top 3", label: "Google rankings for 23 target town searches" },
      { metric: "44%", label: "Growth in landlord enquiry form completions" },
    ],
    quote:
      "The location pages alone transformed our visibility. We're now capturing landlords researching areas before they even know which agent they want — and we're first.",
    author: "Head of Lettings",
    stars: 5,
    tags: ["Local SEO", "Content Strategy"],
  },
];

const EstateAgentsCaseStudies = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="estate-agents-case-studies"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-2xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Case Studies
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-5">
            Estate Agent SEO Results That Speak for Themselves
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Real outcomes from estate agents and property businesses that
            invested in specialist SEO strategy. Every result is grounded in
            measurable pipeline impact — not vanity metrics.
          </p>
        </div>

        {/* Case study cards */}
        <div className="space-y-10">
          {caseStudies.map((study) => (
            <Card
              key={study.agency}
              className="overflow-hidden border-border shadow-card bg-card"
            >
              <div className="grid grid-cols-1 lg:grid-cols-5 gap-0">
                {/* Image column */}
                <div className="lg:col-span-2 relative">
                  <img
                    src={study.image}
                    alt={study.imageAlt}
                    width={800}
                    height={600}
                    loading="lazy"
                    className="w-full h-56 lg:h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent lg:bg-gradient-to-r" />
                  <div className="absolute bottom-4 left-4 lg:bottom-auto lg:top-4">
                    <div className="flex items-center gap-1.5 text-white/80 text-sm">
                      <MapPin className="h-3.5 w-3.5" />
                      {study.location}
                    </div>
                  </div>
                </div>

                {/* Content column */}
                <CardContent className="lg:col-span-3 p-6 md:p-8">
                  {/* Tags */}
                  <div className="flex flex-wrap gap-2 mb-4">
                    {study.tags.map((tag) => (
                      <Badge key={tag} variant="secondary" className="text-xs">
                        {tag}
                      </Badge>
                    ))}
                  </div>

                  <h3 className="text-xl font-bold text-foreground mb-1">
                    {study.agency}
                  </h3>

                  {/* Challenge & Solution */}
                  <div className="space-y-3 mb-6">
                    <div>
                      <span className="text-xs uppercase tracking-wider text-primary font-semibold">
                        Challenge
                      </span>
                      <p className="text-sm text-muted-foreground mt-1 leading-relaxed">
                        {study.challenge}
                      </p>
                    </div>
                    <div>
                      <span className="text-xs uppercase tracking-wider text-primary font-semibold">
                        Solution
                      </span>
                      <p className="text-sm text-muted-foreground mt-1 leading-relaxed">
                        {study.solution}
                      </p>
                    </div>
                  </div>

                  {/* Results */}
                  <div className="grid grid-cols-3 gap-4 mb-6 p-4 bg-muted rounded-xl">
                    {study.results.map((result) => (
                      <div key={result.label} className="text-center">
                        <div className="flex items-center justify-center gap-1 mb-1">
                          <TrendingUp className="h-3.5 w-3.5 text-primary" />
                          <span className="text-xl font-bold text-primary">
                            {result.metric}
                          </span>
                        </div>
                        <p className="text-xs text-muted-foreground leading-tight">
                          {result.label}
                        </p>
                      </div>
                    ))}
                  </div>

                  {/* Quote */}
                  <blockquote className="border-l-2 border-primary pl-4">
                    <div className="flex gap-2 mb-2">
                      {Array.from({ length: study.stars }).map((_, i) => (
                        <Star
                          key={i}
                          className="h-3.5 w-3.5 fill-primary text-primary"
                        />
                      ))}
                    </div>
                    <Quote className="h-4 w-4 text-muted-foreground mb-1" />
                    <p className="text-sm italic text-foreground leading-relaxed">
                      {study.quote}
                    </p>
                    <footer className="text-xs text-muted-foreground mt-2">
                      — {study.author}
                    </footer>
                  </blockquote>
                </CardContent>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
});

EstateAgentsCaseStudies.displayName = "EstateAgentsCaseStudies";

export default EstateAgentsCaseStudies;
