import React from "react";
import { motion } from "framer-motion";
import { UserCheck, Layers, BadgeCheck, TrendingUp, MessageSquare, Shield, Section } from "lucide-react";

const differentiators = [
  {
    icon: UserCheck,
    heading: "One consultant, start to finish",
    body: "You work directly with me on every aspect of your SEO — not a junior account executive briefing an offshore team. I write the strategy, I carry out the work, and I'm accountable for the results.",
  },
  {
    icon: Layers,
    heading: "No account manager layers",
    body: "Agencies charge premium rates to cover internal overhead: account managers, team meetings, project tools, sales commissions. As an independent consultant, my fees go directly into the work itself.",
  },
  {
    icon: BadgeCheck,
    heading: "No upselling, no padding",
    body: "Agencies are structured to grow accounts. My model is structured around outcomes. I'll recommend what your site actually needs — not whatever adds the most hours to the invoice.",
  },
  {
    icon: TrendingUp,
    heading: "Senior expertise on every engagement",
    body: "You're not getting someone mid-career learning on your project. I bring over a decade of hands-on SEO experience to every audit, strategy, and implementation I take on.",
  },
  {
    icon: MessageSquare,
    heading: "Direct communication, always",
    body: "When you email me, I reply. When there's a ranking shift or technical issue, I tell you about it — clearly and promptly. No ticket queues, no status updates from an account handler.",
  },
  {
    icon: Shield,
    heading: "Transparent pricing, no surprises",
    body: "You'll know exactly what you're getting and what it costs before we begin. No contracts designed to obscure scope, no surprise add-ons mid-project.",
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay: i * 0.09 },
  }),
};

const SeoConsultingWhyIndependent = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seo-consulting-why-independent"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <div className="max-w-3xl mb-14 md:mb-20">
          <motion.span
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium"
          >
            Independent vs agency
          </motion.span>

          <motion.h2
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.08 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight mb-6"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Why an Independent Consultant,{" "}
            <span className="whitespace-nowrap">Not an Agency</span>
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.15 }}
            className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl"
          >
            Most UK businesses seeking SEO support default to an agency. It's the obvious choice — until you examine what you're actually paying for. As an independent consultant, I offer something structurally different: direct expertise, undiluted accountability, and a working relationship built around your goals rather than an agency's billing targets.
          </motion.p>
        </div>

        {/* Differentiator grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {differentiators.map((item, index) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.heading}
                custom={index}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-40px" }}
                variants={fadeUp}
                className="group bg-background border border-border rounded-md p-6 md:p-7 flex flex-col gap-4 hover:shadow-md transition-shadow duration-300"
              >
                <div className="flex items-center justify-center w-11 h-11 rounded-md bg-primary/10 shrink-0">
                  <Icon className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <h3
                    className="text-base md:text-lg font-semibold text-foreground mb-2 leading-snug"
                    style={{ fontFamily: "Sora, sans-serif" }}
                  >
                    {item.heading}
                  </h3>
                  <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                    {item.body}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Callout strip */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
          className="mt-14 md:mt-20 border border-border rounded-md bg-background px-6 py-8 md:px-10 md:py-10 flex flex-col md:flex-row md:items-center gap-6"
        >
          <div className="shrink-0 hidden md:flex items-center justify-center w-14 h-14 rounded-full bg-primary/10">
            <UserCheck className="w-7 h-7 text-primary" />
          </div>
          <div>
            <p
              className="text-base md:text-lg font-semibold text-foreground mb-1 leading-snug"
              style={{ fontFamily: "Sora, sans-serif" }}
            >
              The model is simple: you hire a senior SEO consultant and work directly with that person.
            </p>
            <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
              There's no onboarding to a team, no handover to a junior analyst, no dependency on a sales relationship. When you engage me, you engage me — and that's who does the work.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
});

SeoConsultingWhyIndependent.displayName = "SeoConsultingWhyIndependent";

export default SeoConsultingWhyIndependent;
