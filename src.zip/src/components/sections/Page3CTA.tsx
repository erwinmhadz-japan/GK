import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle, Book } from "lucide-react";
import { ImageBackground } from "@/components/ImageBackground";

const trustPoints = [
  "No long-term agency contracts",
  "Direct access to a senior consultant",
  "Transparent, measurable reporting",
  "UK-based, Warrington, Cheshire",
];

const Page3CTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="page3-cta"
      aria-label="Results CTA section"
      src="https://images.unsplash.com/photo-1591484385394-f5083609ed6a?w=1920&h=1080&fit=crop"
      alt="Blue and white modern building — professional backdrop for CTA"
      imgProps={{ fetchpriority: "auto", loading: "lazy" }}
      className="py-24 md:py-36"
    >
      <div className="container relative z-10">
        <div className="max-w-2xl mx-auto text-center">
          <motion.span
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="inline-block text-xs uppercase tracking-[0.25em] text-white/80 mb-5"
          >
            Get started today
          </motion.span>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-3xl md:text-5xl font-bold text-white mb-6"
          >
            Ready to add your result to this page?
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg text-white/90 mb-8 leading-relaxed"
          >
            Every engagement starts with an honest conversation about where your
            organic search stands today and what's genuinely achievable. No
            sales pitch — just a strategy session with a senior SEO consultant.
          </motion.p>

          {/* Trust bullets */}
          <motion.ul
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-wrap justify-center gap-x-6 gap-y-2 mb-10"
          >
            {trustPoints.map((point) => (
              <li key={point} className="flex items-center gap-2 text-sm text-white/80">
                <CheckCircle className="h-4 w-4 text-primary shrink-0" aria-hidden="true" />
                {point}
              </li>
            ))}
          </motion.ul>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex flex-wrap justify-center gap-4"
          >
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold shadow-green-glow"
              asChild
            >
              <a href="/contact" className="inline-flex items-center gap-2">
                Book a Free Consultation
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white/50 hover:bg-white/10 font-medium"
              asChild
            >
              <a href="/services">Explore Services</a>
            </Button>
          </motion.div>
        </div>
      </div>
    </ImageBackground>
  );
});

Page3CTA.displayName = "Page3CTA";

export default Page3CTA;
