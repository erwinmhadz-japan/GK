import React from "react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, CheckCircle, Group, Image } from "lucide-react";

const solutions = [
  {
    badge: "Entity SEO",
    badgeHref: "/entity-seo",
    title: "Entity SEO for Firm & Consultant Authority",
    description:
      "Google's Knowledge Graph recognises entities — named consultants, named firms, specialist practice areas. By building your firm's entity footprint through structured data, Wikipedia-adjacent content, and consistent NAP signals, we help Google understand exactly who you are and what you specialise in. This is the foundation of long-term B2B authority.",
    points: [
      "Knowledge Graph entity establishment for named consultants",
      "Schema markup for Organisation, Service, and Person entities",
      "Brand search optimisation for firm name recognition",
      "Entity co-occurrence across authoritative industry publications",
      "Author entity building for thought leadership content",
    ],
    image:
      "https://images.unsplash.com/photo-1633537065982-ef16506d42b8?w=800&h=600&fit=crop",
    imageAlt: "Tall modern glass office building reflecting sky — entity and brand authority",
    cta: { label: "Explore Entity SEO", href: "/entity-seo" },
    reverse: false,
  },
  {
    badge: "Technical SEO",
    badgeHref: "/technical-seo",
    title: "Technical SEO for Complex Service Site Architecture",
    description:
      "Many professional services websites suffer from poor crawl architecture, duplicate service pages across practice areas, and slow Core Web Vitals — all of which erode rankings. A rigorous technical audit and remediation programme ensures your site is search-engine accessible, fast, and correctly structured to signal topical expertise.",
    points: [
      "Site architecture review and crawl optimisation",
      "Core Web Vitals improvement — LCP, CLS, INP",
      "Canonical tag and duplicate content remediation",
      "Internal linking strategy for service area siloing",
      "Hreflang configuration for multi-region firms",
    ],
    image:
      "https://images.unsplash.com/photo-1685492259744-f42597aac776?w=800&h=600&fit=crop",
    imageAlt: "Two tall commercial office buildings against sky — technical architecture",
    cta: { label: "Explore Technical SEO", href: "/technical-seo" },
    reverse: true,
  },
  {
    badge: "Content Strategy",
    badgeHref: "/content-strategy",
    title: "Content Strategy for Vertical Expertise & Thought Leadership",
    description:
      "Buyers in consulting, accountancy, engineering, and HR search for answers to complex business problems before they search for a firm. A content strategy built around your vertical expertise positions your firm as the authoritative source in your niche — generating inbound enquiries from decision-makers already pre-sold on your capability.",
    points: [
      "Topical authority mapping for your practice areas",
      "Long-form pillar content targeting enterprise buyer intent",
      "Thought leadership articles attributed to named consultants",
      "Case study content optimised for bottom-of-funnel search",
      "Industry insight reports that attract natural backlinks",
    ],
    image:
      "https://images.unsplash.com/photo-1568649704650-a6ab20e84311?w=800&h=600&fit=crop",
    imageAlt: "Group of professionals walking near commercial buildings",
    cta: { label: "Explore Content Strategy", href: "/content-strategy" },
    reverse: false,
  },
];

const B2BSEOSolutions = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="b2b-seo-solutions"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            The SEO Approach
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            SEO Solutions Built for Professional Services
          </h2>
          <p className="text-muted-foreground leading-relaxed">
            Three interconnected disciplines that work together to generate a
            consistent pipeline of qualified enterprise enquiries — each
            designed specifically for the B2B professional services buying
            journey.
          </p>
        </div>

        <div className="flex flex-col gap-20">
          {solutions.map((solution, index) => (
            <div
              key={index}
              className={`flex flex-col ${
                solution.reverse ? "lg:flex-row-reverse" : "lg:flex-row"
              } gap-10 items-center`}
            >
              {/* Image */}
              <div className="w-full lg:w-1/2">
                <div className="relative rounded-2xl overflow-hidden shadow-card">
                  <img
                    src={solution.image}
                    alt={solution.imageAlt}
                    width={800}
                    height={600}
                    loading="lazy"
                    className="w-full h-72 md:h-96 object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent pointer-events-none" />
                </div>
              </div>

              {/* Content */}
              <div className="w-full lg:w-1/2 flex flex-col gap-5">
                <Link to={solution.badgeHref}>
                  <Badge className="bg-primary/10 text-primary border border-primary/20 hover:bg-primary/20 transition-colors cursor-pointer uppercase tracking-wider text-xs">
                    {solution.badge}
                  </Badge>
                </Link>

                <h3 className="text-2xl md:text-3xl font-bold text-foreground">
                  {solution.title}
                </h3>

                <p className="text-muted-foreground leading-relaxed">
                  {solution.description}
                </p>

                <ul className="flex flex-col gap-2">
                  {solution.points.map((point, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                      <span className="text-foreground text-sm leading-relaxed">
                        {point}
                      </span>
                    </li>
                  ))}
                </ul>

                <Button
                  variant="outline"
                  className="self-start border-primary text-primary hover:bg-primary/10 mt-2"
                  asChild
                >
                  <Link to={solution.cta.href}>
                    {solution.cta.label}
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
});

B2BSEOSolutions.displayName = "B2BSEOSolutions";

export default B2BSEOSolutions;
