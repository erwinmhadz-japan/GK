import React from "react";
import { Badge } from "@/components/ui/badge";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "How competitive is SEO in Birmingham compared to other UK cities?",
    answer:
      "Birmingham is the UK's second-most competitive digital market after London. The sheer density of businesses — over 87,000 — and the city's diverse economic base means many sectors see fierce organic competition. However, this also means there are significant opportunities for businesses that invest in strategic, expert SEO. Local authority, entity SEO, and technical foundations are especially important in this market.",
  },
  {
    question: "How long does it take to see SEO results for a Birmingham business?",
    answer:
      "Most Birmingham clients begin to see meaningful improvements in rankings and traffic within three to six months, with stronger results building over eight to twelve months. Timelines vary based on your starting position, the competitiveness of your sector, and the scope of work. I focus on prioritising wins that deliver ROI as quickly as possible while building sustainable, long-term growth.",
  },
  {
    question: "Do I need a local Birmingham-based SEO consultant?",
    answer:
      "Not necessarily — effective SEO is about strategy, technical expertise, and market understanding, not physical proximity. I work remotely with Birmingham clients and have a thorough understanding of the city's business districts, local search behaviour, and competitive dynamics. All work is delivered online with regular calls and reporting. What matters is specialist knowledge of the Birmingham market, which I have.",
  },
  {
    question: "What makes your Birmingham SEO different from working with a large agency?",
    answer:
      "When you work with me, you work directly with a senior SEO consultant — not a junior account manager. There are no layers of sales teams or processes adding cost and delay. I handle your strategy, implementation oversight, and reporting personally. This means faster decisions, clearer communication, and strategies that are genuinely tailored to your business rather than templated from a playbook.",
  },
  {
    question: "Do you offer local SEO for specific Birmingham neighbourhoods?",
    answer:
      "Yes. I specialise in hyper-local SEO targeting specific Birmingham postcodes and neighbourhoods — from Edgbaston and Harborne to Sutton Coldfield, Erdington, Digbeth, and the Jewellery Quarter. This includes Google Business Profile optimisation, local citation building, and neighbourhood-specific content strategy to ensure you rank precisely where your customers are searching.",
  },
];

// FAQ JSON-LD for SEO
const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((faq) => ({
    "@type": "Question",
    name: faq.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: faq.answer,
    },
  })),
};

const BirminghamFAQ: React.FC = () => {
  return (
    <section className="relative py-20 md:py-32 border-t border-border bg-background">
      {/* FAQ JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />

      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <Badge variant="secondary" className="mb-4 text-xs uppercase tracking-widest">
            FAQs
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Frequently Asked Questions About Birmingham SEO
          </h2>
          <p className="text-muted-foreground text-lg">
            Answers to common questions from Birmingham businesses about SEO strategy,
            timelines, and working with an independent consultant.
          </p>
        </div>

        <Accordion type="single" collapsible className="w-full max-w-3xl mx-auto">
          {faqs.map((faq, index) => (
            <AccordionItem key={index} value={`item-${index}`}>
              <AccordionTrigger className="text-left font-medium text-foreground">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground leading-relaxed">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
};

export default BirminghamFAQ;
