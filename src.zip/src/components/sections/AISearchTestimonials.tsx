import React from "react";
import { motion } from "framer-motion";
import { Quote, Star, Building2, Briefcase, Scale, Icon, Section, Stars } from "lucide-react";

const testimonials = [
  {
    quote:
      "We'd invested significantly in traditional SEO over the years, but AI search was a blind spot. Gregg audited our entity presence, restructured our schema, and within three months our firm was being cited in ChatGPT and Perplexity responses for key practice areas. The ROI has been measurable and the approach was methodical — not a single piece of guesswork.",
    author: "James Whitfield",
    role: "Managing Partner",
    company: "Whitfield & Co Solicitors",
    sector: "Law",
    Icon: Scale,
    image:
      "https://images.unsplash.com/photo-1605857840732-188f2f08cb31?w=400&h=400&fit=crop&crop=face",
    imageAlt: "James Whitfield, Managing Partner at Whitfield & Co Solicitors",
    stars: 5,
  },
  {
    quote:
      "As a private healthcare provider, trust signals and authority are everything — patients don't choose a clinic from a generic list result. Gregg understood that immediately. His AI search optimisation work strengthened our brand citations, improved our entity clarity, and our clinic now appears in AI-generated answers for the treatments we specialise in. It's exactly the kind of visibility that matters in healthcare.",
    author: "Dr. Sarah Okafor",
    role: "Clinical Director",
    company: "Meridian Health Clinics",
    sector: "Healthcare",
    Icon: Building2,
    image:
      "https://images.unsplash.com/photo-1710778044102-56a3a6b69a1b?w=400&h=400&fit=crop&crop=face",
    imageAlt: "Dr. Sarah Okafor, Clinical Director at Meridian Health Clinics",
    stars: 5,
  },
  {
    quote:
      "I was sceptical about AI search as a channel — it felt like hype. Gregg changed that. He explained precisely how Gemini and Google AI Overviews were pulling competitor brands into high-intent answers and why our financial services firm wasn't appearing. The work he did on our structured data, content authority signals, and brand entity alignment was thorough and transparent. We now appear consistently in AI-surfaced results for our core advisory services.",
    author: "Richard Ashby",
    role: "Head of Marketing",
    company: "Ashby Capital Advisory",
    sector: "Financial Services",
    Icon: Briefcase,
    image:
      "https://images.unsplash.com/photo-1678282955795-200c1e18bc7d?w=400&h=400&fit=crop&crop=face",
    imageAlt: "Richard Ashby, Head of Marketing at Ashby Capital Advisory",
    stars: 5,
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.15,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.65,
      ease: "easeOut",
    },
  },
};

const headingVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut" },
  },
};

const AISearchTestimonials = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="aisearch-testimonials"
      className="relative py-20 md:py-32 border-t border-border bg-[hsl(225_28%_14%)]"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section Header */}
        <motion.div
          className="mb-14 md:mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={headingVariants}
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-white/80 mb-4 font-medium">
            Client Feedback
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white max-w-2xl leading-tight">
            What Clients Say
          </h2>
          <p className="mt-4 text-base md:text-lg text-white/80 max-w-xl leading-relaxed">
            Independent results from UK businesses in competitive, trust-led
            sectors.
          </p>
        </motion.div>

        {/* Testimonial Cards */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={containerVariants}
        >
          {testimonials.map((item) => {
            const SectorIcon = item.Icon;
            return (
              <motion.div
                key={item.author}
                variants={cardVariants}
                className="group relative flex flex-col rounded-md border border-white/10 bg-[hsl(231_9%_16%)] p-7 md:p-8 transition-all duration-300 hover:border-white/20 hover:shadow-[0_8px_32px_rgba(0,0,0,0.35)]"
              >
                {/* Quote icon */}
                <div className="mb-5">
                  <Quote className="h-6 w-6 text-[hsl(84_74%_60%)] opacity-80" />
                </div>

                {/* Stars */}
                <div className="flex gap-0.5 mb-5">
                  {Array.from({ length: item.stars }).map((_, i) => (
                    <Star
                      key={i}
                      className="h-4 w-4 fill-[hsl(84_74%_60%)] text-[hsl(84_74%_60%)]"
                    />
                  ))}
                </div>

                {/* Quote body */}
                <blockquote className="flex-1 mb-7">
                  <p className="text-sm md:text-base leading-relaxed text-white/85 italic">
                    &ldquo;{item.quote}&rdquo;
                  </p>
                </blockquote>

                {/* Attribution */}
                <footer className="flex items-center gap-4 pt-5 border-t border-white/10">
                  <div className="relative h-11 w-11 shrink-0">
                    <img
                      src={item.image}
                      alt={item.imageAlt}
                      width={44}
                      height={44}
                      className="h-11 w-11 rounded-full object-cover ring-2 ring-white/10"
                      loading="lazy"
                    />
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="text-sm font-semibold text-white leading-tight truncate">
                      {item.author}
                    </p>
                    <p className="text-xs text-white/60 mt-0.5 leading-tight">
                      {item.role},{" "}
                      <span className="text-white/50">{item.company}</span>
                    </p>
                  </div>
                  <div className="shrink-0">
                    <div className="flex h-8 w-8 items-center justify-center rounded-md bg-white/5 border border-white/10">
                      <SectorIcon className="h-4 w-4 text-white/40" />
                    </div>
                  </div>
                </footer>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Closing note */}
        <motion.p
          className="mt-12 text-center text-sm text-white/80 tracking-wide"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.4, ease: "easeOut" }}
        >
          All engagements are handled directly by Gregg — no account managers,
          no handoffs.
        </motion.p>
      </div>
    </section>
  );
});

AISearchTestimonials.displayName = "AISearchTestimonials";

export default AISearchTestimonials;
