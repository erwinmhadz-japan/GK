import React from "react";
import { motion } from "framer-motion";
import { ScanSearch, GitMerge, Layers, Link2, Radar, Search, Section } from "lucide-react";

interface ProcessStep {
  number: string;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  detail: string;
}

const steps: ProcessStep[] = [
  {
    number: "01",
    icon: ScanSearch,
    title: "Entity Audit & Gap Analysis",
    description:
      "I begin by mapping your current entity footprint across the web — assessing how search engines understand your brand, the completeness of your Knowledge Graph profile, and where gaps or ambiguities exist in your entity signals.",
    detail:
      "This audit covers your Knowledge Panel status, Wikipedia and Wikidata presence, author entity signals, existing schema markup, and co-citation patterns across authoritative sources.",
  },
  {
    number: "02",
    icon: GitMerge,
    title: "Knowledge Graph Claim & Consolidation",
    description:
      "Once gaps are identified, I work to establish and consolidate your brand entity within Google's Knowledge Graph. This involves aligning your identity signals across owned and third-party sources so search engines can confidently disambiguate who you are.",
    detail:
      "Disambiguation is often the most critical step — especially for businesses operating in competitive sectors such as law, finance, or healthcare, where brand clarity directly influences trust and visibility.",
  },
  {
    number: "03",
    icon: Layers,
    title: "Schema Markup Implementation",
    description:
      "I implement structured data — including Organisation, Person, LocalBusiness, and SameAs properties — to provide machine-readable entity signals that search engines can parse with confidence.",
    detail:
      "Schema is not a substitute for entity authority; it is a reinforcement layer. I apply it strategically to the pages where entity signals matter most: your homepage, about page, and key service pages.",
  },
  {
    number: "04",
    icon: Link2,
    title: "Off-Site Co-Citation Strategy",
    description:
      "Entity authority is built off-site as much as on-site. I develop a co-citation and co-occurrence strategy to ensure your brand entity is mentioned alongside the right topics, keywords, and authoritative sources across the web.",
    detail:
      "This involves digital PR, editorial placement, and structured mentions in industry publications, directories, and knowledge bases that Google recognises as authoritative within your sector.",
  },
  {
    number: "05",
    icon: Radar,
    title: "Ongoing Entity Monitoring",
    description:
      "Entity SEO is not a one-time task. I monitor your entity health on a continuous basis — tracking Knowledge Panel changes, new co-citations, schema rendering in Search Console, and shifts in how search engines classify and surface your brand.",
    detail:
      "As AI-powered search evolves through Google's Gemini, AI Overviews, and generative engines like ChatGPT and Perplexity, entity authority increasingly determines whether your brand is cited as a trusted source.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.15,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" },
  },
};

const EntitySeoProcess = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="entity-seo-process"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.65, ease: "easeOut" }}
          className="mb-14 md:mb-20"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            My Process
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground max-w-2xl leading-tight">
            How I Approach Entity SEO
          </h2>
          <p className="mt-5 text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
            Entity SEO requires a methodical, layered approach — not a checklist.
            Below is the five-stage process I follow when helping UK businesses
            build semantic authority and establish a clear, trusted entity
            presence in search.
          </p>
        </motion.div>

        {/* Process steps */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="relative"
        >
          {/* Vertical connector line (desktop) */}
          <div
            className="hidden md:block absolute left-[2.25rem] top-10 bottom-10 w-px bg-border"
            aria-hidden="true"
          />

          <div className="flex flex-col gap-0">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isLast = index === steps.length - 1;

              return (
                <motion.div
                  key={step.number}
                  variants={itemVariants}
                  className={`relative flex flex-col md:flex-row gap-6 md:gap-10 ${
                    isLast ? "pb-0" : "pb-10 md:pb-12"
                  }`}
                >
                  {/* Step indicator */}
                  <div className="flex md:flex-col items-center gap-4 md:gap-0 flex-shrink-0">
                    {/* Icon circle */}
                    <div className="relative z-10 flex items-center justify-center w-[4.5rem] h-[4.5rem] rounded-full bg-background border border-border shadow-sm flex-shrink-0">
                      <Icon className="h-6 w-6 text-primary" />
                    </div>
                    {/* Step number — visible on mobile beside icon */}
                    <span className="text-xs font-semibold tracking-[0.15em] text-muted-foreground uppercase md:hidden">
                      Step {step.number}
                    </span>
                  </div>

                  {/* Content card */}
                  <div className="flex-1 bg-background border border-border rounded-md p-6 md:p-8 shadow-sm hover:shadow-md transition-shadow duration-300">
                    {/* Step number — desktop only */}
                    <span className="hidden md:inline-block text-xs font-semibold tracking-[0.15em] text-muted-foreground uppercase mb-3">
                      Step {step.number}
                    </span>

                    <h3 className="text-lg md:text-xl font-semibold text-foreground mb-3 leading-snug">
                      {step.title}
                    </h3>

                    <p className="text-base text-muted-foreground leading-relaxed mb-4">
                      {step.description}
                    </p>

                    {/* Detail note */}
                    <div className="border-l-2 border-primary/40 pl-4">
                      <p className="text-sm text-muted-foreground leading-relaxed italic">
                        {step.detail}
                      </p>
                    </div>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Closing note */}
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.6, ease: "easeOut", delay: 0.2 }}
          className="mt-14 text-sm text-muted-foreground max-w-2xl leading-relaxed"
        >
          Every engagement is tailored to your sector, your existing entity
          signals, and your search visibility goals. I work directly with you
          throughout — no handoffs, no account managers.
        </motion.p>
      </div>
    </section>
  );
});

EntitySeoProcess.displayName = "EntitySeoProcess";

export default EntitySeoProcess;
