import React from "react";
import { Badge } from "@/components/ui/badge";
import { Quote, TrendingUp, Star, Search } from "lucide-react";

const BirminghamTestimonial: React.FC = () => {
  return (
    <section className="relative isolate py-20 md:py-32 border-t border-border bg-muted">
      <div className="container">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left: case study results */}
          <div>
            <Badge variant="secondary" className="mb-4 text-xs uppercase tracking-widest">
              Birmingham Case Study
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-5">
              From Page 4 to Position 1 in Birmingham Search
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-6">
              A professional services firm based in Birmingham's Jewellery Quarter came
              to me with a strong offline reputation but minimal digital visibility. Within
              eight months, their core service pages ranked in position one across
              Birmingham-specific queries, driving a{" "}
              <span className="font-semibold text-foreground">143% increase in organic enquiries</span>.
            </p>

            <div className="grid grid-cols-3 gap-4 mt-8">
              {[
                { value: "143%", label: "More organic leads" },
                { value: "#1", label: "Position in Birmingham" },
                { value: "8 mo", label: "Time to results" },
              ].map((stat) => (
                <div
                  key={stat.label}
                  className="bg-card border border-border rounded-xl p-5 text-center shadow-soft"
                >
                  <div className="text-2xl font-bold text-primary mb-1">{stat.value}</div>
                  <div className="text-xs text-muted-foreground">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Right: testimonial quote */}
          <div className="relative">
            <div className="bg-card border border-border rounded-2xl p-8 shadow-card">
              <div className="flex gap-1 mb-5">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-primary text-primary" />
                ))}
              </div>

              <Quote className="h-8 w-8 text-primary/20 mb-4" />

              <blockquote className="text-foreground text-lg leading-relaxed italic mb-6">
                "We'd worked with two agencies before and seen very little movement.
                Working directly with an independent consultant who actually understood
                Birmingham's market — the specific postcodes, the competitors, the local
                intent — was a completely different experience. Our enquiries from Google
                are now our primary lead source."
              </blockquote>

              <div className="flex items-center gap-4 border-t border-border pt-5">
                <img
                  src="https://images.unsplash.com/photo-1734830268394-6c4a1f165af1?w=400&h=400&fit=crop&crop=face"
                  alt="Smiling male business owner based in Birmingham"
                  width="48"
                  height="48"
                  className="rounded-full object-cover h-12 w-12"
                />
                <div>
                  <div className="font-semibold text-foreground text-sm">James Hartley</div>
                  <div className="text-xs text-muted-foreground">Director, Hartley & Partners — Birmingham</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default BirminghamTestimonial;
