import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, ExternalLink, Sparkles, Search } from "lucide-react";
import { ImageBackground } from "@/components/ImageBackground";

const CopilotVisibilityCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="copilot-visibility-cta"
      src="https://images.unsplash.com/photo-1573496130141-209d200cebd8?w=1920&h=1080&fit=crop"
      alt="Professional consultant at work"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="py-24 md:py-36"
    >
      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="flex items-center justify-center gap-2 mb-6"
          >
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="text-xs uppercase tracking-[0.2em] text-white/80 font-medium">
              Independent UK SEO Consultant
            </span>
          </motion.div>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.1 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-6"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Ready to Improve Your AI Search Visibility?
          </motion.h2>

          {/* Sub-headline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.2 }}
            className="text-lg md:text-xl text-white/85 leading-relaxed mb-10 max-w-2xl mx-auto"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Gregg King helps UK businesses build the authority signals that AI search engines rely on. Start with a free SEO audit.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            {/* Primary CTA */}
            <Button
              size="lg"
              asChild
              className="h-12 px-8 text-sm font-semibold tracking-wide bg-primary text-primary-foreground hover:bg-primary/90 transition-all duration-300 hover:shadow-[0_0_32px_hsl(84_74%_60%/0.4)] rounded-md"
            >
              <Link to="/contact">
                FREE SEO AUDIT
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>

            {/* Secondary CTA */}
            <Button
              size="lg"
              variant="outline"
              asChild
              className="h-12 px-8 text-sm font-medium bg-transparent text-white border-white/40 hover:bg-white/10 hover:border-white/60 transition-all duration-300 rounded-md"
            >
              <Link to="/services-ai-search-optimisation">
                AI Search Optimisation Service
                <ExternalLink className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </motion.div>

          {/* Trust note */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.45 }}
            className="mt-8 text-sm text-white/80"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Based in Warrington, Cheshire — working with UK businesses in competitive sectors.
          </motion.p>
        </div>
      </div>
    </ImageBackground>
  );
});

CopilotVisibilityCTA.displayName = "CopilotVisibilityCTA";

export default CopilotVisibilityCTA;
