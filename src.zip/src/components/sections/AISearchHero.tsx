import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Sparkles, Bot, Globe, Brain, ChevronDown, ChevronRight, Home, Search, View } from "lucide-react";
import { Link } from "react-router-dom";

const platforms = [
  { icon: Bot, label: "ChatGPT" },
  { icon: Globe, label: "Perplexity" },
  { icon: Sparkles, label: "AI Overviews" },
  { icon: Brain, label: "Gemini" },
  { icon: Globe, label: "Copilot" },
];

const AISearchHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="aisearch-hero"
      className="relative py-24 md:py-36 border-t border-border bg-background overflow-hidden"
    >
      {/* Subtle decorative background pattern */}
      <div
        className="absolute inset-0 pointer-events-none"
        aria-hidden="true"
      >
        {/* Faint radial gradient accent */}
        <div
          className="absolute top-0 right-0 w-[600px] h-[600px] rounded-full opacity-[0.06]"
          style={{
            background:
              "radial-gradient(circle, hsl(84 74% 58%) 0%, transparent 70%)",
          }}
        />
        <div
          className="absolute bottom-0 left-0 w-[400px] h-[400px] rounded-full opacity-[0.04]"
          style={{
            background:
              "radial-gradient(circle, hsl(214 40% 22%) 0%, transparent 70%)",
          }}
        />
        {/* Subtle grid lines */}
        <svg
          className="absolute inset-0 w-full h-full"
          xmlns="http://www.w3.org/2000/svg"
        >
          <defs>
            <pattern
              id="grid-aisearch"
              x="0"
              y="0"
              width="48"
              height="48"
              patternUnits="userSpaceOnUse"
            >
              <path
                d="M 48 0 L 0 0 0 48"
                fill="none"
                stroke="hsl(220 16% 88%)"
                strokeWidth="0.5"
                opacity="0.5"
              />
            </pattern>
          </defs>
          <rect width="100%" height="100%" fill="url(#grid-aisearch)" />
        </svg>
      </div>

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        {/* Breadcrumb */}
        <nav aria-label="Breadcrumb" className="mb-8">
          <ol className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <li>
              <Link to="/" className="hover:text-foreground transition-colors duration-200">
                Home
              </Link>
            </li>
            <li aria-hidden="true">
              <ChevronRight className="h-3 w-3" />
            </li>
            <li aria-current="page" className="text-foreground font-medium">
              AI Search
            </li>
          </ol>
        </nav>

        <div className="max-w-3xl">
          {/* Eyebrow label */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            <Badge
              variant="outline"
              className="mb-6 text-xs uppercase tracking-widest font-medium border-border text-muted-foreground px-3 py-1"
            >
              <Sparkles className="h-3 w-3 mr-1.5 text-primary" />
              AI Search Hub
            </Badge>
          </motion.div>

          {/* Main headline */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight tracking-tight font-[Sora,sans-serif]"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            AI Search Visibility{" "}
            <span
              className="inline-block"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              Explained
            </span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.2 }}
            className="mt-6 text-lg md:text-xl text-muted-foreground leading-relaxed max-w-2xl"
          >
            How ChatGPT, Perplexity, Google AI Overviews, Gemini, and Copilot
            surface answers — and what it means for your organic presence.
          </motion.p>

          {/* Platform chips */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
            className="mt-8 flex flex-wrap gap-2"
          >
            {platforms.map((platform, i) => {
              const Icon = platform.icon;
              return (
                <span
                  key={platform.label}
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md border border-border bg-background text-xs font-medium text-foreground shadow-sm"
                  style={{
                    animationDelay: `${0.35 + i * 0.05}s`,
                  }}
                >
                  <Icon className="h-3.5 w-3.5 text-primary" />
                  {platform.label}
                </span>
              );
            })}
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.4 }}
            className="mt-10 flex flex-col sm:flex-row gap-3 items-start"
          >
            <Button
              size="lg"
              className="h-11 px-8 text-sm font-semibold"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                color: "hsl(222 42% 8%)",
                border: "none",
              }}
              asChild
            >
              <a href="#aisearch-hub-index">
                Explore AI Search
                <ChevronDown className="ml-2 h-4 w-4" />
              </a>
            </Button>

            <Button
              size="lg"
              variant="outline"
              className="h-11 px-8 text-sm font-medium border-border text-foreground hover:bg-muted"
              asChild
            >
              <a href="/ai-search-optimisation">
                View AI Search Optimisation Service
              </a>
            </Button>
          </motion.div>

          {/* Informational note */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.55 }}
            className="mt-5 text-xs text-muted-foreground"
          >
            This is an informational guide. For commercial AI search
            optimisation,{" "}
            <a
              href="/ai-search-optimisation"
              className="underline underline-offset-2 hover:text-foreground transition-colors"
            >
              explore the service page
            </a>
            .
          </motion.p>
        </div>

        {/* Decorative right-side panel */}
        <motion.div
          initial={{ opacity: 0, x: 32 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8, ease: "easeOut", delay: 0.3 }}
          className="hidden lg:block absolute right-0 top-1/2 -translate-y-1/2 w-80 xl:w-96"
          aria-hidden="true"
        >
          <div
            className="relative rounded-xl border border-border p-6 shadow-md"
            style={{
              background:
                "linear-gradient(160deg, hsl(222 42% 8%) 0%, hsl(222 35% 18%) 60%, hsl(214 40% 22%) 100%)",
            }}
          >
            {/* Header row */}
            <div className="flex items-center gap-2 mb-5">
              <div className="h-2 w-2 rounded-full bg-green-400" />
              <span className="text-xs text-white/60 font-mono">
                ai-search-landscape.md
              </span>
            </div>

            {/* Mock content rows */}
            {[
              { label: "ChatGPT", detail: "Conversational AI answers" },
              { label: "Perplexity", detail: "Real-time source citations" },
              { label: "AI Overviews", detail: "Google SERP summaries" },
              { label: "Gemini", detail: "Google's generative AI" },
              { label: "Copilot", detail: "Microsoft AI integration" },
            ].map((item, i) => (
              <motion.div
                key={item.label}
                initial={{ opacity: 0, x: 12 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{
                  duration: 0.4,
                  ease: "easeOut",
                  delay: 0.5 + i * 0.08,
                }}
                className="flex items-center justify-between py-2.5 border-b border-white/10 last:border-0"
              >
                <div className="flex items-center gap-2.5">
                  <div
                    className="h-1.5 w-1.5 rounded-full flex-shrink-0"
                    style={{
                      background:
                        "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                    }}
                  />
                  <span className="text-sm font-medium text-white/90">
                    {item.label}
                  </span>
                </div>
                <span className="text-xs text-white/50">{item.detail}</span>
              </motion.div>
            ))}

            {/* Bottom note */}
            <p className="mt-4 text-xs text-white/40 font-mono leading-relaxed">
              # Informational guide — last updated 2025
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
});

AISearchHero.displayName = "AISearchHero";

export default AISearchHero;
