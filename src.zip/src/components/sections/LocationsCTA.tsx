import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, MapPin, CheckCircle, View } from "lucide-react";

const cities = [
  { label: "Warrington", slug: "/locations-warrington" },
  { label: "Manchester",  slug: "/locations-manchester" },
  { label: "Liverpool",   slug: "/locations-liverpool" },
  { label: "Birmingham",  slug: "/locations-birmingham" },
  { label: "Leeds",       slug: "/locations-leeds" },
  { label: "Sheffield",   slug: "/locations-sheffield" },
  { label: "London",      slug: "/locations-london" },
];

const LocationsCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="locations-cta"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut" }}
            className="flex items-center justify-center gap-2 mb-6"
          >
            <MapPin className="h-4 w-4 text-primary" aria-hidden="true" />
            <span className="text-xs uppercase tracking-[0.18em] text-muted-foreground font-medium">
              Serving businesses across the UK
            </span>
          </motion.div>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.08 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground tracking-tight leading-tight mb-5"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Work with an SEO Consultant Who{" "}
            <span className="text-primary">Knows Your Market</span>
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.16 }}
            className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-8 max-w-2xl mx-auto"
          >
            Whether you're based in Manchester, London, or anywhere in between
            — get in touch for a free SEO audit.
          </motion.p>

          {/* City pills */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.24 }}
            className="flex flex-wrap justify-center gap-2 mb-10"
            aria-label="Cities served"
          >
            {cities.map((city, index) => (
              <Link
                key={city.label}
                to={city.slug}
                className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-md bg-background border border-border text-sm text-foreground hover:border-primary/50 hover:text-primary transition-colors duration-200"
                style={{ animationDelay: `${0.28 + index * 0.05}s` }}
              >
                <CheckCircle
                  className="h-3.5 w-3.5 text-primary flex-shrink-0"
                  aria-hidden="true"
                />
                {city.label}
              </Link>
            ))}
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.32 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Button
              size="lg"
              className="h-12 px-8 text-base font-semibold bg-primary text-primary-foreground hover:bg-primary/90 shadow-md transition-all duration-200 hover:shadow-lg group"
              asChild
            >
              <Link to="/contact">
                Get a Free SEO Audit
                <ArrowRight
                  className="ml-2 h-4 w-4 group-hover:translate-x-0.5 transition-transform duration-200"
                  aria-hidden="true"
                />
              </Link>
            </Button>

            <Button
              size="lg"
              variant="outline"
              className="h-12 px-8 text-base font-medium border-border bg-background text-foreground hover:bg-accent hover:text-accent-foreground transition-colors duration-200"
              asChild
            >
              <Link to="/locations">View All Locations</Link>
            </Button>
          </motion.div>

          {/* Reassurance line */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: "easeOut", delay: 0.44 }}
            className="mt-6 text-sm text-muted-foreground"
          >
            Independent UK SEO consultant — no agency overhead, no junior
            handoffs.
          </motion.p>
        </div>
      </div>
    </section>
  );
});

LocationsCTA.displayName = "LocationsCTA";

export default LocationsCTA;
