import React from "react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { UserCheck, GitBranch, Layers, Globe, MessageSquare, Search, ShieldCheck, Zap, Contact, Scale, Section } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (delay: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut", delay },
  }),
};

const differentiators = [
  {
    icon: UserCheck,
    title: "Single Point of Contact",
    body: "You work directly with me — the consultant doing the work. No account managers, no handoffs, no communication overhead. Every decision and deliverable comes from one experienced specialist.",
  },
  {
    icon: MessageSquare,
    title: "Direct Access to the Expert",
    body: "Agency technical teams bury the expert behind layers of account management. With me, you have my direct number, direct email, and a straight line to the person who understands your site architecture.",
  },
  {
    icon: GitBranch,
    title: "Deep Specialism in Crawl & Architecture",
    body: "My technical SEO practice is built around crawl budget optimisation, log file analysis, and entity-based site architecture — disciplines that require sustained focus, not a junior resource spread across a client roster.",
  },
  {
    icon: Layers,
    title: "Structured Data at Scale",
    body: "I design and implement schema markup strategies that support entity disambiguation, knowledge graph eligibility, and AI search citation — not just checkbox compliance for automated audit tools.",
  },
  {
    icon: Globe,
    title: "National UK Reach",
    body: "I work with businesses across the UK from my base in Warrington, Cheshire. Remote-first and highly responsive — geography is not a constraint on the quality or depth of engagement.",
  },
  {
    icon: Search,
    title: "No Retainer Mill Mentality",
    body: "Independent practice means I take on a deliberate number of engagements, not a volume target. Your technical SEO audit gets my full attention — not a templated output produced under time pressure.",
  },
];

const trustSignals = [
  {
    icon: ShieldCheck,
    label: "Independent specialist — not a team of generalists",
  },
  {
    icon: Zap,
    label: "Fixes briefed directly to your development team",
  },
  {
    icon: UserCheck,
    label: "Senior-level expertise on every engagement",
  },
];

const TechnicalSEOWhyGregg = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="technical-seowhy-gregg"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          {/* Left: editorial prose block */}
          <div>
            <motion.span
              className="inline-block text-xs uppercase tracking-[0.2em] font-medium mb-4"
              style={{ color: "hsl(214 32% 60%)" }}
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              custom={0}
            >
              Why independent matters
            </motion.span>

            <motion.h2
              className="text-3xl md:text-4xl lg:text-[2.625rem] font-bold text-foreground leading-[1.15] tracking-tight max-w-xl"
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              custom={0.08}
            >
              Why Hire an Independent Technical SEO Specialist
            </motion.h2>

            <motion.p
              className="mt-6 text-base md:text-lg text-muted-foreground leading-relaxed max-w-prose"
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              custom={0.16}
            >
              Agency technical SEO teams are structured around throughput.
              Engagements are staffed with junior resource, managed by account
              handlers, and measured against billable hours — not your rankings.
              As an independent technical SEO consultant, I operate differently.
            </motion.p>

            <motion.p
              className="mt-4 text-base md:text-lg text-muted-foreground leading-relaxed max-w-prose"
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              custom={0.22}
            >
              Every engagement I take on is handled exclusively by me. I audit
              the site, I write the brief, I review implementation, and I
              validate the fixes. There is no relay race between specialists —
              only a direct, senior-level technical review that moves at the
              pace your business requires.
            </motion.p>

            {/* Trust signals */}
            <motion.div
              className="mt-8 space-y-3"
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              custom={0.28}
            >
              {trustSignals.map((item) => {
                const Icon = item.icon;
                return (
                  <div
                    key={item.label}
                    className="flex items-center gap-3"
                  >
                    <div
                      className="flex-shrink-0 flex h-7 w-7 items-center justify-center rounded-md"
                      style={{ backgroundColor: "hsl(119 35% 61% / 0.14)" }}
                    >
                      <Icon
                        className="h-4 w-4"
                        style={{ color: "hsl(119 35% 61%)" }}
                      />
                    </div>
                    <span className="text-sm text-foreground font-medium">
                      {item.label}
                    </span>
                  </div>
                );
              })}
            </motion.div>

            {/* Location badge */}
            <motion.div
              className="mt-8"
              variants={fadeUp}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true }}
              custom={0.34}
            >
              <Badge
                variant="outline"
                className="text-xs font-medium border-border"
                style={{ color: "hsl(214 32% 60%)" }}
              >
                Independent SEO Consultant — Warrington, Cheshire · National UK
                reach
              </Badge>
            </motion.div>
          </div>

          {/* Right: differentiator grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {differentiators.map((item, i) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.title}
                  className="group relative flex flex-col gap-3 rounded-md border border-border bg-card p-5 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:border-border hover:shadow-md"
                  variants={fadeUp}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  custom={0.1 + i * 0.07}
                >
                  {/* Icon */}
                  <div
                    className="flex h-9 w-9 items-center justify-center rounded-md"
                    style={{ backgroundColor: "hsl(214 32% 60% / 0.10)" }}
                  >
                    <Icon
                      className="h-4 w-4"
                      style={{ color: "hsl(214 32% 60%)" }}
                    />
                  </div>

                  {/* Title */}
                  <h3 className="text-sm font-semibold text-foreground leading-snug">
                    {item.title}
                  </h3>

                  {/* Body */}
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {item.body}
                  </p>

                  {/* Subtle left accent */}
                  <div
                    className="pointer-events-none absolute left-0 top-4 bottom-4 w-[2px] rounded-full opacity-0 transition-opacity duration-300 group-hover:opacity-100"
                    style={{
                      background:
                        "linear-gradient(180deg, hsl(84 74% 60%), hsl(119 35% 61%))",
                    }}
                  />
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Bottom editorial note */}
        <motion.div
          className="mt-16 md:mt-20 border-t border-border pt-10"
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          custom={0.1}
        >
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {[
              {
                label: "Crawl budget & indexation",
                detail:
                  "Precise analysis of how search engines spend their crawl budget — and how to ensure your priority pages are discovered and indexed.",
              },
              {
                label: "Entity-based architecture",
                detail:
                  "Site structure designed around topical authority, entity disambiguation, and knowledge graph eligibility — not legacy siloing.",
              },
              {
                label: "Structured data strategy",
                detail:
                  "Schema markup planned for business type, sector, and AI search citation — integrated into broader entity SEO, not applied as an afterthought.",
              },
            ].map((item, i) => (
              <motion.div
                key={item.label}
                className="flex flex-col gap-2"
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                custom={0.12 + i * 0.08}
              >
                <span
                  className="text-xs uppercase tracking-[0.18em] font-semibold"
                  style={{ color: "hsl(214 32% 60%)" }}
                >
                  {item.label}
                </span>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {item.detail}
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
});

TechnicalSEOWhyGregg.displayName = "TechnicalSEOWhyGregg";

export default TechnicalSEOWhyGregg;
