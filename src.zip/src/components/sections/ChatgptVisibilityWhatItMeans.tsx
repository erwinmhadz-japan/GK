import React from "react";
import { motion } from "framer-motion";
import { Bot, Search, Globe, Eye, Database, Network, CheckCircle, Lightbulb, Building, Key, Section } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (delay: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut", delay },
  }),
};

const concepts = [
  {
    icon: Search,
    title: "How ChatGPT retrieves information",
    body: "ChatGPT does not crawl the web in real time like Google. Instead, it draws on knowledge embedded during training — supplemented, in newer versions, by live retrieval from select indexed sources. A business's visibility depends on whether its information exists in sources that ChatGPT was trained on, or that its retrieval layer can access and trust.",
  },
  {
    icon: Globe,
    title: "Why some businesses appear and others do not",
    body: "ChatGPT favours entities it can confidently identify and describe. If your business lacks a clear, consistent presence across authoritative sources — Wikipedia, industry directories, high-authority press mentions, structured data on your own site — the model has little basis to surface you. Businesses with strong entity clarity and third-party corroboration appear; those without typically do not.",
  },
  {
    icon: Database,
    title: "The role of entity data",
    body: "An \"entity\" in SEO terms is a clearly defined, uniquely identifiable thing — a business, a person, a service, a location. ChatGPT relies on entity data to understand who you are, what you do, and where you operate. Consistent NAP data (name, address, phone), schema markup, and cross-platform brand signals all help establish that entity identity in a way AI models can recognise and trust.",
  },
  {
    icon: Network,
    title: "Authoritative citation signals",
    body: "When credible publications, professional bodies, or established directories mention your business by name, they act as corroborating signals. ChatGPT's outputs tend to reflect the consensus of sources it considers authoritative. A business that appears consistently across trusted domains is far more likely to be included in AI-generated answers than one that exists only on its own website.",
  },
  {
    icon: Eye,
    title: "Content clarity and topical relevance",
    body: "ChatGPT surfaces information when it can clearly understand what a business does and for whom. Vague, jargon-heavy, or poorly structured content makes that difficult. Clear, well-organised pages — written for a specific audience, covering specific topics — give the model usable information to reference when a relevant query is asked.",
  },
  {
    icon: Bot,
    title: "Retrieval-augmented generation (RAG)",
    body: "Some ChatGPT deployments use retrieval-augmented generation — pulling live content from the web to supplement the model's training knowledge. In these contexts, the same principles that drive organic search visibility become relevant: clear content structure, authoritative backlinks, and fast, accessible pages. The gap between traditional SEO and AI visibility is narrower than many assume.",
  },
];

const signals = [
  "Consistent brand name across all platforms and directories",
  "Structured data (schema markup) on your website",
  "Third-party mentions in credible publications",
  "Wikipedia or Wikidata presence (where applicable)",
  "Clear, unambiguous descriptions of your services and location",
  "High-authority backlink profile from relevant sources",
];

const ChatgptVisibilityWhatItMeans = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="chatgpt-visibility-what-it-means"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          className="max-w-3xl mb-14 md:mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
        >
          <motion.span
            custom={0}
            variants={fadeUp}
            className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4"
          >
            Understanding AI visibility
          </motion.span>
          <motion.h2
            custom={0.1}
            variants={fadeUp}
            className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground leading-snug max-w-2xl"
          >
            What ChatGPT visibility actually means
          </motion.h2>
          <motion.p
            custom={0.2}
            variants={fadeUp}
            className="mt-5 text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed"
          >
            ChatGPT does not rank websites. It does not run searches. It generates answers — and those answers draw on a specific, learnable set of signals. Understanding those signals is the first step toward doing something about them.
          </motion.p>
        </motion.div>

        {/* Core explainer prose block */}
        <motion.div
          className="grid md:grid-cols-2 gap-8 md:gap-10 mb-16 md:mb-24"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
        >
          {concepts.map((item, i) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.title}
                custom={i * 0.08}
                variants={fadeUp}
                className="flex gap-5 p-6 rounded-md border border-border bg-card shadow-sm hover:shadow-md transition-shadow duration-300"
              >
                <div className="shrink-0 mt-0.5">
                  <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                </div>
                <div>
                  <h3 className="text-base font-semibold text-foreground mb-2 leading-snug">
                    {item.title}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {item.body}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Key signals summary strip */}
        <motion.div
          className="rounded-md border border-border bg-muted/40 px-6 py-8 md:px-10 md:py-10"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
        >
          <div className="flex items-start gap-4 mb-6">
            <div className="shrink-0">
              <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10">
                <Lightbulb className="h-5 w-5 text-primary" />
              </div>
            </div>
            <div>
              <motion.h3
                custom={0}
                variants={fadeUp}
                className="text-base md:text-lg font-semibold text-foreground leading-snug"
              >
                The signals that influence whether ChatGPT mentions your business
              </motion.h3>
              <motion.p
                custom={0.08}
                variants={fadeUp}
                className="mt-1 text-sm text-muted-foreground leading-relaxed max-w-2xl"
              >
                These are not ranking factors in the traditional sense — they are trust and entity signals that help an AI model understand, corroborate, and confidently surface your business.
              </motion.p>
            </div>
          </div>

          <ul className="grid sm:grid-cols-2 gap-3">
            {signals.map((signal, i) => (
              <motion.li
                key={signal}
                custom={0.1 + i * 0.07}
                variants={fadeUp}
                className="flex items-start gap-3 text-sm text-foreground"
              >
                <CheckCircle className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                <span>{signal}</span>
              </motion.li>
            ))}
          </ul>
        </motion.div>

        {/* Closing context note */}
        <motion.p
          className="mt-10 text-sm text-muted-foreground max-w-2xl leading-relaxed"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          custom={0}
          variants={fadeUp}
        >
          ChatGPT visibility is not a separate discipline from SEO — it is an extension of it. The businesses that tend to appear in AI-generated answers are, almost without exception, the ones that have built strong entity authority and a credible digital footprint over time. Building that foundation is what I work on with clients.
        </motion.p>

      </div>
    </section>
  );
});

ChatgptVisibilityWhatItMeans.displayName = "ChatgptVisibilityWhatItMeans";

export default ChatgptVisibilityWhatItMeans;
