import React from "react";
import { motion } from "framer-motion";
import { TrendingUp, User, Repeat2, LineChart, Section } from "lucide-react";
import { Link } from "react-router-dom";

const SeoRetainerOverview = React.forwardRef<HTMLElement>((props, ref) => {
  const pillars = [
    {
      icon: User,
      title: "Direct consultant accountability",
      body: "Every aspect of the retainer is managed by Gregg King personally. There are no account managers, no handoffs to junior staff, and no diluted attention. The person you brief is the person doing the work.",
    },
    {
      icon: TrendingUp,
      title: "Strategy and execution in one engagement",
      body: "An SEO retainer with Gregg King combines strategic direction with practical delivery — covering technical oversight, content planning, link acquisition, and performance analysis within a single, coherent engagement.",
    },
    {
      icon: Repeat2,
      title: "Continuity over campaigns",
      body: "Effective SEO compounds over time. A retainer provides the consistency required to build topical authority, resolve technical debt progressively, and respond to algorithmic shifts — without restarting from scratch each month.",
    },
    {
      icon: LineChart,
      title: "Transparent, structured reporting",
      body: "Monthly reporting covers rankings, organic traffic, indexation health, and work completed — presented clearly, without vanity metrics. You always know what has been done and why.",
    },
  ];

  const containerVariants = {
    hidden: {},
    visible: {
      transition: {
        staggerChildren: 0.12,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 24 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.6, ease: "easeOut" },
    },
  };

  return (
    <section
      ref={ref}
      id="seo-retainer-overview"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="max-w-3xl mb-14 md:mb-20"
        >
          <span className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium">
            What a retainer means
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground font-[Sora,sans-serif] leading-tight mb-6">
            Ongoing SEO delivered by a single consultant — not an agency on rotation
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl">
            An SEO retainer with Gregg King is a structured, ongoing engagement — not a rolling contract that quietly bills for activity with little accountability. It is a commitment to sustained organic growth through consistent strategy, senior-level execution, and clear reporting, month after month.
          </p>
        </motion.div>

        {/* Dividing line — editorial detail */}
        <div className="w-12 h-px bg-primary mb-14 md:mb-20" aria-hidden="true" />

        {/* Distinguishing from agency retainers — editorial prose block */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
          className="grid md:grid-cols-2 gap-8 md:gap-16 mb-16 md:mb-24"
        >
          <div>
            <h3 className="text-lg md:text-xl font-semibold text-foreground mb-4 font-[Sora,sans-serif]">
              What distinguishes this from an agency retainer
            </h3>
            <p className="text-muted-foreground text-base leading-relaxed">
              Agency retainers typically involve a commercial account manager coordinating work across multiple specialists — with no guarantee that senior expertise is applied consistently to your account. Priorities shift. Staff change. Strategic direction can drift between reporting cycles.
            </p>
          </div>
          <div>
            <h3 className="text-lg md:text-xl font-semibold text-foreground mb-4 font-[Sora,sans-serif]">
              A consultant-led model built around your objectives
            </h3>
            <p className="text-muted-foreground text-base leading-relaxed">
              With Gregg King, the retainer is structured around your specific commercial objectives. Work is prioritised by impact, not by what is easiest to bill. Strategy is informed by the same person who monitors your performance data — eliminating the gap between analysis and action that agency structures inevitably create.
            </p>
          </div>
        </motion.div>

        {/* Four pillars */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8"
        >
          {pillars.map((pillar) => {
            const Icon = pillar.icon;
            return (
              <motion.div
                key={pillar.title}
                variants={itemVariants}
                className="group relative rounded-md border border-border bg-background p-7 md:p-8 hover:border-primary/40 hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%_/_0.10),_0_1px_4px_hsl(222_28%_11%_/_0.05)] transition-all duration-300"
              >
                {/* Icon */}
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mb-5">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                {/* Title */}
                <h4 className="text-base md:text-lg font-semibold text-foreground mb-3 font-[Sora,sans-serif] leading-snug">
                  {pillar.title}
                </h4>
                {/* Body */}
                <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                  {pillar.body}
                </p>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Closing note — positioned consultancy context */}
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
          className="mt-14 md:mt-16 max-w-2xl text-sm text-muted-foreground leading-relaxed border-t border-border pt-8"
        >
          Gregg King is an independent SEO consultant based in Warrington, Cheshire. Retainer clients receive senior-level attention on every engagement — whether they are{" "}
          <Link to="#law-firms-cta" className="text-foreground underline underline-offset-2 hover:text-primary transition-colors">law firms in Manchester</Link>,{" "}
          <Link to="#healthcare-cta" className="text-foreground underline underline-offset-2 hover:text-primary transition-colors">private healthcare providers in Liverpool</Link>, or professional services businesses operating nationally.
        </motion.p>

        {/* Related services — internal linking */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: "easeOut", delay: 0.2 }}
          className="mt-8 pt-6 border-t border-border"
        >
          <p className="text-xs uppercase tracking-[0.16em] text-muted-foreground mb-4 font-medium">Related services</p>
          <div className="flex flex-wrap gap-3">
            {[
              { label: "SEO Consulting", to: "#seo-consulting-cta" },
              { label: "SEO Audit", to: "/seo-audit" },
              { label: "Technical SEO", to: "/technical-seo" },
              { label: "Content Strategy", to: "/content-strategy" },
              { label: "All Services", to: "/services" },
            ].map(({ label, to }) => (
              <Link
                key={to}
                to={to}
                className="inline-flex items-center gap-1.5 text-xs text-muted-foreground border border-border rounded-md px-3 py-1.5 hover:border-primary/40 hover:text-foreground transition-colors"
              >
                {label}
              </Link>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
});

SeoRetainerOverview.displayName = "SeoRetainerOverview";

export default SeoRetainerOverview;
