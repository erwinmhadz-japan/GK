import React from "react";
import { CheckCircle, ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";

const solutions = [
  {
    label: "Entity SEO for Financial Authority",
    href: "/entity-seo",
    headline: "Make Google Recognise You as a Financial Authority",
    body: "Entity SEO builds a structured knowledge graph around your brand — connecting your services, credentials, advisers and published content into a coherent entity Google can understand and trust. For financial services firms, this means appearing in AI-generated answers, knowledge panels and authoritative search features that drive brand awareness before a user even clicks.",
    points: [
      "Brand entity optimisation across Google's knowledge graph",
      "Adviser and author credentialing for E-E-A-T signals",
      "Structured data markup for financial service entities",
      "Co-citation strategy across trusted financial publications",
    ],
  },
  {
    label: "Schema Markup for Financial Services",
    href: "/schema-markup",
    headline: "Schema Markup That Signals Financial Credibility",
    body: "Implementing the correct schema vocabulary for financial services — FinancialProduct, LoanOrCredit, InvestmentOrDeposit, InsuranceAgency — tells search engines precisely what your offerings are, enabling rich results and higher click-through rates. Combined with FAQPage and HowTo schema, you capture featured-snippet placements that build brand trust at the zero-click stage.",
    points: [
      "FinancialProduct and FinancialService schema implementation",
      "FAQPage schema for compliance-ready answer boxes",
      "LocalBusiness schema for branch and adviser pages",
      "Review and rating schema to surface trust signals in SERPs",
    ],
  },
  {
    label: "Compliant Content Strategy",
    href: "/content-strategy",
    headline: "Content Strategy Built for Compliance and Rankings",
    body: "Financial content must satisfy two masters: compliance teams and search algorithms. Our content strategy for financial services firms maps the full client journey — from awareness queries to comparison searches to high-intent product searches — and creates a compliant content architecture that ranks sustainably without regulatory exposure.",
    points: [
      "Keyword research aligned with financial buyer journeys",
      "Compliant content briefs reviewed against FCA guidelines",
      "Expert-authored articles and money pages for E-E-A-T",
      "Topical authority clusters around core product areas",
    ],
  },
];

const FinancialServicesSolutions = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="financial-seo-solutions"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        <div className="max-w-2xl mx-auto text-center mb-16">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            Our Approach
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            SEO Solutions Designed for Financial Services
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Three core strategies that address the specific search challenges of financial services firms —
            from building Google's trust in your brand to driving measurable lead quality improvements.
          </p>
        </div>

        <div className="space-y-16">
          {solutions.map((solution, index) => (
            <div
              key={index}
              className={`grid grid-cols-1 lg:grid-cols-2 gap-10 items-center ${
                index % 2 === 1 ? "lg:grid-flow-col-dense" : ""
              }`}
            >
              {/* Content side */}
              <div className={index % 2 === 1 ? "lg:col-start-2" : ""}>
                <span className="inline-block text-xs uppercase tracking-[0.18em] text-primary font-semibold mb-3">
                  {solution.label}
                </span>
                <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-4 leading-snug">
                  {solution.headline}
                </h3>
                <p className="text-muted-foreground leading-relaxed mb-6">
                  {solution.body}
                </p>
                <ul className="space-y-3 mb-8">
                  {solution.points.map((point, i) => (
                    <li key={i} className="flex items-start gap-3">
                      <CheckCircle className="h-5 w-5 text-primary mt-0.5 shrink-0" />
                      <span className="text-foreground text-sm leading-relaxed">{point}</span>
                    </li>
                  ))}
                </ul>
                <Button variant="outline" className="group" asChild>
                  <a href={solution.href}>
                    Learn More
                    <ArrowRight className="ml-2 h-4 w-4 transition-transform group-hover:translate-x-1" />
                  </a>
                </Button>
              </div>

              {/* Visual side */}
              <div className={`relative ${index % 2 === 1 ? "lg:col-start-1" : ""}`}>
                <div className="rounded-xl overflow-hidden shadow-card aspect-[4/3]">
                  <img
                    src={
                      index === 0
                        ? "https://images.unsplash.com/photo-1633537065982-ef16506d42b8?w=800&h=600&fit=crop"
                        : index === 1
                        ? "https://images.unsplash.com/photo-1571120245989-c2878f4c89b9?w=800&h=600&fit=crop"
                        : "https://images.unsplash.com/photo-1568649704650-a6ab20e84311?w=800&h=600&fit=crop"
                    }
                    alt={
                      index === 0
                        ? "Modern financial district with tall glass buildings"
                        : index === 1
                        ? "Contemporary office space with large windows for financial team"
                        : "Business professionals walking near financial buildings"
                    }
                    width="800"
                    height="600"
                    loading="lazy"
                    className="w-full h-full object-cover"
                  />
                </div>
                {/* Stat badge */}
                <div className="absolute -bottom-4 -right-4 bg-card border border-border rounded-xl p-4 shadow-card">
                  <p className="text-2xl font-bold text-primary">
                    {index === 0 ? "3.2×" : index === 1 ? "+47%" : "68%"}
                  </p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {index === 0
                      ? "avg. authority lift"
                      : index === 1
                      ? "more rich results"
                      : "lower cost per lead"}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
});

FinancialServicesSolutions.displayName = "FinancialServicesSolutions";

export default FinancialServicesSolutions;
