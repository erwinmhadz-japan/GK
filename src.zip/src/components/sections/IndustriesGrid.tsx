import React from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Gavel, Stethoscope, Home, BarChart2, Briefcase, Image, Search, Section } from "lucide-react";

const industries = [
  {
    icon: Gavel,
    label: "Legal",
    title: "Law Firms",
    slug: "/industries/law-firms",
    description:
      "SEO for solicitors, barristers, and law firms competing for high-value clients. From personal injury and conveyancing to commercial law, I build search authority in the competitive legal sector with compliance-conscious content that converts.",
    services: ["Local SEO for solicitors", "Legal content strategy", "Entity SEO", "Google AI Overviews"],
    img: "https://images.unsplash.com/photo-1573496130141-209d200cebd8?w=800&h=600&fit=crop",
    imgAlt: "Legal professionals in a boardroom",
  },
  {
    icon: Stethoscope,
    label: "Healthcare",
    title: "Healthcare Providers",
    slug: "/industries/healthcare",
    description:
      "Search visibility for clinics, private practices, dental surgeries, and specialist healthcare providers. I understand YMYL sensitivities and craft E-E-A-T-rich content that earns trust from patients and search engines alike.",
    services: ["Medical SEO", "Local search for clinics", "Patient-focused content", "Reputation management SEO"],
    img: "https://images.unsplash.com/photo-1758691461916-dc7894eb8f94?w=800&h=600&fit=crop",
    imgAlt: "Doctor wearing a stethoscope at his desk",
  },
  {
    icon: Home,
    label: "Property",
    title: "Estate Agents",
    slug: "/industries/estate-agents",
    description:
      "Property search is hyper-local and fiercely competitive. I help independent estate agents and national agencies dominate local search results, Google Maps, and AI-generated property answers across every target location.",
    services: ["Local SEO for estate agents", "Schema markup", "Google Business Profile", "AI search visibility"],
    img: "https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?w=800&h=600&fit=crop",
    imgAlt: "Modern property office with laptop and documents",
  },
  {
    icon: BarChart2,
    label: "Finance",
    title: "Financial Services",
    slug: "/industries/financial-services",
    description:
      "SEO for IFAs, accountants, mortgage brokers, and fintech companies. I navigate FCA compliance sensitivities to build sustainable organic growth, improve domain authority, and position your firm as the trusted expert search engines recommend.",
    services: ["Financial content SEO", "Technical SEO audits", "Digital PR", "Entity & authority building"],
    img: "https://images.unsplash.com/photo-1571677246347-5040036b95cc?w=800&h=600&fit=crop",
    imgAlt: "MacBook Pro showing financial data and analytics",
  },
  {
    icon: Briefcase,
    label: "B2B",
    title: "B2B Professional Services",
    slug: "/industries/b2b-professional-services",
    description:
      "Long sales cycles and complex buying committees require an SEO strategy built for consideration-stage content. I help consultancies, agencies, and professional service firms attract qualified decision-makers through intelligent organic search.",
    services: ["B2B content strategy", "Thought leadership SEO", "AI search optimisation", "Case study visibility"],
    img: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=800&h=600&fit=crop",
    imgAlt: "Business team collaborating with laptops in a modern office",
  },
];

const IndustriesGrid = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-2xl mb-14 md:mb-20">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-3">
            Industry Verticals
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground">
            Specialist SEO for Every Professional Sector
          </h2>
          <p className="mt-4 text-lg text-muted-foreground leading-relaxed">
            Each industry has distinct search behaviours, regulatory constraints, and
            competitive landscapes. Choose your sector to explore a tailored approach.
          </p>
        </div>

        {/* Industry cards */}
        <div className="grid grid-cols-1 gap-8">
          {industries.map((industry, idx) => {
            const Icon = industry.icon;
            const isEven = idx % 2 === 0;
            return (
              <div
                key={industry.slug}
                className={`group flex flex-col md:flex-row ${isEven ? "" : "md:flex-row-reverse"} gap-0 rounded-2xl overflow-hidden border border-border bg-card shadow-card hover:shadow-card-hover transition-shadow duration-300`}
              >
                {/* Image */}
                <div className="md:w-2/5 relative overflow-hidden min-h-[220px] md:min-h-0">
                  <img
                    src={industry.img}
                    alt={industry.imgAlt}
                    width={800}
                    height={600}
                    loading="lazy"
                    className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 to-transparent pointer-events-none" />
                  <Badge className="absolute top-4 left-4 bg-primary text-primary-foreground font-semibold text-xs uppercase tracking-wider px-3 py-1">
                    {industry.label}
                  </Badge>
                </div>

                {/* Content */}
                <div className="md:w-3/5 p-8 md:p-10 flex flex-col justify-center">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 shrink-0">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <h3 className="text-2xl md:text-3xl font-bold text-foreground">
                      {industry.title}
                    </h3>
                  </div>

                  <p className="text-muted-foreground leading-relaxed mb-6">
                    {industry.description}
                  </p>

                  <ul className="grid grid-cols-2 gap-2 mb-8">
                    {industry.services.map((svc) => (
                      <li key={svc} className="flex items-center gap-2 text-sm text-muted-foreground">
                        <span className="h-1.5 w-1.5 rounded-full bg-primary shrink-0" />
                        {svc}
                      </li>
                    ))}
                  </ul>

                  <Button
                    className="self-start bg-gradient-cta text-foreground font-semibold hover:opacity-90 transition-opacity"
                    asChild
                  >
                    <a href={industry.slug}>
                      Learn More
                      <ArrowRight className="ml-2 h-4 w-4" />
                    </a>
                  </Button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
});

IndustriesGrid.displayName = "IndustriesGrid";

export default IndustriesGrid;
