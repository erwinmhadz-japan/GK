import React from "react";
import { motion } from "framer-motion";
import { Brain, Tag, Link, FileText, Database, Building, Search } from "lucide-react";

interface Step {
  number: string;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  body: string;
}

const steps: Step[] = [
  {
    number: "01",
    icon: Brain,
    title: "Entity SEO",
    body:
      "I map your business, brand, and subject matter as discrete entities recognised by knowledge graphs. Establishing clear entity relationships signals authoritative subject coverage to AI systems that surface brand and topic answers.",
  },
  {
    number: "02",
    icon: Tag,
    title: "Schema Markup",
    body:
      "I implement structured data that precisely communicates what your organisation does, who runs it, and where — the machine-readable layer that AI models rely on when forming answers from your content.",
  },
  {
    number: "03",
    icon: Link,
    title: "Brand Citation Building",
    body:
      "AI engines synthesise answers from sources they trust. I develop a consistent, accurate citation footprint across authoritative directories, industry publications, and the wider web to reinforce your brand's credibility.",
  },
  {
    number: "04",
    icon: FileText,
    title: "Content Authority Signals",
    body:
      "I audit and develop content that demonstrates genuine topical depth — the kind of E-E-A-T signals that cause AI models to treat your site as a primary reference source rather than one of many results.",
  },
  {
    number: "05",
    icon: Database,
    title: "Structured Data Architecture",
    body:
      "Beyond individual schema tags, I design a coherent structured data architecture across your site — linking entities, pages, and data points in a way that gives AI systems a reliable, well-formed picture of your business.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" },
  },
};

const AISearchApproach = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="aisearch-approach"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      {/* Subtle dot grid texture — purely decorative */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-30"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(var(--border)) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.65, ease: "easeOut" }}
          className="mb-14 md:mb-20"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            My Methodology
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground max-w-2xl leading-snug">
            How I Optimise for AI Search
          </h2>
          <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
            AI search engines — ChatGPT, Perplexity, Google AI Overviews,
            Gemini, Copilot — draw on a different set of signals than
            traditional search. Below is the five-pillar methodology I apply to
            build sustainable AI search visibility for UK businesses.
          </p>
        </motion.div>

        {/* Steps */}
        <motion.ol
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="space-y-0 divide-y divide-border"
        >
          {steps.map((step) => {
            const Icon = step.icon;
            return (
              <motion.li
                key={step.number}
                variants={itemVariants}
                className="group grid grid-cols-1 md:grid-cols-[80px_1fr] gap-6 py-8 md:py-10"
              >
                {/* Left column: number + icon */}
                <div className="flex md:flex-col items-center md:items-start gap-3 md:gap-2">
                  <span
                    aria-hidden="true"
                    className="font-mono text-xs tracking-widest text-muted-foreground select-none"
                  >
                    {step.number}
                  </span>
                  <div
                    className="flex h-10 w-10 items-center justify-center rounded-md border border-border bg-background
                      group-hover:border-primary group-hover:bg-primary/10 transition-colors duration-300"
                  >
                    <Icon className="h-5 w-5 text-muted-foreground group-hover:text-primary transition-colors duration-300" />
                  </div>
                </div>

                {/* Right column: heading + body */}
                <div>
                  <h3 className="text-lg md:text-xl font-semibold text-foreground mb-2 leading-snug">
                    {step.title}
                  </h3>
                  <p className="text-sm md:text-base text-muted-foreground leading-relaxed max-w-prose">
                    {step.body}
                  </p>
                </div>
              </motion.li>
            );
          })}
        </motion.ol>

        {/* Foot note */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, ease: "easeOut", delay: 0.3 }}
          className="mt-12 text-xs text-muted-foreground border-t border-border pt-6 max-w-2xl"
        >
          This methodology is applied as a coordinated programme, not as
          isolated tactics — each pillar reinforces the others. I work with
          clients across the UK on a retained or project basis.
        </motion.p>
      </div>
    </section>
  );
});

AISearchApproach.displayName = "AISearchApproach";

export default AISearchApproach;
