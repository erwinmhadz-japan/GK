import React from "react";
import { AlertTriangle, Lock, Scale, Globe, FileText, Shield, Search, Volume } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

const painPoints = [
  {
    icon: Shield,
    title: "YMYL / E-E-A-T Requirements",
    description:
      "Financial content sits squarely in Google's 'Your Money or Your Life' category. Pages that discuss investments, loans, insurance or retirement planning are held to the highest quality bar — without demonstrable Experience, Expertise, Authoritativeness and Trustworthiness, your rankings will stall regardless of technical SEO quality.",
  },
  {
    icon: Scale,
    title: "Regulatory Complexity",
    description:
      "FCA, SEC, MiFID II and other regulatory frameworks place strict boundaries on financial marketing. Content must be accurate, balanced and fair while still driving organic search performance. Striking that balance without specialist guidance frequently means either non-compliant content or content so cautious it ranks for nothing.",
  },
  {
    icon: Lock,
    title: "Trust Barriers in Search",
    description:
      "Consumers searching for financial advice are inherently sceptical. They scrutinise credentials, read reviews and compare providers extensively before enquiring. If your brand lacks an authoritative digital footprint — credible backlinks, verified expertise signals, third-party citations — you simply won't appear at the decision stage.",
  },
  {
    icon: Globe,
    title: "Fierce Market Competition",
    description:
      "High-street banks, global asset managers and well-funded fintech challengers all compete for the same keywords. Generic SEO tactics will not break through. Outranking established financial brands requires a sophisticated entity-based strategy that builds Google's understanding of your unique value proposition.",
  },
  {
    icon: FileText,
    title: "Content Compliance Friction",
    description:
      "Many financial firms underinvest in content because internal compliance review is slow and resource-intensive. We build content workflows that satisfy compliance teams upfront — reducing revision cycles while still producing material Google rewards with sustained rankings.",
  },
  {
    icon: AlertTriangle,
    title: "Low-Quality Lead Volume",
    description:
      "Organic traffic that doesn't convert to qualified prospects is a silent cost. Financial services pages that target informational keywords without intent architecture attract high bounce rates and unqualified enquiries, eroding confidence in SEO as a channel.",
  },
];

const FinancialServicesPainPoints = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="financial-pain-points"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="max-w-2xl mx-auto text-center mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            Industry Challenges
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Why Financial Services SEO Is Different
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            The obstacles facing financial services firms in organic search are not generic SEO problems.
            They require specialist understanding of both the regulatory environment and Google's
            elevated quality standards for financial content.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {painPoints.map((point, index) => {
            const Icon = point.icon;
            return (
              <Card
                key={index}
                className="bg-card border-border shadow-card hover-lift transition-all duration-300 h-full"
              >
                <CardHeader className="pb-3">
                  <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 mb-4">
                    <Icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-foreground text-lg leading-snug">
                    {point.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground leading-relaxed text-sm">
                    {point.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
});

FinancialServicesPainPoints.displayName = "FinancialServicesPainPoints";

export default FinancialServicesPainPoints;
