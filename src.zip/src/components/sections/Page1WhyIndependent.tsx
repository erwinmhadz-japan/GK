import React from "react";
import { motion } from "framer-motion";
import { Shield, Zap, Users, Star, Target, Handshake, ArrowRight, Grid, View } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "react-router-dom";

const reasons = [
  {
    icon: Handshake,
    title: "Direct Consultant Access",
    description:
      "You work directly with me — a senior SEO consultant — from the first call through to delivery. No account managers, no junior staff, no handoffs.",
  },
  {
    icon: Target,
    title: "Bespoke, Not Packaged",
    description:
      "Every engagement is custom-built around your specific goals, market, and budget. I don't believe in one-size-fits-all packages that don't fit anyone perfectly.",
  },
  {
    icon: Zap,
    title: "Faster Decision-Making",
    description:
      "Without agency layers, strategy changes happen quickly. When an opportunity or issue arises, we can act on it — not wait for a committee to approve it.",
  },
  {
    icon: Shield,
    title: "Honest, Unbiased Advice",
    description:
      "I'm not incentivised to upsell services you don't need. My only goal is your organic performance — and I'll always tell you exactly where your budget is best spent.",
  },
  {
    icon: Star,
    title: "Breadth of Expertise",
    description:
      "From technical SEO and schema markup to content strategy, entity SEO, and AI search optimisation — I bring the full spectrum of modern search expertise to every engagement.",
  },
  {
    icon: Users,
    title: "Flexible Engagement Models",
    description:
      "Whether you need a one-off SEO audit, a monthly retainer, or project-based consulting, I work around your needs — not a rigid agency billing structure.",
  },
];

const Page1WhyIndependent = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="page1-why-independent"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="text-center mb-14 md:mb-16"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Why Choose Independent
          </span>
          <h2
            className="text-3xl md:text-4xl font-bold text-foreground max-w-2xl mx-auto leading-tight mb-4"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            The Case for Independent SEO Consulting
          </h2>
          <p className="text-base md:text-lg text-muted-foreground max-w-xl mx-auto leading-relaxed">
            When you hire an independent consultant, you get the senior expertise you're paying for — every session, every deliverable.
          </p>
        </motion.div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {reasons.map((reason, index) => {
            const Icon = reason.icon;
            return (
              <motion.div
                key={reason.title}
                initial={{ opacity: 0, y: 28 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.55, ease: "easeOut", delay: index * 0.07 }}
              >
                <Card className="h-full border-border shadow-card hover:shadow-card-hover hover-lift transition-all duration-300 bg-card">
                  <CardContent className="p-6 flex flex-col gap-4">
                    <div
                      className="flex h-11 w-11 items-center justify-center rounded-lg"
                      style={{
                        background:
                          "linear-gradient(135deg, hsl(84 74% 58% / 0.15) 0%, hsl(119 35% 61% / 0.10) 100%)",
                      }}
                    >
                      <Icon
                        className="h-5 w-5"
                        style={{ color: "hsl(88 59% 56%)" }}
                        aria-hidden="true"
                      />
                    </div>
                    <div>
                      <h3
                        className="text-base font-semibold text-foreground mb-2 leading-snug"
                        style={{ fontFamily: "Sora, sans-serif" }}
                      >
                        {reason.title}
                      </h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {reason.description}
                      </p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Bottom pull-quote */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
          className="mt-14 md:mt-16 rounded-xl border border-border bg-card p-8 md:p-10 text-center shadow-soft"
        >
          <p
            className="text-lg md:text-xl font-medium text-foreground max-w-2xl mx-auto leading-relaxed"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            "Great SEO isn't about gaming algorithms — it's about understanding your audience, your market, and building sustainable visibility that compounds over time."
          </p>
          <p
            className="mt-4 text-sm font-semibold uppercase tracking-widest"
            style={{ color: "hsl(88 59% 56%)" }}
          >
            Gregg Holloway · Independent SEO Consultant
          </p>
          <div className="mt-8 flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              to="/services"
              className="inline-flex items-center gap-1.5 text-sm font-medium hover:underline underline-offset-2 transition-colors"
              style={{ color: "hsl(88 59% 56%)" }}
            >
              Explore All Services <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
            </Link>
            <span className="hidden sm:inline text-muted-foreground" aria-hidden="true">·</span>
            <Link
              to="#case-studies-cta"
              className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground hover:underline underline-offset-2 transition-colors"
            >
              View Case Studies <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
            </Link>
            <span className="hidden sm:inline text-muted-foreground" aria-hidden="true">·</span>
            <Link
              to="/about"
              className="inline-flex items-center gap-1.5 text-sm font-medium text-muted-foreground hover:text-foreground hover:underline underline-offset-2 transition-colors"
            >
              About Gregg <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
            </Link>
          </div>
        </motion.div>
      </div>
    </section>
  );
});

Page1WhyIndependent.displayName = "Page1WhyIndependent";

export default Page1WhyIndependent;
