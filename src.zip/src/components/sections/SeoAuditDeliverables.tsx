import React from "react";
import { motion } from "framer-motion";
import { FileText, ClipboardList, Eye, Phone, ArrowRight, Forward, Search, Section, View } from "lucide-react";
import { Link } from "react-router-dom";

const deliverables = [
  {
    icon: FileText,
    title: "Written Audit Document",
    description:
      "A clear, structured report detailing every finding — technical, on-page, content, and off-site. Written in plain English, not jargon. Each issue is explained in context, so you understand not just what is wrong but why it matters to your visibility.",
    accent: "Prioritised by impact",
  },
  {
    icon: ClipboardList,
    title: "Prioritised Action Roadmap",
    description:
      "Not a list of generic recommendations, but a sequenced roadmap ordered by expected impact and effort. You receive a clear picture of where to focus first — whether that is a critical technical fix or a content gap undermining your authority.",
    accent: "Ordered by impact and effort",
  },
  {
    icon: Eye,
    title: "AI Search Visibility Commentary",
    description:
      "An assessment of how your site is currently performing — or likely to perform — within AI-generated search experiences such as Google AI Overviews, ChatGPT, and Perplexity. Increasingly, visibility in these surfaces requires a distinct approach to content structure and entity clarity.",
    accent: "Forward-looking perspective",
  },
  {
    icon: Phone,
    title: "One-to-One Results Call",
    description:
      "Once you have read the report, Gregg walks you through the key findings and recommendations. This is not a handoff call — it is a working conversation in which you can ask questions, challenge assumptions, and leave with complete clarity on next steps.",
    accent: "Direct access, no intermediaries",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const SeoAuditDeliverables = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seo-audit-deliverables"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mb-14 md:mb-20 max-w-2xl"
        >
          <span className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium">
            Audit Output
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground font-[Sora,sans-serif] leading-tight mb-5">
            What You Receive
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-xl">
            The audit produces a concise, well-structured set of materials
            designed for clarity and action — not volume. Every deliverable is
            produced by Gregg King directly, with no delegation to junior staff
            or automated tooling.
          </p>
        </motion.div>

        {/* Deliverables grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8"
        >
          {deliverables.map((item, index) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.title}
                variants={itemVariants}
                className="group relative bg-background border border-border rounded-md p-7 md:p-8 flex flex-col gap-5 transition-all duration-300 hover:border-primary/40"
                style={{
                  boxShadow:
                    "0 2px 12px -2px hsl(222 28% 11% / 0.06), 0 1px 3px hsl(222 28% 11% / 0.04)",
                }}
              >
                {/* Step number — subtle positional marker */}
                <span
                  className="absolute top-6 right-7 text-xs font-medium text-muted-foreground/40 tabular-nums select-none"
                  aria-hidden="true"
                >
                  0{index + 1}
                </span>

                {/* Icon */}
                <div className="flex items-center justify-start">
                  <div className="flex h-11 w-11 items-center justify-center rounded-md bg-primary/10 shrink-0 transition-colors duration-300 group-hover:bg-primary/18">
                    <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
                  </div>
                </div>

                {/* Content */}
                <div className="flex flex-col gap-3">
                  <h3 className="text-lg md:text-xl font-semibold text-foreground font-[Sora,sans-serif] leading-snug pr-8">
                    {item.title}
                  </h3>
                  <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                    {item.description}
                  </p>
                </div>

                {/* Accent label */}
                <div className="mt-auto pt-2 border-t border-border">
                  <span className="inline-flex items-center gap-1.5 text-xs uppercase tracking-[0.15em] font-medium text-primary">
                    <span className="block h-px w-4 bg-primary rounded-full shrink-0" aria-hidden="true" />
                    {item.accent}
                  </span>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Closing note — editorial framing, no hard CTA */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.55, ease: "easeOut", delay: 0.2 }}
          className="mt-14 md:mt-16 max-w-2xl"
        >
          <p className="text-sm text-muted-foreground leading-relaxed">
            The emphasis throughout is on clarity — a smaller number of high-confidence
            findings with clear commercial rationale, rather than an exhaustive
            list that obscures what actually matters.{" "}
            <Link
              to="/services"
              className="inline-flex items-center gap-1 text-primary font-medium hover:underline underline-offset-2 transition-colors"
            >
              View all services
              <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
            </Link>
          </p>
        </motion.div>
      </div>
    </section>
  );
});

SeoAuditDeliverables.displayName = "SeoAuditDeliverables";

export default SeoAuditDeliverables;
