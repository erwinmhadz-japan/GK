import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Quote, Star, Stars } from "lucide-react";

const testimonials = [
  {
    quote:
      "We'd been invisible in search for years despite having genuine expertise. Gregg's entity SEO approach completely changed that — within eight months our managing partners were ranking for the exact queries our target CFOs were typing. The quality of inbound enquiries improved dramatically.",
    name: "Jonathan Hartley",
    role: "Managing Director",
    firm: "Hartley & Associates — Management Consultancy",
    image:
      "https://images.unsplash.com/photo-1734830268394-6c4a1f165af1?w=400&h=400&fit=crop&crop=face",
    result: "+340% qualified enquiries in 12 months",
  },
  {
    quote:
      "Our engineering consultancy was losing RFP opportunities to competitors we knew were less capable. Gregg identified that they were simply more visible online. His technical SEO and content strategy gave us the search presence our expertise deserved — and the leads followed.",
    name: "Priya Mehta",
    role: "Business Development Director",
    firm: "Meridian Engineering Consultants",
    image:
      "https://images.unsplash.com/photo-1710778044102-56a3a6b69a1b?w=400&h=400&fit=crop&crop=face",
    result: "£2.4M pipeline attributed to organic search",
  },
  {
    quote:
      "As an HR consultancy, our buyers are sophisticated — they research extensively before making contact. The thought leadership content strategy Gregg built positioned our senior consultants as genuine authorities. We now receive enquiries from prospects who've already read three or four of our articles.",
    name: "Sandra Clarke",
    role: "Founding Partner",
    firm: "Clarke & Webb HR Consulting",
    image:
      "https://images.unsplash.com/photo-1681500920181-0aff411f8cab?w=400&h=400&fit=crop&crop=face",
    result: "Average deal size increased by 60%",
  },
];

const B2BTestimonials = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="b2b-testimonials"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Client Results
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            B2B Firms That Transformed Their SEO Presence
          </h2>
          <p className="text-muted-foreground leading-relaxed">
            Real results from consulting, engineering, and HR firms that
            invested in specialist B2B SEO strategy — and saw measurable
            pipeline impact.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-14">
          {testimonials.map((testimonial, index) => (
            <Card
              key={index}
              className="bg-card border border-border shadow-card hover-lift flex flex-col"
            >
              <CardContent className="flex flex-col gap-5 pt-6 flex-1">
                {/* Stars */}
                <div className="flex gap-1">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className="h-4 w-4 text-primary fill-primary"
                    />
                  ))}
                </div>

                {/* Quote */}
                <div className="relative">
                  <Quote className="h-6 w-6 text-primary/30 absolute -top-1 -left-1" />
                  <p className="text-muted-foreground text-sm leading-relaxed pl-5 italic">
                    {testimonial.quote}
                  </p>
                </div>

                {/* Result badge */}
                <Badge className="self-start bg-primary/10 text-primary border border-primary/20 text-xs uppercase tracking-wider">
                  {testimonial.result}
                </Badge>

                {/* Author */}
                <div className="flex items-center gap-3 mt-auto pt-4 border-t border-border">
                  <img
                    src={testimonial.image}
                    alt={`${testimonial.name} — ${testimonial.role}`}
                    width={400}
                    height={400}
                    loading="lazy"
                    className="h-10 w-10 rounded-full object-cover"
                  />
                  <div>
                    <p className="text-foreground font-semibold text-sm">
                      {testimonial.name}
                    </p>
                    <p className="text-muted-foreground text-xs">
                      {testimonial.role}, {testimonial.firm}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Case study callout */}
        <div className="bg-card border border-border rounded-2xl p-8 md:p-10 shadow-card max-w-4xl mx-auto">
          <div className="flex flex-col md:flex-row gap-8 items-center">
            <div className="flex-1">
              <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-3">
                Case Study Highlight
              </span>
              <h3 className="text-2xl font-bold text-foreground mb-3">
                Accountancy Firm Doubles Partner-Level Enquiries
              </h3>
              <p className="text-muted-foreground leading-relaxed text-sm mb-4">
                A 12-partner regional accountancy practice was generating fewer
                than five organic enquiries per month. After a 12-month SEO
                programme combining technical remediation, entity authority
                building, and a vertical content strategy targeting CFO and FD
                search behaviour, organic enquiries rose to over 40 per month —
                with average deal values increasing from £8,000 to £22,000 as
                inbound prospects arrived better pre-qualified.
              </p>
              <div className="flex flex-wrap gap-4">
                <div className="text-center">
                  <p className="text-2xl font-bold text-primary">8×</p>
                  <p className="text-xs text-muted-foreground">
                    Organic Enquiry Growth
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-primary">£22K</p>
                  <p className="text-xs text-muted-foreground">
                    Avg. Deal Value
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-2xl font-bold text-primary">12mo</p>
                  <p className="text-xs text-muted-foreground">
                    To Measurable ROI
                  </p>
                </div>
              </div>
            </div>
            <div className="w-full md:w-56 shrink-0">
              <img
                src="https://images.unsplash.com/photo-1600896997793-b8ed3459a17f?w=400&h=400&fit=crop&crop=face"
                alt="Accountancy firm partner client testimonial"
                width={400}
                height={400}
                loading="lazy"
                className="rounded-xl object-cover w-full h-48 md:h-56"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

B2BTestimonials.displayName = "B2BTestimonials";

export default B2BTestimonials;
