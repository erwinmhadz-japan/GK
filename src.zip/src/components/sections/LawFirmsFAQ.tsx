import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { HelpCircle, Code } from "lucide-react";

const faqs = [
  {
    question: "Is SEO for law firms compliant with SRA advertising rules?",
    answer:
      "Yes — when implemented correctly. The Solicitors Regulation Authority's Code of Conduct requires that legal marketing is accurate, not misleading, and does not guarantee outcomes. We ensure all content we produce for law firm clients avoids prohibited claims, uses appropriate disclaimers, and follows SRA guidance on client testimonials and outcome statements. Every strategy we implement is reviewed against current SRA advertising standards.",
  },
  {
    question: "How does local SEO work for solicitors and law firms?",
    answer:
      "Local SEO for law firms focuses on ranking in Google's local pack (the map results) and in organic search for location-specific legal terms such as 'family solicitor Leeds' or 'conveyancing solicitor near me'. This involves optimising your Google Business Profile, building consistent citations across legal directories (Solicitors.guru, The Law Society Find a Solicitor, Yell, etc.), creating geo-targeted service pages, and implementing LocalBusiness and LegalService schema markup. A well-executed local SEO strategy places your firm in front of clients at the moment they need legal help.",
  },
  {
    question: "What keywords should a law firm target for SEO?",
    answer:
      "The most valuable keywords for law firms are practice area + location combinations ('divorce solicitor Manchester'), intent-driven legal questions ('how to make a will'), and specific legal processes ('conveyancing costs UK'). We build a comprehensive keyword strategy that covers high-volume commercial terms for your practice areas, long-tail question-based queries ideal for blog content, and local search terms that drive footfall and phone calls. We prioritise terms by monthly search volume, ranking difficulty, and commercial intent — not just volume alone.",
  },
  {
    question: "How long does SEO take to show results for a law firm?",
    answer:
      "Most law firm clients begin to see meaningful movement in rankings within 3 to 4 months, with substantial organic traffic and enquiry growth typically visible by month 6. Highly competitive practice areas like personal injury and clinical negligence may take 9–12 months to reach page one for primary terms. Local SEO for less competitive locations can move faster — sometimes within 6–8 weeks. We provide transparent monthly reporting so you can track progress against agreed KPIs throughout the campaign.",
  },
  {
    question: "Do you use schema markup for law firm websites?",
    answer:
      "Yes — schema markup is a core part of our technical SEO strategy for legal sites. We implement LegalService schema to define your practice areas, Attorney schema where relevant, LocalBusiness schema with opening hours and contact details, and FAQ JSON-LD on question-based content pages. Structured data helps Google understand exactly what your firm does, can unlock rich snippet features in search results, and improves your visibility in AI-powered search tools like Google AI Overviews and Perplexity.",
  },
  {
    question: "Can you help our law firm appear in AI search tools like ChatGPT and Perplexity?",
    answer:
      "Yes. As AI-driven search becomes more prominent, law firms need to optimise for how these tools retrieve and cite information. This involves creating authoritative, well-structured content that answers specific legal questions, implementing comprehensive schema markup, building entity signals across authoritative directories and legal publications, and earning high-quality backlinks from trusted sources. We specialise in AI search optimisation alongside traditional SEO, ensuring your firm is visible however your clients choose to search.",
  },
];

const LawFirmsFAQ = React.forwardRef<HTMLElement>((props, ref) => {
  // FAQ JSON-LD schema
  const faqSchema = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: faq.answer,
      },
    })),
  };

  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
      aria-label="Frequently asked questions about law firm SEO"
    >
      {/* FAQ JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />

      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 items-start">
          {/* Left column */}
          <div className="lg:col-span-1">
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
              FAQ
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Legal SEO Questions Answered
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Common questions from law firm partners and practice managers about
              SEO compliance, strategy, and results timelines.
            </p>

            <div className="flex items-center gap-3 p-4 rounded-lg bg-muted border border-border mb-6">
              <HelpCircle className="h-5 w-5 text-primary shrink-0" />
              <p className="text-sm text-muted-foreground">
                Have a question not covered here?{" "}
                <a href="/contact" className="text-primary hover:underline underline-offset-4 font-medium">
                  Ask us directly
                </a>
                .
              </p>
            </div>

            <Button className="bg-primary text-primary-foreground hover:bg-primary/90 w-full sm:w-auto" asChild>
              <a href="/contact">Get a Free Consultation</a>
            </Button>
          </div>

          {/* Right column — accordion */}
          <div className="lg:col-span-2">
            <Accordion type="single" collapsible className="w-full space-y-2">
              {faqs.map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="border border-border rounded-lg px-4 data-[state=open]:border-primary/40 bg-card"
                >
                  <AccordionTrigger className="text-left font-medium text-foreground hover:no-underline py-5">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed pb-5">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </div>
    </section>
  );
});

LawFirmsFAQ.displayName = "LawFirmsFAQ";

export default LawFirmsFAQ;
