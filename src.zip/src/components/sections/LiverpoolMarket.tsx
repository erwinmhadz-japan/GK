import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Anchor, Building2, Users, TrendingUp, Briefcase, Globe, ArrowRight, Search, Section, Triangle } from "lucide-react";

const marketInsights = [
  {
    icon: Anchor,
    title: "Port City Commerce",
    description:
      "Liverpool's historic port identity fuels thriving logistics, shipping, and import/export businesses — all competing hard for local and national search visibility.",
  },
  {
    icon: Building2,
    title: "Baltic Triangle Tech Scene",
    description:
      "Liverpool's creative and tech quarter is growing fast. Digital agencies, startups, and SaaS companies need authoritative local and national rankings to compete.",
  },
  {
    icon: Users,
    title: "600,000+ City Population",
    description:
      "With nearly 500,000 residents in the city and over 1.5 million in Greater Merseyside, the local search audience is significant — and largely underserved.",
  },
  {
    icon: Briefcase,
    title: "Professional Services Hub",
    description:
      "Law firms, accountants, financial advisers, and consultancies across Liverpool City Region face fierce local competition for Google's 'near me' searches.",
  },
  {
    icon: TrendingUp,
    title: "Regeneration & Investment",
    description:
      "Major investment zones — from Liverpool Waters to the Knowledge Quarter — are attracting new businesses that need immediate local search presence.",
  },
  {
    icon: Globe,
    title: "Tourism & Hospitality",
    description:
      "Millions of visitors per year make tourism, hospitality, and leisure one of Liverpool's biggest local search battlegrounds — standing out requires strategic SEO.",
  },
];

const LiverpoolMarket = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="liverpool-market"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-3xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Liverpool's Local Market
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-5">
            Understanding Liverpool's Unique Local Search Landscape
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Liverpool isn't just another northern city. It has a distinct
            economic identity — shaped by its port heritage, creative industries,
            and a fiercely loyal local consumer base. That uniqueness creates
            specific local SEO dynamics that a one-size-fits-all agency simply
            won't understand. Here's what makes Liverpool's market different:
          </p>
        </div>

        {/* Insight cards grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {marketInsights.map((insight) => {
            const Icon = insight.icon;
            return (
              <Card
                key={insight.title}
                className="border border-border shadow-card hover-lift bg-card"
              >
                <CardContent className="p-6">
                  <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-4">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground mb-2">
                    {insight.title}
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {insight.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Pull-quote / editorial paragraph */}
        <div className="bg-muted rounded-xl p-8 md:p-10 border border-border">
          <blockquote className="text-foreground text-lg md:text-xl font-medium leading-relaxed mb-4">
            "Liverpool businesses operate in a hyper-local search environment
            where proximity, trust signals, and local authority matter more than
            sheer domain age. Getting the fundamentals right here delivers
            results fast."
          </blockquote>
          <p className="text-muted-foreground text-sm">
            — Gregg, Independent SEO Consultant
          </p>
        </div>

        <div className="mt-10 text-center">
          <Button variant="outline" asChild>
            <a href="/services" className="inline-flex items-center gap-2">
              See All SEO Services
              <ArrowRight className="h-4 w-4" />
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
});

LiverpoolMarket.displayName = "LiverpoolMarket";

export default LiverpoolMarket;
