import React from "react";
;
import { Button } from "@/components/ui/button";
import { Shield, BadgeCheck, Star, Users, FileText, Activity, ArrowRight, Building, Code } from "lucide-react"
;

const trustSignals = [
  {
    icon: BadgeCheck,
    title: "E-E-A-T Authority Building",
    description:
      "We embed demonstrable Experience, Expertise, Authoritativeness, and Trustworthiness signals into every piece of content — from practitioner bios with GMC registration numbers to evidence-based citations from peer-reviewed sources.",
  },
  {
    icon: Star,
    title: "Review Strategy & Reputation Management",
    description:
      "A proactive review generation framework that encourages satisfied patients to leave reviews on Google, NHS Choices, and Doctify — with compliant, non-incentivised strategies that meet CQC and ASA guidelines.",
  },
  {
    icon: Shield,
    title: "CQC-Aligned Content Standards",
    description:
      "All content produced adheres to Care Quality Commission standards and ASA healthcare advertising guidelines. We understand the boundaries of medical claims and ensure your SEO content is both effective and compliant.",
  },
  {
    icon: FileText,
    title: "Medical Schema & Rich Results",
    description:
      "Structured data implementation across MedicalOrganization, Physician, and FAQPage schemas drives rich search features — displaying star ratings, opening hours, and accepted insurance types directly in search results.",
  },
  {
    icon: Users,
    title: "Patient-Centred UX Signals",
    description:
      "We audit and optimise the patient journey from search to appointment booking — ensuring your site's Core Web Vitals, accessibility standards, and mobile experience meet both NHS Digital accessibility guidelines and Google's ranking signals.",
  },
  {
    icon: Activity,
    title: "Healthcare Performance Metrics",
    description:
      "Bespoke reporting dashboards tracking metrics that matter to clinic managers: organic patient enquiry volume, local pack positions, appointment booking conversion rates, and return on SEO investment.",
  },
];

const HealthcareClinicsTrustSignals = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="healthcare-trust-signals"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-start">
          {/* Left column — heading & CTA */}
          <div className="lg:sticky lg:top-24">
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4 font-semibold">
              Patient Trust Signals
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-5">
              Building the Trust That Converts Patients in a{" "}
              <span className="text-gradient-green">High-Stakes Sector</span>
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed mb-6">
              Healthcare SEO is uniquely personal. When someone searches for a clinic, they're
              often anxious, vulnerable, or in need of urgent help. Every trust signal we
              build — from schema to reviews to content depth — is designed to reduce
              friction and convert that visit into a patient relationship.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              We work with both NHS-funded and private medical providers to create search
              presences that communicate genuine clinical expertise — the kind of authority
              that earns both algorithmic trust and patient confidence.
            </p>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" asChild className="font-semibold shadow-green-glow">
                <a href="/contact">
                  Start Building Patient Trust
                  <ArrowRight className="ml-2 h-5 w-5" />
                </a>
              </Button>
              <Button size="lg" variant="outline" asChild className="font-semibold">
                <a href="/schema-markup">Schema Markup Service</a>
              </Button>
            </div>

            {/* Compliance note */}
            <div className="mt-8 p-4 rounded-xl border border-border bg-muted">
              <p className="text-xs text-muted-foreground leading-relaxed">
                <strong className="text-foreground">Compliance note:</strong> All healthcare
                SEO work adheres to ASA CAP Code guidelines for medical advertising, CQC
                registration requirements, GDPR Article 9 (special category health data),
                and Google's YMYL quality rater guidelines.
              </p>
            </div>
          </div>

          {/* Right column — trust signal cards */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
            {trustSignals.map((signal) => {
              const Icon = signal.icon;
              return (
                <div
                  key={signal.title}
                  className="rounded-xl border border-border bg-card p-5 shadow-soft hover-lift transition-all duration-300"
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 mb-3">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="text-sm font-bold text-foreground mb-2 leading-snug">
                    {signal.title}
                  </h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {signal.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
});

HealthcareClinicsTrustSignals.displayName = "HealthcareClinicsTrustSignals";

export default HealthcareClinicsTrustSignals;
