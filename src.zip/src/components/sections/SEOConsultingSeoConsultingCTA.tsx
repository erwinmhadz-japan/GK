import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, Mail, CheckCircle } from "lucide-react";

const trustPoints = [
  "Direct access to a senior UK SEO consultant",
  "No account managers or junior teams",
  "Transparent, independent advice",
];

const SEOConsultingSeoConsultingCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seoconsulting-seo-consulting-cta"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          {/* Eyebrow label */}
          <motion.span
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-6 font-medium"
          >
            Work with Gregg
          </motion.span>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.08 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground tracking-tight mb-5"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Start a Consulting Conversation
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.15 }}
            className="text-base md:text-lg text-muted-foreground leading-relaxed mb-8 max-w-2xl mx-auto"
          >
            Get in touch to discuss your SEO challenges — or request a free GBP audit as a starting
            point.
          </motion.p>

          {/* Trust points */}
          <motion.ul
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: "easeOut", delay: 0.22 }}
            className="flex flex-col sm:flex-row sm:flex-wrap items-center justify-center gap-3 mb-10"
          >
            {trustPoints.map((point) => (
              <li
                key={point}
                className="flex items-center gap-2 text-sm text-muted-foreground"
              >
                <CheckCircle className="h-4 w-4 shrink-0 text-primary" />
                {point}
              </li>
            ))}
          </motion.ul>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: "easeOut", delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Button
              size="lg"
              asChild
              className="bg-primary text-primary-foreground hover:bg-primary/90 h-12 px-8 text-base font-semibold rounded-md shadow-[0_4px_24px_-6px_hsl(88_59%_56%/0.35)] transition-all duration-300 hover:shadow-[0_6px_32px_-6px_hsl(88_59%_56%/0.45)]"
            >
              <Link to="/contact">
                Enquire About Consulting
                <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>

            <Button
              size="lg"
              variant="outline"
              asChild
              className="h-12 px-8 text-base font-semibold rounded-md border-border text-foreground hover:bg-muted transition-all duration-300"
            >
              <Link to="/contact">
                <Mail className="mr-2 h-5 w-5 text-primary" />
                FREE GBP AUDIT
              </Link>
            </Button>
          </motion.div>

          {/* Reassurance note */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: "easeOut", delay: 0.42 }}
            className="mt-6 text-xs text-muted-foreground"
          >
            Independent consultant · Based in Warrington, Cheshire · No obligation
          </motion.p>
        </div>
      </div>
    </section>
  );
});

SEOConsultingSeoConsultingCTA.displayName = "SEOConsultingSeoConsultingCTA";

export default SEOConsultingSeoConsultingCTA;
