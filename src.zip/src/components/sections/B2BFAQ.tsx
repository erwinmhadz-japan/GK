import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { ArrowRight } from "lucide-react";

const faqs = [
  {
    question: "What makes SEO for B2B different from standard SEO?",
    answer:
      "B2B SEO must account for long purchase cycles, multiple stakeholders, and low-volume but high-intent search terms. Unlike B2C, where a single page often converts a single buyer, B2B content must serve awareness, consideration, and decision-stage queries across an entire buying committee. Entity authority — ensuring Google and AI models recognise your firm's expertise and credibility — is also far more critical in professional services than in most consumer categories.",
  },
  {
    question: "How does content strategy drive B2B lead generation through SEO?",
    answer:
      "Effective B2B content strategy starts with a thorough audit of what decision-makers, influencers, and end users are searching for at each stage of the buying journey. We build topic clusters that establish topical authority, create cornerstone service pages optimised for high-intent terms, and develop supporting thought leadership content that captures early-stage researchers. The result is a content ecosystem that generates qualified inbound enquiries, not just traffic.",
  },
  {
    question: "What is entity SEO and why does it matter for professional services firms?",
    answer:
      "Entity SEO is the process of establishing your firm as a clearly defined, authoritative entity within Google's Knowledge Graph and broader semantic web. For professional services companies, this means structuring your online presence so search engines and AI tools confidently associate your brand with specific service categories, geographies, and areas of expertise. Firms with strong entity signals are more likely to appear in AI-generated answers (ChatGPT, Perplexity, Gemini), knowledge panels, and featured snippets — all high-credibility placements that drive trust and enquiries.",
  },
  {
    question: "How does schema markup help B2B and professional services websites?",
    answer:
      "Schema markup provides structured data that tells search engines exactly what your firm does, who it serves, where it operates, and how credible it is. For B2B professional services, we implement Service, ProfessionalService, Organization, Person, and FAQPage schemas. This structured data can unlock rich results (star ratings, FAQs in SERPs), improves how AI models describe your business in generated responses, and provides the factual scaffolding Google needs to assign topical authority confidently.",
  },
  {
    question: "How long does B2B SEO take to show results?",
    answer:
      "B2B SEO typically shows meaningful progress within four to six months, with significant pipeline impact at nine to twelve months. The longer timeline compared to B2C reflects the complexity of establishing entity authority, building topical content clusters, and earning relevant backlinks from industry publications. However, because individual B2B conversions carry high commercial value, the ROI from organic growth is substantial — firms that invest in a sustained strategy consistently outperform paid channels over a 12-to-24-month horizon.",
  },
  {
    question: "Can digital PR work alongside B2B SEO to improve rankings?",
    answer:
      "Absolutely. Digital PR is one of the highest-leverage tactics in a B2B SEO programme. Links from respected industry publications, sector associations, and authoritative news sites send powerful trust signals to Google. Beyond the direct link equity, being featured in credible outlets accelerates entity recognition and can generate direct referral traffic from buyers who already trust those publications. We integrate Digital PR with content strategy and entity SEO to create compounding authority gains across all three channels.",
  },
];

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((faq) => ({
    "@type": "Question",
    name: faq.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: faq.answer,
    },
  })),
};

const B2BFAQ = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="b2b-faq"
      className="relative py-20 md:py-32 border-t border-border bg-background"
      aria-label="B2B SEO frequently asked questions"
    >
      {/* FAQ JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />

      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12 lg:gap-16 items-start">
          {/* Left column — heading + CTAs */}
          <div className="lg:col-span-1">
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
              Common Questions
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-5">
              B2B SEO Questions Answered
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Professional services leaders frequently ask us these questions
              before starting an SEO programme. If your question isn't here,
              get in touch.
            </p>

            <div className="flex flex-col gap-3">
              <Button size="lg" asChild>
                <a href="/contact">
                  Ask a Question
                  <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="#case-studies-cta">See Client Results</a>
              </Button>
            </div>

            {/* Internal links */}
            <div className="mt-10 pt-8 border-t border-border">
              <p className="text-sm font-semibold text-foreground mb-3">
                Relevant Services
              </p>
              <ul className="space-y-2">
                {[
                  { label: "Entity SEO", href: "/entity-seo" },
                  { label: "Content Strategy", href: "/content-strategy" },
                  { label: "Digital PR", href: "/digital-pr" },
                  { label: "Schema Markup", href: "/schema-markup" },
                  { label: "All Industries", href: "#industries-cta" },
                ].map((link) => (
                  <li key={link.href}>
                    <a
                      href={link.href}
                      className="text-sm text-primary hover:underline underline-offset-4 font-medium"
                    >
                      {link.label} →
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Right column — accordion */}
          <div className="lg:col-span-2">
            <Accordion type="single" collapsible className="w-full space-y-1">
              {faqs.map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="border border-border rounded-lg px-2 mb-2 bg-card"
                >
                  <AccordionTrigger className="text-left font-semibold text-foreground hover:no-underline py-5 text-base">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed pb-5 text-sm">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </div>
    </section>
  );
});

B2BFAQ.displayName = "B2BFAQ";

export default B2BFAQ;
