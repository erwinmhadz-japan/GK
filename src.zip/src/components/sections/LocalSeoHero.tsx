import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Search, TrendingUp, ChevronRight, Contact, Map as MapIcon } from "lucide-react";

const LocalSeoHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="local-seo-hero"
      className="relative isolate overflow-hidden border-t border-border bg-[hsl(225_28%_14%)]"
    >
      {/* Subtle dot-grid texture overlay */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(0 0% 100%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      {/* Faint green gradient accent — bottom-right */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-32 -right-32 h-96 w-96 rounded-full opacity-[0.07] blur-3xl"
        style={{ background: "hsl(84 74% 58%)" }}
      />

      {/* Faint green accent — top-left */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -left-24 -top-24 h-72 w-72 rounded-full opacity-[0.05] blur-3xl"
        style={{ background: "hsl(119 35% 61%)" }}
      />

      <div className="container max-w-6xl mx-auto px-4 py-20 md:py-32 relative z-10">
        <div className="max-w-3xl">
          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0 }}
            className="flex flex-wrap items-center gap-3 mb-6"
          >
            <Badge
              variant="outline"
              className="border-[hsl(84_74%_58%)]/40 bg-[hsl(84_74%_58%)]/10 text-[hsl(84_74%_58%)] text-xs uppercase tracking-widest px-3 py-1"
            >
              Independent Consultant
            </Badge>
            <span className="flex items-center gap-1.5 text-xs text-white/80 uppercase tracking-widest font-medium">
              <MapPin className="h-3.5 w-3.5 text-[hsl(84_74%_58%)]" aria-hidden="true" />
              Warrington, Cheshire
            </span>
          </motion.div>

          {/* H1 */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-[1.08] tracking-tight mb-5"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Local SEO
            <br />
            <span
              className="inline-block"
              style={{
                background: "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              Consultant UK
            </span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.2 }}
            className="text-lg md:text-xl text-white/80 leading-relaxed mb-8 max-w-2xl"
          >
            Helping UK businesses dominate local search — from Google Business Profile to map pack rankings and beyond.
          </motion.p>

          {/* Trust signals */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
            className="flex flex-wrap items-center gap-x-6 gap-y-2 mb-8 text-sm text-white/80"
          >
            <span className="flex items-center gap-2">
              <Search className="h-4 w-4 text-[hsl(119_35%_61%)]" aria-hidden="true" />
              Map pack &amp; GBP specialist
            </span>
            <span className="flex items-center gap-2">
              <TrendingUp className="h-4 w-4 text-[hsl(119_35%_61%)]" aria-hidden="true" />
              Local citation &amp; rankings
            </span>
            <span className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-[hsl(119_35%_61%)]" aria-hidden="true" />
              UK-wide coverage
            </span>
          </motion.div>

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.38 }}
            className="flex flex-wrap items-center gap-4"
          >
            <Button
              size="lg"
              asChild
              className="text-sm font-semibold uppercase tracking-wider px-7 py-3 h-12 rounded-md shadow-none border-0 text-[hsl(225_28%_14%)]"
              style={{
                background: "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
              }}
            >
              <Link to="/contact">FREE GBP AUDIT</Link>
            </Button>

            <Button
              size="lg"
              variant="outline"
              asChild
              className="text-sm font-medium uppercase tracking-wider px-7 py-3 h-12 rounded-md border-white/25 bg-transparent text-white hover:bg-white/10 hover:border-white/40"
            >
              <Link to="/contact" className="flex items-center gap-2">
                Contact Me
                <ChevronRight className="h-4 w-4" aria-hidden="true" />
              </Link>
            </Button>
          </motion.div>

          {/* Reassurance note */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.7, ease: "easeOut", delay: 0.5 }}
            className="mt-5 text-sm text-white/80"
          >
            I work directly with your business — no account managers, no agency overhead.
          </motion.p>
        </div>
      </div>
    </section>
  );
});

LocalSeoHero.displayName = "LocalSeoHero";

export default LocalSeoHero;
