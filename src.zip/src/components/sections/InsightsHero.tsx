import React from "react";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { BookOpen, FileText, Rss, ChevronRight, Home, Icon, Search } from "lucide-react";

const pillars = [
  { icon: FileText, label: "SEO Strategy" },
  { icon: BookOpen, label: "AI Search" },
  { icon: Rss, label: "Digital PR" },
];

const InsightsHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="insights-hero"
      className="relative py-20 md:py-32 border-t border-border bg-muted overflow-hidden"
    >
      {/* Subtle decorative grid pattern */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.035]"
        aria-hidden="true"
        style={{
          backgroundImage:
            "linear-gradient(hsl(222 42% 8%) 1px, transparent 1px), linear-gradient(90deg, hsl(222 42% 8%) 1px, transparent 1px)",
          backgroundSize: "48px 48px",
        }}
      />

      {/* Subtle green accent line — top */}
      <div
        className="pointer-events-none absolute top-0 left-0 right-0 h-[3px]"
        aria-hidden="true"
        style={{
          background:
            "linear-gradient(90deg, transparent 0%, hsl(84 74% 58% / 0.6) 40%, hsl(119 35% 61% / 0.4) 70%, transparent 100%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4">
        {/* Breadcrumb */}
        <nav aria-label="Breadcrumb" className="mb-8">
          <ol className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <li>
              <Link to="/" className="hover:text-foreground transition-colors duration-150">Home</Link>
            </li>
            <li aria-hidden="true"><ChevronRight className="h-3 w-3" /></li>
            <li className="text-foreground font-medium" aria-current="page">Insights</li>
          </ol>
        </nav>

        <div className="max-w-3xl">
          {/* Eyebrow label */}
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="text-xs uppercase tracking-[0.2em] font-medium text-muted-foreground mb-5"
          >
            Gregg King · Independent SEO Consultant
          </motion.p>

          {/* H1 headline */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.08 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-foreground leading-[1.1] mb-6"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Insights &amp;{" "}
            <span
              className="inline-block"
              style={{
                backgroundImage:
                  "linear-gradient(135deg, hsl(84 74% 44%) 0%, hsl(119 35% 48%) 100%)",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              Commentary
            </span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.16 }}
            className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-2xl mb-10"
          >
            Expert analysis on SEO, AI search, and digital strategy — written for UK businesses navigating a rapidly changing search landscape.
          </motion.p>

          {/* Topic pillars */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut", delay: 0.22 }}
            className="flex flex-wrap gap-3 mb-10"
          >
            {pillars.map(({ icon: Icon, label }) => (
              <span
                key={label}
                className="inline-flex items-center gap-2 rounded-md border border-border bg-background px-3 py-1.5 text-sm font-medium text-foreground"
              >
                <Icon className="h-3.5 w-3.5 text-muted-foreground" />
                {label}
              </span>
            ))}
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut", delay: 0.3 }}
          >
            <Button
              size="lg"
              className="text-base h-11 px-8"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                color: "hsl(222 42% 8%)",
                border: "none",
              }}
              asChild
            >
              <a href="#insights-grid">Browse Articles</a>
            </Button>
          </motion.div>
        </div>

        {/* Editorial note — restrained broadsheet-style aside */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, ease: "easeOut", delay: 0.42 }}
          className="mt-16 md:mt-20 border-t border-border pt-8 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4"
        >
          <p className="text-sm text-muted-foreground max-w-lg">
            Articles reflect Gregg King's independent perspective as an SEO consultant. Content covers SEO strategy, AI-driven search changes, technical optimisation, and digital marketing for UK businesses.
          </p>
          <p className="text-xs uppercase tracking-[0.15em] text-muted-foreground shrink-0">
            greggking.co.uk
          </p>
        </motion.div>
      </div>
    </section>
  );
});

InsightsHero.displayName = "InsightsHero";

export default InsightsHero;
