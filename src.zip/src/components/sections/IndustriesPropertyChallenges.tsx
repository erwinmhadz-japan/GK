import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin, Users, BarChart, Search, Building2, Calendar, Building, Icon } from "lucide-react";

const challenges = [
  {
    icon: MapPin,
    title: "Hyper-Local Competition",
    description:
      "Every town and postcode has multiple established agencies competing for the same vendor and buyer searches. Ranking for 'estate agents in [your area]' requires deep local SEO signals, consistent citation data, and a Google Business Profile strategy that goes beyond a basic listing.",
  },
  {
    icon: Calendar,
    title: "Seasonal Demand Fluctuations",
    description:
      "Property search behaviour shifts throughout the year — spring and autumn are peak listing seasons, while summer and December see slower activity. Without a content strategy aligned to these cycles, you risk losing visibility precisely when vendors are most motivated to instruct.",
  },
  {
    icon: Search,
    title: "Property Listing Visibility",
    description:
      "Individual property listings rarely rank in organic search because they lack structured data, internal linking depth, and proper schema markup. Most agencies lose significant traffic to the portals that could be captured directly on their own site.",
  },
  {
    icon: Users,
    title: "Brand Authority vs. the Portals",
    description:
      "Rightmove and Zoopla dominate generic property searches, but they can't outrank a well-optimised local agency for branded and neighbourhood-specific queries. Building entity authority for your agency brand is the key differentiator.",
  },
  {
    icon: BarChart,
    title: "Thin or Duplicate Content",
    description:
      "Many agency websites share syndicated property descriptions and neighbourhood guides from portal templates. Google suppresses thin, duplicate content — a unique content strategy built around local market insights is essential to earn and hold rankings.",
  },
  {
    icon: Building2,
    title: "Multi-Branch Complexity",
    description:
      "Agencies with multiple offices face the challenge of ranking each branch separately without cannibalising their own authority. Properly structured location pages with dedicated schema and local signals are critical for multi-branch success.",
  },
];

const IndustriesPropertyChallenges = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="max-w-2xl mb-12">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            SEO Challenges for Property
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-5">
            Why Property SEO Is Uniquely Difficult
          </h2>
          <p className="text-lg text-muted-foreground">
            The property sector combines intense local competition, seasonal search
            patterns, and the constant pressure of portal dominance. Understanding
            these challenges is the starting point for building a strategy that
            consistently delivers vendor instructions and qualified buyer enquiries.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {challenges.map(({ icon: Icon, title, description }) => (
            <Card key={title} className="hover-lift shadow-card border-border bg-card">
              <CardHeader className="pb-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-4">
                  <Icon className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-lg text-foreground">{title}</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground text-sm leading-relaxed">{description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
});

IndustriesPropertyChallenges.displayName = "IndustriesPropertyChallenges";
export default IndustriesPropertyChallenges;
