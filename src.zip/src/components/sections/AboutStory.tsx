import React from "react";
import { motion } from "framer-motion";
import { MapPin, Handshake, Target, Shield, CheckCircle, Section } from "lucide-react";

const principles = [
  {
    icon: Handshake,
    title: "Direct accountability",
    body: "You work with me — not an account manager passing briefs to juniors. Every piece of strategy, every recommendation, every deliverable comes from one person who owns the outcome.",
  },
  {
    icon: Target,
    title: "No diluted attention",
    body: "Independent consultants don't divide their focus across forty retainer clients. I keep my client base deliberately small so the work receives the depth it deserves.",
  },
  {
    icon: Shield,
    title: "Honest counsel",
    body: "There is no upsell pressure, no inflated scope, and no dependency on retained fees to keep the lights on. My advice is governed by what is right for your business — full stop.",
  },
];

const differentiators = [
  "Senior-level thinking on every brief — not delegated to trainees",
  "Warrington-based; UK national reach across law, healthcare, finance, and B2B",
  "Decade-long track record across technical SEO, entity SEO, and AI search",
  "Transparent communication — plain English, no jargon, no spin",
  "Commercial focus — organic performance measured against business outcomes",
  "Established methodology across audits, retainers, schema, and digital PR",
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
    },
  },
};

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut" },
  },
};

const AboutStory = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="about-story"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* — Section header — */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={containerVariants}
          className="max-w-3xl mb-16 md:mb-20"
        >
          <motion.span
            variants={fadeUp}
            className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium"
          >
            About Gregg King
          </motion.span>

          <motion.h2
            variants={fadeUp}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight mb-6"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            A Consultant, Not an Agency
          </motion.h2>

          <motion.p
            variants={fadeUp}
            className="text-lg md:text-xl text-muted-foreground leading-relaxed"
          >
            I built this practice on a deliberate choice: to remain independent.
            No partners, no junior team, no account managers between you and the
            person doing the work. What you see is what you get — a senior SEO
            consultant who is personally accountable for every brief I take on.
          </motion.p>
        </motion.div>

        {/* — Two-column: story + image — */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-start mb-20 md:mb-24">

          {/* Left — narrative prose */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={containerVariants}
            className="space-y-6"
          >
            <motion.p variants={fadeUp} className="text-base md:text-lg text-muted-foreground leading-relaxed">
              I'm Gregg King — an independent SEO consultant based in Warrington,
              Cheshire, working with businesses across the UK. My background spans
              well over a decade of hands-on SEO practice: technical audits,
              entity-led authority building, content strategy, schema implementation,
              local SEO, digital PR, and — increasingly — optimisation for AI search
              platforms including ChatGPT, Perplexity, and Google's AI Overviews.
            </motion.p>

            <motion.p variants={fadeUp} className="text-base md:text-lg text-muted-foreground leading-relaxed">
              The sectors I work in are trust-led and competitive: law firms and
              solicitors, healthcare and private clinics, financial services,
              estate agents, and B2B professional services. These are environments
              where credibility matters as much to Google as it does to prospective
              clients. Generic SEO doesn't cut through. Depth does.
            </motion.p>

            <motion.p variants={fadeUp} className="text-base md:text-lg text-muted-foreground leading-relaxed">
              I chose to remain independent because the agency model, in my
              experience, too often puts distance between senior expertise and the
              client who needs it. Founders and marketing leads deserve counsel from
              someone who has thought carefully about their specific situation — not
              a templated deliverable assembled under time pressure. That's the
              practice I've built, and the way I intend to continue working.
            </motion.p>

            {/* Location badge */}
            <motion.div variants={fadeUp} className="flex items-center gap-2 pt-2">
              <MapPin className="h-4 w-4 text-primary flex-shrink-0" />
              <span className="text-sm text-muted-foreground">
                Based in Warrington, Cheshire — serving clients across the UK
              </span>
            </motion.div>
          </motion.div>

          {/* Right — image + overlay card */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.7, ease: "easeOut", delay: 0.1 }}
            className="relative"
          >
            <div className="relative rounded-md overflow-hidden aspect-[4/3] shadow-[0_4px_24px_rgba(25,31,58,0.14)]">
              <img
                src="https://images.unsplash.com/photo-1709281847780-2b34c28853c0?w=800&h=600&fit=crop"
                alt="Gregg King, independent SEO consultant, working at a desk"
                width="800"
                height="600"
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover"
              />
              {/* Subtle brand tint overlay */}
              <div className="absolute inset-0 bg-gradient-to-br from-[hsl(225_28%_14%/0.35)] to-transparent pointer-events-none" />
            </div>

            {/* Floating credibility card */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.4 }}
              className="absolute -bottom-6 -left-4 md:-left-8 bg-card border border-border rounded-md px-5 py-4 shadow-[0_8px_32px_rgba(25,31,58,0.18)] max-w-[240px]"
            >
              <p className="text-xs uppercase tracking-widest text-muted-foreground mb-1 font-medium">
                Practice model
              </p>
              <p className="text-sm font-semibold text-foreground leading-snug">
                Solo consultant. One point of contact. Full accountability.
              </p>
            </motion.div>
          </motion.div>
        </div>

        {/* — Principles grid — */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={containerVariants}
          className="mb-20 md:mb-24"
        >
          <motion.h3
            variants={fadeUp}
            className="text-xl md:text-2xl font-semibold text-foreground mb-8"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            What independence means in practice
          </motion.h3>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {principles.map((item) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.title}
                  variants={fadeUp}
                  className="bg-card border border-border rounded-md p-6 shadow-[0_2px_12px_rgba(25,31,58,0.08)] hover:shadow-[0_6px_24px_rgba(25,31,58,0.14)] transition-shadow duration-300"
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mb-4">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <h4 className="text-base font-semibold text-foreground mb-2">
                    {item.title}
                  </h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {item.body}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* — Differentiators list — */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={containerVariants}
          className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start"
        >
          <motion.div variants={fadeUp}>
            <h3
              className="text-xl md:text-2xl font-semibold text-foreground mb-3"
              style={{ fontFamily: "Sora, sans-serif" }}
            >
              Why clients choose to work with me
            </h3>
            <p className="text-muted-foreground text-sm leading-relaxed">
              The businesses I work with are not shopping for the cheapest SEO
              provider. They need a consultant who can think strategically, communicate
              clearly, and deliver measurable progress in competitive markets.
            </p>
          </motion.div>

          <motion.ul variants={containerVariants} className="space-y-3">
            {differentiators.map((point, i) => (
              <motion.li
                key={i}
                variants={fadeUp}
                className="flex items-start gap-3"
              >
                <CheckCircle className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
                <span className="text-sm md:text-base text-foreground leading-relaxed">
                  {point}
                </span>
              </motion.li>
            ))}
          </motion.ul>
        </motion.div>

      </div>
    </section>
  );
});

AboutStory.displayName = "AboutStory";

export default AboutStory;
