import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, ArrowRight, CheckCircle } from "lucide-react";

const BirminghamHero: React.FC = () => {
  return (
    <ImageBackground
      src="https://images.unsplash.com/photo-1573496130141-209d200cebd8?w=1920&h=1080&fit=crop"
      alt="Two women in business suits reviewing SEO strategy for Birmingham clients"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center"
      id="birmingham-hero"
    >
      <div className="container relative z-10 py-24 md:py-36">
        <div className="flex items-center gap-2 mb-6">
          <MapPin className="h-4 w-4 text-primary" />
          <span className="text-sm uppercase tracking-[0.2em] text-white/80 font-medium">
            Birmingham, West Midlands
          </span>
        </div>

        <h1 className="text-4xl md:text-6xl font-bold text-white max-w-3xl leading-tight mb-6">
          SEO Consultancy for{" "}
          <span className="text-gradient-green">Birmingham Businesses</span>
        </h1>

        <p className="text-lg md:text-xl text-white/90 max-w-2xl mb-8 leading-relaxed">
          Birmingham is the UK's second-largest city and one of its most competitive
          digital markets. I help ambitious Birmingham businesses win search visibility,
          outperform local rivals, and grow sustainably through expert, independent SEO
          strategy.
        </p>

        <div className="flex flex-col sm:flex-row gap-4 mb-10">
          <Button
            size="lg"
            className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold px-8"
            asChild
          >
            <a href="/contact">
              Get a Free Birmingham SEO Audit
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-transparent text-white border-white hover:bg-white/10 font-semibold px-8"
            asChild
          >
            <a href="/services">Explore Services</a>
          </Button>
        </div>

        <div className="flex flex-wrap gap-4">
          {[
            "Independent SEO Consultant",
            "Birmingham Market Specialist",
            "No Long-Term Contracts",
          ].map((item) => (
            <div key={item} className="flex items-center gap-2">
              <CheckCircle className="h-4 w-4 text-primary shrink-0" />
              <span className="text-white/80 text-sm">{item}</span>
            </div>
          ))}
        </div>
      </div>
    </ImageBackground>
  );
};

export default BirminghamHero;
