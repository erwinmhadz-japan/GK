import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Quote, Star, ArrowRight, Stars, View } from "lucide-react";

const testimonials = [
  {
    quote:
      "Gregg completely transformed our local visibility. Within five months we were ranking in the top three for our core Warrington search terms — and enquiries from new customers more than doubled. No fluff, just real results.",
    name: "Sarah Mitchell",
    role: "Director",
    company: "Warrington Accounting Solutions",
    image:
      "https://images.unsplash.com/photo-1580894732444-8ecded7900cd?w=400&h=400&fit=crop&crop=face",
    rating: 5,
  },
  {
    quote:
      "We'd tried two previous agencies with little to show for it. Gregg audited our site, fixed the technical issues, rewrote our service pages, and rebuilt our citations from scratch. We now appear in the Google Local Pack for every key phrase across Warrington and Cheshire.",
    name: "James Thornton",
    role: "Managing Director",
    company: "Thornton Electrical — Warrington",
    image:
      "https://images.unsplash.com/photo-1734830268394-6c4a1f165af1?w=400&h=400&fit=crop&crop=face",
    rating: 5,
  },
  {
    quote:
      "The depth of understanding Gregg brought to our North West market was impressive. He mapped out exactly which geographic terms we were missing and built a content strategy that's driven a 40% increase in organic traffic from the Warrington and Widnes areas.",
    name: "Rachel Pemberton",
    role: "Marketing Manager",
    company: "NorthWest Legal Services",
    image:
      "https://images.unsplash.com/photo-1699899657680-421c2c2d5064?w=400&h=400&fit=crop&crop=face",
    rating: 5,
  },
];

const WarringtonTestimonials = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
            Client Results
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            What Warrington Businesses Say
          </h2>
          <p className="text-base text-muted-foreground leading-relaxed">
            Real results from real businesses across Warrington and the wider
            Cheshire and North West region.
          </p>
        </div>

        {/* Testimonial cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-14">
          {testimonials.map(({ quote, name, role, company, image, rating }) => (
            <div
              key={name}
              className="flex flex-col p-6 rounded-xl border border-border bg-card shadow-card hover-lift transition-shadow"
            >
              {/* Stars */}
              <div className="flex gap-0.5 mb-4">
                {Array.from({ length: rating }).map((_, i) => (
                  <Star
                    key={i}
                    className="h-4 w-4 text-primary fill-primary"
                  />
                ))}
              </div>

              {/* Quote */}
              <Quote className="h-6 w-6 text-primary/30 mb-3" />
              <p className="text-sm text-muted-foreground leading-relaxed flex-1 italic">
                "{quote}"
              </p>

              {/* Author */}
              <div className="mt-6 flex items-center gap-3 pt-4 border-t border-border">
                <img
                  src={image}
                  alt={`${name}, ${role} at ${company}`}
                  width={44}
                  height={44}
                  className="h-11 w-11 rounded-full object-cover shrink-0"
                  loading="lazy"
                />
                <div>
                  <p className="text-sm font-semibold text-foreground">
                    {name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {role}, {company}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Case studies CTA */}
        <div className="text-center">
          <p className="text-sm text-muted-foreground mb-4">
            Want to see the data behind these results?
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
              asChild
            >
              <a href="#case-studies-cta">
                View Case Studies
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="border-border text-foreground hover:bg-muted"
              asChild
            >
              <a href="/contact">Start a Conversation</a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
});

WarringtonTestimonials.displayName = "WarringtonTestimonials";

export default WarringtonTestimonials;
