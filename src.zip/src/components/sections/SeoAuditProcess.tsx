import React from "react";
import { motion } from "framer-motion";
import { Phone, ScanSearch, FileText, Video } from "lucide-react";

const steps = [
  {
    number: "01",
    icon: Phone,
    title: "Discovery & Briefing",
    description:
      "We begin with a structured discovery call. I take time to understand your business, your target market, the competitive landscape, and what you've already tried. This context shapes every aspect of the audit — it's not a one-size-fits-all process.",
    detail:
      "Typically 30–45 minutes. I'll ask about your current traffic picture, priority pages, known technical issues, and any previous SEO work.",
  },
  {
    number: "02",
    icon: ScanSearch,
    title: "Technical & Content Analysis",
    description:
      "I conduct a thorough manual and tool-assisted review of your site. This covers technical foundations, crawlability, indexation, on-page signals, content quality, internal linking, authority, schema implementation, entity coverage, and AI search visibility.",
    detail:
      "This is where most issues are uncovered. I cross-reference findings across multiple data sources rather than relying on a single automated report.",
  },
  {
    number: "03",
    icon: FileText,
    title: "Written Audit Report",
    description:
      "You receive a comprehensive written report — structured, prioritised, and written for a business audience, not just a technical one. Every issue is explained in plain English with a clear recommendation and an indication of expected impact.",
    detail:
      "Reports are typically 30–60 pages and organised by priority: critical, high, medium, and informational. Findings are evidenced, not assumed.",
  },
  {
    number: "04",
    icon: Video,
    title: "Strategy Debrief Call",
    description:
      "Once you've had time to review the report, we schedule a debrief call to walk through the findings together. I explain the rationale behind each recommendation, answer your questions, and help you decide what to tackle first.",
    detail:
      "This is where the audit becomes actionable. You leave with a clear, prioritised roadmap — whether you implement it in-house or engage me for ongoing support.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.15,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" },
  },
};

const SeoAuditProcess = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seo-audit-process"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.65, ease: "easeOut" }}
          className="mb-14 md:mb-20"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            The Process
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground font-[Sora,sans-serif] max-w-2xl leading-tight">
            How the Audit Works
          </h2>
          <p className="mt-5 text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
            Every audit I carry out is conducted personally — not outsourced,
            not automated. The four-stage process below is designed to give you
            a complete, honest picture of where your site stands and a clear
            path forward.
          </p>
        </motion.div>

        {/* Steps */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-10"
        >
          {steps.map((step) => {
            const Icon = step.icon;
            return (
              <motion.div
                key={step.number}
                variants={itemVariants}
                className="group relative bg-background border border-border rounded-md p-8 md:p-10 shadow-sm hover:shadow-md transition-shadow duration-300"
              >
                {/* Step number — large background numeral */}
                <span
                  className="absolute top-6 right-7 text-7xl font-bold select-none pointer-events-none"
                  style={{ color: "hsl(84 74% 60% / 0.08)" }}
                  aria-hidden="true"
                >
                  {step.number}
                </span>

                {/* Icon + number row */}
                <div className="flex items-center gap-4 mb-5">
                  <div className="flex items-center justify-center w-11 h-11 rounded-md bg-primary/10 shrink-0">
                    <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
                  </div>
                  <span className="text-xs font-semibold uppercase tracking-[0.18em] text-muted-foreground">
                    Step {step.number}
                  </span>
                </div>

                {/* Title */}
                <h3 className="text-xl md:text-2xl font-semibold text-foreground mb-3 font-[Sora,sans-serif] leading-snug">
                  {step.title}
                </h3>

                {/* Description */}
                <p className="text-base text-muted-foreground leading-relaxed mb-5">
                  {step.description}
                </p>

                {/* Detail callout */}
                <div className="border-l-2 border-primary/40 pl-4">
                  <p className="text-sm text-muted-foreground leading-relaxed italic">
                    {step.detail}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Connector note */}
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
          className="mt-12 text-sm text-muted-foreground text-center max-w-xl mx-auto leading-relaxed"
        >
          The entire process is handled by me, directly. You'll deal with one
          person throughout — not a project manager passing work to a junior
          team.
        </motion.p>
      </div>
    </section>
  );
});

SeoAuditProcess.displayName = "SeoAuditProcess";

export default SeoAuditProcess;
