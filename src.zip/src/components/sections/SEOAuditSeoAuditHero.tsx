import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { CheckCircle, ArrowRight, SearchCheck, FileSearch, Target, Icon, Search } from "lucide-react";

const trustItems = [
  "Independent consultant — not automated software",
  "Actionable recommendations, not generic reports",
  "Delivered with a personal debrief call",
];

const auditBadges = [
  { icon: SearchCheck, label: "Technical Health" },
  { icon: FileSearch, label: "Content Gaps" },
  { icon: Target, label: "AI Search Visibility" },
];

const SEOAuditSeoAuditHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seoaudit-seo-audit-hero"
      className="relative py-20 md:py-32 border-t border-border bg-muted overflow-hidden"
    >
      {/* Subtle background dot grid texture */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-30"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(214 32% 60% / 0.18) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      {/* Navy panel accent — left edge */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-0 top-0 h-full w-1 md:w-1.5"
        style={{
          background:
            "linear-gradient(180deg, hsl(84 74% 60%) 0%, hsl(119 35% 61%) 100%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">

          {/* LEFT COLUMN — primary copy */}
          <div className="flex flex-col gap-6">

            {/* Eyebrow label */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, ease: "easeOut", delay: 0 }}
            >
              <span
                className="inline-block text-xs uppercase tracking-[0.22em] font-medium"
                style={{ color: "hsl(214 32% 60%)" }}
              >
                Independent SEO Consultant UK
              </span>
            </motion.div>

            {/* H1 */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, ease: "easeOut", delay: 0.08 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold leading-tight tracking-tight text-foreground max-w-2xl"
              style={{ fontFamily: "Sora, sans-serif" }}
            >
              SEO Audit UK
            </motion.h1>

            {/* Subheadline */}
            <motion.p
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, ease: "easeOut", delay: 0.16 }}
              className="text-lg md:text-xl leading-relaxed text-muted-foreground max-w-xl"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              A thorough, independent SEO audit that surfaces what&apos;s holding your site back — and what to do about it.
            </motion.p>

            {/* Trust checklist */}
            <motion.ul
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, ease: "easeOut", delay: 0.24 }}
              className="flex flex-col gap-3"
              aria-label="Audit trust signals"
            >
              {trustItems.map((item, i) => (
                <li key={i} className="flex items-start gap-3">
                  <CheckCircle
                    className="h-5 w-5 shrink-0 mt-0.5"
                    style={{ color: "hsl(119 35% 61%)" }}
                    aria-hidden="true"
                  />
                  <span className="text-sm md:text-base text-foreground leading-snug">
                    {item}
                  </span>
                </li>
              ))}
            </motion.ul>

            {/* CTA block */}
            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, ease: "easeOut", delay: 0.32 }}
              className="flex flex-col sm:flex-row items-start sm:items-center gap-4 pt-2"
            >
              <Button
                size="lg"
                asChild
                className="h-12 px-8 text-base font-semibold rounded-md text-foreground"
                style={{
                  background:
                    "linear-gradient(135deg, hsl(84 74% 60%) 0%, hsl(119 35% 61%) 100%)",
                }}
              >
                <Link to="/contact">
                  Request Your Free SEO Audit
                  <ArrowRight className="ml-2 h-4 w-4" aria-hidden="true" />
                </Link>
              </Button>

              <Badge
                variant="secondary"
                className="text-xs font-semibold uppercase tracking-wider px-3 py-1.5 rounded-md"
                style={{
                  background: "hsl(84 74% 60% / 0.12)",
                  color: "hsl(119 35% 45%)",
                  border: "1px solid hsl(84 74% 60% / 0.3)",
                }}
              >
                FREE GBP AUDIT
              </Badge>
            </motion.div>

            {/* Positioning note */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, ease: "easeOut", delay: 0.42 }}
              className="text-xs text-muted-foreground"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              Conducted personally by Gregg King — SEO consultant based in Warrington, Cheshire.
              <br className="hidden sm:block" />
              Serving UK businesses across law, finance, healthcare, and professional services.
            </motion.p>
          </div>

          {/* RIGHT COLUMN — audit scope visual card */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, ease: "easeOut", delay: 0.2 }}
            className="flex flex-col gap-5"
            aria-label="What your SEO audit covers"
          >
            {/* Consultant card */}
            <article
              className="rounded-md border border-border bg-background shadow-md p-6 flex flex-col gap-4"
              style={{
                boxShadow:
                  "0 4px 24px hsl(225 28% 14% / 0.10), 0 1px 4px hsl(225 28% 14% / 0.07)",
              }}
            >
              <div className="flex items-center gap-3">
                <img
                  src="https://images.unsplash.com/photo-1730851357916-3802b6405271?w=400&h=400&fit=crop&crop=face"
                  alt="Gregg King, independent SEO consultant based in Warrington UK"
                  width={48}
                  height={48}
                  className="h-12 w-12 rounded-full object-cover shrink-0 border border-border"
                  loading="eager"
                />
                <div>
                  <p
                    className="text-sm font-semibold text-foreground leading-tight"
                    style={{ fontFamily: "Sora, sans-serif" }}
                  >
                    Gregg King
                  </p>
                  <p className="text-xs text-muted-foreground leading-tight">
                    Independent SEO Consultant · Warrington, Cheshire
                  </p>
                </div>
              </div>

              <blockquote className="text-sm text-muted-foreground leading-relaxed border-l-2 border-border pl-4 italic">
                &ldquo;I conduct every audit personally — reviewing your site&apos;s technical foundations, content signals, backlink profile, and AI search visibility, then walking you through my findings in a structured debrief call.&rdquo;
              </blockquote>
            </article>

            {/* Audit scope badges */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {auditBadges.map(({ icon: Icon, label }, i) => (
                <article
                  key={i}
                  className="rounded-md border border-border bg-background px-4 py-4 flex flex-col items-start gap-2"
                  style={{
                    boxShadow: "0 2px 8px hsl(225 28% 14% / 0.07)",
                  }}
                >
                  <div
                    className="flex h-9 w-9 items-center justify-center rounded-md"
                    style={{
                      background: "hsl(84 74% 60% / 0.10)",
                    }}
                    aria-hidden="true"
                  >
                    <Icon
                      className="h-4 w-4"
                      style={{ color: "hsl(119 35% 45%)" }}
                    />
                  </div>
                  <p
                    className="text-xs font-semibold text-foreground leading-tight"
                    style={{ fontFamily: "Sora, sans-serif" }}
                  >
                    {label}
                  </p>
                </article>
              ))}
            </div>

            {/* Audience note */}
            <div
              className="rounded-md border border-border bg-background px-5 py-4"
              style={{
                boxShadow: "0 2px 8px hsl(225 28% 14% / 0.07)",
              }}
            >
              <p className="text-xs uppercase tracking-widest font-medium mb-2" style={{ color: "hsl(214 32% 60%)" }}>
                Suited for
              </p>
              <ul className="grid grid-cols-2 gap-x-4 gap-y-1.5">
                {[
                  "Law firms & solicitors",
                  "Healthcare providers",
                  "Financial services",
                  "Estate agents",
                  "B2B professional services",
                  "UK-based businesses",
                ].map((sector, i) => (
                  <li key={i} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                    <span
                      className="h-1.5 w-1.5 rounded-full shrink-0"
                      style={{ background: "hsl(119 35% 61%)" }}
                      aria-hidden="true"
                    />
                    {sector}
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>

        </div>
      </div>
    </section>
  );
});

SEOAuditSeoAuditHero.displayName = "SEOAuditSeoAuditHero";

export default SEOAuditSeoAuditHero;
