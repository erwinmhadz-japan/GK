import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { MapPin, ChevronRight, ArrowRight, Quote } from "lucide-react";

const manchesterAreas = [
  "Manchester City Centre",
  "Spinningfields",
  "Deansgate",
  "Northern Quarter",
  "MediaCity, Salford",
  "Trafford Park",
  "Stockport",
  "Bury",
  "Bolton",
  "Oldham",
  "Rochdale",
  "Wigan",
  "Tameside",
  "Cheadle",
  "Didsbury",
  "Chorlton",
];

const otherLocations = [
  { name: "Liverpool", href: "#liverpool-cta" },
  { name: "Leeds", href: "#leeds-cta" },
  { name: "Birmingham", href: "#birmingham-cta" },
  { name: "Sheffield", href: "#sheffield-cta" },
  { name: "London", href: "#london-cta" },
  { name: "Warrington", href: "#warrington-cta" },
];

const ManchesterLocations = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="manchester-locations"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-14 items-start">
          {/* Left: Areas covered */}
          <div>
            <motion.span
              initial={{ opacity: 0, y: 12 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
              className="inline-block text-xs uppercase tracking-[0.2em] text-primary font-semibold mb-4"
            >
              Coverage Area
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.55, delay: 0.06 }}
              className="text-3xl md:text-4xl font-bold text-foreground mb-5"
            >
              Greater Manchester SEO Coverage
            </motion.h2>
            <motion.p
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.55, delay: 0.12 }}
              className="text-base text-muted-foreground leading-relaxed mb-8"
            >
              Our Manchester SEO services extend across the entire Greater Manchester conurbation.
              Whether your customers are in Spinningfields or Stockport, we build localised
              search strategies that capture intent borough by borough.
            </motion.p>

            {/* Area tags */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: 0.14 }}
              className="flex flex-wrap gap-2 mb-8"
            >
              {manchesterAreas.map((area) => (
                <span
                  key={area}
                  className="inline-flex items-center gap-1.5 text-xs font-medium bg-background border border-border text-muted-foreground rounded-full px-3 py-1.5"
                >
                  <MapPin className="h-3 w-3 text-primary" />
                  {area}
                </span>
              ))}
            </motion.div>

            <motion.div
              initial={{ opacity: 0, y: 16 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5 }}
            >
              <Button size="lg" asChild>
                <Link to="/contact">
                  Get Manchester SEO Quote
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
            </motion.div>
          </div>

          {/* Right: Office details + other locations */}
          <div className="space-y-8">
            {/* Office / presence */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.55, delay: 0.08 }}
              className="bg-background rounded-xl border border-border p-7"
            >
              <div className="flex items-center gap-2 mb-4">
                <MapPin className="h-5 w-5 text-primary" />
                <h3 className="text-base font-semibold text-foreground">Manchester Presence</h3>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                Based in Warrington — equidistant between Manchester and Liverpool —
                we work with Manchester businesses on-site and remotely. Regular
                meetings in Manchester city centre, Spinningfields, and MediaCity
                available for retained clients.
              </p>
              <address className="not-italic text-sm text-muted-foreground space-y-1">
                <div className="font-medium text-foreground">Service Area: Greater Manchester</div>
                <div>City Centre · Salford · Trafford · Stockport</div>
                <div>Bury · Bolton · Oldham · Rochdale · Wigan</div>
              </address>
            </motion.div>

            {/* Other location pages */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.55, delay: 0.14 }}
              className="bg-background rounded-xl border border-border p-7"
            >
              <h3 className="text-base font-semibold text-foreground mb-4">
                SEO Services in Other UK Cities
              </h3>
              <ul className="space-y-2">
                {otherLocations.map((loc) => (
                  <li key={loc.name}>
                    <Link
                      to={loc.href}
                      className="flex items-center justify-between group text-sm text-muted-foreground hover:text-primary transition-colors py-1"
                    >
                      <span className="flex items-center gap-2">
                        <MapPin className="h-3.5 w-3.5 text-primary" />
                        {loc.name}
                      </span>
                      <ChevronRight className="h-4 w-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                    </Link>
                  </li>
                ))}
              </ul>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
});

ManchesterLocations.displayName = "ManchesterLocations";

export default ManchesterLocations;
