import React from "react";
import { motion } from "framer-motion";
import { Globe, ScanSearch, Link2, FileText, Database, Eye, CheckCircle, ArrowRight, Key, Search, Section } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const retrievalSteps = [
  {
    number: "01",
    icon: Globe,
    title: "Bing Web Index",
    description:
      "Copilot is built on Bing's search infrastructure. Before a response is generated, Bing's crawler must have indexed your pages. If Bing cannot crawl and index your site, your content will not enter Copilot's retrieval pool — no matter how authoritative your brand may be.",
    detail: "Bing indexation is the entry point, not an afterthought.",
  },
  {
    number: "02",
    icon: ScanSearch,
    title: "Query Interpretation",
    description:
      "When a user submits a prompt, Copilot parses the intent behind the query. It identifies the topic, context, and information type needed — whether that's a definition, a comparison, a recommendation, or an explanation — and maps this against its knowledge of relevant sources.",
    detail: "Intent resolution happens before any source is selected.",
  },
  {
    number: "03",
    icon: Database,
    title: "Retrieval-Augmented Generation",
    description:
      "Copilot uses a technique called Retrieval-Augmented Generation (RAG). Rather than relying on static pre-trained knowledge alone, it actively retrieves live web content at inference time. This means freshness, crawlability, and content clarity all influence which pages get pulled into context.",
    detail: "RAG makes live web content part of every AI response.",
  },
  {
    number: "04",
    icon: FileText,
    title: "Content Evaluation",
    description:
      "From its retrieval pool, Copilot evaluates content for relevance, clarity, and trustworthiness. Well-structured pages — with clear headings, defined entities, concise factual statements, and authoritative sourcing — are more likely to be selected. Dense, ambiguous, or low-signal content is filtered out.",
    detail: "Clarity and structure determine whether content is selected.",
  },
  {
    number: "05",
    icon: Link2,
    title: "Citation Selection",
    description:
      "When Copilot includes citations in its response, it prioritises sources that are clearly attributed, structurally coherent, and already referenced by authoritative third parties. Brand mentions in press, directories, and trusted publications increase the likelihood of citation inclusion.",
    detail: "Third-party authority signals influence citation probability.",
  },
  {
    number: "06",
    icon: Eye,
    title: "Response Synthesis",
    description:
      "Copilot synthesises information from multiple retrieved sources into a single coherent answer. Brands that consistently appear across multiple trusted sources — rather than relying on a single page — are more likely to be represented in the synthesised output and attributed by name.",
    detail: "Consistent entity presence across sources reinforces attribution.",
  },
];

const keySignals = [
  {
    label: "Bing Indexation",
    description: "Pages must be crawlable and indexed by Bing — not just Google.",
  },
  {
    label: "Structured Content",
    description: "Clear headings, concise statements, and logical hierarchy improve retrieval likelihood.",
  },
  {
    label: "Entity Authority",
    description: "Named entities (your brand, services, people) must be clearly defined and consistently referenced.",
  },
  {
    label: "Third-Party Mentions",
    description: "Citations in press, directories, and authoritative sources improve citation probability.",
  },
  {
    label: "E-E-A-T Signals",
    description: "Experience, expertise, authoritativeness, and trustworthiness are evaluated by Bing's quality layer.",
  },
  {
    label: "Content Freshness",
    description: "RAG pulls live content — recently updated, well-maintained pages have an advantage.",
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay: i * 0.08 },
  }),
};

const CopilotVisibilityWhatIs = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="copilot-visibility-what-is"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section Header */}
        <motion.div
          className="max-w-3xl mb-14 md:mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={fadeUp}
          custom={0}
        >
          <Badge
            variant="outline"
            className="mb-5 text-xs uppercase tracking-[0.18em] border-border text-muted-foreground font-medium"
          >
            How It Works
          </Badge>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight mb-5">
            How Microsoft Copilot Retrieves and Cites Sources
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl">
            Microsoft Copilot is powered by Bing's search infrastructure combined with large language model
            reasoning. Understanding its retrieval architecture helps UK businesses and marketing leads
            appreciate why certain brands appear in AI-generated responses — and others do not.
          </p>
        </motion.div>

        {/* Retrieval Steps */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16 md:mb-24">
          {retrievalSteps.map((step, index) => {
            const Icon = step.icon;
            return (
              <motion.div
                key={step.number}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-40px" }}
                variants={fadeUp}
                custom={index * 0.5 + 1}
                className="group bg-background border border-border rounded-md p-6 hover:shadow-[0_4px_24px_0_hsl(225_28%_14%/0.10)] transition-shadow duration-300"
              >
                <div className="flex items-start gap-4 mb-4">
                  <div className="flex-shrink-0 flex items-center justify-center w-10 h-10 rounded-md bg-primary/10">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <span className="text-xs font-mono text-muted-foreground mt-3 tracking-widest">
                    {step.number}
                  </span>
                </div>
                <h3 className="text-base font-semibold text-foreground mb-2">{step.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                  {step.description}
                </p>
                <p className="text-xs text-primary font-medium flex items-center gap-1.5">
                  <CheckCircle className="h-3.5 w-3.5 shrink-0" />
                  {step.detail}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Explainer Block */}
        <motion.div
          className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-start mb-16 md:mb-24"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={fadeUp}
          custom={0}
        >
          <div>
            <h3 className="text-xl md:text-2xl font-bold text-foreground mb-4 leading-snug">
              Why This Matters for UK Businesses
            </h3>
            <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-4">
              Search behaviour is shifting. A growing number of UK consumers and B2B buyers are using
              Microsoft Copilot — integrated into Windows, Microsoft 365, and Edge — to answer questions
              before they ever visit a website. If your brand is not surfacing in those AI-generated responses,
              a meaningful share of your potential audience may not encounter you at all.
            </p>
            <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-4">
              This is particularly relevant in trust-led sectors — law, finance, healthcare, and professional
              services — where Copilot users often ask advisory questions. Brands that appear as cited sources
              in those responses benefit from an implicit credibility signal that is difficult to replicate
              through paid or organic search alone.
            </p>
            <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
              Understanding how Copilot's retrieval layer works is the first step toward influencing it.
              The signals it relies on — Bing indexation, entity clarity, structured content, and
              third-party authority — are the same fundamentals that underpin strong technical SEO.
            </p>
          </div>

          <div className="bg-background border border-border rounded-md p-6 md:p-8">
            <h4 className="text-sm font-semibold text-foreground mb-5 uppercase tracking-wider">
              Key Signals Copilot Evaluates
            </h4>
            <ul className="space-y-4">
              {keySignals.map((signal, index) => (
                <motion.li
                  key={signal.label}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  variants={fadeUp}
                  custom={index * 0.5}
                  className="flex items-start gap-3"
                >
                  <CheckCircle className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                  <div>
                    <span className="text-sm font-semibold text-foreground">{signal.label}</span>
                    <span className="text-sm text-muted-foreground"> — {signal.description}</span>
                  </div>
                </motion.li>
              ))}
            </ul>
          </div>
        </motion.div>

        {/* Contextual Note */}
        <motion.div
          className="border-t border-border pt-10"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.55, ease: "easeOut" }}
        >
          <div className="max-w-2xl">
            <p className="text-xs text-muted-foreground leading-relaxed mb-3">
              <span className="font-semibold text-foreground">A note on Bing vs Google: </span>
              Many UK businesses focus their indexation efforts entirely on Google. Copilot's reliance on
              Bing's index means that Bing-specific crawlability, structured data rendering, and Webmaster
              Tools verification are independently relevant — even if Google indexation is already strong.
              These are not interchangeable.
            </p>
            <a
              href="/ai-search-optimisation"
              className="inline-flex items-center gap-1.5 text-xs font-medium text-primary hover:underline underline-offset-4 transition-colors"
            >
              Read more about AI search optimisation
              <ArrowRight className="h-3.5 w-3.5" />
            </a>
          </div>
        </motion.div>

      </div>
    </section>
  );
});

CopilotVisibilityWhatIs.displayName = "CopilotVisibilityWhatIs";

export default CopilotVisibilityWhatIs;
