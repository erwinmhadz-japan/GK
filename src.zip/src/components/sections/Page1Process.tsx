import React from "react";
import { motion } from "framer-motion";
import { Search, FileText, Rocket, LineChart, Section } from "lucide-react";

const steps = [
  {
    number: "01",
    icon: Search,
    title: "Discovery & Audit",
    description:
      "We start with a detailed conversation about your business goals, current SEO challenges, and competitive landscape. I then conduct a thorough technical and content audit to identify exactly where the opportunities lie.",
    highlights: ["Technical crawl analysis", "Competitor gap review", "Keyword opportunity mapping"],
  },
  {
    number: "02",
    icon: FileText,
    title: "Bespoke Strategy",
    description:
      "No off-the-shelf templates here. I craft a tailored SEO strategy aligned to your specific objectives — whether that's local visibility, national reach, entity authority, or AI-search presence.",
    highlights: ["Prioritised action plan", "Clear KPI framework", "On-page & off-page roadmap"],
  },
  {
    number: "03",
    icon: Rocket,
    title: "Execution & Optimisation",
    description:
      "Strategy only works when it's implemented properly. I work directly with your team or handle implementation end-to-end — from schema markup and technical fixes to content strategy and digital PR.",
    highlights: ["Hands-on implementation", "Developer-ready recommendations", "Content & link building"],
  },
  {
    number: "04",
    icon: LineChart,
    title: "Reporting & Iteration",
    description:
      "You'll receive clear, jargon-free monthly reports that focus on what matters: rankings, traffic, and leads. We review progress together and iterate the strategy as your market evolves.",
    highlights: ["Monthly performance reports", "Direct consultant access", "Ongoing strategy refinement"],
  },
];

const Page1Process = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="page1-process"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      {/* Subtle dot grid */}
      <div
        className="absolute inset-0 pointer-events-none bg-dot-grid opacity-40"
        aria-hidden="true"
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="text-center mb-16 md:mb-20"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            My Process
          </span>
          <h2
            className="text-3xl md:text-4xl font-bold text-foreground max-w-2xl mx-auto leading-tight mb-4"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            How We Go From Discovery to Measurable Growth
          </h2>
          <p className="text-base md:text-lg text-muted-foreground max-w-xl mx-auto leading-relaxed">
            A clear, structured approach that keeps you informed at every stage — and focused on outcomes that matter to your business.
          </p>
        </motion.div>

        {/* Steps */}
        <div className="relative">
          {/* Vertical connector line (desktop) */}
          <div
            className="hidden lg:block absolute left-1/2 top-0 bottom-0 w-px bg-border -translate-x-1/2"
            aria-hidden="true"
          />

          <div className="space-y-12 md:space-y-16">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isEven = index % 2 === 0;
              return (
                <motion.div
                  key={step.number}
                  initial={{ opacity: 0, y: 32 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.6, ease: "easeOut", delay: index * 0.08 }}
                  className={`relative grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center ${
                    isEven ? "" : "lg:flex lg:flex-row-reverse"
                  }`}
                >
                  {/* Content card */}
                  <div className={`${isEven ? "lg:pr-12" : "lg:pl-12"}`}>
                    <div className="bg-card border border-border rounded-xl p-7 shadow-card hover:shadow-card-hover transition-shadow duration-300">
                      <div className="flex items-start gap-4 mb-4">
                        <div
                          className="flex h-11 w-11 flex-shrink-0 items-center justify-center rounded-lg"
                          style={{
                            background: "linear-gradient(135deg, hsl(84 74% 58% / 0.15) 0%, hsl(119 35% 61% / 0.10) 100%)",
                          }}
                        >
                          <Icon
                            className="h-5 w-5"
                            style={{ color: "hsl(88 59% 56%)" }}
                            aria-hidden="true"
                          />
                        </div>
                        <div>
                          <p
                            className="text-xs font-bold uppercase tracking-[0.2em] mb-0.5"
                            style={{ color: "hsl(88 59% 56%)" }}
                          >
                            Step {step.number}
                          </p>
                          <h3
                            className="text-xl font-bold text-foreground leading-tight"
                            style={{ fontFamily: "Sora, sans-serif" }}
                          >
                            {step.title}
                          </h3>
                        </div>
                      </div>
                      <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-5">
                        {step.description}
                      </p>
                      <ul className="space-y-2">
                        {step.highlights.map((h) => (
                          <li key={h} className="flex items-center gap-2 text-sm text-foreground">
                            <span
                              className="h-1.5 w-1.5 rounded-full flex-shrink-0"
                              style={{ background: "hsl(84 74% 58%)" }}
                              aria-hidden="true"
                            />
                            {h}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>

                  {/* Step number (desktop centre dot) */}
                  <div className="hidden lg:flex absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 z-10">
                    <div
                      className="flex h-12 w-12 items-center justify-center rounded-full border-2 border-border bg-background shadow-soft"
                    >
                      <span
                        className="text-sm font-bold"
                        style={{ color: "hsl(88 59% 56%)" }}
                      >
                        {step.number}
                      </span>
                    </div>
                  </div>

                  {/* Spacer column (desktop) */}
                  <div className="hidden lg:block" />
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
});

Page1Process.displayName = "Page1Process";

export default Page1Process;
