import React from "react";
import { Badge } from "@/components/ui/badge";
import { MapPin, Square, View } from "lucide-react";

const boroughs = [
  "City of London",
  "Westminster",
  "Canary Wharf / Tower Hamlets",
  "Shoreditch / Hackney",
  "Southwark",
  "Islington",
  "Camden",
  "Hammersmith & Fulham",
  "Kensington & Chelsea",
  "Wandsworth",
  "Lambeth",
  "Greenwich",
  "Lewisham",
  "Croydon",
  "Richmond upon Thames",
  "Kingston upon Thames",
  "Ealing",
  "Hounslow",
  "Brent",
  "Barnet",
  "Enfield",
  "Haringey",
  "Waltham Forest",
  "Redbridge",
  "Newham",
  "Barking & Dagenham",
  "Havering",
  "Bromley",
  "Merton",
  "Sutton",
];

const LondonBoroughs = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="london-boroughs"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="max-w-2xl mx-auto text-center mb-12">
          <Badge variant="outline" className="mb-4 text-primary border-primary/30">
            Service Coverage
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            London SEO Across Every Borough
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Whether you're based in the Square Mile, South Bank, or the outer suburbs,
            we provide expert SEO services across all 33 London boroughs — with deep knowledge
            of each area's unique business landscape and search demand.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3 max-w-5xl mx-auto mb-12">
          {boroughs.map((borough) => (
            <div
              key={borough}
              className="flex items-center gap-1.5 rounded-lg border border-border bg-card px-3 py-2.5 text-sm text-foreground hover:border-primary/40 hover:bg-primary/5 transition-colors cursor-default"
            >
              <MapPin className="h-3.5 w-3.5 text-primary shrink-0" />
              <span className="truncate">{borough}</span>
            </div>
          ))}
        </div>

        <div className="max-w-3xl mx-auto rounded-xl border border-border bg-card p-8 shadow-card text-center">
          <h3 className="text-xl font-bold text-foreground mb-3">
            Serving London and Beyond
          </h3>
          <p className="text-muted-foreground text-sm leading-relaxed mb-4">
            In addition to central and Greater London, we also work with businesses in the
            wider South East including Surrey, Essex, Kent, and Hertfordshire — helping
            businesses rank across London's extended commuter belt and catchment areas.
          </p>
          <p className="text-sm text-muted-foreground">
            Not sure if we cover your area?{" "}
            <a href="/contact" className="text-primary font-medium hover:underline">
              Get in touch
            </a>{" "}
            — we'd love to help.{" "}
            <a href="/locations" className="text-primary font-medium hover:underline">
              View all UK locations →
            </a>
          </p>
        </div>
      </div>
    </section>
  );
});

LondonBoroughs.displayName = "LondonBoroughs";
export default LondonBoroughs;
