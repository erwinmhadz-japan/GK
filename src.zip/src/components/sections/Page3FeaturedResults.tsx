import React from "react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TrendingUp, ChevronRight, Building, Globe, Briefcase, Search, Group, Image, Section, View } from "lucide-react";

const results = [
  {
    sector: "Professional Services",
    sectorIcon: Briefcase,
    client: "UK Law Firm",
    challenge:
      "A mid-size law firm in Manchester was invisible in Google search for competitive practice-area terms. Their site had severe technical debt and no content strategy.",
    outcome: "410% increase in organic sessions within 10 months. Page-1 rankings for 38 high-intent legal queries.",
    services: ["Technical SEO", "Content Strategy", "Entity SEO"],
    image: "https://images.unsplash.com/photo-1568649704650-a6ab20e84311?w=800&h=600&fit=crop",
    imageAlt: "Group of people walking near professional office buildings",
    growthLabel: "+410%",
    growthSub: "organic sessions",
  },
  {
    sector: "SaaS & Technology",
    sectorIcon: Globe,
    client: "B2B SaaS Platform",
    challenge:
      "A UK SaaS startup was spending heavily on PPC with weak organic presence. They needed predictable, compounding traffic from SEO without bloating their team.",
    outcome: "From 900 to 14,000 monthly organic visits in 14 months. CAC via organic reduced by 63%.",
    services: ["SEO Consulting", "SEO Retainer", "Schema Markup"],
    image: "https://images.unsplash.com/photo-1633537065980-5ec9245c0b0b?w=800&h=600&fit=crop",
    imageAlt: "Modern architectural structures against a cloudy sky",
    growthLabel: "15.5×",
    growthSub: "organic traffic",
  },
  {
    sector: "Healthcare",
    sectorIcon: Building,
    client: "Private Medical Group",
    challenge:
      "A private healthcare provider struggled with local visibility and was losing patients to NHS-adjacent results. E-E-A-T signals were weak across their site.",
    outcome: "Top-3 local pack rankings in 6 cities. 280% increase in appointment-inquiry form completions.",
    services: ["Local SEO", "Technical SEO", "Digital PR"],
    image: "https://images.unsplash.com/photo-1559659386-5b78a2a4290c?w=800&h=600&fit=crop",
    imageAlt: "Professional architecture photography of modern building",
    growthLabel: "+280%",
    growthSub: "inquiry conversions",
  },
  {
    sector: "E-commerce & Retail",
    sectorIcon: Search,
    client: "UK Retail Brand",
    challenge:
      "A national retail brand had thousands of product pages with duplicate content, cannibalization issues, and a crawl budget crisis following a platform migration.",
    outcome: "Crawl efficiency improved by 74%. Organic revenue up 195% YoY after 12-month retainer.",
    services: ["SEO Audit", "Technical SEO", "Content Strategy"],
    image: "https://images.unsplash.com/photo-1685492259744-f42597aac776?w=800&h=600&fit=crop",
    imageAlt: "Tall modern buildings next to each other in the city",
    growthLabel: "+195%",
    growthSub: "organic revenue",
  },
];

const Page3FeaturedResults = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="page3-featured-results"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div
        className="absolute inset-0 pointer-events-none"
        aria-hidden="true"
        style={{
          backgroundImage:
            "radial-gradient(circle at 15% 60%, hsl(214 32% 60% / 0.06) 0%, transparent 50%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        {/* Section header */}
        <div className="max-w-2xl mb-14">
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Featured results
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
            Industry-spanning wins
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            From professional services to SaaS, healthcare to retail — the same
            disciplined, independent approach delivers across sectors.
          </p>
        </div>

        {/* Results list */}
        <div className="space-y-8">
          {results.map(
            (
              {
                sector,
                sectorIcon: SectorIcon,
                client,
                challenge,
                outcome,
                services,
                image,
                imageAlt,
                growthLabel,
                growthSub,
              },
              index
            ) => (
              <motion.div
                key={client}
                initial={{ opacity: 0, y: 28 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.55, delay: index * 0.07 }}
                className="group grid grid-cols-1 lg:grid-cols-12 gap-0 rounded-2xl border border-border bg-card overflow-hidden shadow-card hover-lift"
              >
                {/* Image panel */}
                <div className="lg:col-span-4 relative min-h-[220px] lg:min-h-0 overflow-hidden">
                  <img
                    src={image}
                    alt={imageAlt}
                    width="800"
                    height="600"
                    loading="lazy"
                    className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent pointer-events-none" />
                  {/* Growth badge overlay */}
                  <div className="absolute bottom-4 left-4 bg-primary rounded-lg px-4 py-2 shadow-green-glow">
                    <div className="text-2xl font-bold text-primary-foreground leading-none">
                      {growthLabel}
                    </div>
                    <div className="text-xs text-primary-foreground/90 mt-0.5">
                      {growthSub}
                    </div>
                  </div>
                </div>

                {/* Content panel */}
                <div className="lg:col-span-8 p-8 flex flex-col justify-between">
                  <div>
                    {/* Sector badge */}
                    <div className="flex items-center gap-2 mb-4">
                      <div className="flex h-7 w-7 items-center justify-center rounded-md bg-primary/10">
                        <SectorIcon className="h-4 w-4 text-primary" aria-hidden="true" />
                      </div>
                      <span className="text-xs uppercase tracking-widest text-muted-foreground font-medium">
                        {sector}
                      </span>
                    </div>

                    <h3 className="text-xl md:text-2xl font-bold text-foreground mb-3">
                      {client}
                    </h3>

                    <div className="space-y-3 mb-5">
                      <div>
                        <span className="text-xs uppercase tracking-widest text-muted-foreground font-semibold block mb-1">
                          Challenge
                        </span>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {challenge}
                        </p>
                      </div>
                      <div>
                        <span className="text-xs uppercase tracking-widest text-primary font-semibold block mb-1">
                          Outcome
                        </span>
                        <p className="text-sm text-foreground font-medium leading-relaxed">
                          {outcome}
                        </p>
                      </div>
                    </div>

                    {/* Services used */}
                    <div className="flex flex-wrap gap-2">
                      {services.map((s) => (
                        <Badge
                          key={s}
                          variant="secondary"
                          className="text-xs font-medium"
                        >
                          {s}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.div>
            )
          )}
        </div>

        {/* CTA row */}
        <div className="mt-12 text-center">
          <Button size="lg" variant="outline" className="border-border text-foreground hover:bg-muted" asChild>
            <a href="#case-studies-cta" className="inline-flex items-center gap-2">
              View All Case Studies
              <ChevronRight className="h-4 w-4" aria-hidden="true" />
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
});

Page3FeaturedResults.displayName = "Page3FeaturedResults";

export default Page3FeaturedResults;
