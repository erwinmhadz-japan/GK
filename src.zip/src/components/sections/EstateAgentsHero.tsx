import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Search, TrendingUp, Building, Icon, View } from "lucide-react";

const EstateAgentsHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <>
      {/* JSON-LD Structured Data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify([
            {
              "@context": "https://schema.org",
              "@type": "LocalBusiness",
              "name": "Gregg Jefferies SEO — Estate Agent SEO Specialist",
              "description":
                "Expert SEO services for estate agents and property businesses. Dominate local property search rankings, attract qualified buyers and vendors, and grow your pipeline through organic search.",
              "url": "https://greggjefferies.com/industries/estate-agents",
              "areaServed": "United Kingdom",
              "serviceType": "SEO Consulting for Estate Agents",
              "knowsAbout": [
                "Local SEO",
                "Property Schema Markup",
                "Estate Agent SEO",
                "Entity SEO",
                "Location Authority Building",
              ],
            },
            {
              "@context": "https://schema.org",
              "@type": "Service",
              "name": "Estate Agent SEO",
              "provider": {
                "@type": "Person",
                "name": "Gregg Jefferies",
              },
              "description":
                "Specialist SEO strategy for estate agents covering local search dominance, schema markup for property listings, and entity SEO for agent branding.",
              "serviceType": "Search Engine Optimisation",
              "areaServed": {
                "@type": "Country",
                "name": "United Kingdom",
              },
            },
            {
              "@context": "https://schema.org",
              "@type": "BrokerageService",
              "name": "Property Market SEO Consulting",
              "description":
                "SEO consultancy tailored for residential and commercial estate agents, property portals, and letting agencies seeking to grow their local search presence.",
              "provider": {
                "@type": "Person",
                "name": "Gregg Jefferies",
              },
              "areaServed": "United Kingdom",
            },
          ]),
        }}
      />

      <ImageBackground
        ref={ref}
        id="estate-agents-hero"
        aria-label="Estate Agent SEO hero section"
        src="https://images.unsplash.com/photo-1685492259744-f42597aac776?w=1920&h=1080&fit=crop"
        alt="Modern residential buildings representing the property market"
        imgProps={{ fetchpriority: "high", loading: "eager" }}
        className="min-h-[85vh] md:min-h-screen flex items-center"
      >
        <div className="container relative z-10 py-24 md:py-36">
          <div className="max-w-3xl">
            <Badge className="mb-5 bg-primary/20 text-white border border-primary/40 backdrop-blur-sm">
              <MapPin className="h-3.5 w-3.5 mr-1.5" />
              Estate Agent SEO Specialist
            </Badge>

            <h1 className="text-4xl md:text-6xl font-bold text-white leading-tight mb-6">
              Dominate Local Property{" "}
              <span className="text-gradient-green">Search Rankings</span> and
              Win More Instructions
            </h1>

            <p className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl leading-relaxed">
              Buyers and vendors search locally before they call. A specialist
              estate agent SEO strategy ensures your agency appears at the top
              of every location-specific search — from "estate agents in
              [town]" to hyperlocal neighbourhood queries that drive genuine
              pipeline.
            </p>

            <div className="flex flex-wrap gap-4 mb-10">
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
                asChild
              >
                <a href="/contact">Get a Free Property SEO Audit</a>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="bg-transparent text-white border-white hover:bg-white/10 font-semibold"
                asChild
              >
                <a href="/local-seo">View Local SEO Services</a>
              </Button>
            </div>

            <div className="flex flex-wrap gap-6">
              {[
                { icon: Search, label: "Hyperlocal keyword dominance" },
                { icon: TrendingUp, label: "Measurable lead growth" },
                { icon: MapPin, label: "Location authority building" },
              ].map(({ icon: Icon, label }) => (
                <div key={label} className="flex items-center gap-2 text-white/80">
                  <Icon className="h-4 w-4 text-primary" />
                  <span className="text-sm">{label}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </ImageBackground>
    </>
  );
});

EstateAgentsHero.displayName = "EstateAgentsHero";

export default EstateAgentsHero;
