import React from "react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Brain, Globe, Shield, FileText, Network, Layers, TrendingUp, Eye, Fingerprint, BookOpen, Building, Grid } from "lucide-react";

interface Factor {
  number: string;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  body: string;
  badge: string;
}

const factors: Factor[] = [
  {
    number: "01",
    icon: Brain,
    title: "Entity Authority in Google's Knowledge Graph",
    body: "Gemini draws heavily on Google's Knowledge Graph when constructing AI-generated responses. If your business, brand, or key individuals are recognised entities with confirmed attributes — industry, location, founding date, relationships — you are far more likely to be surfaced. Building a coherent entity footprint across authoritative sources is the foundation.",
    badge: "Entity SEO",
  },
  {
    number: "02",
    icon: Shield,
    title: "E-E-A-T Signals Across Your Web Presence",
    body: "Google's Quality Rater Guidelines define Experience, Expertise, Authoritativeness, and Trustworthiness as the benchmark for high-quality content. Gemini inherits this framework. Bylines with verifiable credentials, citations from sector publications, and consistent professional profiles signal to Gemini that your content deserves amplification.",
    badge: "E-E-A-T",
  },
  {
    number: "03",
    icon: FileText,
    title: "Structured Data and Schema Markup",
    body: "Structured data communicates meaning to machines. When your pages include accurately implemented Schema — Organisation, Person, LocalBusiness, FAQPage, Article — Gemini has explicit, machine-readable signals to work with. This reduces ambiguity about who you are, what you do, and where you operate, increasing the likelihood of accurate citation.",
    badge: "Schema",
  },
  {
    number: "04",
    icon: Network,
    title: "Topical Authority and Content Depth",
    body: "Gemini favours sources that demonstrate comprehensive knowledge of a subject rather than surface-level coverage. A coherent topic cluster — a well-structured hub page supported by in-depth subtopic content — signals that you are a primary source, not a secondary one. Thin or duplicated content reduces your relevance in AI-generated results.",
    badge: "Content Strategy",
  },
  {
    number: "05",
    icon: Globe,
    title: "Corroborating Mentions Across Independent Sources",
    body: "AI models cross-reference multiple sources before attributing information to an entity. If only your own site claims your expertise, that carries limited weight. Coverage in industry publications, chambers of commerce listings, authoritative directories, and editorial mentions from credible third parties collectively corroborate your claims and reinforce your entity authority.",
    badge: "Digital PR",
  },
  {
    number: "06",
    icon: Fingerprint,
    title: "Distinct Brand and Personal Identity Signals",
    body: "Gemini struggles to surface entities it cannot clearly disambiguate. If your brand name, your personal name, or your business category overlaps with numerous other entities, clarity of identity becomes critical. Consistent NAP data, a clearly defined domain, and distinctive branded content help Gemini distinguish your entity from noise.",
    badge: "Brand Entity",
  },
  {
    number: "07",
    icon: Layers,
    title: "Technical Site Quality and Indexability",
    body: "Gemini relies on Googlebot's ability to crawl and index content effectively. Pages that are slow to load, poorly structured, or blocked from crawling are at a disadvantage regardless of content quality. Core Web Vitals, clean internal link architecture, and proper canonical signals all contribute to the technical foundation that makes content accessible to AI systems.",
    badge: "Technical SEO",
  },
  {
    number: "08",
    icon: TrendingUp,
    title: "Demonstrated Relevance to the Query Context",
    body: "Gemini constructs responses based on the semantic context of a query, not just keyword matching. Your content must clearly address the topics, use cases, and questions relevant to your sector. Pages that directly answer the kinds of questions your target audience asks — in plain, expert language — are more likely to be drawn upon as a source.",
    badge: "Relevance",
  },
  {
    number: "09",
    icon: Eye,
    title: "Recency and Content Freshness Signals",
    body: "AI-generated responses tend to prioritise current, up-to-date information for queries where recency matters. For professional services, industry commentary, and sector-specific guidance, maintaining a content programme that produces fresh material — insights, analysis, updated service pages — keeps your entity visible and relevant in Gemini's training and retrieval processes.",
    badge: "Content Freshness",
  },
  {
    number: "10",
    icon: BookOpen,
    title: "Local Entity Signals for Geographic Queries",
    body: "For location-specific queries — 'SEO consultant in Manchester' or 'solicitor near me' — Gemini integrates local entity data including Google Business Profile information, local citations, and geographic references in on-page content. A well-maintained GBP listing with consistent, accurate information is a foundational local signal that feeds directly into AI-generated local results.",
    badge: "Local SEO",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.08,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const GeminiVisibilityFactors = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="gemini-visibility-factors"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mb-12 md:mb-16"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Visibility Factors
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground max-w-3xl leading-snug">
            Ten Signals That Influence Gemini Visibility
          </h2>
          <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
            Based on analysis of AI-generated responses across Google Gemini, these are the factors that consistently distinguish brands that are cited from those that are not. These are observations, not guarantees — Gemini's behaviour evolves continuously.
          </p>
        </motion.div>

        {/* Factors Grid — 2 columns on md+, 1 on mobile */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8"
        >
          {factors.map((factor) => {
            const Icon = factor.icon;
            return (
              <motion.div
                key={factor.number}
                variants={itemVariants}
                className="group relative bg-background border border-border rounded-md p-6 md:p-7 transition-shadow duration-300 hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%_/_0.10),0_1px_4px_hsl(222_28%_11%_/_0.05)]"
              >
                {/* Number + Badge row */}
                <div className="flex items-center justify-between mb-4">
                  <span
                    className="text-xs font-mono font-semibold tracking-widest text-muted-foreground select-none"
                    aria-hidden="true"
                  >
                    {factor.number}
                  </span>
                  <Badge
                    variant="secondary"
                    className="text-xs font-medium px-2.5 py-0.5"
                  >
                    {factor.badge}
                  </Badge>
                </div>

                {/* Icon + Title */}
                <div className="flex items-start gap-3 mb-3">
                  <div className="flex-shrink-0 mt-0.5 flex h-9 w-9 items-center justify-center rounded-md bg-primary/10">
                    <Icon className="h-4 w-4 text-primary" />
                  </div>
                  <h3 className="text-base md:text-lg font-semibold text-foreground leading-snug">
                    {factor.title}
                  </h3>
                </div>

                {/* Body */}
                <p className="text-sm md:text-base text-muted-foreground leading-relaxed pl-12">
                  {factor.body}
                </p>

                {/* Subtle left accent bar on hover */}
                <div
                  className="absolute left-0 top-6 bottom-6 w-[3px] rounded-full bg-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  aria-hidden="true"
                />
              </motion.div>
            );
          })}
        </motion.div>

        {/* Editorial footnote */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3, ease: "easeOut" }}
          className="mt-10 text-xs text-muted-foreground max-w-2xl"
        >
          These factors are drawn from Gregg's ongoing analysis of AI search behaviour across client engagements. Gemini's retrieval and generation mechanisms are not publicly documented in full — this is an expert interpretation, not an official Google framework.
        </motion.p>
      </div>
    </section>
  );
});

GeminiVisibilityFactors.displayName = "GeminiVisibilityFactors";

export default GeminiVisibilityFactors;
