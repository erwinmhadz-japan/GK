import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Search, MapPin, Target, Globe, Shield, ArrowRight, CheckCircle, Book, Icon, Map as MapIcon, Package } from "lucide-react";

const steps = [
  {
    icon: Search,
    title: "Leeds Keyword Landscape Audit",
    description:
      "Map the exact search terms Leeds customers use — from 'SEO agency Leeds' to hyper-local neighbourhood queries — and identify the gaps your competitors are leaving open.",
  },
  {
    icon: MapPin,
    title: "Google Business Profile Optimisation",
    description:
      "Claim the Map Pack positions that capture the highest local intent. Your GBP is the most powerful local SEO asset for Leeds businesses and most are badly under-optimised.",
  },
  {
    icon: Target,
    title: "Location-Specific Content Strategy",
    description:
      "Create content that signals genuine Leeds authority — covering LS postcode areas, local landmarks, neighbourhood intent, and Yorkshire-specific customer needs.",
  },
  {
    icon: Globe,
    title: "Local Link Acquisition",
    description:
      "Build authority through links from Leeds business directories, Yorkshire media, chamber of commerce listings, and regional industry associations.",
  },
  {
    icon: Shield,
    title: "Technical SEO Foundation",
    description:
      "Ensure your site's crawlability, Core Web Vitals, and structured data are flawless — the non-negotiable baseline for ranking in competitive Leeds searches.",
  },
];

const included = [
  "Leeds-specific keyword research",
  "Map Pack / GBP ranking strategy",
  "LS postcode content targeting",
  "Yorkshire regional link building",
  "Local schema markup (LocalBusiness)",
  "Competitor gap analysis",
  "Monthly performance reporting",
];

const LeedsApproach = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="leeds-approach"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 md:gap-16 items-start">
          {/* Left column — process */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.6, ease: "easeOut" }}
              className="mb-10"
            >
              <div className="flex items-center gap-2 mb-4">
                <Target className="h-4 w-4 text-primary flex-shrink-0" aria-hidden="true" />
                <span className="text-xs uppercase tracking-[0.2em] font-medium text-muted-foreground">
                  Local SEO approach
                </span>
              </div>
              <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-[1.15] mb-4 tracking-tight">
                How We Win{" "}
                <span className="text-gradient-green">Leeds Searches</span>
              </h2>
              <p className="text-lg text-muted-foreground leading-relaxed">
                A proven local SEO methodology built specifically for the Leeds
                market — combining technical precision with genuine local authority signals.
              </p>
            </motion.div>

            {/* Steps */}
            <div className="space-y-6">
              {steps.map(({ icon: Icon, title, description }, i) => (
                <motion.div
                  key={title}
                  initial={{ opacity: 0, x: -16 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.5, delay: i * 0.08, ease: "easeOut" }}
                  className="flex gap-4"
                >
                  <div className="flex-shrink-0 flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 mt-0.5">
                    <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
                  </div>
                  <div>
                    <h3 className="text-base font-semibold text-foreground mb-1">{title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>

          {/* Right column — what's included + CTA */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6, delay: 0.15, ease: "easeOut" }}
            className="lg:sticky lg:top-8"
          >
            <div className="rounded-2xl border border-border bg-card shadow-card p-8">
              <h3 className="text-xl font-bold text-foreground mb-2">
                Leeds Local SEO Package
              </h3>
              <p className="text-sm text-muted-foreground mb-6">
                Every Leeds engagement includes a comprehensive set of deliverables tailored
                to the local competitive landscape.
              </p>

              <ul className="space-y-3 mb-8">
                {included.map((item) => (
                  <li key={item} className="flex items-start gap-3">
                    <CheckCircle className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" aria-hidden="true" />
                    <span className="text-sm text-foreground">{item}</span>
                  </li>
                ))}
              </ul>

              <div className="space-y-3">
                <Button size="lg" className="w-full font-semibold" asChild>
                  <Link to="/services-local-seo">
                    Explore Local SEO Services
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Link>
                </Button>
                <Button size="lg" variant="outline" className="w-full" asChild>
                  <Link to="/contact">Book a Free Leeds Consultation</Link>
                </Button>
              </div>

              <p className="text-xs text-muted-foreground mt-4 text-center">
                No commitment · Yorkshire-based expertise
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
});

LeedsApproach.displayName = "LeedsApproach";

export default LeedsApproach;
