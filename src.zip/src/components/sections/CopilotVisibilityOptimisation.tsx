import React from "react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Search, Database, ShieldCheck, Eye, Link2, Layers, TrendingUp, CheckCircle2, Podcast, Section, Signal } from "lucide-react";

interface OptimisationFactor {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  signals: string[];
}

const factors: OptimisationFactor[] = [
  {
    icon: Search,
    title: "Bing Indexation & Crawlability",
    description:
      "Microsoft Copilot sources its responses from the Bing index. If Bing cannot crawl and index your pages, your content will not be considered for citation — regardless of its quality. Ensuring clean technical architecture, a submitted sitemap, and no Bing-blocking directives forms the baseline of Copilot visibility.",
    signals: [
      "Bing Webmaster Tools submission",
      "XML sitemap integrity",
      "Crawl budget and robots.txt",
      "Canonical tag consistency",
    ],
  },
  {
    icon: Database,
    title: "Structured Data & Schema Markup",
    description:
      "Structured data provides machine-readable context that helps Copilot understand what your content is about, who produced it, and what entities it references. Implementing schema types such as Organisation, Person, Article, FAQPage, and LocalBusiness gives the retrieval layer explicit signals to work with when matching queries to sources.",
    signals: [
      "Organisation and Person schema",
      "Article and BlogPosting markup",
      "FAQPage and HowTo schema",
      "LocalBusiness and BreadcrumbList",
    ],
  },
  {
    icon: Layers,
    title: "Entity Authority & Knowledge Graph Presence",
    description:
      "Copilot relies on knowledge-graph-style entity relationships when constructing responses. Brands and individuals with clear, consistent entity signals across the web — including Wikipedia, Wikidata, industry directories, and authoritative publications — are far more likely to be cited. Entity disambiguation and co-citation patterns matter significantly.",
    signals: [
      "Consistent NAP data across the web",
      "Wikidata and Wikipedia presence",
      "Industry directory citations",
      "Co-citation with trusted entities",
    ],
  },
  {
    icon: ShieldCheck,
    title: "E-E-A-T Signals",
    description:
      "Experience, Expertise, Authoritativeness, and Trustworthiness (E-E-A-T) are central to how AI search systems evaluate content credibility. Copilot's retrieval layer favours sources that demonstrate genuine expertise through author credentials, original research, cited sources, and a strong domain authority profile built through editorial links.",
    signals: [
      "Author bio pages with credentials",
      "First-person experience signals",
      "Editorial backlinks from trusted domains",
      "Original research and data citations",
    ],
  },
  {
    icon: Eye,
    title: "Content Clarity & Topical Depth",
    description:
      "AI language models retrieve content that directly and clearly answers the questions users are asking. Pages that are well-structured, use plain language, answer questions explicitly, and cover a topic with genuine depth are better positioned for AI retrieval than thin or over-optimised content written primarily for keyword stuffing.",
    signals: [
      "Clear, direct answers near the top",
      "Logical heading structure (H1–H3)",
      "Topical coverage without padding",
      "Plain, precise British English",
    ],
  },
  {
    icon: Link2,
    title: "Brand Mentions & Off-Page Authority",
    description:
      "Unlinked brand mentions, press coverage, and references in authoritative publications all feed into how Copilot perceives a brand's standing. Digital PR activity that places your brand name in credible editorial contexts — particularly in UK trade publications and national media — reinforces your entity's trustworthiness within the retrieval model.",
    signals: [
      "Press mentions in UK media",
      "Branded anchor links from authority domains",
      "Industry forum and Q&A contributions",
      "Podcast and interview appearances",
    ],
  },
];

const fadeUpVariant = {
  hidden: { opacity: 0, y: 28 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay: i * 0.1 },
  }),
};

const CopilotVisibilityOptimisation = React.forwardRef<HTMLElement>(
  (props, ref) => {
    return (
      <section
        ref={ref}
        id="copilot-visibility-optimisation"
        className="relative py-20 md:py-32 border-t border-border bg-background"
      >
        <div className="container max-w-6xl mx-auto px-4">
          {/* Section header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="max-w-3xl mb-14 md:mb-20"
          >
            <Badge
              variant="outline"
              className="mb-4 text-xs uppercase tracking-widest border-border text-muted-foreground"
            >
              Optimisation Factors
            </Badge>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground font-[Sora] mb-5 max-w-2xl">
              What Affects Your Visibility in Microsoft Copilot
            </h2>
            <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl">
              Microsoft Copilot does not surface content randomly. Several
              distinct signals influence which brands and pages it retrieves and
              cites. Understanding these factors is the starting point for any
              meaningful improvement to your AI search presence.
            </p>
          </motion.div>

          {/* Optimisation factors grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 lg:gap-10">
            {factors.map((factor, index) => {
              const Icon = factor.icon;
              return (
                <motion.div
                  key={factor.title}
                  custom={index}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  variants={fadeUpVariant}
                  className="group border border-border rounded-md bg-background p-7 hover:shadow-[0_4px_24px_rgba(26,31,46,0.10)] transition-shadow duration-300"
                >
                  {/* Icon */}
                  <div className="flex items-start gap-4 mb-4">
                    <div className="flex-shrink-0 flex items-center justify-center w-10 h-10 rounded-md bg-primary/10">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <h3 className="text-base md:text-lg font-semibold text-foreground font-[Sora] leading-snug pt-1">
                      {factor.title}
                    </h3>
                  </div>

                  {/* Description */}
                  <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-5">
                    {factor.description}
                  </p>

                  {/* Signal checklist */}
                  <ul className="space-y-2">
                    {factor.signals.map((signal) => (
                      <li
                        key={signal}
                        className="flex items-center gap-2 text-sm text-muted-foreground"
                      >
                        <CheckCircle2 className="h-4 w-4 text-primary flex-shrink-0" />
                        <span>{signal}</span>
                      </li>
                    ))}
                  </ul>
                </motion.div>
              );
            })}
          </div>

          {/* Closing context note */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.2 }}
            className="mt-16 md:mt-20 border border-border rounded-md bg-background p-8 md:p-10 flex flex-col md:flex-row gap-6 md:gap-10 items-start"
          >
            <div className="flex-shrink-0 flex items-center justify-center w-12 h-12 rounded-md bg-primary/10">
              <TrendingUp className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h3 className="text-base md:text-lg font-semibold text-foreground font-[Sora] mb-3">
                These factors are cumulative, not independent
              </h3>
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed max-w-3xl">
                No single signal guarantees Copilot visibility. The retrieval
                model weighs a combination of technical accessibility, semantic
                clarity, entity recognition, and authority indicators. Brands
                that perform consistently across all six areas tend to see the
                strongest presence in AI-generated responses — not just in
                Copilot, but across Perplexity, ChatGPT, Gemini, and Google AI
                Overviews as well.
              </p>
              <p className="text-sm text-muted-foreground mt-3 leading-relaxed max-w-3xl">
                If you're unsure where your current performance stands across
                these signals, a structured SEO audit is often the clearest
                starting point.{" "}
                <a
                  href="/seo-audit"
                  className="text-primary hover:underline underline-offset-2 font-medium"
                >
                  Learn about the audit process →
                </a>
              </p>
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
);

CopilotVisibilityOptimisation.displayName = "CopilotVisibilityOptimisation";

export default CopilotVisibilityOptimisation;
