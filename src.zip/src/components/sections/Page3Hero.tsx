import React from "react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ImageBackground } from "@/components/ImageBackground";
import { TrendingUp, Award, Users, Icon, View } from "lucide-react";

const Page3Hero = React.forwardRef<HTMLElement>((props, ref) => {
  const stats = [
    { icon: TrendingUp, label: "Avg. Organic Growth", value: "312%" },
    { icon: Users, label: "Clients Served", value: "80+" },
    { icon: Award, label: "Years of Expertise", value: "15+" },
  ];

  return (
    <ImageBackground
      ref={ref}
      id="page3-hero"
      aria-label="Results hero section"
      src="https://images.unsplash.com/photo-1571120245989-c2878f4c89b9?w=1920&h=1080&fit=crop"
      alt="Modern office with windows — SEO results background"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center"
    >
      <div className="container relative z-10 py-24 md:py-36">
        <div className="max-w-3xl">
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            <Badge
              variant="outline"
              className="inline-flex items-center gap-1.5 text-xs font-medium tracking-widest uppercase border-white/30 text-white/80 bg-white/10 mb-6"
            >
              <span
                className="w-1.5 h-1.5 rounded-full bg-primary"
                aria-hidden="true"
              />
              Proven Results
            </Badge>
          </motion.div>

          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-4xl md:text-6xl font-bold text-white leading-tight mb-6"
          >
            Real Organic Growth.{" "}
            <span className="text-gradient-green">Measurable Results.</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg md:text-xl text-white/90 mb-10 max-w-2xl leading-relaxed"
          >
            Every engagement is built on strategy, not guesswork. See how
            independent SEO consultancy from Gregg King delivers consistent,
            compounding organic growth for UK businesses.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-wrap gap-4 mb-14"
          >
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
              asChild
            >
              <a href="/contact">Get a Free Consultation</a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white/50 hover:bg-white/10 font-medium"
              asChild
            >
              <a href="#case-studies-cta">View Case Studies</a>
            </Button>
          </motion.div>

          {/* Stat strip */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex flex-wrap gap-8"
          >
            {stats.map(({ icon: Icon, label, value }) => (
              <div key={label} className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20 shrink-0">
                  <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
                </div>
                <div>
                  <div className="text-2xl font-bold text-white leading-none">
                    {value}
                  </div>
                  <div className="text-xs text-white/80 mt-0.5">{label}</div>
                </div>
              </div>
            ))}
          </motion.div>
        </div>
      </div>
    </ImageBackground>
  );
});

Page3Hero.displayName = "Page3Hero";

export default Page3Hero;
