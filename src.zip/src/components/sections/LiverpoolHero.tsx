import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, ArrowRight, TrendingUp, View } from "lucide-react";

const LiverpoolHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="liverpool-hero"
      aria-label="Liverpool SEO hero section"
      src="https://images.unsplash.com/photo-1573496130141-209d200cebd8?w=1920&h=1080&fit=crop"
      alt="Two women in suits standing beside wall — professional SEO consulting in Liverpool"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center py-24"
    >
      <div className="container relative z-10">
        <div className="max-w-3xl">
          <div className="flex flex-wrap items-center gap-3 mb-6">
            <Badge className="bg-primary/20 text-primary border-primary/30 text-sm px-3 py-1">
              <MapPin className="h-3.5 w-3.5 mr-1.5" />
              Liverpool, Merseyside
            </Badge>
            <Badge className="bg-white/10 text-white/90 border-white/20 text-sm px-3 py-1">
              <TrendingUp className="h-3.5 w-3.5 mr-1.5" />
              Local SEO Specialists
            </Badge>
          </div>

          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
            SEO Consulting in{" "}
            <span className="text-gradient-green">Liverpool</span>
          </h1>

          <p className="text-lg md:text-xl text-white/90 mb-8 leading-relaxed max-w-2xl">
            Independent SEO consultancy helping Liverpool businesses dominate local search, outrank Merseyside competitors, and build sustainable organic growth across the North West.
          </p>

          <div className="flex flex-wrap gap-4 mb-10">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold px-8"
              asChild
            >
              <a href="/contact">
                Get a Liverpool SEO Audit
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10 font-semibold px-8"
              asChild
            >
              <a href="/services">View SEO Services</a>
            </Button>
          </div>

          <div className="flex flex-wrap gap-6 text-sm text-white/80">
            <span className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-primary inline-block" />
              Liverpool City Centre
            </span>
            <span className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-primary inline-block" />
              Merseyside &amp; North West
            </span>
            <span className="flex items-center gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-primary inline-block" />
              UK-Wide Remote Available
            </span>
          </div>
        </div>
      </div>
    </ImageBackground>
  );
});

LiverpoolHero.displayName = "LiverpoolHero";

export default LiverpoolHero;
