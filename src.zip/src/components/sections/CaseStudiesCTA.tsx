import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { ArrowRight, BookOpen, MessageSquare, Book } from "lucide-react";

const CaseStudiesCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="case-studies-cta"
      aria-label="Call to action section"
      src="https://images.unsplash.com/photo-1582005450386-52b25f82d9bb?w=1920&h=1080&fit=crop"
      alt="Professional team collaborating on SEO strategy with laptops"
      imgProps={{ loading: "lazy" }}
      className="py-24 md:py-36 flex items-center"
    >
      <div className="container relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-5">
            Ready to Get Started?
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 leading-tight">
            Let's Write Your Case Study Next
          </h2>
          <p className="text-base md:text-lg text-white/90 mb-10 leading-relaxed max-w-2xl mx-auto">
            Whether you're looking to dominate local search, fix deep technical issues,
            build an AI-visible content strategy, or outrank competitors in a competitive sector
            — the process starts with a conversation. No commitment required.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold shadow-green-glow"
              asChild
            >
              <a href="/contact">
                <MessageSquare className="mr-2 h-5 w-5" />
                Book a Free Consultation
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10"
              asChild
            >
              <a href="#insights-cta">
                <BookOpen className="mr-2 h-5 w-5" />
                Explore All Case Studies
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </Button>
          </div>
          <p className="mt-8 text-sm text-white/80">
            No setup fees · No long-term lock-in · Results-first approach
          </p>
        </div>
      </div>
    </ImageBackground>
  );
});

CaseStudiesCTA.displayName = "CaseStudiesCTA";

export default CaseStudiesCTA;
