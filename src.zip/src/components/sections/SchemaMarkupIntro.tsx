import React from "react";
import { motion } from "framer-motion";
import { Code2, Search, Eye, Network, CheckCircle, Section } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (delay: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut", delay },
  }),
};

const pillars = [
  {
    icon: Code2,
    heading: "What schema markup is",
    body:
      "Schema markup is structured data — machine-readable code added to a page's HTML that communicates directly with search engines. It uses vocabularies such as Schema.org to label content: this is a product, this is a review, this is an FAQ. Search engines no longer have to infer meaning from prose; you declare it explicitly.",
  },
  {
    icon: Search,
    heading: "Why it matters for search visibility",
    body:
      "Correctly implemented schema can unlock rich results in Google Search — star ratings, FAQs, breadcrumbs, how-to steps, sitelinks — that increase your click-through rate without moving your ranking position. It also reinforces topical relevance signals, supports featured-snippet eligibility, and feeds the Knowledge Graph with accurate entity data about your brand.",
  },
  {
    icon: Eye,
    heading: "The entity-recognition layer",
    body:
      "Beyond rich results, structured data is central to how modern search engines model entity relationships. When your schema correctly identifies who you are, what you do, where you operate, and how you relate to other known entities, you become more visible across AI-assisted search surfaces — including Google's AI Overviews and Knowledge Panels.",
  },
  {
    icon: Network,
    heading: "Where most implementations fall short",
    body:
      "Generic CMS plugins apply one-size-fits-all schema that is often incomplete, mis-scoped, or outright incorrect. Common failures include missing required properties, duplicate or conflicting type declarations, mismatched canonical signals, and schema that contradicts on-page content. These issues can suppress rather than enhance search performance.",
  },
];

const approachPoints = [
  "I audit existing structured data against current Schema.org specifications and Google's documentation before writing a single line of new markup.",
  "Implementation is tailored to the page type and business context — a law firm's service page needs different schema to an e-commerce product listing.",
  "I cross-reference schema declarations with on-page signals (headings, copy, internal links) to ensure consistency that search engines can trust.",
  "Validation testing covers Google's Rich Results Test, Schema Markup Validator, and manual inspection of rendered structured data — not just automated passes.",
  "Where appropriate, I integrate schema strategy with entity SEO and technical SEO to form a coherent, mutually reinforcing signal set.",
];

const SchemaMarkupIntro = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="schema-markup-intro"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          className="max-w-2xl mb-14 md:mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          custom={0}
          variants={fadeUp}
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Understanding the discipline
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight mb-5">
            Schema markup: what it is,<br className="hidden sm:block" /> why it works, and how I do it
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-prose">
            Structured data is one of the most misunderstood, most under-used, and most impactful levers in technical SEO. Here is an honest account of what it involves — and what separates careful implementation from a generic plugin install.
          </p>
        </motion.div>

        {/* Four-pillar explanatory grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-10 mb-16 md:mb-24">
          {pillars.map((pillar, index) => {
            const Icon = pillar.icon;
            return (
              <motion.div
                key={pillar.heading}
                className="bg-background border border-border rounded-md p-7 md:p-8"
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-60px" }}
                custom={0.1 + index * 0.1}
                variants={fadeUp}
              >
                <div className="flex items-center gap-3 mb-4">
                  <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10 shrink-0">
                    <Icon className="h-4 w-4 text-primary" />
                  </div>
                  <h3 className="text-base font-semibold text-foreground leading-snug">
                    {pillar.heading}
                  </h3>
                </div>
                <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                  {pillar.body}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* My approach — two-column prose layout */}
        <motion.div
          className="grid grid-cols-1 lg:grid-cols-5 gap-10 lg:gap-16 items-start"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          custom={0}
          variants={fadeUp}
        >
          {/* Left column — heading block */}
          <div className="lg:col-span-2">
            <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-3 font-medium">
              My approach
            </span>
            <h2 className="text-2xl md:text-3xl font-bold text-foreground leading-snug mb-4">
              Methodical, not mechanical
            </h2>
            <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
              I treat schema markup as a precision discipline, not a checkbox exercise. Every implementation starts with understanding the page's purpose, the business context, and the search intent I am trying to satisfy — then I build structured data that reflects all three accurately.
            </p>
            <p className="text-sm md:text-base text-muted-foreground leading-relaxed mt-4">
              I work with UK businesses across law, finance, healthcare, and property — sectors where accuracy, credibility, and trust signals are as important to conversion as they are to search visibility. Schema done properly reinforces both.
            </p>
          </div>

          {/* Right column — approach checklist */}
          <motion.div
            className="lg:col-span-3"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            custom={0.15}
            variants={fadeUp}
          >
            <ul className="space-y-5">
              {approachPoints.map((point, index) => (
                <li key={index} className="flex gap-4 items-start">
                  <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                    {point}
                  </p>
                </li>
              ))}
            </ul>

            {/* Inline contextual reference — no CTA block */}
            <div className="mt-8 pt-8 border-t border-border">
              <p className="text-sm text-muted-foreground leading-relaxed">
                For a broader view of how structured data fits within a technical SEO programme, see my{" "}
                <a
                  href="/technical-seo"
                  className="text-foreground underline underline-offset-4 decoration-border hover:decoration-primary transition-colors duration-200"
                >
                  Technical SEO service
                </a>
                {" "}and{" "}
                <a
                  href="/entity-seo"
                  className="text-foreground underline underline-offset-4 decoration-border hover:decoration-primary transition-colors duration-200"
                >
                  Entity SEO service
                </a>
                {" "}— both of which work in close concert with schema markup strategy.
              </p>
            </div>
          </motion.div>
        </motion.div>

      </div>
    </section>
  );
});

SchemaMarkupIntro.displayName = "SchemaMarkupIntro";

export default SchemaMarkupIntro;
