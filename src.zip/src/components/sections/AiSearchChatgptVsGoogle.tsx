import React from "react";
import { Check, Users } from "lucide-react";

const comparisonRows = [
  {
    factor: "Result format",
    google: "Ranked list of blue links",
    chatgpt: "Synthesised prose answer with inline citations",
  },
  {
    factor: "Query type",
    google: "Short keyword queries dominate",
    chatgpt: "Natural language, conversational questions",
  },
  {
    factor: "Primary ranking signals",
    google: "Backlinks, E-E-A-T, page experience",
    chatgpt: "Training data weight, structured markup, crawlability",
  },
  {
    factor: "Crawler",
    google: "Googlebot",
    chatgpt: "GPTBot (must be allowed in robots.txt)",
  },
  {
    factor: "Structured data impact",
    google: "Rich results (stars, FAQs, sitelinks)",
    chatgpt: "Passage extraction, direct answer sourcing",
  },
  {
    factor: "Content freshness",
    google: "Query-dependent freshness factor",
    chatgpt: "Newer pages preferred in browsing mode",
  },
  {
    factor: "Click-through",
    google: "Users click through to your site",
    chatgpt: "Answer often delivered in-chat; citation click is optional",
  },
  {
    factor: "Local signals",
    google: "Google Business Profile, local citations",
    chatgpt: "Schema LocalBusiness, authoritative local mentions",
  },
];

const AiSearchChatgptVsGoogle = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section ref={ref} className="relative py-20 md:py-32 border-t border-border bg-background">
      <div className="container">
        <div className="max-w-2xl mb-12">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Platform comparison
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            ChatGPT Visibility vs. Traditional Google SEO
          </h2>
          <p className="text-muted-foreground leading-relaxed">
            Optimising for ChatGPT requires a different strategy than Google. While there is meaningful overlap — quality content, technical hygiene, authority signals — the mechanisms and outputs differ in important ways.
          </p>
        </div>

        <div className="overflow-x-auto rounded-xl border border-border shadow-card">
          <table className="w-full text-sm">
            <thead>
              <tr className="bg-secondary text-secondary-foreground">
                <th className="text-left px-6 py-4 font-semibold w-1/4">Factor</th>
                <th className="text-left px-6 py-4 font-semibold w-[37.5%]">
                  <span className="text-muted-foreground text-xs uppercase tracking-wider">Traditional</span>
                  {" "}Google SEO
                </th>
                <th className="text-left px-6 py-4 font-semibold w-[37.5%] text-primary">
                  ChatGPT Visibility
                </th>
              </tr>
            </thead>
            <tbody>
              {comparisonRows.map((row, i) => (
                <tr
                  key={row.factor}
                  className={i % 2 === 0 ? "bg-background" : "bg-muted/50"}
                >
                  <td className="px-6 py-4 font-medium text-foreground align-top">{row.factor}</td>
                  <td className="px-6 py-4 text-muted-foreground align-top leading-relaxed">{row.google}</td>
                  <td className="px-6 py-4 text-foreground align-top leading-relaxed font-medium">{row.chatgpt}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        <div className="mt-10 bg-gradient-hero-panel rounded-xl p-8 text-white">
          <h3 className="text-xl font-bold mb-3">The Good News: Shared Foundations</h3>
          <p className="text-white/80 leading-relaxed mb-6">
            Strong Google SEO and ChatGPT visibility share the same roots — authoritative content, clean technical infrastructure, and genuine expertise. A well-executed SEO programme creates the ideal conditions for AI citation. The key additions are GPTBot access, structured data depth, and passage-level content optimisation.
          </p>
          <div className="grid sm:grid-cols-3 gap-4">
            {[
              "Technical SEO improves both channels",
              "E-E-A-T signals carry across platforms",
              "Schema markup amplifies AI citations",
            ].map((point) => (
              <div key={point} className="flex items-start gap-2">
                <Check className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                <span className="text-sm text-white/80">{point}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
});

AiSearchChatgptVsGoogle.displayName = "AiSearchChatgptVsGoogle";
export default AiSearchChatgptVsGoogle;
