import React from "react";
import { motion } from "framer-motion";
import { Search, FileSearch, Gauge, Code, GitBranch, Globe, Link, RefreshCw, Monitor, Network, File, Section } from "lucide-react";

interface Discipline {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
}

const disciplines: Discipline[] = [
  {
    icon: Search,
    title: "Crawl Audits",
    description:
      "A thorough analysis of how search engines discover and process your site — identifying crawl traps, blocked resources, and pages wasting crawl budget on content that adds no value.",
  },
  {
    icon: FileSearch,
    title: "Log File Analysis",
    description:
      "Raw server log data reveals exactly which URLs Googlebot is visiting, how frequently, and which critical pages are being overlooked. I use this to direct crawl budget where it matters most.",
  },
  {
    icon: Gauge,
    title: "Core Web Vitals",
    description:
      "Diagnosing and resolving LCP, CLS, and INP issues that affect both ranking signals and user experience — with a prioritised brief for your development team to act on.",
  },
  {
    icon: Code,
    title: "Structured Data",
    description:
      "Implementing and auditing schema markup — Article, LocalBusiness, FAQ, Product, and beyond — to improve how your content is understood by both traditional search engines and AI-driven results.",
  },
  {
    icon: Network,
    title: "Site Architecture",
    description:
      "Reviewing URL structure, information hierarchy, and internal linking patterns to ensure authority flows efficiently across the site and key pages are positioned to rank.",
  },
  {
    icon: Globe,
    title: "International Hreflang",
    description:
      "Correct hreflang implementation is critical for multi-language and multi-region sites. I audit and resolve hreflang conflicts, self-referencing errors, and return-tag failures.",
  },
  {
    icon: Link,
    title: "Canonical Strategy",
    description:
      "Defining and enforcing canonical rules to consolidate duplicate and near-duplicate content — preventing diluted signals and ensuring the correct version of each page competes in search.",
  },
  {
    icon: RefreshCw,
    title: "Redirect Management",
    description:
      "Auditing redirect chains and loops, resolving broken links, and ensuring that link equity is preserved correctly when URLs are changed, consolidated, or retired.",
  },
  {
    icon: Monitor,
    title: "JavaScript Rendering",
    description:
      "Assessing how search engines render JavaScript-heavy sites — identifying content hidden behind client-side rendering and recommending server-side or hybrid rendering strategies where appropriate.",
  },
  {
    icon: GitBranch,
    title: "Indexation Control",
    description:
      "Reviewing noindex directives, robots.txt rules, and XML sitemaps to ensure the right pages are indexed and the wrong ones are not — protecting crawl budget and search visibility alike.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.07,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const headingVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut" },
  },
};

const TechnicalSEOServices = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="technical-seoservices"
      className="relative py-20 md:py-32 border-t border-white/10"
      style={{ backgroundColor: "hsl(231 9% 16%)" }}
    >
      {/* Subtle dot-grid texture overlay */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(0 0% 100%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        {/* Section header */}
        <motion.div
          className="mb-14 md:mb-16 max-w-2xl"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={headingVariants}
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-white/60 mb-4 font-medium">
            Technical SEO Disciplines
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-white leading-tight">
            What Technical SEO Covers
          </h2>
          <p className="mt-4 text-base md:text-lg text-white/70 leading-relaxed max-w-prose">
            Technical SEO is the structural foundation of organic search performance. Below are the core disciplines I work across — each one diagnosed, prioritised, and briefed for action rather than left as a theoretical list of recommendations.
          </p>
        </motion.div>

        {/* 10-card grid — 2 columns (md), 2 rows of 5 */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-5"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={containerVariants}
        >
          {disciplines.map((discipline) => {
            const Icon = discipline.icon;
            return (
              <motion.div
                key={discipline.title}
                variants={cardVariants}
                className="group flex gap-5 rounded-md border border-white/10 bg-white/[0.04] p-6 transition-all duration-300 hover:border-white/20 hover:bg-white/[0.07]"
              >
                {/* Icon column */}
                <div className="flex-shrink-0 mt-0.5">
                  <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/15 transition-colors duration-300 group-hover:bg-primary/25">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                </div>

                {/* Content column */}
                <div>
                  <h3 className="text-base font-semibold text-white mb-2 leading-snug">
                    {discipline.title}
                  </h3>
                  <p className="text-sm text-white/65 leading-relaxed">
                    {discipline.description}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Subtle closing note */}
        <motion.p
          className="mt-12 text-sm text-white/50 max-w-xl"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.8, delay: 0.3, ease: "easeOut" }}
        >
          Every engagement is scoped to the issues that will have the greatest measurable impact on your site — not a templated checklist applied regardless of context.
        </motion.p>
      </div>
    </section>
  );
});

TechnicalSEOServices.displayName = "TechnicalSEOServices";

export default TechnicalSEOServices;
