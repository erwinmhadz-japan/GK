import React from "react";
import { motion, Variants } from "framer-motion";
import { MapPin, Phone, Mail, Clock, Contact, Section } from "lucide-react";

interface ContactDetail {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  subvalue?: string;
  href?: string;
  description: string;
}

const contactDetails: ContactDetail[] = [
  {
    icon: Phone,
    label: "Telephone",
    value: "01925 214707",
    href: "tel:+441925214707",
    description: "Available Monday to Friday, 9am – 5:30pm",
  },
  {
    icon: Mail,
    label: "Email",
    value: "gregg@greggking.co.uk",
    href: "mailto:gregg@greggking.co.uk",
    description: "I aim to respond to all enquiries within one working day",
  },
  {
    icon: MapPin,
    label: "Location",
    value: "22 Foxdale Court, Warrington WA4 5BS",
    subvalue: "Cheshire, England",
    href: "https://maps.google.com/?q=22+Foxdale+Court+Warrington+WA4+5BS",
    description: "Based in Warrington — working with UK businesses nationwide",
  },
  {
    icon: Clock,
    label: "Office Hours",
    value: "Monday – Friday",
    subvalue: "9:00am – 5:30pm",
    description: "Enquiries received outside these hours are reviewed the following working day",
  },
];

const fadeUp: Variants = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay: i * 0.1 },
  }),
};

const schemaData = {
  "@context": "https://schema.org",
  "@type": "LocalBusiness",
  "name": "Gregg King SEO",
  "description": "Independent UK SEO consultant offering SEO consulting, audits, retainers, technical SEO, schema markup, entity SEO, content strategy, local SEO, digital PR, and AI search optimisation.",
  "url": "https://greggking.co.uk",
  "telephone": "+441925214707",
  "email": "gregg@greggking.co.uk",
  "address": {
    "@type": "PostalAddress",
    "streetAddress": "22 Foxdale Court",
    "addressLocality": "Warrington",
    "postalCode": "WA4 5BS",
    "addressRegion": "Cheshire",
    "addressCountry": "GB",
  },
  "geo": {
    "@type": "GeoCoordinates",
    "latitude": "53.3793",
    "longitude": "-2.5956",
  },
  "openingHoursSpecification": [
    {
      "@type": "OpeningHoursSpecification",
      "dayOfWeek": ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
      "opens": "09:00",
      "closes": "17:30",
    },
  ],
  "areaServed": {
    "@type": "Country",
    "name": "United Kingdom",
  },
};

const ContactInfo = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="contact-info"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mb-12 md:mb-16"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-3 font-medium">
            Contact Details
          </span>
          <h2 className="text-2xl md:text-3xl font-semibold text-foreground max-w-xl leading-snug">
            Direct contact — no intermediaries
          </h2>
          <p className="mt-3 text-muted-foreground text-base max-w-lg leading-relaxed">
            All enquiries are handled personally by Gregg. There are no account managers
            or call handlers — just a direct conversation with the consultant.
          </p>
        </motion.div>

        {/* Contact detail cards grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 md:gap-8">
          {contactDetails.map((item, index) => {
            const Icon = item.icon;
            const isExternal = item.href?.startsWith("http");

            const inner = (
              <div className="flex items-start gap-4">
                <div className="flex-shrink-0 flex items-center justify-center w-11 h-11 rounded-md border border-border bg-muted">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <div className="min-w-0">
                  <p className="text-xs uppercase tracking-[0.15em] text-muted-foreground font-medium mb-1">
                    {item.label}
                  </p>
                  <p className="text-foreground font-semibold text-base leading-snug">
                    {item.value}
                  </p>
                  {item.subvalue && (
                    <p className="text-foreground font-semibold text-base leading-snug">
                      {item.subvalue}
                    </p>
                  )}
                  <p className="mt-1.5 text-sm text-muted-foreground leading-relaxed">
                    {item.description}
                  </p>
                </div>
              </div>
            );

            return (
              <motion.div
                key={item.label}
                custom={index}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-40px" }}
              >
                {item.href ? (
                  <a
                    href={item.href}
                    target={isExternal ? "_blank" : undefined}
                    rel={isExternal ? "noopener noreferrer" : undefined}
                    className="block p-6 rounded-md border border-border bg-background hover:border-primary/50 hover:shadow-md transition-all duration-300 group"
                  >
                    {inner}
                  </a>
                ) : (
                  <div className="p-6 rounded-md border border-border bg-background">
                    {inner}
                  </div>
                )}
              </motion.div>
            );
          })}
        </div>

        {/* LocalBusiness JSON-LD structured data */}
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(schemaData) }}
        />

        {/* Reassurance footnote */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.7, ease: "easeOut", delay: 0.5 }}
          className="mt-10 text-sm text-muted-foreground border-t border-border pt-8"
        >
          Gregg King is an independent SEO consultant based in Warrington, Cheshire,
          working with UK businesses across competitive sectors including law, finance,
          healthcare, and property.
        </motion.p>

      </div>
    </section>
  );
});

ContactInfo.displayName = "ContactInfo";

export default ContactInfo;
