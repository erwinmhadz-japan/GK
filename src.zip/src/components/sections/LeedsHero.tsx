import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, TrendingUp, Search, ArrowRight, CheckCircle, Icon } from "lucide-react";
import { ImageBackground } from "@/components/ImageBackground";

const trustPills = [
  { icon: MapPin, label: "Leeds SEO Specialist" },
  { icon: TrendingUp, label: "Yorkshire Market Expertise" },
  { icon: Search, label: "Local Search Rankings" },
];

const LeedsHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="leeds-hero"
      src="https://images.unsplash.com/photo-1633537065985-c65a413f5961?w=1920&h=1080&fit=crop"
      alt="Leeds city skyline showing modern architecture and commercial buildings"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center py-24 md:py-36"
    >
      <div className="container relative z-10 max-w-6xl mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 28 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.65, ease: "easeOut" }}
          className="max-w-3xl"
        >
          {/* Location badge */}
          <div className="flex items-center gap-2 mb-5">
            <MapPin className="h-4 w-4 text-primary flex-shrink-0" aria-hidden="true" />
            <span className="text-sm uppercase tracking-[0.2em] font-medium text-white/80">
              Leeds, West Yorkshire
            </span>
          </div>

          {/* H1 */}
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-[1.1] mb-5 tracking-tight">
            SEO Services for{" "}
            <span className="text-gradient-green">Leeds Businesses</span>
          </h1>

          {/* Subheadline */}
          <p className="text-lg md:text-xl text-white/90 leading-relaxed mb-8 max-w-2xl">
            Leeds is one of the UK's fastest-growing business hubs — and competition for
            search visibility has never been fiercer. Independent SEO consultancy helping
            Leeds companies dominate local rankings and capture high-intent customers.
          </p>

          {/* CTAs */}
          <div className="flex flex-wrap gap-4 mb-10">
            <Button size="lg" asChild className="bg-primary text-primary-foreground font-semibold hover:bg-primary/90">
              <Link to="/contact">
                Get a Leeds SEO Audit
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              asChild
              className="bg-transparent text-white border-white hover:bg-white/10"
            >
              <Link to="/services-local-seo">
                Local SEO Services
              </Link>
            </Button>
          </div>

          {/* Trust pills */}
          <div className="flex flex-wrap gap-3">
            {trustPills.map(({ icon: Icon, label }) => (
              <Badge
                key={label}
                variant="secondary"
                className="flex items-center gap-1.5 px-3 py-1.5 bg-white/10 text-white/90 border border-white/20 backdrop-blur-sm text-xs font-medium"
              >
                <Icon className="h-3.5 w-3.5 text-primary flex-shrink-0" aria-hidden="true" />
                {label}
              </Badge>
            ))}
          </div>
        </motion.div>
      </div>
    </ImageBackground>
  );
});

LeedsHero.displayName = "LeedsHero";

export default LeedsHero;
