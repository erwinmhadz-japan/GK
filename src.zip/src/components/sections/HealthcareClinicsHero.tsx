import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Stethoscope, ShieldCheck, MapPin, Icon, Search } from "lucide-react";

const HealthcareClinicsHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="healthcare-hero"
      aria-label="Healthcare clinics SEO hero section"
      src="https://images.unsplash.com/photo-1758691461916-dc7894eb8f94?w=1920&h=1080&fit=crop"
      alt="Doctor wearing a stethoscope at his desk — representing healthcare SEO expertise"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center"
    >
      <div className="container relative z-10 py-24 md:py-32">
        <div className="max-w-3xl">
          <Badge
            variant="secondary"
            className="mb-6 inline-flex items-center gap-2 bg-primary/20 text-white border-primary/30 uppercase tracking-wider text-xs font-semibold px-4 py-1.5"
          >
            <Stethoscope className="h-3.5 w-3.5" />
            Healthcare SEO Specialists
          </Badge>

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight mb-6">
            SEO That Drives{" "}
            <span className="text-gradient-green">Patient Acquisition</span>{" "}
            for Healthcare Clinics
          </h1>

          <p className="text-lg md:text-xl text-white/90 leading-relaxed mb-8 max-w-2xl">
            Private medical providers face unique challenges: YMYL scrutiny, local search
            competition, and strict regulatory compliance. We deliver specialist healthcare
            SEO that builds trust, dominates local search, and converts patients at every
            stage of their journey.
          </p>

          <div className="flex flex-wrap gap-3 mb-10">
            {[
              { icon: ShieldCheck, label: "YMYL-Compliant SEO" },
              { icon: MapPin, label: "Local Search Domination" },
              { icon: Stethoscope, label: "Healthcare Schema" },
            ].map(({ icon: Icon, label }) => (
              <div
                key={label}
                className="flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-4 py-2 text-white/90 text-sm font-medium"
              >
                <Icon className="h-4 w-4 text-primary" />
                {label}
              </div>
            ))}
          </div>

          <div className="flex flex-wrap gap-4">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold shadow-green-glow"
              asChild
            >
              <a href="/contact">
                Get Your Free Healthcare SEO Audit
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10 font-semibold"
              asChild
            >
              <a href="/services-local-seo">Explore Local SEO</a>
            </Button>
          </div>

          <p className="mt-6 text-sm text-white/80">
            Trusted by NHS and private medical providers across the UK · No long-term lock-in
          </p>
        </div>
      </div>
    </ImageBackground>
  );
});

HealthcareClinicsHero.displayName = "HealthcareClinicsHero";

export default HealthcareClinicsHero;
