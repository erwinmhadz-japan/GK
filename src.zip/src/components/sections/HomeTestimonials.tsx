import React from "react";
import { motion } from "framer-motion";
import { Quote, ArrowRight, Group, Section, View } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";

interface Testimonial {
  quote: string;
  attribution: string;
  sector: string;
  result: string;
}

const testimonials: Testimonial[] = [
  {
    quote:
      "Gregg brought a level of technical rigour and commercial understanding I hadn't found elsewhere. Organic enquiries from search increased substantially within the first quarter — and the quality of leads improved noticeably.",
    attribution: "Partner",
    sector: "Commercial Law Firm, Manchester",
    result: "Significant increase in qualified organic enquiries",
  },
  {
    quote:
      "Working with an independent consultant rather than an agency made an immediate difference. Gregg is accountable, direct, and clearly knows how the search landscape is shifting — particularly around AI-generated results.",
    attribution: "Director",
    sector: "Private Healthcare Group, Cheshire",
    result: "Improved visibility across AI search platforms",
  },
  {
    quote:
      "The SEO audit identified structural issues we didn't know existed. The technical recommendations were clear, prioritised, and implementable. Our organic traffic has grown steadily since.",
    attribution: "Head of Marketing",
    sector: "Financial Services, Leeds",
    result: "Sustained organic traffic growth post-audit",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.15,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut" },
  },
};

const headingVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut" },
  },
};

const HomeTestimonials = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="home-testimonials"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section heading */}
        <motion.div
          className="mb-14 md:mb-18"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={headingVariants}
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Voice of Clients
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground max-w-2xl leading-tight">
            Client Results
          </h2>
          <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-xl">
            A selection of outcomes from UK businesses I've worked with across
            law, healthcare, and financial services.
          </p>
        </motion.div>

        {/* Testimonial cards */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={containerVariants}
        >
          {testimonials.map((item, index) => (
            <motion.div
              key={index}
              variants={cardVariants}
              className="group relative flex flex-col border border-border rounded-md p-7 md:p-8 bg-background hover:border-primary/40 transition-colors duration-300"
              style={{
                boxShadow:
                  "0 2px 16px 0 hsl(225 28% 14% / 0.07), 0 1px 3px 0 hsl(225 28% 14% / 0.05)",
              }}
            >
              {/* Large decorative quote icon */}
              <Quote
                className="h-8 w-8 mb-6 flex-shrink-0"
                style={{ color: "hsl(119 35% 61% / 0.70)" }}
                aria-hidden="true"
              />

              {/* Pull-quote */}
              <blockquote className="flex-1 mb-8">
                <p className="text-foreground text-base md:text-lg leading-relaxed font-light italic">
                  &ldquo;{item.quote}&rdquo;
                </p>
              </blockquote>

              {/* Result pill */}
              <div className="mb-5">
                <span
                  className="inline-block text-xs uppercase tracking-widest font-semibold px-3 py-1.5 rounded-sm"
                  style={{
                    background: "hsl(84 74% 58% / 0.10)",
                    color: "hsl(119 35% 40%)",
                  }}
                >
                  {item.result}
                </span>
              </div>

              {/* Attribution */}
              <footer className="border-t border-border pt-5">
                <p className="text-sm font-semibold text-foreground">
                  {item.attribution}
                </p>
                <p className="text-xs text-muted-foreground mt-0.5 tracking-wide">
                  {item.sector}
                </p>
              </footer>
            </motion.div>
          ))}
        </motion.div>

        {/* Link to full case studies */}
        <motion.div
          className="mt-12 flex justify-center"
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
        >
          <Button
            variant="outline"
            className="group border-border text-foreground hover:border-primary/60 hover:text-primary transition-colors duration-200"
            asChild
          >
            <Link to="#case-studies-cta">
              View full case studies
              <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform duration-200" />
            </Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
});

HomeTestimonials.displayName = "HomeTestimonials";

export default HomeTestimonials;
