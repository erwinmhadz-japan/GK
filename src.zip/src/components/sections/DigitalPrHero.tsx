import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Newspaper, Link as LinkIcon, TrendingUp, Contact, Icon, View } from "lucide-react";

const DigitalPrHero = React.forwardRef<HTMLElement>((props, ref) => {
  const pillars = [
    {
      icon: Newspaper,
      label: "Editorial Coverage",
    },
    {
      icon: LinkIcon,
      label: "High-Authority Links",
    },
    {
      icon: TrendingUp,
      label: "Ranking Impact",
    },
  ];

  return (
    <section
      ref={ref}
      id="digital-pr-hero"
      className="relative isolate overflow-hidden border-t border-border bg-[hsl(225_28%_14%)]"
    >
      {/* Subtle dot-grid texture */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(214 32% 60%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      {/* Soft green gradient glow — top right */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-32 right-0 h-[480px] w-[480px] rounded-full opacity-10 blur-3xl"
        style={{
          background:
            "radial-gradient(circle at center, hsl(84 74% 58%), transparent 70%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 py-24 md:py-36 relative z-10">
        <div className="max-w-3xl">
          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0 }}
            className="mb-6"
          >
            <span className="inline-block text-xs uppercase tracking-[0.2em] font-medium text-white/80">
              Digital PR · SEO Consultant UK
            </span>
          </motion.div>

          {/* H1 */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-tight tracking-tight max-w-2xl"
          >
            Digital PR for SEO
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.2 }}
            className="mt-6 text-lg md:text-xl text-white/80 leading-relaxed max-w-2xl"
          >
            Earn high-authority backlinks through strategic digital PR — coverage that builds rankings, trust, and brand authority.
          </motion.p>

          {/* Pillar badges */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
            className="mt-8 flex flex-wrap gap-3"
          >
            {pillars.map(({ icon: Icon, label }) => (
              <Badge
                key={label}
                variant="outline"
                className="flex items-center gap-1.5 border-white/20 bg-white/5 text-white/80 text-xs px-3 py-1.5"
              >
                <Icon className="h-3.5 w-3.5 text-[hsl(84_74%_58%)]" />
                {label}
              </Badge>
            ))}
          </motion.div>

          {/* CTA row */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.4 }}
            className="mt-10 flex flex-wrap items-center gap-4"
          >
            <Button
              size="lg"
              className="bg-gradient-to-r from-[hsl(84_74%_58%)] to-[hsl(119_35%_61%)] text-[hsl(225_28%_14%)] font-semibold hover:opacity-90 transition-opacity h-12 px-8"
              asChild
            >
              <Link to="/contact">
                Contact Me
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>

            <Button
              size="lg"
              variant="outline"
              className="bg-transparent border-white/30 text-white hover:bg-white/10 hover:border-white/50 transition-all h-12 px-8"
              asChild
            >
              <Link to="/services">
                View All Services
              </Link>
            </Button>
          </motion.div>

          {/* Trust note */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.55 }}
            className="mt-6 text-sm text-white/80"
          >
            Independent UK SEO consultant · Editorial link building · No mass outreach
          </motion.p>
        </div>
      </div>
    </section>
  );
});

DigitalPrHero.displayName = "DigitalPrHero";

export default DigitalPrHero;
