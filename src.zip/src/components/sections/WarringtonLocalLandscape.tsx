import React from "react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin, TrendingUp, Building2, Users, Search, Zap, Grid, Icon } from "lucide-react";

const insights = [
  {
    icon: Building2,
    title: "Diverse Business Ecosystem",
    body: "Warrington's economy spans logistics and distribution, professional services, retail, hospitality, and a growing tech sector — all competing for the same high-intent local searches. Standing out requires precision, not guesswork.",
  },
  {
    icon: TrendingUp,
    title: "Growing Digital Demand",
    body: "Local search volumes for Warrington businesses have grown year-on-year as consumers search for services 'near me'. Businesses that invest in local SEO now capture demand their competitors are leaving behind.",
  },
  {
    icon: MapPin,
    title: "Strategic North West Location",
    body: "Positioned between Liverpool and Manchester, Warrington draws customers from a wide catchment — Widnes, Runcorn, Northwich, and St Helens. Your SEO must reflect this geographic reach, not just the WA postcode.",
  },
  {
    icon: Users,
    title: "Mobile-First Local Audience",
    body: "Over 60% of local Warrington searches happen on mobile devices. Google prioritises mobile-optimised, fast-loading pages in local packs — your site must perform flawlessly across all devices.",
  },
  {
    icon: Search,
    title: "Competitive Local Packs",
    body: "The Google Local Pack for high-value Warrington service categories is fiercely contested. Appearing in the top three positions requires a holistic strategy: citations, reviews, on-page signals, and authority building.",
  },
  {
    icon: Zap,
    title: "Voice & AI Search Rising",
    body: "More Warrington consumers are using voice search and AI assistants to find local businesses. Structuring your content with schema markup and conversational queries now positions you ahead of the next wave of local search.",
  },
];

const WarringtonLocalLandscape = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        {/* Header */}
        <div className="max-w-2xl mb-12">
          <Badge className="mb-4 bg-primary/10 text-primary border-primary/20">
            Local Search Landscape
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Understanding Warrington's Local Search Market
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Warrington is a thriving commercial hub in the heart of the North
            West. To win local customers, you need to understand how they
            search — and build an SEO strategy that meets them exactly where
            they are.
          </p>
        </div>

        {/* Insights Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {insights.map(({ icon: Icon, title, body }) => (
            <Card
              key={title}
              className="border border-border bg-card shadow-card hover-lift transition-shadow"
            >
              <CardHeader className="pb-3">
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-3">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <CardTitle className="text-base font-semibold text-foreground leading-snug">
                  {title}
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {body}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Stat strip */}
        <div className="mt-14 grid grid-cols-1 sm:grid-cols-3 gap-6 border border-border rounded-xl p-6 md:p-8 bg-muted">
          <div className="text-center">
            <p className="text-4xl font-bold text-primary mb-1">78%</p>
            <p className="text-sm text-muted-foreground">
              of local searches result in a store visit or contact within 24 hours
            </p>
          </div>
          <div className="text-center border-t sm:border-t-0 sm:border-l border-border pt-4 sm:pt-0 sm:pl-6">
            <p className="text-4xl font-bold text-primary mb-1">3×</p>
            <p className="text-sm text-muted-foreground">
              more clicks go to the top 3 Google Local Pack results vs page-one organic listings
            </p>
          </div>
          <div className="text-center border-t sm:border-t-0 sm:border-l border-border pt-4 sm:pt-0 sm:pl-6">
            <p className="text-4xl font-bold text-primary mb-1">46%</p>
            <p className="text-sm text-muted-foreground">
              of all Google searches are looking for local information or local businesses
            </p>
          </div>
        </div>
      </div>
    </section>
  );
});

WarringtonLocalLandscape.displayName = "WarringtonLocalLandscape";

export default WarringtonLocalLandscape;
