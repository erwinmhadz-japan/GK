import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle } from "lucide-react";

const checkPoints = [
  "Identify missing or broken schema",
  "Review rich result eligibility",
  "Pinpoint implementation errors",
  "Receive clear, actionable next steps",
];

const SchemaMarkupCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="schema-markup-cta"
      className="relative py-20 md:py-32 border-t border-border bg-background"
      style={{
        background: "hsl(225 28% 14%)",
      }}
    >
      {/* Subtle dot-grid texture layer */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(0 0% 100%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      {/* Subtle green accent glow — top-right */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-32 right-0 w-96 h-96 rounded-full blur-3xl opacity-10"
        style={{ background: "hsl(84 74% 58%)" }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">

          {/* Eyebrow */}
          <motion.span
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut" }}
            className="inline-block text-xs uppercase tracking-[0.2em] font-medium mb-6"
            style={{ color: "hsl(84 74% 58%)" }}
          >
            Schema Markup Audit
          </motion.span>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.08 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight tracking-tight mb-6"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Get Your Structured Data Audited
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.16 }}
            className="text-lg md:text-xl leading-relaxed mb-10 max-w-2xl mx-auto"
            style={{ color: "hsl(0 0% 100% / 0.82)", fontFamily: "Inter, sans-serif" }}
          >
            Find out whether your schema markup is helping or hurting your search
            visibility — and what to fix first.
          </motion.p>

          {/* Checklist */}
          <motion.ul
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.24 }}
            className="flex flex-col sm:flex-row sm:flex-wrap sm:justify-center gap-3 mb-12"
            aria-label="What the audit covers"
          >
            {checkPoints.map((point, i) => (
              <li
                key={i}
                className="flex items-center gap-2 text-sm"
                style={{ color: "hsl(0 0% 100% / 0.80)", fontFamily: "Inter, sans-serif" }}
              >
                <CheckCircle
                  className="h-4 w-4 flex-shrink-0"
                  style={{ color: "hsl(84 74% 58%)" }}
                  aria-hidden="true"
                />
                {point}
              </li>
            ))}
          </motion.ul>

          {/* CTA button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.32 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Button
              size="lg"
              asChild
              className="h-12 px-8 text-base font-semibold rounded-md transition-all duration-300 hover:opacity-90 hover:shadow-[0_0_32px_hsl(84_74%_58%_/_0.35)]"
              style={{
                background: "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                color: "hsl(225 28% 14%)",
                fontFamily: "Inter, sans-serif",
                border: "none",
              }}
            >
              <Link to="/contact">
                Free SEO Audit
                <ArrowRight className="ml-2 h-4 w-4" aria-hidden="true" />
              </Link>
            </Button>

            <span
              className="text-sm"
              style={{ color: "hsl(0 0% 100% / 0.80)", fontFamily: "Inter, sans-serif" }}
            >
              No obligation · Independent advice · UK-based
            </span>
          </motion.div>

        </div>
      </div>
    </section>
  );
});

SchemaMarkupCTA.displayName = "SchemaMarkupCTA";

export default SchemaMarkupCTA;
