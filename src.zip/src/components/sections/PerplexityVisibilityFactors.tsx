import React from "react";
import { motion } from "framer-motion";
import { ShieldCheck, FileText, Link2, Brain, BookOpen, Globe, Eye, Tag, ListChecks, TrendingUp, ArrowRight, Search, Signal } from "lucide-react";
import { Link } from "react-router-dom";
import { Badge } from "@/components/ui/badge";

interface Factor {
  number: string;
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  body: string;
  tag: string;
}

const factors: Factor[] = [
  {
    number: "01",
    icon: ShieldCheck,
    title: "E-E-A-T Signal Strength",
    body: "Perplexity prioritises sources with demonstrable Experience, Expertise, Authoritativeness, and Trustworthiness. For UK businesses, this means publishing content authored by named, credentialled individuals with verifiable professional standing — not anonymous brand copy.",
    tag: "Trust Signals",
  },
  {
    number: "02",
    icon: FileText,
    title: "Structured, Answer-Ready Content",
    body: "Perplexity retrieves content that directly answers a specific question. Pages structured with clear headings, concise definitions, and explicit answers — rather than introductory waffle — are far more likely to be surfaced as cited sources.",
    tag: "Content Structure",
  },
  {
    number: "03",
    icon: Link2,
    title: "Authoritative External Citations",
    body: "Pages that cite high-quality external sources — industry bodies, academic research, government data — signal editorial rigour. Perplexity models reward content that demonstrates awareness of the broader knowledge landscape rather than self-referential claims.",
    tag: "Citation Quality",
  },
  {
    number: "04",
    icon: Brain,
    title: "Entity Recognition and Consistency",
    body: "Consistent entity representation across your website, Google Business Profile, industry directories, and third-party publications helps Perplexity identify and trust your brand as a distinct, well-defined entity. Inconsistent NAP data or fragmented brand presence works against this.",
    tag: "Entity SEO",
  },
  {
    number: "05",
    icon: BookOpen,
    title: "Topical Authority and Depth",
    body: "Perplexity is more likely to cite a source that covers a topic comprehensively and consistently. A single well-written article is rarely sufficient. Sustained publication across a defined subject area — with internal links that reinforce topical clusters — builds the authority Perplexity recognises.",
    tag: "Topical Coverage",
  },
  {
    number: "06",
    icon: Globe,
    title: "Domain Reputation and Link Profile",
    body: "Perplexity's underlying retrieval layer is influenced by the same domain authority signals that affect traditional search. Authoritative inbound links from reputable UK domains — trade publications, professional associations, press mentions — remain a foundational visibility factor.",
    tag: "Domain Authority",
  },
  {
    number: "07",
    icon: Eye,
    title: "Readability and Editorial Quality",
    body: "Poorly edited, verbose, or jargon-heavy content is deprioritised. Perplexity favours prose that is precise, readable, and free of filler. For UK professional services businesses, this aligns well with a measured, authoritative editorial standard rather than high-volume content output.",
    tag: "Editorial Quality",
  },
  {
    number: "08",
    icon: Tag,
    title: "Schema Markup and Structured Data",
    body: "Implementing appropriate schema — including Organisation, Article, FAQPage, and Person markup — makes content semantically legible to retrieval systems. While Perplexity does not publish a schema specification, structured data improves the machine-readability of your content across all AI answer engines.",
    tag: "Technical SEO",
  },
  {
    number: "09",
    icon: ListChecks,
    title: "Crawlability and Indexation Health",
    body: "Perplexity retrieves and indexes publicly accessible content. Technical barriers — blocked crawl paths, slow page speeds, thin or duplicated content, or pages excluded from indexation — will prevent your content from being considered as a citation source, regardless of its quality.",
    tag: "Technical Foundations",
  },
  {
    number: "10",
    icon: TrendingUp,
    title: "Recency and Ongoing Publication",
    body: "For fast-moving topics, Perplexity gives weight to recently published or updated content. UK businesses that maintain a consistent editorial calendar — particularly in regulated sectors such as finance, law, and healthcare — are better positioned to remain cited as the information landscape evolves.",
    tag: "Content Freshness",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.07,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: "easeOut" },
  },
};

const PerplexityVisibilityFactors = React.forwardRef<HTMLElement>(
  (props, ref) => {
    return (
      <section
        ref={ref}
        id="perplexity-visibility-factors"
        className="relative py-20 md:py-32 border-t border-border bg-muted"
      >
        <div className="container max-w-6xl mx-auto px-4">
          {/* Header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="mb-12 md:mb-16"
          >
            <span className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground font-medium mb-4">
              Visibility Factors
            </span>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-semibold text-foreground tracking-tight max-w-3xl mb-4">
              Ten Factors That Influence Perplexity Citations
            </h2>
            <p className="text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
              Perplexity does not publish ranking criteria, but the signals that
              determine whether a UK business is cited as a trusted source are
              identifiable through careful analysis. These are the factors that
              matter most.
            </p>
          </motion.div>

          {/* Factors grid — 2 columns on md+, 1 on mobile */}
          <motion.div
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            className="grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-6"
          >
            {factors.map((factor) => {
              const Icon = factor.icon;
              return (
                <motion.div
                  key={factor.number}
                  variants={itemVariants}
                  className="group relative bg-background border border-border rounded-md p-6 md:p-7 flex flex-col gap-4 hover:border-primary/40 transition-colors duration-300"
                  style={{
                    boxShadow:
                      "0 2px 12px -2px hsl(222 28% 11% / 0.06), 0 1px 3px hsl(222 28% 11% / 0.04)",
                  }}
                >
                  {/* Number + icon row */}
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex items-center gap-3">
                      {/* Step number */}
                      <span className="text-xs font-semibold text-primary/70 tabular-nums leading-none mt-0.5">
                        {factor.number}
                      </span>
                      {/* Icon */}
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-primary/10">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                    </div>
                    {/* Tag badge */}
                    <Badge
                      variant="secondary"
                      className="text-xs shrink-0 mt-0.5"
                    >
                      {factor.tag}
                    </Badge>
                  </div>

                  {/* Title */}
                  <h3 className="text-base md:text-lg font-semibold text-foreground leading-snug">
                    {factor.title}
                  </h3>

                  {/* Body */}
                  <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                    {factor.body}
                  </p>

                  {/* Hover accent line */}
                  <span
                    className="absolute bottom-0 left-0 h-0.5 w-0 group-hover:w-full bg-gradient-to-r from-primary to-accent rounded-b-md transition-all duration-500 ease-out"
                    aria-hidden="true"
                  />
                </motion.div>
              );
            })}
          </motion.div>

          {/* Closing note */}
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-40px" }}
            transition={{ duration: 0.5, ease: "easeOut", delay: 0.2 }}
            className="mt-10 md:mt-12 text-sm text-muted-foreground max-w-2xl leading-relaxed"
          >
            These factors do not operate in isolation. Perplexity's citation
            behaviour reflects the cumulative strength of a site's authority
            signals, structural quality, and editorial consistency — all of
            which feed into the same foundations that drive traditional search
            performance.
          </motion.p>

          {/* Internal links — AI Search child pages */}
          <motion.div
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-40px" }}
            transition={{ duration: 0.5, ease: "easeOut", delay: 0.28 }}
            className="mt-8 pt-8 border-t border-border"
          >
            <p className="text-xs uppercase tracking-widest text-muted-foreground font-medium mb-4">
              Apply these factors — AI Search services
            </p>
            <div className="flex flex-wrap gap-3">
              <Link
                to="/ai-search-optimisation"
                className="inline-flex items-center gap-1.5 text-sm text-foreground hover:text-primary border border-border rounded-md px-3 py-1.5 bg-background hover:border-primary/40 transition-colors"
              >
                AI Search Optimisation
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
              <Link
                to="#ai-search-cta"
                className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary border border-border rounded-md px-3 py-1.5 bg-background hover:border-primary/40 transition-colors"
              >
                AI Search Hub
                <ArrowRight className="h-3.5 w-3.5" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
);

PerplexityVisibilityFactors.displayName = "PerplexityVisibilityFactors";

export default PerplexityVisibilityFactors;
