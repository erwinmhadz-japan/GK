import React from "react";
import { Lightbulb, FileText, Target, Network, TrendingUp, Layers, Scale } from "lucide-react";

const strategies = [
  {
    icon: FileText,
    step: "01",
    title: "Answer-First Content Structure",
    description:
      "Copilot favours content that delivers a direct, concise answer within the first paragraph — then expands with detail. Restructure key pages to lead with a clear answer to the implied query, followed by supporting context. This mirrors how Copilot surfaces and truncates citations in its responses.",
  },
  {
    icon: Target,
    step: "02",
    title: "Target Informational Queries at Scale",
    description:
      "Copilot is primarily used for informational and research-type queries. Build topical clusters around the questions your customers ask — including 'what is', 'how does', 'which is best' formats — so Copilot sees your content as the authoritative reference for your niche.",
  },
  {
    icon: Network,
    step: "03",
    title: "Internal Linking & Topic Cluster Architecture",
    description:
      "Copilot traces topical authority through content relationships. A well-structured internal linking strategy — where a pillar page links out to supporting cluster pages and vice versa — reinforces entity associations and helps Copilot understand the breadth of your expertise.",
    link: { href: "/content-strategy", label: "See our content strategy services" },
  },
  {
    icon: Layers,
    step: "04",
    title: "FAQPage and Structured Q&A Markup",
    description:
      "Implementing FAQPage schema on pages that answer common questions creates a direct signal to Copilot's retrieval layer. Copilot is trained to surface well-structured Q&A content — and schema markup ensures the right question-answer pairs are extracted cleanly.",
  },
  {
    icon: TrendingUp,
    step: "05",
    title: "Freshness Signals & Content Updates",
    description:
      "Copilot prioritises recent, updated content — particularly for fast-moving topics like AI, technology, finance, and regulations. Regularly refreshing existing pages with updated statistics, new examples, and current best practices improves Copilot citation likelihood.",
  },
  {
    icon: Lightbulb,
    step: "06",
    title: "Brand Authority & Digital PR",
    description:
      "Copilot's sourcing is heavily influenced by how authoritative your brand is perceived to be across the web. A targeted digital PR programme — securing editorial coverage in industry publications indexed by Bing — accelerates Copilot trust and citation frequency.",
    link: { href: "/technical-seo", label: "Explore technical SEO foundations" },
  },
];

const AiSearchCopilotContentStrategy = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="copilot-content-strategy"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Content Strategies
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            How to Get Your Content Cited by Copilot
          </h2>
          <p className="text-muted-foreground text-base md:text-lg leading-relaxed">
            Copilot visibility is earned through deliberate content strategy — not luck. These six approaches, applied consistently, move the needle on how often Copilot selects your site as a source.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
          {strategies.map((s) => (
            <div
              key={s.title}
              className="relative p-7 rounded-xl bg-card border border-border hover-lift shadow-card flex flex-col"
            >
              <div className="text-5xl font-black text-primary/10 absolute top-5 right-6 leading-none select-none">
                {s.step}
              </div>
              <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-4">
                <s.icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="text-lg font-bold text-foreground mb-3">{s.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed flex-1">{s.description}</p>
              {s.link && (
                <a
                  href={s.link.href}
                  className="inline-flex items-center gap-1 mt-4 text-sm text-primary font-medium hover:underline underline-offset-4"
                >
                  {s.link.label} →
                </a>
              )}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
});

AiSearchCopilotContentStrategy.displayName = "AiSearchCopilotContentStrategy";
export default AiSearchCopilotContentStrategy;
