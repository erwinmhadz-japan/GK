import React from "react";
import { motion } from "framer-motion";
import { Quote, Section } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const testimonials = [
  {
    quote:
      "Gregg transformed our organic performance within six months. Unlike the agencies we'd tried before, he gave us clear explanations and a strategy that actually made sense for our business.",
    name: "Sarah Mitchell",
    role: "Head of Marketing",
    company: "Manchester-based B2B SaaS",
    image: "https://images.unsplash.com/photo-1681500920181-0aff411f8cab?w=400&h=400&fit=crop&crop=face",
    initials: "SM",
  },
  {
    quote:
      "The SEO audit alone was worth its weight in gold. Gregg identified technical issues our previous agency had missed for over a year. Our click-through rates jumped 40% within three months of implementing his recommendations.",
    name: "James Whitfield",
    role: "Director",
    company: "Specialist law firm, Leeds",
    image: "https://images.unsplash.com/photo-1734830268394-6c4a1f165af1?w=400&h=400&fit=crop&crop=face",
    initials: "JW",
  },
  {
    quote:
      "We brought Gregg in specifically for his AI search expertise, and he delivered. Our brand is now consistently appearing in ChatGPT and Perplexity responses for key industry queries — something we hadn't even considered before.",
    name: "Priya Nair",
    role: "Digital Lead",
    company: "Financial services firm",
    image: "https://images.unsplash.com/photo-1710778044102-56a3a6b69a1b?w=400&h=400&fit=crop&crop=face",
    initials: "PN",
  },
];

const Page1Testimonials = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="page1-testimonials"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      {/* Subtle gradient accent */}
      <div
        className="absolute inset-0 pointer-events-none"
        aria-hidden="true"
        style={{
          backgroundImage:
            "radial-gradient(circle at 80% 30%, hsl(88 59% 56% / 0.05) 0%, transparent 55%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="text-center mb-14 md:mb-16"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Client Feedback
          </span>
          <h2
            className="text-3xl md:text-4xl font-bold text-foreground max-w-2xl mx-auto leading-tight mb-4"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            What Clients Say About Working With Me
          </h2>
          <p className="text-base md:text-lg text-muted-foreground max-w-xl mx-auto leading-relaxed">
            Real feedback from businesses that have seen genuine, measurable improvements to their organic presence.
          </p>
        </motion.div>

        {/* Testimonial cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.55, ease: "easeOut", delay: index * 0.1 }}
              className="flex flex-col bg-card border border-border rounded-xl p-7 shadow-card hover:shadow-card-hover transition-shadow duration-300"
            >
              {/* Quote icon */}
              <Quote
                className="h-7 w-7 mb-5 flex-shrink-0"
                style={{ color: "hsl(88 59% 56%)" }}
                aria-hidden="true"
              />

              {/* Quote text */}
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed flex-1 mb-6 italic">
                "{testimonial.quote}"
              </p>

              {/* Attribution */}
              <div className="flex items-center gap-3 mt-auto pt-5 border-t border-border">
                <Avatar className="h-10 w-10 flex-shrink-0">
                  <AvatarImage
                    src={testimonial.image}
                    alt={testimonial.name}
                  />
                  <AvatarFallback className="text-xs font-semibold bg-muted text-muted-foreground">
                    {testimonial.initials}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <p className="text-sm font-semibold text-foreground leading-tight">
                    {testimonial.name}
                  </p>
                  <p className="text-xs text-muted-foreground">
                    {testimonial.role}, {testimonial.company}
                  </p>
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
});

Page1Testimonials.displayName = "Page1Testimonials";

export default Page1Testimonials;
