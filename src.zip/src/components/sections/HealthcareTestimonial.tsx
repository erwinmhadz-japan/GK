import React from "react";
import { Star, TrendingUp, Users, MapPin, Group, Icon, Stars, View } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const stats = [
  { icon: TrendingUp, value: "+183%", label: "Organic traffic in 9 months" },
  { icon: Users, value: "+240%", label: "New patient enquiries" },
  { icon: MapPin, value: "#1", label: "Local Pack for 6 key services" },
];

const HealthcareTestimonial: React.FC = () => {
  return (
    <section className="relative isolate py-24 md:py-36 border-t border-border overflow-hidden">
      {/* faded_photo background */}
      <img
        src="https://images.unsplash.com/photo-1758691463393-a2aa9900af8a?w=1920&h=1080&fit=crop"
        alt="Smiling doctor wearing glasses and stethoscope in office"
        width={1920}
        height={1080}
        loading="lazy"
        className="absolute inset-0 w-full h-full object-cover opacity-20"
      />
      {/* No black overlay needed — image is already faded */}
      <div className="container relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Case study content */}
          <div>
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
              Case Study
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
              How a Multi-Site Private Clinic Grew Patient Enquiries by{" "}
              <span className="text-gradient-green">240%</span>
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-6">
              A private GP group operating across three locations in the South East was invisible in
              local search — losing patients to NHS walk-in centres that ranked above them for
              branded condition searches. Their website had no structured data, duplicate location
              pages, and thin service content that failed YMYL standards.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Over nine months we restructured their entity architecture, implemented{" "}
              <a href="/schema-markup" className="text-primary hover:underline font-medium">
                MedicalClinic and Physician schema
              </a>{" "}
              across all three locations, built a practitioner-led{" "}
              <a href="/content-strategy" className="text-primary hover:underline font-medium">
                patient education content hub
              </a>
              , and consolidated their{" "}
              <a href="/local-seo" className="text-primary hover:underline font-medium">
                local SEO signals
              </a>{" "}
              into a coherent, citation-consistent profile. The result: first-page visibility for
              every core service and a trebling of organic appointment enquiries.
            </p>

            {/* Stats row */}
            <div className="grid grid-cols-3 gap-4 mb-8">
              {stats.map(({ icon: Icon, value, label }) => (
                <div
                  key={label}
                  className="rounded-xl border border-border bg-card p-4 text-center shadow-soft"
                >
                  <Icon className="h-5 w-5 text-primary mx-auto mb-2" />
                  <p className="text-xl font-bold text-foreground">{value}</p>
                  <p className="text-xs text-muted-foreground mt-1 leading-snug">{label}</p>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap gap-3">
              <a
                href="#case-studies-cta"
                className="inline-flex items-center gap-2 rounded-lg bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary/90 transition-colors"
              >
                View Full Case Study
              </a>
              <a
                href="/contact"
                className="inline-flex items-center gap-2 rounded-lg border border-border bg-background px-5 py-2.5 text-sm font-medium text-foreground hover:border-primary hover:text-primary transition-colors"
              >
                Get Your Free Audit
              </a>
            </div>
          </div>

          {/* Testimonial quote */}
          <div className="relative">
            <div className="rounded-2xl border border-border bg-card shadow-card p-8 md:p-10">
              {/* Stars */}
              <div className="flex gap-1 mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="h-5 w-5 fill-primary text-primary" />
                ))}
              </div>

              <blockquote className="text-lg md:text-xl font-medium text-foreground leading-relaxed mb-8">
                "Before working with Gregg, we were effectively invisible to patients searching
                online — even for our own practitioners by name. Within six months we had patients
                telling us they found us on Google for the first time. The structured data work
                alone transformed how our practices appeared in search results."
              </blockquote>

              <div className="flex items-center gap-4">
                <img
                  src="https://images.unsplash.com/photo-1758691463582-11aea602cd4a?w=400&h=400&fit=crop&crop=face"
                  alt="Smiling doctor with glasses and stethoscope"
                  width={400}
                  height={400}
                  loading="lazy"
                  className="h-14 w-14 rounded-full object-cover border-2 border-primary/20"
                />
                <div>
                  <p className="font-semibold text-foreground">Dr. Sarah Whitfield</p>
                  <p className="text-sm text-muted-foreground">Clinical Director, Whitfield Medical Group</p>
                  <Badge variant="outline" className="mt-1 text-xs">
                    Private GP Group · South East England
                  </Badge>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HealthcareTestimonial;
