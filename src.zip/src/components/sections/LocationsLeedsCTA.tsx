import React from "react";
import { Phone, Mail, MapPin, ArrowRight, CheckCircle, Book, Contact, Search, View } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ImageBackground } from "@/components/ImageBackground";

const benefits = [
  "Free Leeds SEO audit — no obligation",
  "Leeds market analysis included",
  "Response within 1 working day",
  "No long-term contracts required",
];

const LocationsLeedsCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      src="https://images.unsplash.com/photo-1730851357916-3802b6405271?w=1920&h=1080&fit=crop"
      alt="Professional consultant ready to help Leeds businesses grow"
      imgProps={{ loading: "lazy" }}
      className="py-24 md:py-36"
      as="section"
      id="leeds-contact"
    >
      <div className="container relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left — copy */}
          <div>
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4">
              Get Started in Leeds
            </span>
            <h2 className="text-3xl md:text-5xl font-bold text-white leading-tight mb-6">
              Ready to Dominate Leeds Search Results?
            </h2>
            <p className="text-white/90 text-lg leading-relaxed mb-8">
              Whether you're starting from scratch or want to accelerate
              existing growth, let's talk about your Leeds SEO goals. Book a
              free consultation and get a clear picture of what's possible for
              your business.
            </p>
            <ul className="space-y-3 mb-10">
              {benefits.map((benefit) => (
                <li key={benefit} className="flex items-center gap-3">
                  <CheckCircle className="h-5 w-5 text-primary shrink-0" />
                  <span className="text-white/90">{benefit}</span>
                </li>
              ))}
            </ul>
            <div className="flex flex-wrap gap-4">
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90"
                asChild
              >
                <a href="/contact">
                  Book a Free Leeds Consultation
                  <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="bg-transparent text-white border-white hover:bg-white/10"
                asChild
              >
                <a href="/services">View All Services</a>
              </Button>
            </div>
          </div>

          {/* Right — contact info card */}
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-8">
            <h3 className="text-xl font-bold text-white mb-6">
              Leeds Contact Details
            </h3>
            <div className="space-y-5">
              <div className="flex items-start gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20 shrink-0">
                  <MapPin className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-white/80 font-medium uppercase tracking-wide mb-1">
                    Address
                  </p>
                  <p className="text-white leading-snug">
                    1 Park Row, Leeds, LS1 5AB
                    <br />
                    West Yorkshire, UK
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20 shrink-0">
                  <Phone className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-white/80 font-medium uppercase tracking-wide mb-1">
                    Phone
                  </p>
                  <a
                    href="tel:+441130000000"
                    className="text-white hover:text-primary transition-colors"
                  >
                    +44 113 000 0000
                  </a>
                </div>
              </div>
              <div className="flex items-start gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20 shrink-0">
                  <Mail className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm text-white/80 font-medium uppercase tracking-wide mb-1">
                    Email
                  </p>
                  <a
                    href="mailto:leeds@greggseo.com"
                    className="text-white hover:text-primary transition-colors"
                  >
                    leeds@greggseo.com
                  </a>
                </div>
              </div>
            </div>
            <div className="mt-8 pt-6 border-t border-white/20">
              <p className="text-sm text-white/80 mb-4">
                Serving Leeds, West Yorkshire, and the wider Northern England
                region.
              </p>
              <a
                href="/locations"
                className="inline-flex items-center gap-1 text-sm text-primary font-medium hover:underline"
              >
                See all our locations
                <ArrowRight className="h-3 w-3" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </ImageBackground>
  );
});

LocationsLeedsCTA.displayName = "LocationsLeedsCTA";
export default LocationsLeedsCTA;
