import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, MessageSquare, Search } from "lucide-react";

const ChatgptVisibilityCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="chatgpt-visibility-cta"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">

          {/* Eyebrow label */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut" }}
          >
            <span className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.18em] text-muted-foreground font-medium mb-6">
              <MessageSquare className="h-3.5 w-3.5" />
              AI Search Optimisation
            </span>
          </motion.div>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.08 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground tracking-tight leading-tight mb-6"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Want to Appear in ChatGPT Answers?
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.16 }}
            className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl mx-auto mb-10"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Gregg King helps UK businesses build the entity authority and content
            signals needed to be cited by AI search tools. If you're ready to move
            from understanding ChatGPT visibility to actively improving it, I can help.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.24 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            {/* Primary CTA — AI Search Optimisation service page */}
            <Button
              size="lg"
              className="h-12 px-8 text-base font-semibold rounded-md bg-[hsl(84,74%,60%)] text-[hsl(225,28%,14%)] hover:bg-[hsl(84,74%,54%)] hover:shadow-[0_0_32px_hsl(84_74%_60%_/_0.28)] transition-all duration-300"
              asChild
            >
              <Link to="/ai-search-optimisation">
                Explore AI Search Optimisation
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>

            {/* Secondary CTA — direct enquiry */}
            <Button
              size="lg"
              variant="outline"
              className="h-12 px-8 text-base font-medium rounded-md border-border text-foreground hover:bg-background hover:border-foreground transition-all duration-200"
              asChild
            >
              <Link to="/contact">
                Discuss My Requirements
              </Link>
            </Button>
          </motion.div>

          {/* Trust note */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: "easeOut", delay: 0.36 }}
            className="mt-8 text-sm text-muted-foreground"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Independent SEO consultant &middot; Based in Warrington, Cheshire &middot; No agency overhead
          </motion.p>
        </div>
      </div>
    </section>
  );
});

ChatgptVisibilityCTA.displayName = "ChatgptVisibilityCTA";

export default ChatgptVisibilityCTA;
