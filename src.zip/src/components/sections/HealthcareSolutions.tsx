import React from "react";
import { MapPin, FileText, ClipboardList, Lock, ArrowRight, View } from "lucide-react";
import { Button } from "@/components/ui/button";

const solutions = [
  {
    icon: MapPin,
    number: "01",
    title: "Local SEO for Clinics",
    description:
      "Dominate 'near me' searches and the Google Local Pack for every service you offer. We optimise your Google Business Profile, build consistent NAP citations across healthcare directories, and implement geo-targeted on-page signals — so patients in your catchment area find you first.",
    link: "/local-seo",
    linkLabel: "Learn about Local SEO",
  },
  {
    icon: FileText,
    number: "02",
    title: "Healthcare Schema Markup",
    description:
      "Structured data is essential for healthcare entities. We implement Physician, MedicalClinic, MedicalSpecialty, and LocalBusiness schema to help Google understand your practice's services, practitioners, and location data precisely — improving rich result eligibility and entity authority.",
    link: "/schema-markup",
    linkLabel: "Explore Schema Markup",
  },
  {
    icon: ClipboardList,
    number: "03",
    title: "Patient Education Content Strategy",
    description:
      "We build content strategies that answer real patient questions at every stage of their healthcare journey — from awareness to booking. All content is written to YMYL standards, attributed to credentialled practitioners, and structured for featured snippet and AI Overview eligibility.",
    link: "/content-strategy",
    linkLabel: "View Content Strategy",
  },
  {
    icon: Lock,
    number: "04",
    title: "Technical SEO for Healthcare",
    description:
      "Technical SEO for clinics goes beyond Core Web Vitals. We audit for HTTPS enforcement across booking forms, hreflang for multi-location practices, crawl efficiency, and page speed — ensuring your site is not only fast and indexable but also technically trustworthy for patients.",
    link: "/entity-seo",
    linkLabel: "See Entity SEO",
  },
];

const HealthcareSolutions: React.FC = () => {
  return (
    <section className="relative py-20 md:py-32 border-t border-border bg-background">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Our Approach
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">
            Specialist SEO Solutions for{" "}
            <span className="text-gradient-green">Healthcare Providers</span>
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Every strategy is built around your specific clinic type, patient demographic, and
            competitive landscape. No generic healthcare templates — tailored work only.
          </p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-14">
          {solutions.map((item) => {
            const Icon = item.icon;
            return (
              <div
                key={item.number}
                className="group flex gap-6 p-6 rounded-xl border border-border bg-card shadow-card hover-lift"
              >
                <div className="shrink-0">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
                    <Icon className="h-6 w-6 text-primary" />
                  </div>
                  <span className="block mt-3 text-xs font-mono text-muted-foreground tracking-widest text-center">
                    {item.number}
                  </span>
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-foreground mb-3">{item.title}</h3>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                    {item.description}
                  </p>
                  <a
                    href={item.link}
                    className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:underline"
                  >
                    {item.linkLabel}
                    <ArrowRight className="h-3.5 w-3.5" />
                  </a>
                </div>
              </div>
            );
          })}
        </div>

        {/* Internal navigation links */}
        <div className="rounded-xl border border-border bg-muted p-6 md:p-8">
          <p className="text-sm font-semibold text-foreground mb-4 uppercase tracking-wider">
            Related Services & Resources
          </p>
          <div className="flex flex-wrap gap-3">
            {[
              { label: "Local SEO", href: "/local-seo" },
              { label: "Schema Markup", href: "/schema-markup" },
              { label: "Entity SEO", href: "/entity-seo" },
              { label: "Content Strategy", href: "/content-strategy" },
              { label: "All Industries", href: "#industries-cta" },
              { label: "Technical SEO", href: "/technical-seo" },
            ].map(({ label, href }) => (
              <a
                key={href}
                href={href}
                className="inline-flex items-center gap-1 rounded-full border border-border bg-background px-4 py-1.5 text-sm text-foreground hover:border-primary hover:text-primary transition-colors"
              >
                {label}
                <ArrowRight className="h-3 w-3" />
              </a>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default HealthcareSolutions;
