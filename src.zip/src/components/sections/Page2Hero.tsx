import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { BookOpen, ArrowRight, Group } from "lucide-react";

const Page2Hero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="page2-hero"
      aria-label="SEO Resources hero section"
      src="https://images.unsplash.com/photo-1568649704650-a6ab20e84311?w=1920&h=1080&fit=crop"
      alt="Group of people walking near modern office buildings representing business growth"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[75vh] md:min-h-[80vh] flex items-center"
    >
      <div className="container relative z-10 py-24 md:py-32">
        <div className="max-w-3xl">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-4 py-2 mb-6">
            <BookOpen className="h-4 w-4 text-primary" />
            <span className="text-white/90 text-sm font-medium tracking-wide">SEO Knowledge Hub</span>
          </div>

          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white mb-6 leading-tight">
            SEO Resources &amp;{" "}
            <span className="text-gradient-green">Expert Guides</span>
          </h1>

          <p className="text-lg md:text-xl text-white/90 mb-8 leading-relaxed max-w-2xl">
            Everything you need to understand modern SEO — from foundational concepts to cutting-edge
            AI search optimisation. Practical knowledge, actionable insights, no fluff.
          </p>

          <div className="flex flex-wrap gap-4">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold px-8"
              asChild
            >
              <a href="#insights-cta">
                Browse Insights <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10 font-semibold px-8"
              asChild
            >
              <a href="/contact">Talk to an Expert</a>
            </Button>
          </div>

          <div className="flex flex-wrap items-center gap-6 mt-10 pt-8 border-t border-white/20">
            {[
              { value: "10+", label: "Years Experience" },
              { value: "500+", label: "Clients Helped" },
              { value: "50+", label: "Free Guides" },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="text-2xl font-bold text-white">{stat.value}</div>
                <div className="text-sm text-white/80">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </ImageBackground>
  );
});

Page2Hero.displayName = "Page2Hero";

export default Page2Hero;
