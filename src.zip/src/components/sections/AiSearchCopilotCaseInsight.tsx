import React from "react";
import { TrendingUp, CheckCircle, ArrowRight, Monitor } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const outcomes = [
  "Bing crawl coverage increased from 62% to 94% of key pages within 6 weeks",
  "FAQPage and Article schema implemented across 40+ priority pages",
  "Copilot citation rate for brand-related queries rose measurably within 3 months",
  "Bing organic traffic increased 38% as a by-product of Copilot-focused technical work",
  "Brand now appears in Copilot responses for 12 target service-category queries",
];

const process = [
  {
    phase: "Audit",
    detail: "Full Bing crawl analysis via Bing Webmaster Tools — identified 280 pages blocked or deprioritised.",
  },
  {
    phase: "Structure",
    detail: "Rewrote page templates to lead with direct answers; implemented Schema.org markup across priority pages.",
  },
  {
    phase: "Authority",
    detail: "Secured 14 editorial mentions in Bing-indexed industry publications over 90 days.",
  },
  {
    phase: "Monitor",
    detail: "Ongoing Bing Webmaster Tools monitoring and quarterly content freshness reviews.",
  },
];

const AiSearchCopilotCaseInsight = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="copilot-case-insight"
      className="relative isolate py-24 md:py-36"
    >
      <img
        src="https://images.unsplash.com/photo-1499951360447-b19be8fe80f5?w=1920&h=1080&fit=crop"
        alt="Professional laptop and notes on desk representing strategic planning"
        className="absolute inset-0 w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-br from-primary/80 via-primary/55 to-accent/60 pointer-events-none" />
      <div className="container relative z-10">
        <div className="max-w-4xl mx-auto">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4 font-medium">
            Optimisation Insight
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">
            From Invisible to Cited: A Copilot Visibility Case Example
          </h2>
          <p className="text-white/90 text-base md:text-lg leading-relaxed mb-10 max-w-2xl">
            A UK-based professional services firm came to us with zero Copilot citation presence despite strong Google rankings. Their Bing crawl coverage was poor, they had no structured data, and Copilot simply wasn't finding their content. Here's what we did.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-10">
            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-7">
              <h3 className="text-lg font-bold text-white mb-5 flex items-center gap-2">
                <TrendingUp className="h-5 w-5 text-white" />
                Outcomes Achieved
              </h3>
              <ul className="space-y-3">
                {outcomes.map((o) => (
                  <li key={o} className="flex items-start gap-2.5 text-sm text-white/90">
                    <CheckCircle className="h-4 w-4 text-white shrink-0 mt-0.5" />
                    {o}
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-7">
              <h3 className="text-lg font-bold text-white mb-5">
                The Optimisation Process
              </h3>
              <div className="space-y-4">
                {process.map((p, i) => (
                  <div key={p.phase} className="flex items-start gap-3">
                    <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-white/20 text-white text-xs font-bold">
                      {i + 1}
                    </div>
                    <div>
                      <span className="text-sm font-semibold text-white block">{p.phase}</span>
                      <p className="text-xs text-white/80 leading-relaxed mt-0.5">{p.detail}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="flex flex-wrap gap-4">
            <a
              href="/services-ai-search-optimisation"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-white text-foreground font-semibold text-sm hover:bg-white/90 transition-colors"
            >
              Get Your Copilot Audit
              <ArrowRight className="h-4 w-4" />
            </a>
            <a
              href="/contact"
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-white/15 border border-white/30 text-white font-semibold text-sm hover:bg-white/25 transition-colors"
            >
              Discuss Your Strategy
            </a>
          </div>
        </div>
      </div>
    </section>
  );
});

AiSearchCopilotCaseInsight.displayName = "AiSearchCopilotCaseInsight";
export default AiSearchCopilotCaseInsight;
