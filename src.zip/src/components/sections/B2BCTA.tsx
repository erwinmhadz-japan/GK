import React from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle, View } from "lucide-react";

const benefits = [
  "Entity SEO tailored to your firm's service lines",
  "Content strategy mapped to the full B2B buyer journey",
  "Schema markup for ProfessionalService & Organization",
  "Digital PR to build sector authority",
];

const B2BCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="b2b-cta"
      className="relative isolate py-24 md:py-36"
      aria-label="B2B SEO call to action"
    >
      {/* Background image */}
      <img
        src="https://images.unsplash.com/photo-1580894732444-8ecded7900cd?w=1920&h=1080&fit=crop"
        alt="Business professional presenting strategy at a whiteboard"
        className="absolute inset-0 w-full h-full object-cover"
        loading="lazy"
        width="1920"
        height="1080"
      />
      {/* Dark overlay for readability */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/85 via-black/80 to-black/70 pointer-events-none" />

      {/* Content */}
      <div className="container relative z-10">
        <div className="max-w-2xl mx-auto text-center">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-6 font-medium">
            Ready to Grow Your Firm's Organic Presence?
          </span>

          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 leading-tight">
            Let's Build a B2B SEO Strategy That Wins the Buying Committee
          </h2>

          <p className="text-lg text-white/90 mb-8 leading-relaxed">
            From entity authority and schema markup to thought leadership
            content and Digital PR — we create the organic infrastructure that
            puts your professional services firm in front of the right buyers
            at the right time.
          </p>

          {/* Benefits list */}
          <ul className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-10 text-left max-w-xl mx-auto">
            {benefits.map((benefit, i) => (
              <li key={i} className="flex items-start gap-2">
                <CheckCircle className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                <span className="text-sm text-white/90">{benefit}</span>
              </li>
            ))}
          </ul>

          {/* Buttons */}
          <div className="flex flex-wrap justify-center gap-4">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold shadow-green-glow"
              asChild
            >
              <a href="/contact">
                Get a Free B2B SEO Audit
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10"
              asChild
            >
              <a href="#case-studies-cta">View B2B Case Studies</a>
            </Button>
          </div>

          <p className="mt-6 text-sm text-white/80">
            No long-term lock-in. Transparent reporting. Results-focused.
          </p>
        </div>
      </div>
    </section>
  );
});

B2BCTA.displayName = "B2BCTA";

export default B2BCTA;
