import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Bot, Search, Layers, Globe, Monitor, Brain, Network, Database, ChevronRight, Info, Section } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent } from "@/components/ui/card";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (delay: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay },
  }),
};

const howCopilotWorks = [
  {
    icon: Search,
    title: "Retrieval via Bing's Index",
    body: "Microsoft Copilot draws on Bing's web index as its primary retrieval layer. Unlike large language models that rely solely on training data, Copilot queries live indexed content, meaning Bing crawlability and indexation directly influence whether your content surfaces in responses.",
  },
  {
    icon: Brain,
    title: "Synthesis and Response Generation",
    body: "Once relevant documents are retrieved, Copilot's language model synthesises information into a coherent answer. It selects sources it deems authoritative, well-structured, and contextually relevant — rewarding content that is clearly written, entity-rich, and technically sound.",
  },
  {
    icon: Layers,
    title: "Integration Across Microsoft 365 and Edge",
    body: "Copilot is embedded throughout Microsoft's product ecosystem — including Edge, Bing, Word, Outlook, and Teams. This means brand mentions can surface in a range of contexts, from web searches in Edge to document-drafting suggestions inside Word.",
  },
  {
    icon: Network,
    title: "Entity and Knowledge Graph Signals",
    body: "Microsoft maintains its own entity understanding layer, informed by Bing's knowledge graph. Brands and individuals with consistent, structured online identities — across their website, third-party references, and structured data — are more reliably recognised and included in responses.",
  },
];

const distinguishers = [
  {
    icon: Globe,
    platform: "ChatGPT",
    note: "Primarily trained on a static dataset (with optional web browsing via plugins); response quality is less tied to live Bing indexation.",
  },
  {
    icon: Database,
    platform: "Perplexity",
    note: "A dedicated AI search engine that fetches and cites real-time web sources, closer in architecture to Copilot but not integrated into a productivity suite.",
  },
  {
    icon: Monitor,
    platform: "Gemini",
    note: "Google's answer layer, which draws on Google's search index. Separate indexation ecosystem to Copilot; optimisation signals overlap but are not identical.",
  },
];

const whyItMatters = [
  "Microsoft 365 has over 300 million commercial users globally, including a significant share of UK professional services businesses.",
  "Copilot responses in Edge and Bing appear prominently in commercial and informational searches — particularly in B2B and professional contexts.",
  "Brand inclusion in Copilot answers can influence trust and awareness without a direct click, making it a form of passive visibility with long-term authority benefits.",
  "As AI-assisted search becomes standard in enterprise environments, businesses not optimised for Copilot risk being absent from a growing share of professional research and decision-making.",
];

const CopilotVisibilityExplainer = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="copilot-visibility-explainer"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section heading */}
        <motion.div
          className="mb-14 max-w-3xl"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
        >
          <motion.span
            variants={fadeUp}
            custom={0}
            className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium"
          >
            Understanding Copilot
          </motion.span>
          <motion.h2
            variants={fadeUp}
            custom={0.08}
            className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground leading-tight font-[Sora,sans-serif] mb-5"
          >
            What Is Microsoft Copilot and How Does It Retrieve Information?
          </motion.h2>
          <motion.p
            variants={fadeUp}
            custom={0.16}
            className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl"
          >
            Microsoft Copilot is an AI assistant embedded across Bing, Edge, and the Microsoft 365
            suite. Unlike earlier search engines that return a list of links, Copilot synthesises
            web content into direct, conversational answers — drawing heavily on Bing's live index
            to determine which sources and brands to include.
          </motion.p>
        </motion.div>

        {/* How Copilot Works — 4 cards */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
        >
          {howCopilotWorks.map((item, i) => {
            const Icon = item.icon;
            return (
              <motion.div key={item.title} variants={fadeUp} custom={i * 0.09}>
                <Card className="h-full border border-border bg-background shadow-[var(--shadow-card)] hover:shadow-[var(--shadow-card-hover)] transition-all duration-300">
                  <CardContent className="p-6 flex gap-4">
                    <div className="flex-shrink-0 flex items-start pt-0.5">
                      <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                    </div>
                    <div>
                      <h3 className="text-base font-semibold text-foreground mb-2 font-[Sora,sans-serif]">
                        {item.title}
                      </h3>
                      <p className="text-sm text-muted-foreground leading-relaxed">{item.body}</p>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Distinguishing Copilot from other AI platforms */}
        <motion.div
          className="mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
        >
          <motion.h3
            variants={fadeUp}
            custom={0}
            className="text-xl md:text-2xl font-bold text-foreground mb-2 font-[Sora,sans-serif]"
          >
            How Copilot Differs from ChatGPT, Perplexity, and Gemini
          </motion.h3>
          <motion.p
            variants={fadeUp}
            custom={0.07}
            className="text-sm md:text-base text-muted-foreground mb-8 max-w-2xl"
          >
            Each AI platform has a distinct retrieval architecture. Understanding where Copilot
            diverges from its peers matters for any business prioritising AI search visibility.
          </motion.p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {distinguishers.map((item, i) => {
              const Icon = item.icon;
              return (
                <motion.div key={item.platform} variants={fadeUp} custom={0.12 + i * 0.08}>
                  <div className="border border-border rounded-md p-5 bg-background hover:bg-muted/30 transition-colors duration-200 h-full">
                    <div className="flex items-center gap-3 mb-3">
                      <div className="flex h-8 w-8 items-center justify-center rounded bg-muted">
                        <Icon className="h-4 w-4 text-muted-foreground" />
                      </div>
                      <span className="text-sm font-semibold text-foreground font-[Sora,sans-serif]">
                        {item.platform}
                      </span>
                      <Badge variant="outline" className="ml-auto text-xs">
                        Distinct platform
                      </Badge>
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed">{item.note}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Why Copilot visibility matters */}
        <motion.div
          className="mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
        >
          <motion.h3
            variants={fadeUp}
            custom={0}
            className="text-xl md:text-2xl font-bold text-foreground mb-2 font-[Sora,sans-serif]"
          >
            Why Copilot Visibility Matters for UK Businesses
          </motion.h3>
          <motion.p
            variants={fadeUp}
            custom={0.07}
            className="text-sm md:text-base text-muted-foreground mb-7 max-w-2xl"
          >
            For professional services, finance, healthcare, and legal businesses, the audiences
            most likely to research providers are already using Microsoft's ecosystem daily.
          </motion.p>

          <div className="space-y-3">
            {whyItMatters.map((point, i) => (
              <motion.div
                key={i}
                variants={fadeUp}
                custom={0.1 + i * 0.07}
                className="flex items-start gap-3 rounded-md border border-border bg-background px-5 py-4 hover:bg-muted/20 transition-colors duration-200"
              >
                <ChevronRight className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                <p className="text-sm md:text-base text-muted-foreground leading-relaxed">{point}</p>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Brand inclusion signals callout */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={fadeUp}
          custom={0}
          className="mb-12"
        >
          <div className="rounded-md border border-border bg-muted/30 px-6 py-6 flex flex-col md:flex-row md:items-start gap-4">
            <div className="flex-shrink-0">
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                <Info className="h-5 w-5 text-primary" />
              </div>
            </div>
            <div>
              <h4 className="text-base font-semibold text-foreground mb-2 font-[Sora,sans-serif]">
                What Determines Brand Inclusion in Copilot Answers?
              </h4>
              <p className="text-sm text-muted-foreground leading-relaxed mb-3">
                Copilot's responses are shaped by Bing's underlying index, structured data signals,
                entity clarity, and the authority of sources it retrieves. Brands that are
                consistently indexed, technically sound, and clearly described across the web
                — through schema markup, authoritative backlinks, and well-structured content —
                stand a meaningfully better chance of inclusion.
              </p>
              <p className="text-sm text-muted-foreground leading-relaxed">
                The factors that influence Copilot visibility are closely related to, but distinct
                from, traditional Bing SEO. Understanding the distinction is the starting point for
                any AI search visibility strategy.{" "}
                <Link
                  to="#copilot-visibility-factors"
                  className="text-primary underline underline-offset-2 hover:text-primary/80 transition-colors duration-150"
                >
                  Explore the key factors →
                </Link>
              </p>
            </div>
          </div>
        </motion.div>

        {/* Sibling AI Search pages nav */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={fadeUp}
          custom={0.1}
        >
          <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium">
            Also in the AI Search Hub
          </p>
          <div className="flex flex-wrap gap-3">
            {[
              { label: "ChatGPT Visibility", to: "/chatgpt-visibility" },
              { label: "Google AI Overviews", to: "/google-ai-overviews" },
              { label: "Gemini Visibility", to: "/gemini-visibility" },
              { label: "Perplexity Visibility", to: "/perplexity-visibility" },
              { label: "AI Search Hub", to: "#ai-search-cta" },
            ].map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className="inline-flex items-center gap-1.5 text-xs font-medium text-muted-foreground border border-border rounded-md px-3 py-1.5 hover:bg-muted hover:text-foreground transition-colors duration-150"
              >
                <ChevronRight className="h-3 w-3 flex-shrink-0" aria-hidden="true" />
                {link.label}
              </Link>
            ))}
          </div>
        </motion.div>

      </div>
    </section>
  );
});

CopilotVisibilityExplainer.displayName = "CopilotVisibilityExplainer";

export default CopilotVisibilityExplainer;
