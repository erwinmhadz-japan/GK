import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, Phone } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { NavDropdown, MobileNavItems } from "@/components/NavDropdown";
import { navItems } from "@/config/nav";
import { cn } from "@/lib/utils";

// Brand accent SVG mark — shared between desktop and mobile
const BrandMark = ({ size = 14 }: { size?: number }) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 14 14"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
    aria-hidden="true"
  >
    <path
      d="M2 12 L7 2 L12 12 M4.5 8 H9.5"
      stroke="hsl(225 28% 14%)"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

const Header = React.forwardRef<HTMLElement>((props, ref) => {
  const [isOpen, setIsOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 12);
    };
    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <header
      ref={ref}
      id="header"
      className={cn(
        "fixed top-0 left-0 right-0 z-50 transition-all duration-300",
        scrolled
          ? "bg-[hsl(var(--navy-deep))]/98 backdrop-blur-md shadow-nav border-b border-white/[0.06]"
          : "bg-[hsl(var(--navy-deep))]/90 backdrop-blur-sm"
      )}
    >
      {/* ── Top contact bar (desktop only) ───────────────────────── */}
      <div className="hidden lg:block border-b border-white/[0.06]">
        <div className="container max-w-6xl mx-auto px-4">
          <div className="flex items-center justify-end gap-5 py-1.5">
            <a
              href="tel:01925214707"
              className="flex items-center gap-1.5 text-xs text-[hsl(var(--blue-muted))] hover:text-white transition-colors duration-200"
              aria-label="Call 01925 214707"
            >
              <Phone className="h-3 w-3" />
              <span>01925 214707</span>
            </a>
            <span aria-hidden="true" className="text-xs text-white/25 select-none">
              |
            </span>
            <a
              href="mailto:gregg@greggking.co.uk"
              className="text-xs text-[hsl(var(--blue-muted))] hover:text-white transition-colors duration-200"
            >
              gregg@greggking.co.uk
            </a>
            <span aria-hidden="true" className="text-xs text-white/25 select-none">
              |
            </span>
            <span className="text-xs text-white/40">
              Independent SEO Consultant · Warrington, Cheshire
            </span>
          </div>
        </div>
      </div>

      {/* ── Primary navigation bar ───────────────────────────────── */}
      <nav
        className="container max-w-6xl mx-auto px-4"
        aria-label="Primary navigation"
      >
        <div className="flex items-center justify-between h-16">

          {/* Logo / brand wordmark */}
          <motion.div
            initial={{ opacity: 0, x: -8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
          >
            <Link
              to="/"
              className="group flex items-center gap-2.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--primary))] rounded-sm"
              aria-label="Gregg King SEO — home"
            >
              {/* Green accent mark */}
              <span
                className="flex items-center justify-center w-7 h-7 rounded-sm bg-gradient-cta shrink-0"
                aria-hidden="true"
              >
                <BrandMark size={14} />
              </span>

              {/* Wordmark */}
              <span className="font-['Sora',sans-serif] font-bold text-base leading-tight tracking-tight">
                <span className="text-white">Gregg King</span>
                <span className="text-[hsl(var(--primary))] ml-1">SEO</span>
              </span>
            </Link>
          </motion.div>

          {/* Desktop nav links */}
          <motion.div
            className="hidden lg:flex flex-1 justify-center"
            initial={{ opacity: 0, y: -4 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.1, ease: "easeOut" }}
          >
            <NavDropdown
              items={navItems}
              className="flex items-center gap-0.5"
              linkClassName="text-sm font-medium text-white/80 hover:text-white transition-colors duration-200 px-3 py-2 rounded-sm hover:bg-white/[0.06]"
            />
          </motion.div>

          {/* Desktop CTA */}
          <motion.div
            className="hidden lg:flex items-center"
            initial={{ opacity: 0, x: 8 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.15, ease: "easeOut" }}
          >
            <Button
              asChild
              size="default"
              className="bg-gradient-cta text-[hsl(var(--navy-deep))] font-semibold text-sm px-5 py-2 rounded-md hover:opacity-90 hover:shadow-green-glow transition-all duration-200 border-0"
            >
              <Link to="/contact">Discuss Your SEO</Link>
            </Button>
          </motion.div>

          {/* Mobile controls */}
          <div className="flex lg:hidden items-center gap-2">
            {/* Small CTA on medium+ mobile */}
            <Button
              asChild
              size="sm"
              className="bg-gradient-cta text-[hsl(var(--navy-deep))] font-semibold text-xs px-3 py-1.5 rounded-md hover:opacity-90 transition-opacity border-0 hidden sm:inline-flex"
            >
              <Link to="/contact">Enquire</Link>
            </Button>

            {/* Hamburger — only rendered when there are nav items */}
            {navItems.length > 0 && (
              <Sheet open={isOpen} onOpenChange={setIsOpen}>
                <SheetTrigger asChild>
                  <button
                    type="button"
                    className="inline-flex items-center justify-center w-9 h-9 rounded-sm text-white/80 hover:text-white hover:bg-white/[0.08] transition-colors duration-200 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(var(--primary))]"
                    aria-label={isOpen ? "Close navigation menu" : "Open navigation menu"}
                    aria-expanded={isOpen}
                  >
                    <AnimatePresence mode="wait" initial={false}>
                      {isOpen ? (
                        <motion.span
                          key="close-icon"
                          initial={{ rotate: -90, opacity: 0 }}
                          animate={{ rotate: 0, opacity: 1 }}
                          exit={{ rotate: 90, opacity: 0 }}
                          transition={{ duration: 0.15, ease: "easeOut" }}
                          className="flex"
                        >
                          <X className="h-5 w-5" />
                        </motion.span>
                      ) : (
                        <motion.span
                          key="open-icon"
                          initial={{ rotate: 90, opacity: 0 }}
                          animate={{ rotate: 0, opacity: 1 }}
                          exit={{ rotate: -90, opacity: 0 }}
                          transition={{ duration: 0.15, ease: "easeOut" }}
                          className="flex"
                        >
                          <Menu className="h-5 w-5" />
                        </motion.span>
                      )}
                    </AnimatePresence>
                  </button>
                </SheetTrigger>

                <SheetContent
                  side="right"
                  className="w-[300px] sm:w-[340px] bg-[hsl(var(--navy-deep))] border-l border-white/[0.08] p-0 flex flex-col"
                >
                  {/* Sheet header */}
                  <div className="flex items-center px-5 py-4 border-b border-white/[0.08] shrink-0">
                    <Link
                      to="/"
                      onClick={() => setIsOpen(false)}
                      className="flex items-center gap-2 focus-visible:outline-none"
                    >
                      <span
                        className="flex items-center justify-center w-6 h-6 rounded-sm bg-gradient-cta shrink-0"
                        aria-hidden="true"
                      >
                        <BrandMark size={12} />
                      </span>
                      <span className="font-['Sora',sans-serif] font-bold text-sm">
                        <span className="text-white">Gregg King</span>
                        <span className="text-[hsl(var(--primary))] ml-1">SEO</span>
                      </span>
                    </Link>
                  </div>

                  {/* Scrollable nav area */}
                  <div className="flex-1 overflow-y-auto">
                    <nav className="px-3 py-4" aria-label="Mobile navigation">
                      <MobileNavItems
                        items={navItems}
                        onLinkClick={() => setIsOpen(false)}
                        linkClassName="text-sm font-medium text-white/80 hover:text-white px-3 py-2.5 rounded-sm hover:bg-white/[0.06] transition-colors duration-200 block w-full text-left"
                      />
                    </nav>
                  </div>

                  {/* Sheet footer CTA */}
                  <div className="px-5 py-4 border-t border-white/[0.08] shrink-0 space-y-3">
                    <Button
                      asChild
                      className="w-full bg-gradient-cta text-[hsl(var(--navy-deep))] font-semibold text-sm py-2.5 rounded-md hover:opacity-90 hover:shadow-green-glow transition-all duration-200 border-0 h-10"
                    >
                      <Link to="/contact" onClick={() => setIsOpen(false)}>
                        Discuss Your SEO
                      </Link>
                    </Button>

                    <div className="space-y-1">
                      <a
                        href="tel:01925214707"
                        className="flex items-center gap-2 text-xs text-white/50 hover:text-white/80 transition-colors duration-200"
                        onClick={() => setIsOpen(false)}
                      >
                        <Phone className="h-3 w-3 text-[hsl(var(--blue-muted))] shrink-0" />
                        <span>01925 214707</span>
                      </a>
                      <p className="text-xs text-white/35 pl-5">
                        Independent consultant · Warrington, Cheshire
                      </p>
                    </div>
                  </div>
                </SheetContent>
              </Sheet>
            )}
          </div>

        </div>
      </nav>
    </header>
  );
});

Header.displayName = "Header";

export default Header;
