import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle, Target, BarChart2, Layers, Lightbulb, Search, Icon, Key, Scale } from "lucide-react";

const pillars = [
  {
    icon: Search,
    title: "Technical SEO at Enterprise Scale",
    description:
      "Large London enterprises often have complex site architectures, multiple subdomains, and legacy CMS issues that create significant crawl waste and indexation gaps. I conduct a forensic technical audit and deliver a prioritised remediation roadmap that unlocks existing ranking potential fast.",
  },
  {
    icon: Layers,
    title: "Topical Authority & Entity SEO",
    description:
      "London's high-value search landscape is dominated by firms with deep content authority. I build comprehensive topic maps and entity relationships that signal genuine expertise to Google — moving you from occasional rankings to consistent category ownership.",
  },
  {
    icon: Target,
    title: "Competitive Intelligence & Gap Analysis",
    description:
      "I map every competitor's organic footprint — keywords, content gaps, backlink profiles, and SERP features — to build a London-specific strategy that exploits their weaknesses and defends your key commercial terms.",
  },
  {
    icon: BarChart2,
    title: "Conversion-Focused Content Strategy",
    description:
      "Traffic without conversion is vanity. Every piece of content I produce is mapped to commercial intent — from awareness-stage thought leadership to high-intent landing pages that convert London decision-makers into pipeline.",
  },
  {
    icon: Lightbulb,
    title: "AI Search & Future-Proofing",
    description:
      "As AI Overviews, Perplexity, and ChatGPT reshape how London's business community researches vendors and services, I build structured content and entity authority that puts your brand in the answer — not just the results.",
  },
  {
    icon: BarChart2,
    title: "Measurable Commercial Impact",
    description:
      "Every engagement is anchored to commercial KPIs — qualified traffic growth, lead pipeline, and revenue attribution. I report on what matters: organic-driven enquiries, demo requests, and client acquisitions — not just rank movements.",
  },
];

const LondonEnterpriseStrategy = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="london-enterprise-strategy"
      aria-label="Enterprise-level SEO strategy for London"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          {/* Left column — content */}
          <div>
            <Badge variant="outline" className="mb-4 text-primary border-primary/40">
              Enterprise SEO Strategy
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
              An SEO Approach Built for London's Complexity and Ambition
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed mb-6">
              London enterprises face a unique convergence of challenges: intensely
              competitive SERPs, long B2B sales cycles, multi-stakeholder buying committees,
              and the pressure to demonstrate ROI across complex attribution models. I've
              built a strategy framework specifically for this environment.
            </p>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Unlike generalist agencies managing hundreds of clients, I work with a focused
              portfolio of London enterprises — giving each engagement the strategic depth
              and senior-level attention required to move the needle in the capital's premium
              search landscape. Every decision is made with commercial impact in mind.
            </p>

            {/* Key outcomes */}
            <div className="space-y-3 mb-8">
              {[
                "Category-defining search visibility across target commercial terms",
                "Measurable pipeline growth from organic search within 90 days",
                "Full technical SEO health that supports large enterprise sites",
                "Content authority that positions your team as London's go-to experts",
                "Transparent reporting tied to revenue, not vanity metrics",
              ].map((item) => (
                <div key={item} className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <span className="text-sm text-foreground">{item}</span>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap gap-3">
              <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold" asChild>
                <a href="/services-seo-audit">Explore SEO Consulting</a>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="/contact">Discuss Your London Project</a>
              </Button>
            </div>
          </div>

          {/* Right column — strategy pillars */}
          <div className="space-y-5">
            {pillars.map(({ icon: Icon, title, description }) => (
              <div
                key={title}
                className="flex gap-4 p-5 rounded-xl bg-background border border-border shadow-soft hover:shadow-card transition-all duration-300 group"
              >
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10 group-hover:bg-primary/20 transition-colors">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground text-sm mb-1">{title}</h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">{description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
});

LondonEnterpriseStrategy.displayName = "LondonEnterpriseStrategy";

export default LondonEnterpriseStrategy;
