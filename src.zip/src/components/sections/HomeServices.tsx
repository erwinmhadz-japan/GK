import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Search, FileText, Layers, Code, Network, Globe, PenTool, MapPin, Megaphone, Bot, ArrowRight, ChevronRight, Building, Section, View } from "lucide-react";

const services = [
  {
    label: "SEO Consulting",
    descriptor:
      "Independent strategic advice on search visibility — scoped to your business goals and competitive landscape.",
    href: "/services-seo-audit",
    icon: Search,
  },
  {
    label: "SEO Audit",
    descriptor:
      "A thorough review of your site's technical foundations, content quality, and authority profile.",
    href: "/services-seo-audit",
    icon: FileText,
  },
  {
    label: "SEO Retainer",
    descriptor:
      "Ongoing consultancy with defined deliverables — structured for businesses that need consistent SEO progress.",
    href: "/seo-retainer",
    icon: Layers,
  },
  {
    label: "Technical SEO",
    descriptor:
      "Crawlability, indexation, Core Web Vitals, and site architecture — the structural foundations of search performance.",
    href: "/services-technical-seo",
    icon: Code,
  },
  {
    label: "Schema Markup",
    descriptor:
      "Structured data implementation to improve how search engines and AI models understand your content.",
    href: "/schema-markup",
    icon: Network,
  },
  {
    label: "Entity SEO",
    descriptor:
      "Building your brand's entity presence in Google's Knowledge Graph and across the semantic web.",
    href: "/entity-seo",
    icon: Globe,
  },
  {
    label: "Content Strategy",
    descriptor:
      "Keyword-led content planning that aligns editorial output with search intent and topical authority.",
    href: "/content-strategy",
    icon: PenTool,
  },
  {
    label: "Local SEO",
    descriptor:
      "Visibility for location-based searches — Google Business Profile, local citations, and geo-targeted content.",
    href: "/services-local-seo",
    icon: MapPin,
  },
  {
    label: "Digital PR",
    descriptor:
      "Earning editorially placed links through targeted outreach, commentary, and credible media coverage.",
    href: "/digital-pr",
    icon: Megaphone,
  },
  {
    label: "AI Search Optimisation",
    descriptor:
      "Optimising for visibility across ChatGPT, Perplexity, Google AI Overviews, Gemini, and Copilot.",
    href: "/services-ai-search-optimisation",
    icon: Bot,
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.07,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 22 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: "easeOut" },
  },
};

const headingVariants = {
  hidden: { opacity: 0, y: 18 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
};

const HomeServices = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="home-services"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          className="mb-12 md:mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={headingVariants}
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-3 font-medium">
            Services
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground max-w-2xl leading-tight">
            SEO Services
          </h2>
          <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-xl">
            Specialist SEO consulting across ten disciplines — each delivered by Gregg King directly.
          </p>
        </motion.div>

        {/* Services grid — exactly 10 items, 2-col layout */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-3 md:gap-4"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          variants={containerVariants}
        >
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <motion.div key={service.label} variants={itemVariants}>
                <Link
                  to={service.href}
                  className="group flex items-start gap-4 rounded-md border border-border bg-background p-5 transition-all duration-200 hover:border-primary/60 hover:shadow-sm block"
                >
                  <div className="flex-shrink-0 mt-0.5 flex h-9 w-9 items-center justify-center rounded-md bg-primary/10 transition-colors duration-200 group-hover:bg-primary/20">
                    <Icon className="h-4 w-4 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors duration-200 leading-snug">
                        {service.label}
                      </span>
                      <ChevronRight className="h-3.5 w-3.5 text-muted-foreground/50 flex-shrink-0 group-hover:text-primary group-hover:translate-x-0.5 transition-all duration-200" />
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground leading-relaxed line-clamp-2">
                      {service.descriptor}
                    </p>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Footer link */}
        <motion.div
          className="mt-10 md:mt-12 flex justify-start"
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, ease: "easeOut", delay: 0.3 }}
        >
          <Button variant="outline" className="group" asChild>
            <Link to="/services">
              View all services
              <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform duration-200" />
            </Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
});

HomeServices.displayName = "HomeServices";

export default HomeServices;
