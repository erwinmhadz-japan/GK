import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
} from "@/components/ui/card";
import { TrendingUp, Award, ArrowRight, BarChart3, Users, Target, Circle, Icon, Image, Key, Search, Section, Tags } from "lucide-react";

const caseStudies = [
  {
    sector: "Financial Services",
    location: "Canary Wharf, London",
    image: "https://images.unsplash.com/photo-1633537065982-712792c23798?w=800&h=600&fit=crop",
    imageAlt: "Modern tall glass office building in London's financial district",
    headline: "340% Increase in Qualified Organic Leads",
    description:
      "A boutique asset management firm based in Canary Wharf needed search visibility for high-net-worth investor queries. Within 9 months, organic traffic grew from 1,200 to 8,400 monthly sessions with a 340% increase in form completions from organic search.",
    metrics: [
      { icon: TrendingUp, value: "340%", label: "Lead Growth" },
      { icon: BarChart3, value: "600%", label: "Organic Traffic" },
      { icon: Target, value: "#1–3", label: "Key Term Rankings" },
    ],
    tags: ["Entity SEO", "Content Strategy", "Technical SEO"],
  },
  {
    sector: "Legal Services",
    location: "EC1, London",
    image: "https://images.unsplash.com/photo-1571120245989-c2878f4c89b9?w=800&h=600&fit=crop",
    imageAlt: "Office interior with large windows and modern meeting room furniture",
    headline: "From Page 4 to Page 1 for 38 Commercial Practice Terms",
    description:
      "A mid-market law firm competing against Magic Circle and Silver Circle firms used enterprise SEO strategy to carve out search dominance for their niche practice areas. Ranking uplift across 38 target terms drove a 220% increase in organic client enquiries.",
    metrics: [
      { icon: Award, value: "38", label: "Terms on Page 1" },
      { icon: Users, value: "220%", label: "Enquiry Growth" },
      { icon: TrendingUp, value: "18mo", label: "Campaign Timeline" },
    ],
    tags: ["Competitive Analysis", "Local SEO", "Digital PR"],
  },
  {
    sector: "B2B Technology",
    location: "Shoreditch, London",
    image: "https://images.unsplash.com/photo-1559659386-5b78a2a4290c?w=800&h=600&fit=crop",
    imageAlt: "Architectural view of a modern commercial building with distinctive brown exterior",
    headline: "Enterprise SaaS Platform Achieves £2.1M Pipeline from Organic",
    description:
      "A London-based cybersecurity platform needed to compete with well-funded US rivals for UK enterprise buyer searches. A 12-month topical authority and technical SEO programme built a content moat that now drives £2.1M in annual qualified pipeline.",
    metrics: [
      { icon: BarChart3, value: "£2.1M", label: "Organic Pipeline" },
      { icon: TrendingUp, value: "510%", label: "Demo Requests" },
      { icon: Target, value: "190+", label: "Keywords Top 10" },
    ],
    tags: ["Schema Markup", "AI Search", "Content Authority"],
  },
];

const LondonCaseStudies = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="london-case-studies"
      aria-label="London SEO case studies and premium client portfolio"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        {/* Section header */}
        <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12">
          <div className="max-w-2xl">
            <Badge variant="outline" className="mb-4 text-primary border-primary/40">
              <Award className="h-3 w-3 mr-1" />
              Premium London Client Portfolio
            </Badge>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Enterprise Results Across London's Most Competitive Sectors
            </h2>
            <p className="text-muted-foreground leading-relaxed">
              These results represent the kind of commercial SEO impact I deliver for London's
              premium market. Every engagement is treated as a long-term investment in search authority,
              not a short-term ranking exercise.
            </p>
          </div>
          <Button variant="outline" className="shrink-0" asChild>
            <a href="#case-studies-cta">
              All Case Studies
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Button>
        </div>

        {/* Case study cards */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-7 mb-12">
          {caseStudies.map(({ sector, location, image, imageAlt, headline, description, metrics, tags }) => (
            <Card
              key={headline}
              className="group border border-border bg-card overflow-hidden hover-lift shadow-card hover:shadow-card-hover transition-all duration-300 flex flex-col"
            >
              {/* Image */}
              <div className="relative h-48 overflow-hidden">
                <img
                  src={image}
                  alt={imageAlt}
                  loading="lazy"
                  width="800"
                  height="600"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
                <div className="absolute bottom-3 left-3">
                  <Badge className="bg-primary/90 text-white text-xs border-0">
                    {sector}
                  </Badge>
                </div>
              </div>

              <CardHeader className="pb-2">
                <div className="text-xs text-muted-foreground font-medium mb-2">{location}</div>
                <h3 className="text-base font-bold text-foreground leading-tight">{headline}</h3>
              </CardHeader>

              <CardContent className="flex-1 flex flex-col gap-4">
                <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>

                {/* Metrics row */}
                <div className="grid grid-cols-3 gap-2 py-4 border-t border-border">
                  {metrics.map(({ icon: Icon, value, label }) => (
                    <div key={label} className="text-center">
                      <div className="flex justify-center mb-1">
                        <Icon className="h-4 w-4 text-primary" />
                      </div>
                      <div className="text-base font-bold text-foreground">{value}</div>
                      <div className="text-xs text-muted-foreground">{label}</div>
                    </div>
                  ))}
                </div>

                {/* Tags */}
                <div className="flex flex-wrap gap-1.5 pt-1">
                  {tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Trust signals band */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 p-8 rounded-xl bg-muted border border-border">
          {[
            { value: "10+", label: "London Enterprise Clients" },
            { value: "£50M+", label: "Client Revenue Influenced" },
            { value: "98%", label: "Client Retention Rate" },
            { value: "4.9/5", label: "Client Satisfaction Score" },
          ].map(({ value, label }) => (
            <div key={label} className="text-center">
              <div className="text-2xl md:text-3xl font-bold text-primary mb-1">{value}</div>
              <div className="text-xs text-muted-foreground uppercase tracking-wide">{label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
});

LondonCaseStudies.displayName = "LondonCaseStudies";

export default LondonCaseStudies;
