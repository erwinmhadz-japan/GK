import React from "react";
import { motion } from "framer-motion";
import { TrendingUp, RefreshCw, Target, Shield, CheckCircle, ArrowRight, Focus, Search, Section } from "lucide-react";

const reasons = [
  {
    icon: TrendingUp,
    heading: "Compounding Results Over Time",
    body:
      "SEO is not a tap you turn on once. Authority, rankings, and organic visibility accrue progressively. A retained engagement means every month builds on the last — rather than starting from scratch after a one-off project closes.",
  },
  {
    icon: RefreshCw,
    heading: "Sustained Strategic Momentum",
    body:
      "Search is not static. Algorithms evolve, competitors adapt, and your content landscape shifts. Ongoing consultancy means I can respond to changes in real time — adjusting priorities, testing hypotheses, and keeping your strategy aligned with where search is heading.",
  },
  {
    icon: Target,
    heading: "Consistent Priority and Focus",
    body:
      "Project-based SEO creates gaps. Between engagements, critical issues go unnoticed, link opportunities are missed, and technical debt accumulates. A retainer ensures your organic presence remains a consistent business priority rather than an occasional exercise.",
  },
  {
    icon: Shield,
    heading: "Direct Consultant Accountability",
    body:
      "With an agency, you liaise with an account manager — not the person doing the work. On retainer, you deal directly with me. I am accountable for strategy, execution, and results. No handoffs, no dilution of focus, no briefing middlemen.",
  },
];

const comparison = [
  {
    label: "One-Off Project",
    points: [
      "Defined scope, then disengagement",
      "No continuity after delivery",
      "Reactive to problems after they surface",
      "Progress stalls between engagements",
    ],
    positive: false,
  },
  {
    label: "SEO Retainer",
    points: [
      "Ongoing strategic ownership",
      "Compounding gains month over month",
      "Proactive monitoring and early intervention",
      "Direct, consistent access to your consultant",
    ],
    positive: true,
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay: i * 0.1 },
  }),
};

const SeoRetainerWhyRetainer = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seo-retainer-why-retainer"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mb-14 md:mb-20 max-w-2xl"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Why retained engagement works
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight mb-5">
            The Case for Retaining an SEO Consultant
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-prose">
            Most SEO problems are not solved by a single project. They are solved by sustained,
            expert attention applied consistently over time. Here is why a retainer arrangement
            outperforms one-off work — and why that matters for competitive UK businesses.
          </p>
        </motion.div>

        {/* Reasons grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 mb-16 md:mb-24">
          {reasons.map((reason, i) => {
            const Icon = reason.icon;
            return (
              <motion.div
                key={reason.heading}
                custom={i}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={fadeUp}
                className="bg-background border border-border rounded-md p-7 md:p-8 flex flex-col gap-4"
              >
                <div className="flex items-center gap-3">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-primary/10">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="text-lg md:text-xl font-semibold text-foreground leading-snug">
                    {reason.heading}
                  </h3>
                </div>
                <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                  {reason.body}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Comparison statement — two-column editorial layout */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mb-16 md:mb-20"
        >
          <h3 className="text-xl md:text-2xl font-semibold text-foreground mb-8 text-center">
            Project-based SEO vs. retained consultancy
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-6">
            {comparison.map((col) => (
              <div
                key={col.label}
                className={
                  col.positive
                    ? "bg-background border border-primary/30 rounded-md p-6 md:p-8"
                    : "bg-background border border-border rounded-md p-6 md:p-8 opacity-80"
                }
              >
                <p
                  className={
                    "text-sm uppercase tracking-[0.15em] font-semibold mb-5 " +
                    (col.positive ? "text-primary" : "text-muted-foreground")
                  }
                >
                  {col.label}
                </p>
                <ul className="space-y-3">
                  {col.points.map((point) => (
                    <li key={point} className="flex items-start gap-3">
                      <CheckCircle
                        className={
                          "h-4 w-4 mt-0.5 shrink-0 " +
                          (col.positive ? "text-primary" : "text-muted-foreground/50")
                        }
                      />
                      <span
                        className={
                          "text-sm leading-relaxed " +
                          (col.positive ? "text-foreground" : "text-muted-foreground line-through decoration-muted-foreground/40")
                        }
                      >
                        {point}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </motion.div>

        {/* Editorial statement block */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="border-l-2 border-primary pl-6 md:pl-8 max-w-3xl"
        >
          <p className="text-lg md:text-xl text-foreground leading-relaxed font-medium mb-3">
            "Sustained SEO is a compounding asset. The businesses that treat it as an ongoing
            investment — not a one-time spend — are consistently the ones that hold and grow
            their organic visibility over the long term."
          </p>
          <p className="text-sm text-muted-foreground">
            Gregg King, Independent SEO Consultant — Warrington, Cheshire
          </p>
          <p className="mt-5 text-sm text-muted-foreground">
            I work with UK businesses in competitive sectors — law, healthcare, finance, and property —
            where search visibility directly affects revenue and reputation. A retained arrangement means
            I can act as a consistent strategic partner, not just a one-off vendor.{" "}
            <a
              href="#seo-retainer-what-is-included"
              className="inline-flex items-center gap-1 text-primary font-medium hover:underline transition-colors"
            >
              See what is included <ArrowRight className="h-3.5 w-3.5" />
            </a>
          </p>
        </motion.div>

      </div>
    </section>
  );
});

SeoRetainerWhyRetainer.displayName = "SeoRetainerWhyRetainer";

export default SeoRetainerWhyRetainer;
