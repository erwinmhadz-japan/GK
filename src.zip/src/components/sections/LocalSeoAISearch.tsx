import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Bot, Star, Database, Globe, BookOpen, Search } from "lucide-react";

interface AISearchPoint {
  number: string;
  icon: React.ComponentType<{ className?: string }>;
  heading: string;
  body: string;
}

const points: AISearchPoint[] = [
  {
    number: "01",
    icon: Database,
    heading: "Entity Clarity",
    body:
      "AI search engines build their understanding of local businesses from structured entity data. When your business name, address, category, and attributes are consistent and well-defined across the web, AI models can confidently surface you in response to relevant local queries. Ambiguous or conflicting entity signals lead to omission — not misattribution.",
  },
  {
    number: "02",
    icon: Globe,
    heading: "Structured Data",
    body:
      "Schema markup — particularly LocalBusiness, Service, and Review schema — gives AI systems an explicit, machine-readable description of what your business offers and where. Google AI Overviews and Perplexity increasingly draw on structured data to compose local answers. Without it, your visibility in AI-generated results is largely left to chance.",
  },
  {
    number: "03",
    icon: Star,
    heading: "Review Signals",
    body:
      "ChatGPT, Perplexity, and Google's AI Overviews all factor review sentiment and volume into local recommendations. A consistent pattern of credible, recent reviews — particularly on Google — strengthens the confidence AI systems have in recommending your business. Review recency and authenticity matter as much as star ratings.",
  },
  {
    number: "04",
    icon: Bot,
    heading: "Google Business Profile Completeness",
    body:
      "Your Google Business Profile is one of the primary data sources AI search engines reference when constructing local answers. Incomplete profiles — missing categories, sparse descriptions, absent photos, or stale hours — reduce the quality of the data available to AI models and limit your chances of appearing in AI-generated local results.",
  },
  {
    number: "05",
    icon: BookOpen,
    heading: "Local Content Authority",
    body:
      "AI search engines reward local businesses that demonstrate genuine topical authority within their geography. Publishing content that addresses locally relevant questions, references local landmarks or context, and earns local citations positions your site as a credible local source — not just a generic business listing.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const LocalSeoAISearch = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="local-seo-aisearch"
      className="relative py-20 md:py-32 border-t border-border bg-muted overflow-hidden"
    >
      {/* Subtle dot-grid texture */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(214 32% 60% / 0.10) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
        aria-hidden="true"
      />

      {/* Dark navy band across the top third for visual accent */}
      <div
        className="absolute top-0 left-0 right-0 h-2 pointer-events-none"
        style={{
          background:
            "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
        }}
        aria-hidden="true"
      />

      <div className="container max-w-6xl mx-auto px-4 relative">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mb-14 md:mb-20"
        >
          <span
            className="inline-block text-xs uppercase tracking-[0.2em] font-medium mb-4"
            style={{ color: "hsl(119 35% 61%)" }}
          >
            Local SEO &amp; AI Search
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground max-w-2xl leading-snug">
            Local SEO in the Age of AI Search
          </h2>
          <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
            AI-powered search engines are changing how local businesses get
            discovered. Understanding the five signals below is now essential to
            maintaining — and growing — local search visibility.
          </p>
        </motion.div>

        {/* Numbered list */}
        <motion.ol
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          className="space-y-0 divide-y divide-border"
          role="list"
        >
          {points.map((point) => {
            const Icon = point.icon;
            return (
              <motion.li
                key={point.number}
                variants={itemVariants}
                className="group flex flex-col sm:flex-row gap-5 sm:gap-8 py-8 md:py-10"
              >
                {/* Number + icon column */}
                <div className="flex sm:flex-col items-center sm:items-start gap-4 sm:gap-3 sm:pt-1 flex-shrink-0">
                  <span
                    className="font-bold text-sm tabular-nums leading-none"
                    style={{ color: "hsl(214 32% 60%)" }}
                  >
                    {point.number}
                  </span>
                  <div
                    className="flex items-center justify-center w-10 h-10 rounded-md"
                    style={{
                      background: "hsl(225 28% 14% / 0.07)",
                      border: "1px solid hsl(214 32% 60% / 0.20)",
                    }}
                  >
                    <Icon
                      className="w-5 h-5"
                      style={{ color: "hsl(119 35% 61%)" }}
                    />
                  </div>
                </div>

                {/* Content column */}
                <div className="flex-1 min-w-0">
                  <h3 className="text-base md:text-lg font-semibold text-foreground mb-2 leading-snug">
                    {point.heading}
                  </h3>
                  <p className="text-sm md:text-base text-muted-foreground leading-relaxed max-w-2xl">
                    {point.body}
                  </p>
                </div>
              </motion.li>
            );
          })}
        </motion.ol>

        {/* Contextual cross-link — subtle, editorial */}
        <motion.div
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.5, ease: "easeOut", delay: 0.2 }}
          className="mt-12 pt-8 border-t border-border"
        >
          <p className="text-sm text-muted-foreground">
            Looking for help optimising your visibility across AI search
            engines?{" "}
            <Link
              to="/services-ai-search-optimisation"
              className="font-medium underline underline-offset-4 decoration-1 hover:text-foreground transition-colors"
              style={{ color: "hsl(119 35% 61%)" }}
            >
              Explore AI Search Optimisation →
            </Link>
          </p>
        </motion.div>
      </div>
    </section>
  );
});

LocalSeoAISearch.displayName = "LocalSeoAISearch";

export default LocalSeoAISearch;
