import React, { useState } from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CheckCircle, Loader2, Phone, Mail, MapPin, Contact, Search, Section, Send, Sidebar, Type } from "lucide-react";
const FORM_UUID = "0dec1e23-57d6-4f8f-888a-a98ec83e848f"; // Auto-injected — backend registration
const FORM_ACTION = `${import.meta.env.VITE_FORM_SUBMIT_URL || ''}/api/forms/${FORM_UUID}/submit/`;


const serviceOptions = [
  "SEO Consulting",
  "SEO Audit",
  "SEO Retainer",
  "Technical SEO",
  "Schema Markup",
  "Entity SEO",
  "Content Strategy",
  "Local SEO",
  "Digital PR",
  "AI Search Optimisation",
  "Free GBP Audit",
];

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (delay: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay },
  }),
};

const RequiredMark = () => (
  <span className="text-[hsl(var(--red-subtle))]" aria-hidden="true"> *</span>
);

const ContactForm = React.forwardRef<HTMLElement>((props, ref) => {
  const [status, setStatus] = useState<"idle" | "loading" | "success" | "error">("idle");
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({});
  const [serviceInterest, setServiceInterest] = useState<string>("");

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    setStatus("loading");
    setFieldErrors({});

    const formData = new FormData(form);
    const rawData = Object.fromEntries(formData.entries()) as Record<string, string>;
    const { honeypot, ...data } = rawData;

    if (serviceInterest) {
      data.service_interest = serviceInterest;
    }

    try {
        const response = await fetch(FORM_ACTION, {
          method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ data, honeypot }),
      });

      if (response.ok) {
        setStatus("success");
        form.reset();
        setServiceInterest("");
      } else if (response.status === 400) {
        const body = await response.json();
        if (body?.data && typeof body.data === "object") {
          setFieldErrors(body.data);
        }
        setStatus("error");
      } else {
        setStatus("error");
      }
    } catch {
      setStatus("error");
    }
  };

  const redToken = "hsl(var(--red-subtle))";

  return (
    <section
      ref={ref}
      id="contact-form"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          className="max-w-2xl mb-12 md:mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={fadeUp}
          custom={0}
        >
          <p className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-3 font-medium">
            Contact
          </p>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground leading-tight">
            Send an Enquiry
          </h2>
          <p className="mt-4 text-base text-muted-foreground leading-relaxed">
            Use the form below to outline your requirements. Gregg responds personally to every message — typically within one business day.
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-[1fr_360px] gap-12 lg:gap-16 items-start">
          {/* Form column */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            custom={0.1}
          >
            {status === "success" ? (
              <div className="flex flex-col items-start gap-4 py-12 px-8 bg-background rounded-md border border-border">
                <CheckCircle className="h-8 w-8 text-primary" />
                <div>
                  <h3 className="text-lg font-semibold text-foreground mb-1">
                    Enquiry received
                  </h3>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    Thank you for getting in touch. Gregg will review your message and respond personally — usually within one business day.
                  </p>
                </div>
              </div>
            ) : (
              <form
                onSubmit={handleSubmit}
                className="bg-background rounded-md border border-border p-7 md:p-9 space-y-6"
              >
                {/* Honeypot */}
                <input
                  type="text"
                  name="honeypot"
                  tabIndex={-1}
                  autoComplete="off"
                  aria-hidden="true"
                  className="absolute -left-[9999px] opacity-0 h-0 w-0"
                />

                {/* Name + Company */}
                <div className="grid sm:grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <Label htmlFor="name" className="text-sm font-medium text-foreground">
                      Full Name<RequiredMark />
                    </Label>
                    <Input
                      id="name"
                      name="name"
                      type="text"
                      placeholder="Jane Smith"
                      required
                      autoComplete="name"
                      className={fieldErrors.name ? "bg-background border-red-500" : "bg-background"}
                    />
                    {fieldErrors.name && (
                      <p className="text-xs" style={{ color: redToken }}>{fieldErrors.name}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="company" className="text-sm font-medium text-foreground">
                      Company / Organisation
                    </Label>
                    <Input
                      id="company"
                      name="company"
                      type="text"
                      placeholder="Smith and Co Solicitors"
                      autoComplete="organization"
                      className="bg-background"
                    />
                  </div>
                </div>

                {/* Email + Phone */}
                <div className="grid sm:grid-cols-2 gap-5">
                  <div className="space-y-2">
                    <Label htmlFor="email" className="text-sm font-medium text-foreground">
                      Email Address<RequiredMark />
                    </Label>
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      placeholder="jane@example.co.uk"
                      required
                      autoComplete="email"
                      className={fieldErrors.email ? "bg-background border-red-500" : "bg-background"}
                    />
                    {fieldErrors.email && (
                      <p className="text-xs" style={{ color: redToken }}>{fieldErrors.email}</p>
                    )}
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone" className="text-sm font-medium text-foreground">
                      Phone Number
                    </Label>
                    <Input
                      id="phone"
                      name="phone"
                      type="tel"
                      placeholder="07700 900000"
                      autoComplete="tel"
                      className="bg-background"
                    />
                  </div>
                </div>

                {/* Service Interest */}
                <div className="space-y-2">
                  <Label htmlFor="service_interest_trigger" className="text-sm font-medium text-foreground">
                    Area of Interest
                  </Label>
                  <Select value={serviceInterest} onValueChange={setServiceInterest}>
                    <SelectTrigger
                      id="service_interest_trigger"
                      className="bg-background w-full"
                    >
                      <SelectValue placeholder="Select a service or enquiry type" />
                    </SelectTrigger>
                    <SelectContent>
                      {serviceOptions.map((option) => (
                        <SelectItem key={option} value={option}>
                          {option}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <p className="text-xs text-muted-foreground">
                    Select "Free GBP Audit" if you would like a complimentary Google Business Profile review.
                  </p>
                </div>

                {/* Message */}
                <div className="space-y-2">
                  <Label htmlFor="message" className="text-sm font-medium text-foreground">
                    Your Message<RequiredMark />
                  </Label>
                  <Textarea
                    id="message"
                    name="message"
                    required
                    rows={5}
                    placeholder="Please briefly describe your SEO goals or challenges, your sector, and any timescales you have in mind."
                    className={fieldErrors.message ? "bg-background resize-none border-red-500" : "bg-background resize-none"}
                  />
                  {fieldErrors.message && (
                    <p className="text-xs" style={{ color: redToken }}>{fieldErrors.message}</p>
                  )}
                </div>

                {/* Submit row */}
                <div className="pt-1 flex flex-col sm:flex-row sm:items-center gap-4">
                  <Button
                    type="submit"
                    size="lg"
                    disabled={status === "loading"}
                    className="bg-primary text-primary-foreground hover:bg-primary/90 h-11 px-8 font-semibold transition-colors"
                  >
                    {status === "loading" ? (
                      <>
                        <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                        Sending…
                      </>
                    ) : (
                      "Send Enquiry"
                    )}
                  </Button>
                  <p className="text-xs text-muted-foreground">
                    No automated replies — Gregg responds personally.
                  </p>
                </div>

                {/* Generic error */}
                {status === "error" && !Object.keys(fieldErrors).length && (
                  <p className="text-sm" style={{ color: redToken }}>
                    Something went wrong. Please try again or email{" "}
                    <a
                      href="mailto:gregg@greggking.co.uk"
                      className="underline underline-offset-2 hover:text-foreground transition-colors"
                    >
                      gregg@greggking.co.uk
                    </a>{" "}
                    directly.
                  </p>
                )}
              </form>
            )}
          </motion.div>

          {/* Sidebar */}
          <motion.aside
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            custom={0.22}
            className="space-y-6"
          >
            {/* Direct contact card */}
            <div className="bg-background rounded-md border border-border p-7 space-y-6">
              <h3 className="text-xs font-semibold text-foreground uppercase tracking-[0.15em]">
                Direct Contact
              </h3>

              <div className="flex items-start gap-4">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-primary/10">
                  <Phone className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">Telephone</p>
                  <a
                    href="tel:01925214707"
                    className="text-sm font-semibold text-foreground hover:text-primary transition-colors"
                  >
                    01925 214707
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-primary/10">
                  <Mail className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">Email</p>
                  <a
                    href="mailto:gregg@greggking.co.uk"
                    className="text-sm font-semibold text-foreground hover:text-primary transition-colors break-all"
                  >
                    gregg@greggking.co.uk
                  </a>
                </div>
              </div>

              <div className="flex items-start gap-4">
                <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-md bg-primary/10">
                  <MapPin className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground mb-0.5">Address</p>
                  <address className="not-italic text-sm font-medium text-foreground leading-relaxed">
                    22 Foxdale Court<br />
                    Warrington WA4 5BS<br />
                    Cheshire
                  </address>
                </div>
              </div>
            </div>

            {/* What to expect */}
            <div className="rounded-md border border-border bg-background p-7 space-y-4">
              <h3 className="text-xs font-semibold text-foreground uppercase tracking-[0.15em]">
                What to Expect
              </h3>
              <ul className="space-y-3">
                {[
                  "A personal reply from Gregg — not a sales team",
                  "An initial conversation to understand your goals",
                  "Honest, straightforward advice before any commitment",
                  "A response within one business day",
                ].map((item) => (
                  <li key={item} className="flex items-start gap-3 text-sm text-muted-foreground">
                    <span className="mt-1.5 block h-1.5 w-1.5 shrink-0 rounded-full bg-primary" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Free GBP audit callout */}
            <div className="rounded-md border border-primary/25 bg-primary/5 p-5">
              <p className="text-xs font-semibold text-primary uppercase tracking-[0.15em] mb-2">
                Free GBP Audit
              </p>
              <p className="text-sm text-foreground leading-relaxed">
                Request a complimentary Google Business Profile review by selecting{" "}
                <strong className="font-medium">Free GBP Audit</strong> from the dropdown and including your business name in the message field.
              </p>
            </div>
          </motion.aside>
        </div>
      </div>
    </section>
  );
});

ContactForm.displayName = "ContactForm";

export default ContactForm;
