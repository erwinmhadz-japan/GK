import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle, Contact, Search } from "lucide-react";

const trustPoints = [
  "Independent consultant — not an agency",
  "Based in Warrington, serving clients across the UK",
  "Transparent, no-pressure approach",
];

const LocalSeoCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="local-seo-cta"
      className="relative py-20 md:py-32 border-t border-border bg-background"
      style={{ background: "hsl(225 28% 14%)" }}
    >
      {/* Subtle dot-grid texture overlay */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(119 35% 61% / 0.08) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      {/* Green accent glow — top-right */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-24 right-0 w-72 h-72 rounded-full"
        style={{
          background:
            "radial-gradient(circle, hsl(84 74% 60% / 0.14) 0%, transparent 70%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-2xl mx-auto text-center">
          {/* Eyebrow */}
          <motion.span
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut" }}
            className="inline-block text-xs uppercase tracking-[0.2em] font-medium mb-6"
            style={{ color: "hsl(119 35% 61%)" }}
          >
            Local SEO Consultation
          </motion.span>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.08 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold leading-tight mb-5 text-white"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Ready to Improve Your Local Search Rankings?
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.16 }}
            className="text-base md:text-lg leading-relaxed mb-8 text-white/80"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Get a free local SEO audit and a clear picture of where you stand
            in your target area. I'll review your current local visibility,
            identify the gaps, and outline what needs to change — no obligation,
            no sales pressure.
          </motion.p>

          {/* Trust points */}
          <motion.ul
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.22 }}
            className="flex flex-col sm:flex-row flex-wrap justify-center gap-3 mb-10"
          >
            {trustPoints.map((point) => (
              <li
                key={point}
                className="flex items-center gap-2 text-sm text-white/80"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                <CheckCircle
                  className="h-4 w-4 shrink-0"
                  style={{ color: "hsl(119 35% 61%)" }}
                  aria-hidden="true"
                />
                {point}
              </li>
            ))}
          </motion.ul>

          {/* CTA Buttons */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
            className="flex flex-col sm:flex-row gap-4 justify-center items-center"
          >
            {/* Primary CTA — bright green */}
            <Button
              size="lg"
              asChild
              className="h-12 px-8 text-sm font-semibold uppercase tracking-wider border-0 transition-all duration-300"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 60%), hsl(119 35% 61%))",
                color: "hsl(225 28% 10%)",
                boxShadow: "0 0 0 0 hsl(84 74% 60% / 0)",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.boxShadow =
                  "0 0 32px hsl(84 74% 60% / 0.4)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.boxShadow =
                  "0 0 0 0 hsl(84 74% 60% / 0)";
              }}
            >
              <Link to="/contact">
                FREE SEO AUDIT
                <ArrowRight className="ml-2 h-4 w-4" aria-hidden="true" />
              </Link>
            </Button>

            {/* Secondary CTA — ghost */}
            <Button
              size="lg"
              variant="outline"
              asChild
              className="h-12 px-8 text-sm font-medium bg-transparent text-white border-white/25 hover:bg-white/8 hover:border-white/50 transition-all duration-300"
            >
              <Link to="/contact">Contact Me</Link>
            </Button>
          </motion.div>

          {/* Reassurance line */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.4 }}
            className="mt-6 text-xs text-white/80"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Free audit · No commitment · Response within one working day
          </motion.p>
        </div>
      </div>
    </section>
  );
});

LocalSeoCTA.displayName = "LocalSeoCTA";

export default LocalSeoCTA;
