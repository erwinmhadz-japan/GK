import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight, Globe, Eye, Layers, Bot, Sparkles, Search, Section, View } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface RelatedPage {
  label: string;
  badge: string;
  headline: string;
  description: string;
  href: string;
  icon: React.ElementType;
  intent: "informational" | "commercial";
}

const relatedPages: RelatedPage[] = [
  {
    label: "Perplexity Visibility",
    badge: "Informational",
    headline: "How to Appear in Perplexity AI Responses",
    description:
      "Perplexity draws on cited web sources to generate answers. Understanding how it selects and attributes content is essential for brands seeking visibility in AI-powered search.",
    href: "/perplexity-visibility",
    icon: Globe,
    intent: "informational",
  },
  {
    label: "Google AI Overviews",
    badge: "Informational",
    headline: "Google AI Overviews and Organic Visibility",
    description:
      "Google's AI Overviews appear above traditional results for many commercial queries. Learn which content signals influence inclusion and how they affect click-through behaviour.",
    href: "/google-ai-overviews",
    icon: Eye,
    intent: "informational",
  },
  {
    label: "Gemini Visibility",
    badge: "Informational",
    headline: "Brand Mentions in Google Gemini",
    description:
      "Gemini integrates across Google products and surfaces brand references based on entity recognition and authority signals. This guide explains the mechanics behind Gemini's responses.",
    href: "/gemini-visibility",
    icon: Sparkles,
    intent: "informational",
  },
  {
    label: "Copilot Visibility",
    badge: "Informational",
    headline: "Microsoft Copilot and Bing-Powered AI Search",
    description:
      "Microsoft Copilot uses Bing's index and entity graph to generate responses. Brands with strong traditional SEO foundations tend to perform better — but the signals overlap only partially.",
    href: "/copilot-visibility",
    icon: Bot,
    intent: "informational",
  },
  {
    label: "AI Search Optimisation",
    badge: "Service",
    headline: "The Commercial Strategy for AI Search Visibility",
    description:
      "If you are looking to act on what you have read here, the AI Search Optimisation service covers the practical work: entity building, citation strategy, structured data, and content alignment across AI platforms.",
    href: "/ai-search-optimisation",
    icon: Layers,
    intent: "commercial",
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay: i * 0.1 },
  }),
};

const ChatgptVisibilityRelatedTopics = React.forwardRef<HTMLElement>(
  (props, ref) => {
    return (
      <section
        ref={ref}
        id="chatgpt-visibility-related-topics"
        className="relative py-20 md:py-32 border-t border-border bg-muted"
      >
        <div className="container max-w-6xl mx-auto px-4">
          {/* Section header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.55, ease: "easeOut" }}
            className="mb-12 md:mb-16"
          >
            <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
              Related Reading
            </span>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground font-[Sora,sans-serif] max-w-2xl leading-snug">
              Explore the AI Search Hub
            </h2>
            <p className="mt-4 text-base text-muted-foreground max-w-xl leading-relaxed">
              ChatGPT is one of several AI platforms shaping how brands are
              discovered. The pages below cover the other major platforms, plus
              the commercial service for businesses ready to take action.
            </p>
          </motion.div>

          {/* Cards grid — exactly 5 items: 4 informational + 1 commercial */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {relatedPages.map((page, index) => {
              const Icon = page.icon;
              const isCommercial = page.intent === "commercial";

              return (
                <motion.div
                  key={page.href}
                  custom={index}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, margin: "-40px" }}
                  variants={fadeUp}
                  className={
                    // The 5th card (commercial) spans full width on md+
                    index === 4 ? "md:col-span-2" : ""
                  }
                >
                  <Link
                    to={page.href}
                    className={[
                      "group flex flex-col h-full rounded-md border bg-background p-6 transition-all duration-300",
                      isCommercial
                        ? "border-primary/30 hover:border-primary/60 hover:shadow-[0_4px_24px_-6px_hsl(88_59%_56%_/_0.18)]"
                        : "border-border hover:border-border hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%_/_0.10)]",
                    ].join(" ")}
                    aria-label={`Read about ${page.label}`}
                  >
                    <div className="flex items-start justify-between gap-4 mb-4">
                      {/* Icon */}
                      <div
                        className={[
                          "flex h-10 w-10 shrink-0 items-center justify-center rounded-md transition-colors duration-300",
                          isCommercial
                            ? "bg-primary/10 group-hover:bg-primary/20"
                            : "bg-muted group-hover:bg-muted/80",
                        ].join(" ")}
                      >
                        <Icon
                          className={[
                            "h-5 w-5",
                            isCommercial
                              ? "text-primary"
                              : "text-muted-foreground group-hover:text-foreground transition-colors duration-300",
                          ].join(" ")}
                        />
                      </div>

                      {/* Badge */}
                      <Badge
                        variant={isCommercial ? "default" : "secondary"}
                        className={[
                          "text-xs shrink-0",
                          isCommercial
                            ? "bg-primary/10 text-primary border border-primary/20"
                            : "bg-muted text-muted-foreground",
                        ].join(" ")}
                      >
                        {page.badge}
                      </Badge>
                    </div>

                    {/* Meta label */}
                    <span className="text-xs uppercase tracking-[0.15em] text-muted-foreground font-medium mb-2">
                      {page.label}
                    </span>

                    {/* Headline */}
                    <h3
                      className={[
                        "text-base md:text-lg font-semibold leading-snug mb-3 transition-colors duration-200 font-[Sora,sans-serif]",
                        isCommercial
                          ? "text-foreground group-hover:text-primary"
                          : "text-foreground group-hover:text-foreground",
                      ].join(" ")}
                    >
                      {page.headline}
                    </h3>

                    {/* Description */}
                    <p className="text-sm text-muted-foreground leading-relaxed flex-1">
                      {page.description}
                    </p>

                    {/* Read more link */}
                    <div
                      className={[
                        "flex items-center gap-1.5 mt-5 text-sm font-medium transition-colors duration-200",
                        isCommercial
                          ? "text-primary"
                          : "text-muted-foreground group-hover:text-foreground",
                      ].join(" ")}
                    >
                      <span>
                        {isCommercial ? "View the service" : "Read the guide"}
                      </span>
                      <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>

          {/* Footer note — understated cross-link to hub */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: "easeOut", delay: 0.5 }}
            className="mt-10 text-sm text-muted-foreground"
          >
            All AI search guides sit within the{" "}
            <Link
              to="#ai-search-cta"
              className="text-foreground underline underline-offset-2 hover:text-primary transition-colors duration-200"
            >
              AI Search hub
            </Link>
            , which covers the informational landscape across ChatGPT, Perplexity,
            Google AI Overviews, Gemini, and Microsoft Copilot.
          </motion.p>
        </div>
      </section>
    );
  }
);

ChatgptVisibilityRelatedTopics.displayName = "ChatgptVisibilityRelatedTopics";

export default ChatgptVisibilityRelatedTopics;
