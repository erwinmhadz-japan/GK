import React from "react";
import { motion } from "framer-motion";
import { Network, Globe, Database, Fingerprint, Layers, Brain, Key, Search, Section } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (delay: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut", delay },
  }),
};

interface ConceptItem {
  icon: React.ComponentType<{ className?: string }>;
  term: string;
  definition: string;
}

const concepts: ConceptItem[] = [
  {
    icon: Network,
    term: "Knowledge Graph",
    definition:
      "Google's structured database of real-world entities — people, organisations, places, and concepts — and the relationships between them. Ranking well today means being a recognised node in that graph.",
  },
  {
    icon: Fingerprint,
    term: "Entity Disambiguation",
    definition:
      "The process of making your brand, name, or organisation unambiguous to search engines. If Google cannot distinguish you from similarly named entities, it cannot confidently surface you in results.",
  },
  {
    icon: Database,
    term: "Structured Identity Signals",
    definition:
      "Schema markup, Wikipedia presence, Wikidata entries, consistent NAP data, and authoritative co-citations that collectively tell search engines — and AI systems — precisely who you are.",
  },
  {
    icon: Globe,
    term: "Brand Entity Consolidation",
    definition:
      "Ensuring your brand is represented consistently across the web — your website, social profiles, directories, press mentions, and third-party platforms — so Google builds a coherent entity profile around you.",
  },
  {
    icon: Layers,
    term: "Semantic Authority",
    definition:
      "A measure of how thoroughly and credibly you are associated with a topic in Google's understanding. Entity SEO is the mechanism for building that association deliberately, not leaving it to chance.",
  },
  {
    icon: Brain,
    term: "AI Search Relevance",
    definition:
      "Generative AI systems — including Google's AI Overviews, ChatGPT, and Perplexity — rely on entity data to determine which sources to surface. Strong entity signals translate directly into AI citation visibility.",
  },
];

const EntitySeoWhatIs = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="entity-seo-what-is"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <div className="max-w-3xl mx-auto mb-14 md:mb-20">
          <motion.p
            custom={0}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            className="text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium"
          >
            Foundations
          </motion.p>

          <motion.h2
            custom={0.1}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight mb-6"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            What Is Entity SEO?
          </motion.h2>

          <motion.p
            custom={0.2}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            className="text-lg text-muted-foreground leading-relaxed mb-5"
          >
            For most of its history, Google ranked pages by matching keywords.
            A page that contained the right words, in the right quantity, with
            enough links pointing at it, would rank. That model still exists —
            but it is no longer the whole picture.
          </motion.p>

          <motion.p
            custom={0.28}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            className="text-base md:text-lg text-muted-foreground leading-relaxed mb-5"
          >
            Over the past decade, Google has shifted its understanding of the
            web away from documents and towards{" "}
            <em className="text-foreground not-italic font-medium">
              entities
            </em>
            . An entity, in Google's terms, is any distinct, uniquely
            identifiable thing — a person, a business, a place, a concept. When
            someone searches for &ldquo;SEO consultant Warrington&rdquo;, Google
            is not simply pattern-matching text strings; it is trying to
            understand which real-world entities best answer that query, and
            whether your brand is one of them.
          </motion.p>

          <motion.p
            custom={0.36}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            className="text-base md:text-lg text-muted-foreground leading-relaxed mb-5"
          >
            Entity SEO is the practice of ensuring search engines — and
            increasingly, AI systems — can identify, understand, and trust your
            brand as a clearly defined entity. It involves structured data,
            Knowledge Graph signals, consistent identity across the web, and
            deliberate co-citation strategy. Done properly, it moves you from
            being a keyword match to being a recognised authority in your field.
          </motion.p>

          <motion.p
            custom={0.44}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            className="text-base md:text-lg text-muted-foreground leading-relaxed"
          >
            For UK businesses operating in competitive, trust-led sectors —
            law, finance, healthcare, property — the ability to be understood
            as a credible, authoritative entity is increasingly what separates
            those who rank from those who do not.
          </motion.p>
        </div>

        {/* Divider */}
        <motion.div
          custom={0.5}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={fadeUp}
          className="w-12 h-0.5 bg-primary mx-auto mb-14 md:mb-20"
        />

        {/* Key concepts heading */}
        <motion.div
          custom={0.52}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={fadeUp}
          className="text-center mb-12"
        >
          <h3
            className="text-xl md:text-2xl font-semibold text-foreground mb-3"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Key Concepts in Entity SEO
          </h3>
          <p className="text-muted-foreground text-sm max-w-xl mx-auto">
            Understanding the vocabulary is the first step. Here is what each
            term means in practical terms for your business.
          </p>
        </motion.div>

        {/* Concepts grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {concepts.map((concept, index) => {
            const Icon = concept.icon;
            return (
              <motion.div
                key={concept.term}
                custom={0.55 + index * 0.08}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-60px" }}
                variants={fadeUp}
                className="group rounded-md border border-border bg-background p-6 transition-all duration-300 hover:shadow-[0_4px_24px_0_rgba(30,40,80,0.10)] hover:-translate-y-0.5"
              >
                {/* Icon */}
                <div className="flex items-center justify-center w-10 h-10 rounded-md bg-primary/10 mb-4 transition-colors duration-300 group-hover:bg-primary/20">
                  <Icon className="h-5 w-5 text-primary" />
                </div>

                {/* Term */}
                <h4
                  className="text-base font-semibold text-foreground mb-2"
                  style={{ fontFamily: "Sora, sans-serif" }}
                >
                  {concept.term}
                </h4>

                {/* Definition */}
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {concept.definition}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Closing editorial note */}
        <motion.div
          custom={0.7}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={fadeUp}
          className="mt-14 md:mt-20 max-w-2xl mx-auto border-l-2 border-primary pl-6"
        >
          <p className="text-base text-muted-foreground leading-relaxed italic">
            &ldquo;Entity SEO is not a replacement for traditional on-page and
            link-building work — it is the layer beneath it. Without a clear
            entity footprint, the rest of your SEO efforts are building on
            uncertain foundations.&rdquo;
          </p>
          <p className="mt-3 text-xs uppercase tracking-widest text-muted-foreground font-medium">
            Gregg King — Independent SEO Consultant, Warrington
          </p>
        </motion.div>
      </div>
    </section>
  );
});

EntitySeoWhatIs.displayName = "EntitySeoWhatIs";

export default EntitySeoWhatIs;
