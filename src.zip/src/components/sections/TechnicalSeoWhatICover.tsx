import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Gauge, FolderTree, FileSearch, Layers, CodeXml, Terminal, Smartphone, ScanLine, GitMerge, Globe, Link2, LayoutGrid, File, Layout, Search, Section } from "lucide-react";

interface TechnicalArea {
  icon: React.ElementType;
  title: string;
  description: string;
}

const technicalAreas: TechnicalArea[] = [
  {
    icon: Gauge,
    title: "Core Web Vitals & Site Speed",
    description:
      "I audit and improve Largest Contentful Paint, Interaction to Next Paint, and Cumulative Layout Shift scores — the performance signals that directly influence both rankings and user experience. This includes server response times, render-blocking resources, and image optimisation.",
  },
  {
    icon: FolderTree,
    title: "Site Architecture & Crawl Budget",
    description:
      "A logical, flat site structure ensures search engines can discover and index your most important content efficiently. I review internal link depth, URL structures, crawl traps, and pagination handling to make certain Google's crawl budget is spent where it matters most.",
  },
  {
    icon: FileSearch,
    title: "Indexation & Canonical Management",
    description:
      "I identify pages that are incorrectly excluded from the index and resolve duplicate content issues through proper canonical tag implementation. This prevents equity dilution and ensures your strongest pages are the ones that appear in search results.",
  },
  {
    icon: CodeXml,
    title: "Structured Data & Schema Markup",
    description:
      "Implementing schema.org vocabulary — Organisation, LocalBusiness, FAQ, Article, BreadcrumbList, and more — helps search engines understand your content with greater precision and enables rich result features in Google Search. I write and validate schema that is accurate to your pages, not generic templates.",
  },
  {
    icon: Terminal,
    title: "JavaScript Rendering & Log File Analysis",
    description:
      "For sites with heavy JavaScript frameworks, I assess what Googlebot can and cannot render, identifying content that is invisible to crawlers. Log file analysis reveals exactly how search engine bots are navigating your site — essential intelligence that analytics tools alone cannot provide.",
  },
  {
    icon: GitMerge,
    title: "Redirect Audits, Hreflang & Mobile Usability",
    description:
      "Broken or chained redirects bleed link equity and slow crawls. I audit redirect chains, identify orphan pages, and resolve redirect loops. For sites serving multiple regions, I implement and validate hreflang annotations. Mobile usability issues — tap target sizing, viewport configuration, and content parity — are reviewed against Google's mobile-first indexing requirements.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.55,
      ease: "easeOut",
    },
  },
};

const headingVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: "easeOut",
    },
  },
};

const TechnicalSeoWhatICover = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="technical-seo-what-icover"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          className="max-w-2xl mb-12 md:mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={headingVariants}
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Scope of work
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 font-[Sora,sans-serif]">
            What Technical SEO Covers
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-prose">
            Technical SEO is not a single task — it is a discipline that spans
            crawlability, performance, structured data, and rendering. Below is
            a clear account of the specific areas I address when working on a
            technical engagement.
          </p>
        </motion.div>

        {/* Cards grid — exactly 6 items */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={containerVariants}
        >
          {technicalAreas.map((area) => {
            const Icon = area.icon;
            return (
              <motion.div key={area.title} variants={itemVariants}>
                <Card className="h-full border border-border bg-background shadow-sm hover:shadow-md transition-shadow duration-300 rounded-md group">
                  <CardHeader className="pb-3">
                    <div className="flex items-start gap-3">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-primary/10 group-hover:bg-primary/15 transition-colors duration-300">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                      <CardTitle className="text-base font-semibold text-foreground leading-snug font-[Sora,sans-serif] pt-1">
                        {area.title}
                      </CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {area.description}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Closing note — consultant voice, no CTA */}
        <motion.p
          className="mt-12 text-sm text-muted-foreground max-w-2xl"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.6, delay: 0.3, ease: "easeOut" }}
        >
          Every engagement begins with a thorough technical audit before any
          recommendations are made. The scope above reflects the most common
          issues I encounter across client sites — though each audit is tailored
          to what the data actually shows, not a fixed checklist.
        </motion.p>
      </div>
    </section>
  );
});

TechnicalSeoWhatICover.displayName = "TechnicalSeoWhatICover";

export default TechnicalSeoWhatICover;
