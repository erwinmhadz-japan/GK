import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Newspaper, Link2, TrendingUp, Target, MessageSquare, Globe, Search, BarChart2, CheckCircle, Building, Link, Section } from "lucide-react";

const services = [
  {
    icon: Globe,
    title: "Media Outreach",
    description:
      "Strategic, targeted outreach to relevant journalists, editors, and publications. I build genuine relationships with media contacts in your sector — pitching stories that earn coverage, not just mentions.",
    points: [
      "Sector-specific journalist targeting",
      "Personalised, pitch-led approach",
      "National and trade press coverage",
    ],
  },
  {
    icon: TrendingUp,
    title: "Reactive PR & Newsjacking",
    description:
      "Capitalise on breaking news and emerging trends to position you as the authoritative voice in your field. Timely commentary placed with the right publications earns high-authority editorial links.",
    points: [
      "Real-time news monitoring",
      "Expert commentary placement",
      "Fast-turnaround reactive pitches",
    ],
  },
  {
    icon: BarChart2,
    title: "Data-Driven Campaigns",
    description:
      "Original research, surveys, and data analysis transformed into compelling campaign assets. Unique data is one of the most reliable drivers of organic editorial coverage and authoritative backlinks.",
    points: [
      "Proprietary research and surveys",
      "Shareable data visualisations",
      "Campaign assets with strong link potential",
    ],
  },
  {
    icon: MessageSquare,
    title: "Expert Quotes & Commentary",
    description:
      "Position you as a credible industry authority through regular expert quote placement. I identify journalist enquiries and editorial opportunities where your voice adds genuine value.",
    points: [
      "HARO and journalist request monitoring",
      "Thought leadership positioning",
      "Consistent authority-building cadence",
    ],
  },
  {
    icon: Target,
    title: "Journalist Relationship Building",
    description:
      "Long-term relationship development with key journalists and editors in your sector. Sustained media relationships generate repeat coverage and reliable link acquisition over time.",
    points: [
      "Ongoing journalist outreach cadence",
      "Sector-specific media mapping",
      "Long-form relationship strategy",
    ],
  },
  {
    icon: Link2,
    title: "Link Acquisition Strategy",
    description:
      "Every digital PR campaign is structured around a clear link acquisition objective. I align coverage targets with your domain's authority gaps to maximise SEO impact from earned media.",
    points: [
      "Authority gap analysis",
      "Target domain prioritisation",
      "Coverage mapped to ranking impact",
    ],
  },
  {
    icon: Search,
    title: "Broken Link Reclamation",
    description:
      "Systematic identification and reclamation of lost or broken backlinks pointing to your domain. A frequently overlooked but high-value tactic for recovering link equity without additional outreach.",
    points: [
      "Full backlink audit for broken links",
      "Redirect and reclaim strategy",
      "Net link equity recovery reporting",
    ],
  },
  {
    icon: Newspaper,
    title: "Editorial Link Building",
    description:
      "Unlike transactional link schemes, I focus exclusively on earned editorial coverage — links placed because the content genuinely merits inclusion. This is the only approach that sustains rankings long-term.",
    points: [
      "No paid placements or link schemes",
      "Editorial-quality content assets",
      "Sustainable, white-hat methodology",
    ],
  },
  {
    icon: CheckCircle,
    title: "Campaign Reporting & Review",
    description:
      "Clear, transparent reporting on every campaign — coverage secured, domains earned, authority metrics tracked. I review performance against your SEO objectives, not vanity PR metrics.",
    points: [
      "Coverage and link attribution reporting",
      "Domain authority tracking",
      "Quarterly strategy review sessions",
    ],
  },
];

const DigitalPrServices = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="digital-pr-services"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          className="mb-14 md:mb-20 max-w-2xl"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <span className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium">
            What I Offer
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground tracking-tight mb-5 max-w-xl">
            Digital PR Services
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-prose">
            A bespoke, consultant-led digital PR service built around your
            business's specific authority goals. Every campaign is structured to
            earn editorial coverage that genuinely moves the needle — not
            volume outreach for its own sake.
          </p>
        </motion.div>

        {/* Services grid — 9 items in 3-col grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            return (
              <motion.div
                key={service.title}
                className="h-full"
                initial={{ opacity: 0, y: 28 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-30px" }}
                transition={{
                  duration: 0.5,
                  ease: "easeOut",
                  delay: (index % 3) * 0.08,
                }}
              >
                <Card className="h-full border border-border bg-card shadow-sm hover:shadow-md transition-all duration-300 hover:-translate-y-0.5 rounded-md group">
                  <CardHeader className="pb-3">
                    <div className="mb-4">
                      <div className="inline-flex items-center justify-center w-10 h-10 rounded-md bg-primary/10 group-hover:bg-primary/15 transition-colors duration-200">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                    </div>
                    <CardTitle className="text-base md:text-lg font-semibold text-foreground leading-snug">
                      {service.title}
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="pt-0">
                    <p className="text-sm text-muted-foreground leading-relaxed mb-5">
                      {service.description}
                    </p>
                    <ul className="space-y-2">
                      {service.points.map((point) => (
                        <li
                          key={point}
                          className="flex items-start gap-2 text-sm text-foreground"
                        >
                          <CheckCircle className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                          <span>{point}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </div>

        {/* Consultant note — editorial footer */}
        <motion.div
          className="mt-14 md:mt-20 border-t border-border pt-10"
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
        >
          <div className="flex flex-col md:flex-row md:items-start gap-5 max-w-3xl">
            <div className="flex-shrink-0 w-1 min-h-[52px] bg-primary rounded-full hidden md:block" />
            <p className="text-sm text-muted-foreground leading-relaxed">
              <span className="text-foreground font-medium">
                A note on approach:
              </span>{" "}
              I don't operate a volume outreach model. Every campaign I run is
              tailored to the client's sector, link profile, and authority
              objectives. If you've previously worked with agencies running
              mass-blast outreach, the difference in quality and editorial
              placement will be immediately apparent.
            </p>
          </div>
        </motion.div>

      </div>
    </section>
  );
});

DigitalPrServices.displayName = "DigitalPrServices";

export default DigitalPrServices;
