import React from "react";
import { Button } from "@/components/ui/button";
import { CheckCircle, ArrowRight, MessageSquare, View } from "lucide-react";

const benefits = [
  "Independent consultant — no agency overhead",
  "Proven results across competitive UK markets",
  "Covers SEO, AI search, local, and technical",
  "Plain-English reporting, no jargon",
];

const Page2CTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="page2-cta"
      className="relative isolate py-24 md:py-36 border-t border-border overflow-hidden"
    >
      {/* Background image with brand tint */}
      <img
        src="https://images.unsplash.com/photo-1571120245989-c2878f4c89b9?w=1920&h=1080&fit=crop"
        alt="Modern boardroom with large windows and city views"
        className="absolute inset-0 w-full h-full object-cover"
        width={1920}
        height={1080}
        loading="lazy"
      />
      {/* Brand tint overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-[hsl(222_42%_8%/0.92)] via-[hsl(222_38%_14%/0.88)] to-[hsl(88_59%_30%/0.75)] pointer-events-none" />

      <div className="container relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-white/10 backdrop-blur-sm border border-white/20 rounded-full px-4 py-2 mb-6">
            <MessageSquare className="h-4 w-4 text-primary" />
            <span className="text-white/90 text-sm font-medium">Free Initial Consultation</span>
          </div>

          <h2 className="text-3xl md:text-5xl font-bold text-white mb-5 leading-tight">
            Ready to Put This Knowledge Into Practice?
          </h2>
          <p className="text-lg text-white/90 mb-8 leading-relaxed">
            Theory is only the start. Work with an independent SEO consultant who understands the
            nuances of UK search — and knows how to translate strategy into measurable results.
          </p>

          <ul className="flex flex-wrap justify-center gap-x-8 gap-y-3 mb-10">
            {benefits.map((benefit) => (
              <li key={benefit} className="flex items-center gap-2 text-white/90 text-sm">
                <CheckCircle className="h-4 w-4 text-primary shrink-0" />
                {benefit}
              </li>
            ))}
          </ul>

          <div className="flex flex-wrap justify-center gap-4">
            <Button
              size="lg"
              className="bg-gradient-cta text-foreground font-bold px-8 hover:opacity-90 transition-opacity shadow-green-glow"
              asChild
            >
              <a href="/contact">
                Get Your Free Consultation <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10 font-semibold px-8"
              asChild
            >
              <a href="/services">View Services</a>
            </Button>
          </div>

          <p className="mt-6 text-white/80 text-sm">
            No commitment required · Response within one business day
          </p>
        </div>
      </div>
    </section>
  );
});

Page2CTA.displayName = "Page2CTA";

export default Page2CTA;
