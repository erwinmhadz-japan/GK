import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle, FileText, Target, TrendingUp, Contact, View } from "lucide-react";

const trustPoints = [
  {
    icon: Target,
    label: "Topical authority built through intent-led planning",
  },
  {
    icon: TrendingUp,
    label: "Editorial depth that earns rankings, not just traffic",
  },
  {
    icon: FileText,
    label: "Content strategy as consultancy — not copywriting or production",
  },
  {
    icon: CheckCircle,
    label: "Independent advice aligned to your commercial objectives",
  },
];

const ContentStrategyCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="content-strategy-cta"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left column — headline + trust points */}
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.65, ease: "easeOut" }}
          >
            {/* Eyebrow */}
            <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-5 font-medium">
              Content Strategy Consultancy
            </span>

            {/* Headline */}
            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight max-w-xl">
              Ready to Build{" "}
              <span className="text-primary">Topical Authority?</span>
            </h2>

            {/* Subheadline */}
            <p className="mt-5 text-base md:text-lg text-muted-foreground leading-relaxed max-w-lg">
              Commission a content strategy that earns rankings through editorial
              depth and relevance — not volume.
            </p>

            {/* Trust points */}
            <ul className="mt-8 space-y-4">
              {trustPoints.map((point, index) => {
                const Icon = point.icon;
                return (
                  <motion.li
                    key={point.label}
                    className="flex items-start gap-3"
                    initial={{ opacity: 0, x: -16 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true, margin: "-60px" }}
                    transition={{
                      duration: 0.5,
                      ease: "easeOut",
                      delay: 0.1 + index * 0.08,
                    }}
                  >
                    <span className="mt-0.5 flex-shrink-0 flex h-5 w-5 items-center justify-center">
                      <Icon className="h-4 w-4 text-primary" />
                    </span>
                    <span className="text-sm md:text-base text-foreground">
                      {point.label}
                    </span>
                  </motion.li>
                );
              })}
            </ul>
          </motion.div>

          {/* Right column — CTA card */}
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.15 }}
          >
            <div className="rounded-md border border-border bg-background p-8 md:p-10 shadow-sm">
              {/* Card eyebrow */}
              <span className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium">
                Independent Consultant · Warrington, Cheshire
              </span>

              {/* Card heading */}
              <h3 className="text-xl md:text-2xl font-semibold text-foreground leading-snug">
                Drive enquiries from commercial buyers who understand the value
                of strategic content planning.
              </h3>

              {/* Card body */}
              <p className="mt-4 text-sm md:text-base text-muted-foreground leading-relaxed">
                I work directly with UK businesses in competitive sectors —
                including law, finance, healthcare, and property — to define
                content that earns authority, not just clicks. If you're ready
                to invest in a structured, strategic approach, I'd be glad to
                discuss your requirements.
              </p>

              {/* Divider */}
              <hr className="my-6 border-border" />

              {/* CTAs */}
              <div className="flex flex-col sm:flex-row gap-3">
                <Button
                  size="lg"
                  className="w-full sm:w-auto text-base font-semibold bg-primary text-primary-foreground hover:bg-primary/90 transition-all duration-200 group"
                  asChild
                >
                  <Link to="/contact">
                    Contact Me
                    <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-0.5 transition-transform duration-200" />
                  </Link>
                </Button>

                <Button
                  size="lg"
                  variant="outline"
                  className="w-full sm:w-auto text-base font-medium border-border text-foreground hover:bg-muted transition-colors duration-200"
                  asChild
                >
                  <Link to="/services">View All Services</Link>
                </Button>
              </div>

              {/* Reassurance note */}
              <p className="mt-4 text-xs text-muted-foreground">
                Independent consultancy only — no account managers, no junior
                handoffs. You work directly with me.
              </p>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
});

ContentStrategyCTA.displayName = "ContentStrategyCTA";

export default ContentStrategyCTA;
