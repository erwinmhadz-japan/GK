import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { ArrowRight, CheckCircle, ChevronRight, Contact, Home, View } from "lucide-react";

const pillars = [
  "No account managers",
  "No junior teams",
  "No padded retainers",
  "Direct expert counsel",
];

const ServicesHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="services-hero"
      className="relative py-20 md:py-32 border-t border-border bg-background"
      style={{
        background:
          "linear-gradient(160deg, hsl(225 28% 14%) 0%, hsl(231 9% 16%) 55%, hsl(225 28% 14%) 100%)",
      }}
    >
      {/* Subtle dot-grid texture overlay */}
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.04]"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(0 0% 100%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
        aria-hidden="true"
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl">

          {/* Breadcrumb */}
          <motion.nav
            aria-label="Breadcrumb"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, ease: "easeOut", delay: 0 }}
            className="flex items-center gap-1.5 mb-6 text-xs text-white/50"
          >
            <Link to="/" className="hover:text-white/80 transition-colors duration-150">Home</Link>
            <ChevronRight className="h-3 w-3 flex-shrink-0" aria-hidden="true" />
            <span className="text-white/80 font-medium" aria-current="page">Services</span>
          </motion.nav>

          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.05 }}
          >
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-5 font-medium">
              Independent SEO Consulting · Warrington, Cheshire
            </span>
          </motion.div>

          {/* H1 */}
          <motion.h1
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-[1.1] tracking-tight mb-6"
          >
            SEO Consulting Services
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.2 }}
            className="text-lg md:text-xl text-white/80 leading-relaxed mb-8 max-w-2xl"
          >
            Independent SEO consulting for UK businesses that need results, not
            retainers padded by agency overhead.
          </motion.p>

          {/* Pillars */}
          <motion.ul
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
            className="flex flex-wrap gap-x-6 gap-y-2 mb-10"
            role="list"
          >
            {pillars.map((item) => (
              <li
                key={item}
                className="flex items-center gap-2 text-sm text-white/80"
              >
                <CheckCircle className="h-4 w-4 shrink-0 text-[hsl(119_35%_61%)]" />
                <span>{item}</span>
              </li>
            ))}
          </motion.ul>

          {/* CTAs */}
          <motion.div
            initial={{ opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.4 }}
            className="flex flex-wrap items-center gap-4"
          >
            <Button
              size="lg"
              asChild
              className="h-12 px-8 text-base font-semibold rounded-md"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                color: "hsl(225 28% 14%)",
                border: "none",
              }}
            >
              <Link to="/contact">
                Contact Gregg
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>

            <Button
              size="lg"
              variant="outline"
              asChild
              className="h-12 px-8 text-base font-semibold rounded-md bg-transparent text-white border-white/30 hover:bg-white/10 hover:border-white/50"
            >
              <a href="#services-list">View All Services</a>
            </Button>
          </motion.div>

          {/* FREE GBP AUDIT badge */}
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.52 }}
            className="mt-6"
          >
            <Badge
              variant="outline"
              className="border-[hsl(119_35%_61%)]/60 text-[hsl(119_35%_61%)] bg-[hsl(119_35%_61%)]/10 text-xs font-semibold tracking-wider uppercase px-3 py-1 rounded-md"
            >
              FREE GBP AUDIT
            </Badge>
            <span className="ml-3 text-xs text-white/60">
              Included with all initial enquiries
            </span>
          </motion.div>
        </div>
      </div>
    </section>
  );
});

ServicesHero.displayName = "ServicesHero";

export default ServicesHero;
