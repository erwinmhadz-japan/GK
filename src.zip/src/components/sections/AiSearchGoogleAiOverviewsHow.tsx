import React from "react";
import { Brain, Layers, ShieldCheck, FileText, Network, Eye, Key, Search } from "lucide-react";

const steps = [
  {
    number: "01",
    icon: Brain,
    title: "Query Interpretation",
    body:
      "Google's Gemini model analyses the search intent behind a query — distinguishing informational, navigational, and transactional intent — to decide whether an AI Overview is appropriate and what type of answer to generate.",
  },
  {
    number: "02",
    icon: Network,
    title: "Source Retrieval & Ranking",
    body:
      "Google retrieves candidate sources from its index using standard ranking signals — including PageRank, relevance, and freshness. Only pages that already perform well in organic search are considered for AI Overview citation.",
  },
  {
    number: "03",
    icon: ShieldCheck,
    title: "Quality & Trust Filtering",
    body:
      "The model filters candidates by applying EEAT signals: it prefers pages from recognised authors, established domains, and sources with clear on-page credentials. Thin, unattributed, or low-trust content is excluded.",
  },
  {
    number: "04",
    icon: FileText,
    title: "Answer Synthesis",
    body:
      "Gemini synthesises a multi-paragraph answer by drawing on the highest-quality sources, then attributes each factual claim back to a cited URL. Pages with structured, clearly labelled information are easier to parse and cite.",
  },
  {
    number: "05",
    icon: Layers,
    title: "Display & Formatting",
    body:
      "The AI Overview is displayed in a collapsible panel above standard results. It includes cited links, expandable sections, and — where applicable — supporting images or rich snippet data pulled from structured markup.",
  },
  {
    number: "06",
    icon: Eye,
    title: "Continuous Refinement",
    body:
      "Google continuously evaluates AI Overview quality through Quality Raters who apply the Search Quality Evaluator Guidelines. This feedback loop means ongoing EEAT investment directly influences citation frequency over time.",
  },
];

const AiSearchGoogleAiOverviewsHow = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            How It Works
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">
            How Google Generates & Displays AI Overviews
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Understanding the six-stage process Google uses to build AI Overviews is
            the first step to ensuring your content is in the running for citation.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {steps.map((step) => (
            <div
              key={step.number}
              className="relative rounded-xl border border-border bg-background p-8 shadow-soft hover-lift"
            >
              <div className="flex items-start gap-4 mb-4">
                <span className="text-4xl font-bold text-primary/20 leading-none font-sora select-none">
                  {step.number}
                </span>
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 shrink-0 mt-0.5">
                  <step.icon className="h-5 w-5 text-primary" />
                </div>
              </div>
              <h3 className="text-lg font-bold text-foreground mb-3">{step.title}</h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{step.body}</p>
            </div>
          ))}
        </div>

        <div className="mt-14 rounded-xl border border-border bg-background p-8 max-w-3xl mx-auto text-center shadow-soft">
          <p className="text-foreground font-semibold text-lg mb-2">
            Key Takeaway
          </p>
          <p className="text-muted-foreground leading-relaxed">
            Google AI Overviews are not a separate index — they draw from the same
            content Google already ranks. If your pages aren't performing in organic
            search, they won't appear in AI Overviews either. Strong{" "}
            <a href="/technical-seo" className="text-primary underline hover:no-underline">
              technical SEO foundations
            </a>{" "}
            and authoritative content are non-negotiable prerequisites.
          </p>
        </div>
      </div>
    </section>
  );
});

AiSearchGoogleAiOverviewsHow.displayName = "AiSearchGoogleAiOverviewsHow";

export default AiSearchGoogleAiOverviewsHow;
