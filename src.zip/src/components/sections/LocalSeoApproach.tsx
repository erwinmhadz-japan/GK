import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { FileSearch, Target, Compass, UserCheck, Landmark, Stethoscope, Home, ChevronRight, CheckCircle, Cross, Map as MapIcon, Search, Section } from "lucide-react";

const approach = [
  {
    step: "01",
    icon: FileSearch,
    title: "Diagnostic before strategy",
    body: "Every engagement begins with a thorough audit of your existing local presence — Google Business Profile health, local citation consistency, on-page signals, and competitive landscape. Understanding the baseline is non-negotiable.",
  },
  {
    step: "02",
    icon: Compass,
    title: "Strategy before tactics",
    body: "Rather than defaulting to a standard checklist, the approach is tailored to your sector, location, and competitive context. Local SEO for a Warrington law firm and a Manchester private clinic are fundamentally different problems.",
  },
  {
    step: "03",
    icon: Target,
    title: "Entity signals and local trust",
    body: "Modern local search is built on entity recognition. Gregg ensures your business is consistently represented across directories, schema markup, and Google's knowledge graph — so it reads as an authoritative, trustworthy entity in your area.",
  },
  {
    step: "04",
    icon: UserCheck,
    title: "Independent counsel, not managed volume",
    body: "As an independent consultant, Gregg works directly with you — not a junior account manager following a template. Every recommendation is informed by diagnostic data and delivered with honest commercial reasoning.",
  },
];

const sectors = [
  {
    icon: Landmark,
    label: "Law firms & solicitors",
    note: "High-trust search environments where local Pack visibility drives qualified enquiries.",
    link: "#law-firms-cta",
  },
  {
    icon: Stethoscope,
    label: "Healthcare & private clinics",
    note: "Patients search locally. A visible, credible GBP and accurate NAP data are essential.",
    link: "#healthcare-cta",
  },
  {
    icon: Home,
    label: "Estate agents & property services",
    note: "Intensely local and competitive. Map Pack and geo-targeted content deliver measurable results.",
    link: "#estate-agents-cta",
  },
];

const crossLinks = [
  {
    href: "/seo-audit",
    label: "SEO Audit",
    description: "Start with a structured audit of your local presence before committing to a strategy.",
  },
  {
    href: "#industries-cta",
    label: "Industry Expertise",
    description: "Sector-specific local SEO strategy for law, healthcare, property, and finance.",
  },
  {
    href: "/services",
    label: "All SEO Services",
    description: "Explore the full range of SEO consulting services available — from technical SEO to digital PR.",
  },
  {
    href: "/locations",
    label: "Locations Served",
    description: "Independent SEO consultant serving Warrington, Manchester, Liverpool, Leeds, Sheffield, Birmingham, and London.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
    },
  },
};

const fadeUp = {
  hidden: { opacity: 0, y: 22 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.55, ease: "easeOut" } },
};

const LocalSeoApproach = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="local-seo-approach"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          className="max-w-2xl mb-14 md:mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={containerVariants}
        >
          <motion.span
            variants={fadeUp}
            className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium"
          >
            Methodology
          </motion.span>
          <motion.h2
            variants={fadeUp}
            className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground font-[Sora,sans-serif] leading-tight mb-5"
          >
            A Consultant-Led Approach to Local Search
          </motion.h2>
          <motion.p
            variants={fadeUp}
            className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-prose"
          >
            Local SEO is frequently treated as a commodity — a monthly retainer of generic tasks delivered by a rotating team of generalists. That model produces inconsistent results. Gregg King's approach is diagnostic-first and strategy-led: beginning with an honest audit of where your local visibility is falling short, then building a plan that addresses the specific signals Google relies on to rank businesses in competitive local markets.
          </motion.p>
        </motion.div>

        {/* Methodology steps */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-8 mb-16 md:mb-24"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={containerVariants}
        >
          {approach.map((item) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.step}
                variants={fadeUp}
                className="group relative rounded-md border border-border bg-background p-6 md:p-8 transition-all duration-300 hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%_/_0.10),_0_1px_4px_hsl(222_28%_11%_/_0.05)] hover:border-primary/40"
              >
                {/* Step number — decorative */}
                <span className="absolute top-6 right-6 text-xs font-semibold text-muted-foreground/40 tabular-nums tracking-widest select-none">
                  {item.step}
                </span>

                {/* Icon */}
                <div className="flex h-11 w-11 items-center justify-center rounded-md bg-primary/10 mb-5 transition-colors duration-300 group-hover:bg-primary/18">
                  <Icon className="h-5 w-5 text-primary" />
                </div>

                <h3 className="text-base md:text-lg font-semibold text-foreground mb-3 leading-snug font-[Sora,sans-serif]">
                  {item.title}
                </h3>
                <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                  {item.body}
                </p>
              </motion.div>
            );
          })}
        </motion.div>

        {/* GBP & entity signals callout */}
        <motion.div
          className="mb-16 md:mb-24"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={containerVariants}
        >
          <motion.div
            variants={fadeUp}
            className="rounded-md border border-border bg-muted/40 px-6 md:px-10 py-8 md:py-10"
          >
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-start">
              <div>
                <span className="inline-block text-xs uppercase tracking-[0.16em] text-muted-foreground mb-3 font-medium">
                  Where the work starts
                </span>
                <h3 className="text-xl md:text-2xl font-bold text-foreground mb-4 font-[Sora,sans-serif] leading-snug">
                  Google Business Profile audit and local entity signals
                </h3>
                <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                  The Google Business Profile audit is the foundation of every local SEO engagement. Category selection, attribute completeness, review patterns, photo quality, and Q&amp;A hygiene all influence Map Pack eligibility. Beyond the GBP, local entity signals — consistent NAP data, structured schema markup, and local link authority — determine how confidently Google associates your business with a specific geography.
                </p>
              </div>
              <div className="space-y-3">
                {[
                  "GBP category and attribute audit",
                  "NAP consistency across directories",
                  "Local schema markup implementation",
                  "Review signal analysis and strategy",
                  "Map Pack competitor benchmarking",
                  "Geo-targeted landing page audit",
                ].map((point) => (
                  <div key={point} className="flex items-start gap-3">
                    <CheckCircle className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                    <span className="text-sm text-foreground">{point}</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        </motion.div>

        {/* Trust-led sectors */}
        <motion.div
          className="mb-14 md:mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={containerVariants}
        >
          <motion.div variants={fadeUp} className="mb-8">
            <span className="inline-block text-xs uppercase tracking-[0.16em] text-muted-foreground mb-3 font-medium">
              Trust-led sectors
            </span>
            <h3 className="text-xl md:text-2xl font-bold text-foreground font-[Sora,sans-serif] leading-snug max-w-xl">
              Local search matters most where trust is the deciding factor
            </h3>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
            {sectors.map((sector) => {
              const Icon = sector.icon;
              return (
                <motion.div
                  key={sector.label}
                  variants={fadeUp}
                  className="group rounded-md border border-border bg-background p-6 transition-all duration-300 hover:border-primary/40 hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%_/_0.10),_0_1px_4px_hsl(222_28%_11%_/_0.05)]"
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mb-4 transition-colors duration-300 group-hover:bg-primary/18">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <h4 className="text-sm font-semibold text-foreground mb-2 leading-snug font-[Sora,sans-serif]">
                    {sector.label}
                  </h4>
                  <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                    {sector.note}
                  </p>
                  <Link
                    to={sector.link}
                    className="inline-flex items-center gap-1 text-xs font-medium text-primary hover:text-primary/80 transition-colors"
                  >
                    Industry detail
                    <ChevronRight className="h-3.5 w-3.5" />
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Cross-links to audit + industries */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={containerVariants}
        >
          <motion.div
            variants={fadeUp}
            className="border-t border-border pt-10"
          >
            <p className="text-xs uppercase tracking-[0.16em] text-muted-foreground mb-6 font-medium">
              Explore further
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {crossLinks.map((cl) => (
                <Link
                  key={cl.href}
                  to={cl.href}
                  className="group flex items-start gap-4 rounded-md border border-border bg-background px-5 py-4 transition-all duration-300 hover:border-primary/40 hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%_/_0.10),_0_1px_4px_hsl(222_28%_11%_/_0.05)]"
                >
                  <div className="flex-1 min-w-0">
                    <span className="block text-sm font-semibold text-foreground mb-1 font-[Sora,sans-serif] group-hover:text-primary transition-colors">
                      {cl.label}
                    </span>
                    <span className="block text-sm text-muted-foreground leading-relaxed">
                      {cl.description}
                    </span>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground/60 group-hover:text-primary mt-0.5 shrink-0 transition-colors" />
                </Link>
              ))}
            </div>
          </motion.div>
        </motion.div>

      </div>
    </section>
  );
});

LocalSeoApproach.displayName = "LocalSeoApproach";

export default LocalSeoApproach;
