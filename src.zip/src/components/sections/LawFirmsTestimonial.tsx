import React from "react";
import { Star, Award, TrendingUp, Users } from "lucide-react";

const stats = [
  { icon: TrendingUp, value: "+312%", label: "Organic traffic growth in 8 months" },
  { icon: Users, value: "+84%", label: "Qualified enquiries from organic search" },
  { icon: Award, value: "Top 3", label: "Rankings for 28 target practice area terms" },
];

const LawFirmsTestimonial = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative isolate py-24 md:py-36"
      aria-label="Law firm SEO case study testimonial"
    >
      {/* Layer 1 — background image */}
      <img
        src="https://images.unsplash.com/photo-1582005450386-52b25f82d9bb?w=1920&h=1080&fit=crop"
        alt="Legal professionals collaborating in a modern law office environment"
        className="absolute inset-0 w-full h-full object-cover"
        loading="lazy"
        width={1920}
        height={1080}
      />
      {/* Layer 2 — brand tint overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/80 via-primary/55 to-accent/60 pointer-events-none" />

      {/* Layer 3 — content */}
      <div className="container relative z-10">
        <div className="max-w-4xl mx-auto">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-6 font-semibold">
            Client Success Story
          </span>

          <div className="flex gap-1 mb-6">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="h-5 w-5 fill-current text-white" />
            ))}
          </div>

          <blockquote className="text-2xl md:text-3xl font-bold text-white leading-snug mb-8">
            "Within six months Gregg had transformed our online presence. We
            now rank on page one for every core practice area in our city, and
            our enquiry form is busier than it's ever been. The ROI has been
            exceptional — I only wish we'd done this three years ago."
          </blockquote>

          <div className="flex items-center gap-4 mb-12">
            <img
              src="https://images.unsplash.com/photo-1681500920181-0aff411f8cab?w=400&h=400&fit=crop&crop=face"
              alt="Sarah Blackwell, Managing Partner at Blackwell Family Law"
              width={56}
              height={56}
              className="rounded-full object-cover w-14 h-14 ring-2 ring-white/30"
              loading="lazy"
            />
            <div>
              <p className="font-semibold text-white">Sarah Blackwell</p>
              <p className="text-white/80 text-sm">
                Managing Partner, Blackwell Family Law — Birmingham
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
            {stats.map((stat) => {
              const Icon = stat.icon;
              return (
                <div
                  key={stat.value}
                  className="bg-white/10 backdrop-blur-sm rounded-xl p-6 border border-white/20"
                >
                  <Icon className="h-6 w-6 text-white mb-3" />
                  <p className="text-3xl font-bold text-white mb-1">{stat.value}</p>
                  <p className="text-white/80 text-sm">{stat.label}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* SVG divider — bottom */}
      <svg
        className="absolute bottom-0 left-0 w-full h-12 md:h-16 z-10 pointer-events-none"
        viewBox="0 0 1200 80"
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <path
          d="M0,40 C300,80 900,0 1200,40 L1200,80 L0,80 Z"
          fill="hsl(var(--background))"
        />
      </svg>
    </section>
  );
});

LawFirmsTestimonial.displayName = "LawFirmsTestimonial";

export default LawFirmsTestimonial;
