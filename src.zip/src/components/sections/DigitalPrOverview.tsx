import React from "react";
import { motion } from "framer-motion";
import { Newspaper, Globe, Award, TrendingUp, CheckCircle, BadgeCheck, FileText, Sparkles, Focus, Link, Search, Section } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (delay: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut", delay },
  }),
};

const distinctions = [
  {
    icon: Newspaper,
    heading: "Editorial Coverage, Not Paid Placement",
    body: "Digital PR earns mentions and links through journalistic merit — not advertising spend. A journalist or editor chooses to reference your brand because your story, data, or expertise is genuinely worth featuring.",
  },
  {
    icon: Globe,
    heading: "Authority Signals for Search Engines",
    body: "When credible UK publications link to your domain, search engines interpret that as a trust signal. High-authority editorial backlinks remain one of the most durable and effective inputs to organic search performance.",
  },
  {
    icon: Award,
    heading: "Distinct from Traditional PR",
    body: "Traditional PR targets brand reputation and offline coverage. Digital PR is specifically oriented toward online publications, indexed content, and the backlink value those placements carry — it is an SEO discipline first.",
  },
  {
    icon: TrendingUp,
    heading: "Not a Link Scheme",
    body: "Digital PR is wholly distinct from guest-post networks, link exchanges, or paid link insertion. Google's quality guidelines reward genuine editorial links and penalise artificial ones. Proper digital PR earns the former.",
  },
];

const differentiators = [
  {
    label: "Topical relevance",
    description: "Placements in publications whose editorial focus aligns with your sector and services.",
  },
  {
    label: "Domain authority",
    description: "Prioritising well-indexed, trusted UK outlets with genuine readership — not content farms.",
  },
  {
    label: "Editorial independence",
    description: "Links appear within genuinely published articles, chosen by editors rather than purchased.",
  },
  {
    label: "Integrated strategy",
    description: "Digital PR activity is coordinated with content strategy, entity SEO, and technical foundations.",
  },
];

const DigitalPrOverview = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="digital-pr-overview"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          className="max-w-3xl mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
        >
          <motion.span
            custom={0}
            variants={fadeUp}
            className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium"
          >
            Understanding Digital PR
          </motion.span>
          <motion.h2
            custom={0.1}
            variants={fadeUp}
            className="text-3xl md:text-4xl font-bold text-foreground mb-6 leading-tight font-[Sora,sans-serif]"
          >
            What Digital PR Means in an SEO Context
          </motion.h2>
          <motion.p
            custom={0.2}
            variants={fadeUp}
            className="text-lg text-muted-foreground leading-relaxed"
          >
            Digital PR, in an SEO context, is the practice of earning authoritative editorial coverage, brand mentions, and inbound links from credible UK publications — through journalistic relevance rather than financial exchange. It is a discipline that requires both editorial judgement and a clear understanding of how search engines evaluate link authority.
          </motion.p>
        </motion.div>

        {/* Four distinction cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-20">
          {distinctions.map((item, index) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.heading}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-60px" }}
                custom={index * 0.1}
                variants={fadeUp}
                className="group relative rounded-md border border-border bg-background p-8 transition-all duration-300 hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%_/_0.10),_0_1px_4px_hsl(222_28%_11%_/_0.05)]"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mb-5">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="text-base font-semibold text-foreground mb-3 leading-snug font-[Sora,sans-serif]">
                  {item.heading}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {item.body}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Horizontal rule / divider */}
        <motion.div
          initial={{ opacity: 0, scaleX: 0 }}
          whileInView={{ opacity: 1, scaleX: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="origin-left h-px bg-border mb-20"
        />

        {/* Two-column: prose + differentiator list */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start">

          {/* Left: prose explanation */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
          >
            <motion.div
              custom={0}
              variants={fadeUp}
              className="flex items-center gap-2 mb-6"
            >
              <Sparkles className="h-4 w-4 text-primary" aria-hidden="true" />
              <span className="text-xs uppercase tracking-[0.18em] text-muted-foreground font-medium">
                How it differs from low-quality link schemes
              </span>
            </motion.div>

            <motion.h3
              custom={0.1}
              variants={fadeUp}
              className="text-xl md:text-2xl font-bold text-foreground mb-5 leading-snug font-[Sora,sans-serif]"
            >
              Earned Authority Versus Manufactured Links
            </motion.h3>

            <motion.div
              custom={0.2}
              variants={fadeUp}
              className="space-y-4 text-muted-foreground text-sm leading-relaxed"
            >
              <p>
                Much of what is marketed as "link building" involves paid guest posts, private blog networks, or link exchanges — practices that Google's quality guidelines explicitly target. These approaches may deliver short-term rankings but carry significant long-term risk, particularly for businesses in regulated sectors such as law, healthcare, or financial services.
              </p>
              <p>
                Genuine digital PR operates differently. It begins with something worth publishing: original research, a well-reasoned expert perspective, or a timely response to a media story. The editorial decision to link back to your domain is made by a journalist or commissioning editor — not purchased or arranged privately.
              </p>
              <p>
                For UK businesses in trust-led sectors, the distinction matters. A link from a national broadsheet or a respected trade publication carries credibility that a link farm cannot replicate, and it is unlikely to be devalued by a future algorithm update.
              </p>
            </motion.div>

            <motion.div
              custom={0.3}
              variants={fadeUp}
              className="mt-8 flex flex-wrap gap-2"
            >
              {["Editorial integrity", "Google-compliant", "Long-term value", "Sector credibility"].map((tag) => (
                <Badge
                  key={tag}
                  variant="secondary"
                  className="text-xs font-medium px-3 py-1"
                >
                  <CheckCircle className="h-3 w-3 mr-1.5 text-primary" />
                  {tag}
                </Badge>
              ))}
            </motion.div>
          </motion.div>

          {/* Right: differentiator checklist */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
          >
            <motion.div
              custom={0}
              variants={fadeUp}
              className="flex items-center gap-2 mb-6"
            >
              <BadgeCheck className="h-4 w-4 text-primary" aria-hidden="true" />
              <span className="text-xs uppercase tracking-[0.18em] text-muted-foreground font-medium">
                What credible digital PR prioritises
              </span>
            </motion.div>

            <motion.h3
              custom={0.1}
              variants={fadeUp}
              className="text-xl md:text-2xl font-bold text-foreground mb-6 leading-snug font-[Sora,sans-serif]"
            >
              The Criteria That Determine Link Quality
            </motion.h3>

            <div className="space-y-5">
              {differentiators.map((item, index) => (
                <motion.div
                  key={item.label}
                  custom={0.15 + index * 0.08}
                  variants={fadeUp}
                  className="flex gap-4 group"
                >
                  <div className="flex-shrink-0 mt-0.5 h-6 w-6 flex items-center justify-center rounded-sm bg-primary/10">
                    <CheckCircle className="h-3.5 w-3.5 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground mb-1">{item.label}</p>
                    <p className="text-sm text-muted-foreground leading-relaxed">{item.description}</p>
                  </div>
                </motion.div>
              ))}
            </div>

            {/* Contextual note */}
            <motion.div
              custom={0.55}
              variants={fadeUp}
              className="mt-8 rounded-md border border-border bg-muted/40 p-5"
            >
              <div className="flex gap-3">
                <FileText className="h-4 w-4 text-muted-foreground flex-shrink-0 mt-0.5" />
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Digital PR is most effective when aligned with a broader SEO strategy — including technical foundations, content authority, and entity signals. As an independent consultant, Gregg King coordinates these disciplines so that each activity reinforces the others.
                </p>
              </div>
            </motion.div>
          </motion.div>
        </div>

        {/* Bottom contextual row: UK focus */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="mt-20 rounded-md border border-border bg-background overflow-hidden"
        >
          <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-border">
            {[
              {
                icon: Globe,
                heading: "UK Publications",
                body: "Focus is placed on UK-indexed, UK-readership outlets — nationals, trade titles, and authoritative regional press relevant to your sector.",
              },
              {
                icon: FileText,
                heading: "Sector-Appropriate Coverage",
                body: "Digital PR strategy is tailored to professional service sectors — law, healthcare, finance, and property — where editorial credibility carries particular weight.",
              },
              {
                icon: TrendingUp,
                heading: "Search-Oriented Outcomes",
                body: "Every placement is evaluated for its likely contribution to domain authority, referral traffic, and organic search performance — not vanity coverage alone.",
              },
            ].map((item, index) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.heading}
                  custom={index * 0.1}
                  variants={fadeUp}
                  className="p-7"
                >
                  <div className="flex h-9 w-9 items-center justify-center rounded-sm bg-primary/10 mb-4">
                    <Icon className="h-4 w-4 text-primary" />
                  </div>
                  <h4 className="text-sm font-semibold text-foreground mb-2 font-[Sora,sans-serif]">
                    {item.heading}
                  </h4>
                  <p className="text-xs text-muted-foreground leading-relaxed">{item.body}</p>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

      </div>
    </section>
  );
});

DigitalPrOverview.displayName = "DigitalPrOverview";

export default DigitalPrOverview;
