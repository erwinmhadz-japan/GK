import React, { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Building, Globe, Layers, Zap, MapPin, FileText, BookOpen, Search, LayoutGrid, Filter, Icon } from "lucide-react";

const industryFilters = [
  { label: "All Industries", value: "all", icon: LayoutGrid },
  { label: "Legal", value: "legal", icon: Building },
  { label: "Healthcare", value: "healthcare", icon: Globe },
  { label: "Property", value: "property", icon: MapPin },
  { label: "Financial", value: "financial", icon: Layers },
  { label: "B2B", value: "b2b", icon: Zap },
];

const serviceFilters = [
  { label: "All Services", value: "all", icon: LayoutGrid },
  { label: "Local SEO", value: "local-seo", icon: MapPin },
  { label: "Technical SEO", value: "technical-seo", icon: Search },
  { label: "Content Strategy", value: "content-strategy", icon: FileText },
  { label: "AI Search", value: "ai-search", icon: Zap },
  { label: "Entity SEO", value: "entity-seo", icon: BookOpen },
];

const CaseStudiesFilter = React.forwardRef<HTMLElement>((props, ref) => {
  const [activeIndustry, setActiveIndustry] = useState("all");
  const [activeService, setActiveService] = useState("all");

  return (
    <section
      ref={ref}
      id="case-studies-filters"
      className="relative py-14 md:py-20 border-t border-border bg-muted"
      aria-label="Filter case studies by industry and service"
    >
      <div className="container">
        {/* Header */}
        <div className="text-center mb-10">
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-3">
            Browse by Category
          </span>
          <h2 className="text-2xl md:text-3xl font-bold text-foreground">
            Find the Right Case Study for Your Sector
          </h2>
          <p className="mt-3 text-muted-foreground max-w-xl mx-auto text-sm md:text-base">
            Filter by industry or service to find the most relevant results for your business.
            Internal links to{" "}
            <a href="#industries-cta" className="text-primary underline-offset-4 hover:underline">
              industries
            </a>{" "}
            and{" "}
            <a href="/services" className="text-primary underline-offset-4 hover:underline">
              services
            </a>{" "}
            pages give you deeper context.
          </p>
        </div>

        {/* Industry filters */}
        <div className="mb-6">
          <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">
            By Industry
          </p>
          <div className="flex flex-wrap gap-2">
            {industryFilters.map(({ label, value, icon: Icon }) => (
              <button
                key={value}
                onClick={() => setActiveIndustry(value)}
                aria-pressed={activeIndustry === value}
                className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium border transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary/40 ${
                  activeIndustry === value
                    ? "bg-primary text-primary-foreground border-primary shadow-green-glow"
                    : "bg-background text-muted-foreground border-border hover:border-primary/50 hover:text-foreground"
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Service filters */}
        <div>
          <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground mb-3">
            By Service
          </p>
          <div className="flex flex-wrap gap-2">
            {serviceFilters.map(({ label, value, icon: Icon }) => (
              <button
                key={value}
                onClick={() => setActiveService(value)}
                aria-pressed={activeService === value}
                className={`inline-flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-medium border transition-all duration-200 focus:outline-none focus:ring-2 focus:ring-primary/40 ${
                  activeService === value
                    ? "bg-secondary text-secondary-foreground border-secondary"
                    : "bg-background text-muted-foreground border-border hover:border-secondary/50 hover:text-foreground"
                }`}
              >
                <Icon className="h-3.5 w-3.5" />
                {label}
              </button>
            ))}
          </div>
        </div>

        {/* Active filter summary */}
        {(activeIndustry !== "all" || activeService !== "all") && (
          <div className="mt-6 flex items-center gap-3 flex-wrap">
            <span className="text-sm text-muted-foreground">Active filters:</span>
            {activeIndustry !== "all" && (
              <Badge variant="secondary" className="capitalize">
                {industryFilters.find((f) => f.value === activeIndustry)?.label}
              </Badge>
            )}
            {activeService !== "all" && (
              <Badge variant="outline" className="capitalize">
                {serviceFilters.find((f) => f.value === activeService)?.label}
              </Badge>
            )}
            <button
              onClick={() => { setActiveIndustry("all"); setActiveService("all"); }}
              className="text-xs text-primary hover:underline underline-offset-4 font-medium"
            >
              Clear all
            </button>
          </div>
        )}
      </div>
    </section>
  );
});

CaseStudiesFilter.displayName = "CaseStudiesFilter";

export default CaseStudiesFilter;
