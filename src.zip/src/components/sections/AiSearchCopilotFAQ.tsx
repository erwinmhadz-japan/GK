import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { HelpCircle, ArrowRight, Tag } from "lucide-react";

const faqs = [
  {
    question: "How does Microsoft Copilot decide which websites to cite?",
    answer:
      "Copilot draws on Microsoft's Bing index to source content. It prioritises pages that are well-crawled by Bingbot, have strong authority signals (quality backlinks, brand mentions), use structured data (Schema.org markup), and produce content that directly answers the query. Sites with poor Bing crawl coverage, thin content, or no structured data are rarely cited — regardless of their Google ranking.",
  },
  {
    question: "Does ranking well on Google guarantee Copilot visibility?",
    answer:
      "No — Google and Bing operate separate indexes with different crawling priorities and ranking signals. A site that ranks #1 on Google may have minimal Bing crawl coverage if it has never been submitted to Bing Webmaster Tools or if its technical configuration blocks Bingbot. Copilot optimisation requires a Bing-specific technical audit alongside your Google SEO work.",
  },
  {
    question: "What structured data is most important for Copilot indexing?",
    answer:
      "The most impactful schema types for Copilot visibility are: FAQPage (for question-answer extraction), Article or BlogPosting (for editorial content), Organization (for brand entity recognition), LocalBusiness (for location-based queries), and BreadcrumbList (for content hierarchy signals). Implementing these via JSON-LD is recommended and aligns with both Bing and Google guidelines.",
  },
  {
    question: "How is Copilot different from ChatGPT for business visibility?",
    answer:
      "The key difference is sourcing: Copilot primarily draws on Bing's live web index and provides inline citations with links — users can verify and click through to sources. ChatGPT in its base form uses training data from a fixed cutoff; its Browse with Bing mode adds live sourcing but is not always active. Copilot's tight integration with Microsoft 365 and Windows makes it the dominant AI tool in enterprise and professional workflows — a different and highly valuable audience from ChatGPT's consumer base.",
  },
  {
    question: "How long does it take to see Copilot citation results after optimisation?",
    answer:
      "Initial improvements to Bing crawl coverage can be observed within 4–8 weeks of submitting your sitemap to Bing Webmaster Tools and resolving crawl blocks. Structured data signals typically surface within 6–10 weeks. Measurable Copilot citation improvements for target queries generally appear within 3–6 months, depending on your current authority level, niche competitiveness, and the volume of content optimised.",
  },
  {
    question: "Do I need to opt in to have my content cited by Copilot?",
    answer:
      "No explicit opt-in is required — Copilot cites publicly indexed content from the Bing index without requiring separate consent. However, if you wish to exclude your content from Bing's index (and by extension Copilot), you can use the Bingbot robots.txt directive or the X-Robots-Tag HTTP header. Conversely, if you want to maximise inclusion, actively submitting your sitemap and verifying your site in Bing Webmaster Tools significantly improves crawl prioritisation.",
  },
];

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((faq) => ({
    "@type": "Question",
    name: faq.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: faq.answer,
    },
  })),
};

const AiSearchCopilotFAQ = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="copilot-faq"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <div className="flex justify-center mb-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
              <HelpCircle className="h-6 w-6 text-primary" />
            </div>
          </div>
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Frequently Asked Questions
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Copilot Indexing &amp; Visibility — Your Questions Answered
          </h2>
          <p className="text-muted-foreground text-base md:text-lg leading-relaxed">
            Common questions about how Microsoft Copilot sources content, what technical requirements matter, and how to improve your citation rate.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full space-y-3">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="border border-border rounded-xl px-6 bg-card shadow-soft"
              >
                <AccordionTrigger className="text-left font-semibold text-foreground py-5 hover:no-underline">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground text-sm leading-relaxed pb-5">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          <div className="mt-10 text-center">
            <p className="text-muted-foreground text-sm mb-4">
              Have a specific question about your site's Copilot visibility?
            </p>
            <a
              href="/contact"
              className="inline-flex items-center gap-2 text-sm text-primary font-semibold hover:underline underline-offset-4"
            >
              Ask us directly
              <ArrowRight className="h-4 w-4" />
            </a>
          </div>
        </div>
      </div>
    </section>
  );
});

AiSearchCopilotFAQ.displayName = "AiSearchCopilotFAQ";
export default AiSearchCopilotFAQ;
