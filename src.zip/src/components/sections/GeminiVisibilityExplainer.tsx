import React from "react";
import { motion } from "framer-motion";
import { Brain, Search, Sparkles, Layers, Globe, MessageSquare, Eye, Database, ArrowRight, Key, Section, User } from "lucide-react";
import { Link } from "react-router-dom";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (delay: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay },
  }),
};

const compareRows = [
  {
    aspect: "How results are generated",
    traditional: "Ranked list of 10 blue links drawn from the web index",
    gemini: "A synthesised AI-generated response that draws on multiple sources simultaneously",
  },
  {
    aspect: "User experience",
    traditional: "User clicks through to individual pages to find information",
    gemini: "User reads a directly composed answer without necessarily clicking anywhere",
  },
  {
    aspect: "What determines inclusion",
    traditional: "Backlink authority, on-page keyword relevance, technical health",
    gemini: "Entity recognition, E-E-A-T signals, topical authority, structured data, citation-worthiness",
  },
  {
    aspect: "Position concept",
    traditional: "Position 1–10 on a results page; rank tracking is straightforward",
    gemini: "No numeric position — either cited/surfaced or not; visibility is qualitative",
  },
  {
    aspect: "Intent served",
    traditional: "Keyword-matching; best for navigational and transactional queries",
    gemini: "Conversational and complex queries; best for informational and multi-step questions",
  },
];

const howGeminiWorks = [
  {
    icon: Brain,
    title: "Large Language Model Foundation",
    body: "Gemini is built on Google's multimodal large language model architecture. It processes queries not as keyword strings but as natural language, understanding context, intent, and nuance in the way a knowledgeable human would.",
  },
  {
    icon: Search,
    title: "Grounding in Live Web Data",
    body: "Unlike standalone LLMs, Gemini in Google Search is 'grounded' — it retrieves and synthesises information from the live web. This means published content, structured data, and entity knowledge graphs all feed into what Gemini surfaces.",
  },
  {
    icon: Layers,
    title: "AI Overviews as the Entry Point",
    body: "For many queries — particularly informational and complex ones — Google now surfaces an AI Overview at the top of the results page. These are Gemini-generated responses, summarising and synthesising information before the user ever scrolls to blue links.",
  },
  {
    icon: Database,
    title: "The Knowledge Graph Connection",
    body: "Google's Knowledge Graph plays a central role. Entities — businesses, people, organisations, products — that are well-represented in the Knowledge Graph are more readily cited by Gemini. Entity SEO is therefore directly relevant to Gemini visibility.",
  },
  {
    icon: MessageSquare,
    title: "Conversational and Follow-Up Queries",
    body: "Gemini supports multi-turn conversations within Search. A user can ask a follow-up question, and Gemini maintains context. Brands cited in the initial response are more likely to persist through the conversation.",
  },
  {
    icon: Globe,
    title: "Multimodal Understanding",
    body: "Gemini is not limited to text. It can process images, audio, and video. For businesses with rich media content, structured and labelled assets can contribute to visibility — particularly in product-led and visual sectors.",
  },
];

const keyDistinctions = [
  {
    icon: Eye,
    label: "Visibility, not ranking",
    detail:
      "In traditional SEO, success is measured by rank position. With Gemini, the question is whether your business, brand, or content is cited at all. There is no position 1 — you are either in the response or you are not.",
  },
  {
    icon: Sparkles,
    label: "Authority signals, not just keywords",
    detail:
      "Gemini does not respond to keyword optimisation in isolation. It responds to genuine topical authority, corroborated by multiple signals: entity consistency, structured data, trusted citations, and content depth.",
  },
  {
    icon: Database,
    label: "Entity-first, not page-first",
    detail:
      "Traditional SEO optimises individual pages for individual queries. Gemini optimises the entity — your business as a coherent, well-defined, consistently described presence across the web.",
  },
];

const GeminiVisibilityExplainer = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="gemini-visibility-explainer"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          className="max-w-3xl mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
          variants={fadeUp}
          custom={0}
        >
          <span className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium">
            Understanding Gemini
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground font-[Sora,sans-serif] leading-snug mb-5">
            What Is Google Gemini — and How Does It Generate Search Answers?
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl">
            Google Gemini is the large language model (LLM) that now underpins a growing proportion of Google Search. Rather than returning a ranked list of links, Gemini synthesises answers from across the web — citing sources it judges to be authoritative, relevant, and well-structured. Understanding how it works is the first step towards ensuring your business is surfaced within it.
          </p>
        </motion.div>

        {/* How Gemini works — 3×2 grid */}
        <motion.div
          className="mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.15 }}
        >
          <motion.h3
            variants={fadeUp}
            custom={0.05}
            className="text-lg md:text-xl font-semibold text-foreground mb-8 font-[Sora,sans-serif]"
          >
            How Gemini Works in Google Search
          </motion.h3>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {howGeminiWorks.map((item, i) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.title}
                  variants={fadeUp}
                  custom={0.08 + i * 0.07}
                  className="rounded-md border border-border bg-background p-6 flex flex-col gap-4 hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%_/_0.10),_0_1px_4px_hsl(222_28%_11%_/_0.05)] transition-shadow duration-300"
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 shrink-0">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-foreground mb-2 font-[Sora,sans-serif]">
                      {item.title}
                    </h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">{item.body}</p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Key distinctions — 3-column row */}
        <motion.div
          className="mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
        >
          <motion.h3
            variants={fadeUp}
            custom={0}
            className="text-lg md:text-xl font-semibold text-foreground mb-8 font-[Sora,sans-serif]"
          >
            Three Things That Make Gemini Visibility Different
          </motion.h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {keyDistinctions.map((item, i) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.label}
                  variants={fadeUp}
                  custom={0.06 + i * 0.08}
                  className="rounded-md border border-border bg-background p-6"
                >
                  <div className="flex items-center gap-3 mb-3">
                    <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/10 shrink-0">
                      <Icon className="h-4 w-4 text-primary" />
                    </div>
                    <h4 className="text-sm font-semibold text-foreground font-[Sora,sans-serif]">
                      {item.label}
                    </h4>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed">{item.detail}</p>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Comparison table */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.15 }}
          variants={fadeUp}
          custom={0.05}
          className="mb-20"
        >
          <h3 className="text-lg md:text-xl font-semibold text-foreground mb-8 font-[Sora,sans-serif]">
            Traditional Google Results vs. Gemini AI Responses
          </h3>
          <div className="rounded-md border border-border overflow-hidden">
            {/* Header row */}
            <div className="grid grid-cols-[1fr_1.5fr_1.5fr] bg-[hsl(222_42%_8%)] text-white text-xs font-semibold uppercase tracking-[0.12em]">
              <div className="px-5 py-4 border-r border-white/10">Aspect</div>
              <div className="px-5 py-4 border-r border-white/10">Traditional Organic Search</div>
              <div className="px-5 py-4">Gemini AI Response</div>
            </div>
            {/* Data rows */}
            {compareRows.map((row, i) => (
              <motion.div
                key={row.aspect}
                variants={fadeUp}
                custom={0.06 + i * 0.06}
                className={`grid grid-cols-[1fr_1.5fr_1.5fr] text-sm ${
                  i % 2 === 0 ? "bg-background" : "bg-[hsl(220_16%_97%)]"
                } border-t border-border`}
              >
                <div className="px-5 py-4 border-r border-border font-medium text-foreground">
                  {row.aspect}
                </div>
                <div className="px-5 py-4 border-r border-border text-muted-foreground leading-relaxed">
                  {row.traditional}
                </div>
                <div className="px-5 py-4 text-muted-foreground leading-relaxed">
                  {row.gemini}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Contextual paragraph + subtle link to commercial page */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
          variants={fadeUp}
          custom={0.08}
          className="max-w-3xl"
        >
          <h3 className="text-lg md:text-xl font-semibold text-foreground mb-4 font-[Sora,sans-serif]">
            Why This Matters for UK Businesses
          </h3>
          <p className="text-base text-muted-foreground leading-relaxed mb-4">
            For businesses in competitive, trust-led sectors — professional services, healthcare, legal, finance — the implications are significant. If a prospective client asks Google a complex question about your service area, and Gemini composes the answer without citing your business, that is a missed visibility opportunity. The business cited in the AI response gains implicit credibility, even if the user does not click through.
          </p>
          <p className="text-base text-muted-foreground leading-relaxed mb-6">
            Improving Gemini visibility is not a separate discipline from SEO — it builds on it. Structured data, entity consistency, topical depth, and E-E-A-T signals are all contributing factors. The difference is that optimising for Gemini requires thinking at the entity level, not just the page level.
          </p>
          <div className="flex flex-col sm:flex-row gap-4">
            <Link
              to="/ai-search-optimisation"
              className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:text-primary/80 transition-colors duration-200"
            >
              Explore AI search optimisation as a commercial service
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              to="#ai-search-cta"
              className="inline-flex items-center gap-2 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors duration-200"
            >
              Back to AI Search hub
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </motion.div>

      </div>
    </section>
  );
});

GeminiVisibilityExplainer.displayName = "GeminiVisibilityExplainer";

export default GeminiVisibilityExplainer;
