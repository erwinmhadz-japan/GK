import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Target, Layers, Network, Icon, View } from "lucide-react";

const ContentStrategyHero = React.forwardRef<HTMLElement>((props, ref) => {
  const pillars = [
    { icon: Target, label: "Topical Authority" },
    { icon: Layers, label: "Entity Coverage" },
    { icon: Network, label: "Internal Linking" },
  ];

  return (
    <section
      ref={ref}
      id="content-strategy-hero"
      className="relative py-20 md:py-32 border-t border-border bg-background overflow-hidden"
    >
      {/* Subtle dot-grid texture — purely decorative */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(var(--foreground)) 1px, transparent 1px)",
          backgroundSize: "32px 32px",
        }}
      />

      {/* Faint green accent glow — top-right corner */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-32 -right-32 h-[480px] w-[480px] rounded-full blur-3xl"
        style={{ background: "hsl(84 74% 60% / 0.07)" }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl">
          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut" }}
          >
            <Badge
              variant="outline"
              className="mb-6 text-xs uppercase tracking-widest border-border text-muted-foreground px-3 py-1"
            >
              Content Strategy Consultancy
            </Badge>
          </motion.div>

          {/* H1 */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.08 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-foreground leading-[1.1] mb-6"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Content Strategy{" "}
            <span
              className="inline-block"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              Consultant UK
            </span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.18 }}
            className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-8 max-w-2xl"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Strategic content planning that builds topical authority, earns
            rankings, and attracts the right audiences — not just traffic.
          </motion.p>

          {/* Pillars row */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.26 }}
            className="flex flex-wrap gap-3 mb-10"
          >
            {pillars.map(({ icon: Icon, label }) => (
              <div
                key={label}
                className="flex items-center gap-2 text-sm text-muted-foreground border border-border rounded-md px-3 py-1.5 bg-card"
              >
                <Icon className="h-3.5 w-3.5 text-primary" aria-hidden="true" />
                <span>{label}</span>
              </div>
            ))}
          </motion.div>

          {/* CTA row */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.34 }}
            className="flex flex-col sm:flex-row gap-4"
          >
            <Button
              size="lg"
              asChild
              className="h-12 px-8 text-base font-semibold shadow-md transition-shadow hover:shadow-lg"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                color: "hsl(225 28% 14%)",
              }}
            >
              <Link to="/contact">
                Free SEO Audit
                <ArrowRight className="ml-2 h-4 w-4" aria-hidden="true" />
              </Link>
            </Button>

            <Button
              size="lg"
              variant="outline"
              asChild
              className="h-12 px-8 text-base border-border text-foreground hover:bg-muted"
            >
              <Link to="/services">
                View All Services
              </Link>
            </Button>
          </motion.div>

          {/* Trust note */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.44 }}
            className="mt-6 text-sm text-muted-foreground"
          >
            Independent SEO consultant based in Warrington, Cheshire —
            working with UK businesses in competitive sectors.
          </motion.p>
        </div>
      </div>
    </section>
  );
});

ContentStrategyHero.displayName = "ContentStrategyHero";

export default ContentStrategyHero;
