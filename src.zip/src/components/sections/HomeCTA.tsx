import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, Mail, Phone, Contact } from "lucide-react";

const HomeCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="home-cta"
      className="relative py-20 md:py-32 border-t border-border bg-muted overflow-hidden"
      style={{ background: "hsl(225 28% 14%)" }}
    >
      {/* Subtle dot-grid texture overlay */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.06]"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(214 32% 60%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      {/* Ambient green glow — top-right */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-32 right-0 h-72 w-72 rounded-full blur-3xl opacity-20"
        style={{ background: "hsl(84 74% 58%)" }}
      />

      {/* Ambient green glow — bottom-left */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-24 -left-16 h-56 w-56 rounded-full blur-3xl opacity-15"
        style={{ background: "hsl(119 35% 61%)" }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">

          {/* Eyebrow label */}
          <motion.span
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut" }}
            className="inline-block text-xs uppercase tracking-[0.22em] font-medium mb-6"
            style={{ color: "hsl(84 74% 60%)" }}
          >
            Independent SEO Consultant · Warrington, Cheshire
          </motion.span>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.08 }}
            className="text-3xl md:text-5xl font-bold leading-tight tracking-tight text-white mb-6"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Start with a Free SEO Audit
          </motion.h2>

          {/* Sub-headline */}
          <motion.p
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.16 }}
            className="text-lg md:text-xl leading-relaxed text-white/80 mb-10 max-w-2xl mx-auto"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Independent, expert SEO consulting — no agency overhead, no account
            managers. Just Gregg.
          </motion.p>

          {/* CTA buttons */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.24 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12"
          >
            {/* Primary CTA — green gradient */}
            <Button
              asChild
              size="lg"
              className="h-12 px-8 text-sm font-semibold uppercase tracking-wider border-0 shadow-none hover:opacity-90 transition-opacity"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                color: "hsl(225 28% 14%)",
                boxShadow: "0 0 0 0 transparent",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.boxShadow =
                  "0 0 32px hsl(84 74% 58% / 0.35)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.boxShadow =
                  "0 0 0 0 transparent";
              }}
            >
              <Link to="/contact" className="flex items-center gap-2">
                FREE SEO AUDIT
                <ArrowRight className="h-4 w-4" />
              </Link>
            </Button>

            {/* Secondary CTA — outline */}
            <Button
              asChild
              size="lg"
              variant="outline"
              className="h-12 px-8 text-sm font-semibold uppercase tracking-wider bg-transparent text-white border-white/25 hover:bg-white/8 hover:border-white/50 transition-all"
            >
              <Link to="/contact" className="flex items-center gap-2">
                Contact Me
              </Link>
            </Button>
          </motion.div>

          {/* Trust footnote — contact details */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease: "easeOut", delay: 0.34 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4 sm:gap-8"
          >
            <a
              href="tel:01925214707"
              className="flex items-center gap-2 text-sm text-white/80 hover:text-white transition-colors"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              <Phone className="h-4 w-4 shrink-0" style={{ color: "hsl(84 74% 60%)" }} />
              01925 214707
            </a>
            <span aria-hidden="true" className="hidden sm:block text-white/20">·</span>
            <a
              href="mailto:gregg@greggking.co.uk"
              className="flex items-center gap-2 text-sm text-white/80 hover:text-white transition-colors"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              <Mail className="h-4 w-4 shrink-0" style={{ color: "hsl(84 74% 60%)" }} />
              gregg@greggking.co.uk
            </a>
          </motion.div>

        </div>
      </div>
    </section>
  );
});

HomeCTA.displayName = "HomeCTA";

export default HomeCTA;
