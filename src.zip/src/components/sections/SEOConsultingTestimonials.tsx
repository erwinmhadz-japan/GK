import React from "react";
import { motion } from "framer-motion";
import { Quote, Section } from "lucide-react";

const testimonials = [
  {
    quote:
      "Working with Gregg gave us a level of strategic clarity we hadn't had before. He identified precisely where our organic visibility was falling short and gave us a clear roadmap to address it. Within six months, we were ranking on page one for several competitive terms we'd long given up on.",
    name: "Jonathan Hargreaves",
    role: "Managing Director",
    company: "Hargreaves Commercial Finance",
    sector: "Financial Services",
    image:
      "https://images.unsplash.com/photo-1734830268394-6c4a1f165af1?w=400&h=400&fit=crop&crop=face",
  },
  {
    quote:
      "As a law firm in a highly competitive market, we needed an SEO consultant who genuinely understood our sector — not just organic traffic in the abstract. Gregg brought exactly that. He spoke our language, understood the compliance constraints, and delivered measurable results: a 40% increase in organic enquiries over the first year.",
    name: "Claire Whitmore",
    role: "Head of Business Development",
    company: "Whitmore &amp; Associates Solicitors",
    sector: "Legal",
    image:
      "https://images.unsplash.com/photo-1681500920181-0aff411f8cab?w=400&h=400&fit=crop&crop=face",
  },
  {
    quote:
      "We engaged Gregg on a consulting basis to review our technical SEO and content architecture before a website migration. His audit identified issues we hadn't considered and his recommendations were practical, prioritised, and delivered without any of the jargon we'd experienced from agencies. The migration went smoothly and our rankings held.",
    name: "Dr. Priya Kapoor",
    role: "Clinical Director",
    company: "Kapoor Private Clinic",
    sector: "Healthcare",
    image:
      "https://images.unsplash.com/photo-1710778044102-56a3a6b69a1b?w=400&h=400&fit=crop&crop=face",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.18,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut" },
  },
};

const SEOConsultingTestimonials = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seoconsulting-testimonials"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          className="mb-14 md:mb-18"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.65, ease: "easeOut" }}
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Client Perspectives
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground max-w-2xl leading-tight">
            What Clients Say
          </h2>
          <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-xl leading-relaxed">
            A selection of outcomes from UK businesses who have worked with me
            on SEO consulting engagements.
          </p>
        </motion.div>

        {/* Testimonials grid */}
        <motion.div
          className="grid grid-cols-1 lg:grid-cols-3 gap-6 md:gap-8"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
        >
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={index}
              variants={itemVariants}
              className="group relative flex flex-col bg-[hsl(225_28%_14%)] rounded-md border border-[hsl(225_28%_22%)] p-8 md:p-9 shadow-[0_4px_24px_rgba(0,0,0,0.18)] transition-shadow duration-300 hover:shadow-[0_8px_36px_rgba(0,0,0,0.28)]"
            >
              {/* Opening quote mark */}
              <div className="mb-6">
                <Quote
                  className="h-8 w-8"
                  style={{ color: "hsl(84 74% 60% / 0.65)" }}
                  aria-hidden="true"
                />
              </div>

              {/* Quote text */}
              <blockquote className="flex-1">
                <p className="text-sm md:text-base leading-relaxed text-white/85 italic font-light">
                  &ldquo;{testimonial.quote}&rdquo;
                </p>
              </blockquote>

              {/* Divider */}
              <div
                className="my-6 h-px w-12"
                style={{
                  background:
                    "linear-gradient(90deg, hsl(84 74% 60% / 0.55), transparent)",
                }}
                aria-hidden="true"
              />

              {/* Attribution */}
              <div className="flex items-center gap-4">
                <img
                  src={testimonial.image}
                  alt={`${testimonial.name}, ${testimonial.role} at ${testimonial.company}`}
                  width={48}
                  height={48}
                  className="h-12 w-12 rounded-full object-cover border border-[hsl(225_28%_28%)] flex-shrink-0"
                  loading="lazy"
                />
                <div className="min-w-0">
                  <p className="text-sm font-semibold text-white leading-tight">
                    {testimonial.name}
                  </p>
                  <p className="text-xs text-white/80 mt-0.5 leading-snug">
                    {testimonial.role}
                  </p>
                  <p className="text-xs text-white/60 mt-0.5 leading-snug">
                    {testimonial.company}
                  </p>
                </div>

                {/* Sector badge */}
                <div className="ml-auto flex-shrink-0">
                  <span className="inline-block text-[10px] uppercase tracking-[0.12em] text-white/50 border border-[hsl(225_28%_28%)] rounded px-2 py-1 leading-tight">
                    {testimonial.sector}
                  </span>
                </div>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Closing note */}
        <motion.p
          className="mt-12 text-center text-sm text-muted-foreground"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.65, delay: 0.4, ease: "easeOut" }}
        >
          All testimonials are from real clients. Names and organisations shared
          with permission.
        </motion.p>
      </div>
    </section>
  );
});

SEOConsultingTestimonials.displayName = "SEOConsultingTestimonials";

export default SEOConsultingTestimonials;
