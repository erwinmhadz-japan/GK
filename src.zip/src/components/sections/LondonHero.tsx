import React from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ImageBackground } from "@/components/ImageBackground";
import { MapPin, TrendingUp, Users, View } from "lucide-react";

const LondonHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="london-hero"
      aria-label="London SEO hero section"
      src="https://images.unsplash.com/photo-1573496528298-f0e9d3c7ce55?w=1920&h=1080&fit=crop"
      alt="SEO consultant working on London digital strategy"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center"
    >
      <div className="container relative z-10 py-20 md:py-32">
        <div className="max-w-3xl">
          <div className="flex items-center gap-2 mb-4">
            <MapPin className="h-4 w-4 text-primary" />
            <span className="text-white/80 text-sm uppercase tracking-[0.2em]">London, United Kingdom</span>
          </div>

          <Badge className="mb-5 bg-primary/20 text-primary border-primary/30 backdrop-blur-sm text-sm">
            London SEO Specialist
          </Badge>

          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
            London SEO Consultant<br />
            <span className="text-gradient-green">Built for the Capital's Market</span>
          </h1>

          <p className="text-lg md:text-xl text-white/90 mb-8 leading-relaxed max-w-2xl">
            London is one of the world's most competitive digital markets. With over 1 million businesses
            competing for attention across the capital's boroughs, winning in organic search requires
            a specialist who understands the scale, nuance, and pace of London SEO.
          </p>

          <div className="flex flex-wrap gap-4 mb-10">
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold" asChild>
              <a href="/contact">Get a Free London SEO Audit</a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10"
              asChild
            >
              <a href="/services">View All Services</a>
            </Button>
          </div>

          <div className="flex flex-wrap gap-6">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-primary" />
              <span className="text-white/80 text-sm">Top-3 rankings for competitive London terms</span>
            </div>
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-primary" />
              <span className="text-white/80 text-sm">Clients across all London boroughs</span>
            </div>
          </div>
        </div>
      </div>
    </ImageBackground>
  );
});

LondonHero.displayName = "LondonHero";
export default LondonHero;
