import React from "react";
import { Building2, Briefcase, TrendingUp, Users, Globe, Award, Heading, Icon } from "lucide-react";

const stats = [
  { label: "Businesses in Leeds City Region", value: "120,000+" },
  { label: "UK city for venture capital investment", value: "3rd" },
  { label: "Digital & tech sector jobs", value: "45,000+" },
  { label: "Monthly Google searches for Leeds services", value: "2M+" },
];

const industries = [
  {
    icon: Briefcase,
    title: "Legal & Professional Services",
    description:
      "Leeds is home to one of the UK's largest concentrations of legal firms. Competition for terms like 'solicitors Leeds' is fierce — strong local SEO is essential.",
  },
  {
    icon: Building2,
    title: "Finance & FinTech",
    description:
      "With major banks and a growing FinTech scene, Leeds finance businesses compete intensely for visibility across product and service searches.",
  },
  {
    icon: TrendingUp,
    title: "E-Commerce & Retail",
    description:
      "From Victoria Gate to online-first brands, Leeds retailers need both local and national SEO strategies to stay ahead in an increasingly digital retail landscape.",
  },
  {
    icon: Users,
    title: "Healthcare & Wellbeing",
    description:
      "Private clinics, dental practices, and wellness brands in Leeds rely on local search visibility. Appearing in the map pack is non-negotiable.",
  },
  {
    icon: Globe,
    title: "Tech & SaaS",
    description:
      "Leeds's thriving tech corridor means SaaS companies and agencies face national SEO competition — requiring content authority and entity-level optimisation.",
  },
  {
    icon: Award,
    title: "Hospitality & Leisure",
    description:
      "Restaurants, hotels, and leisure venues in Leeds compete for local pack rankings across hundreds of micro-queries every day.",
  },
];

const LocationsLeedsMarket = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        {/* Heading */}
        <div className="max-w-3xl mb-12">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-3">
            Leeds Business Landscape
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground">
            Why Leeds SEO Is More Competitive Than Ever
          </h2>
          <p className="mt-4 text-lg text-muted-foreground leading-relaxed">
            Leeds has evolved from a post-industrial city into a powerhouse of
            UK commerce. That growth has made local search one of the most
            contested digital battlegrounds in the North. Understanding the
            market is the first step to winning it.
          </p>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="bg-muted rounded-xl p-6 text-center border border-border"
            >
              <p className="text-3xl md:text-4xl font-bold text-primary">
                {stat.value}
              </p>
              <p className="mt-2 text-sm text-muted-foreground leading-snug">
                {stat.label}
              </p>
            </div>
          ))}
        </div>

        {/* Industry grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {industries.map(({ icon: Icon, title, description }) => (
            <div
              key={title}
              className="group bg-card border border-border rounded-xl p-6 hover-lift transition-shadow"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-4">
                <Icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-2">
                {title}
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {description}
              </p>
            </div>
          ))}
        </div>

        <p className="mt-10 text-center text-muted-foreground text-sm">
          Explore all our location pages at{" "}
          <a
            href="/locations"
            className="text-primary underline underline-offset-4 hover:text-primary/80 transition-colors"
          >
            /locations
          </a>{" "}
          or see how{" "}
          <a
            href="/local-seo"
            className="text-primary underline underline-offset-4 hover:text-primary/80 transition-colors"
          >
            local SEO
          </a>{" "}
          works across different markets.
        </p>
      </div>
    </section>
  );
});

LocationsLeedsMarket.displayName = "LocationsLeedsMarket";
export default LocationsLeedsMarket;
