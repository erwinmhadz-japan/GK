import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, MapPin, CheckCircle, Trophy, Search, Target, View } from "lucide-react";

const reasons = [
  "Independent consultant — no agency overhead",
  "Deep Yorkshire market knowledge",
  "Transparent, results-focused reporting",
  "No long-term contracts required",
];

const LeedsCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="leeds-cta"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      {/* Background accent */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.03]"
        aria-hidden="true"
      >
        <div
          className="absolute bottom-0 left-0 w-[500px] h-[500px] rounded-full"
          style={{
            background:
              "radial-gradient(circle at center, hsl(84 74% 58%) 0%, transparent 70%)",
          }}
        />
      </div>

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          >
            <div className="flex items-center gap-2 mb-4">
              <MapPin className="h-4 w-4 text-primary flex-shrink-0" aria-hidden="true" />
              <span className="text-xs uppercase tracking-[0.2em] font-medium text-muted-foreground">
                Ready to grow in Leeds?
              </span>
            </div>

            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-[1.15] mb-5 tracking-tight">
              Let's Get Your Leeds Business{" "}
              <span className="text-gradient-green">Found First</span>
            </h2>

            <p className="text-lg text-muted-foreground leading-relaxed mb-8">
              Leeds' search landscape is competitive — but most businesses are leaving
              easy wins on the table. A focused local SEO strategy built for your
              specific Leeds market can deliver measurable growth in 90 days.
            </p>

            <ul className="space-y-3 mb-8">
              {reasons.map((reason) => (
                <li key={reason} className="flex items-start gap-3">
                  <CheckCircle className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" aria-hidden="true" />
                  <span className="text-sm text-foreground">{reason}</span>
                </li>
              ))}
            </ul>

            <div className="flex flex-wrap gap-4">
              <Button size="lg" asChild className="font-semibold">
                <Link to="/contact">
                  Start Your Leeds SEO Campaign
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <Link to="#case-studies-cta">View Case Studies</Link>
              </Button>
            </div>
          </motion.div>

          {/* Right — visual trust block */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6, delay: 0.15, ease: "easeOut" }}
            className="relative"
          >
            {/* City image */}
            <div className="relative rounded-2xl overflow-hidden mb-4 h-64">
              <img
                src="https://images.unsplash.com/photo-1685492259744-f42597aac776?w=800&h=600&fit=crop"
                alt="Leeds commercial district with modern office buildings"
                width={800}
                height={600}
                loading="lazy"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent pointer-events-none" />
              <div className="absolute bottom-4 left-4 flex items-center gap-2">
                <Trophy className="h-4 w-4 text-primary" aria-hidden="true" />
                <span className="text-white text-sm font-semibold">
                  Leeds' Competitive Search Landscape
                </span>
              </div>
            </div>

            {/* Stat cards row */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { value: "Page 1", label: "Target rankings" },
                { value: "90 days", label: "First results" },
                { value: "Yorkshire", label: "Market expertise" },
              ].map(({ value, label }) => (
                <div
                  key={label}
                  className="rounded-xl border border-border bg-card p-4 text-center shadow-soft"
                >
                  <div className="text-lg font-bold text-foreground mb-0.5">{value}</div>
                  <div className="text-xs text-muted-foreground leading-snug">{label}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
});

LeedsCTA.displayName = "LeedsCTA";

export default LeedsCTA;
