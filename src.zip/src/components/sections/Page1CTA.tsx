import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { CheckCircle, ArrowRight, Phone, Mail, Contact, Copy, View } from "lucide-react";
import { Link } from "react-router-dom";

const benefits = [
  "Free initial discovery call — no obligation",
  "Direct access to a senior SEO consultant from day one",
  "Bespoke strategy aligned to your goals and budget",
  "Clear, jargon-free reporting every month",
];

const Page1CTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="page1-cta"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      {/* Subtle radial accent */}
      <div
        className="absolute inset-0 pointer-events-none"
        aria-hidden="true"
        style={{
          backgroundImage:
            "radial-gradient(circle at 20% 60%, hsl(88 59% 56% / 0.06) 0%, transparent 50%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">

          {/* Left: Copy block */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          >
            <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-5 font-medium">
              Get Started
            </span>
            <h2
              className="text-3xl md:text-4xl lg:text-[2.6rem] font-bold text-foreground leading-tight max-w-xl mb-5"
              style={{ fontFamily: "Sora, sans-serif" }}
            >
              Ready to Grow Your{" "}
              <span
                style={{
                  backgroundImage:
                    "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
              >
                Organic Presence?
              </span>
            </h2>
            <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-lg mb-8">
              Let's start with a free discovery call to understand your SEO challenges and explore how independent consulting can make a measurable difference to your organic performance.
            </p>

            {/* Benefits list */}
            <ul className="space-y-3 mb-10">
              {benefits.map((benefit, index) => (
                <motion.li
                  key={index}
                  initial={{ opacity: 0, x: -16 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.45, ease: "easeOut", delay: 0.1 + index * 0.07 }}
                  className="flex items-start gap-3"
                >
                  <CheckCircle
                    className="h-5 w-5 mt-0.5 flex-shrink-0"
                    style={{ color: "hsl(84 74% 58%)" }}
                    aria-hidden="true"
                  />
                  <span className="text-sm md:text-base text-foreground">{benefit}</span>
                </motion.li>
              ))}
            </ul>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <Button
                size="lg"
                asChild
                className="text-base h-12 px-8 font-semibold"
                style={{
                  background: "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                  color: "hsl(222 42% 8%)",
                  border: "none",
                }}
              >
                <Link to="/contact">
                  Start a Conversation
                  <ArrowRight className="ml-2 h-4 w-4" aria-hidden="true" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                asChild
                className="text-base h-12 px-8 border-border text-foreground hover:bg-accent/10"
              >
                <Link to="/services">View All Services</Link>
              </Button>
            </div>
          </motion.div>

          {/* Right: Contact info card */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.15 }}
            className="rounded-xl border border-border bg-card shadow-card p-8 md:p-10"
          >
            {/* Avatar / consultant callout */}
            <div className="flex items-center gap-4 mb-7 pb-7 border-b border-border">
              <img
                src="https://images.unsplash.com/photo-1614023342667-6f060e9d1e04?w=400&h=400&fit=crop&crop=face"
                alt="Gregg Holloway, independent SEO consultant"
                width="400"
                height="400"
                className="h-16 w-16 rounded-full object-cover flex-shrink-0 border-2 border-border"
                loading="lazy"
              />
              <div>
                <p
                  className="text-base font-bold text-foreground"
                  style={{ fontFamily: "Sora, sans-serif" }}
                >
                  Gregg Holloway
                </p>
                <p className="text-sm text-muted-foreground">Independent SEO Consultant · Warrington, UK</p>
              </div>
            </div>

            {/* Contact options */}
            <div className="space-y-5 mb-8">
              <a
                href="mailto:hello@greggholloway.co.uk"
                className="flex items-center gap-4 group"
              >
                <div
                  className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg"
                  style={{
                    background:
                      "linear-gradient(135deg, hsl(84 74% 58% / 0.15) 0%, hsl(119 35% 61% / 0.10) 100%)",
                  }}
                >
                  <Mail
                    className="h-5 w-5"
                    style={{ color: "hsl(88 59% 56%)" }}
                    aria-hidden="true"
                  />
                </div>
                <div>
                  <p className="text-xs uppercase tracking-wider text-muted-foreground mb-0.5">Email</p>
                  <p className="text-sm font-medium text-foreground group-hover:underline underline-offset-2 transition-all">
                    hello@greggholloway.co.uk
                  </p>
                </div>
              </a>

              <a
                href="tel:+441925000000"
                className="flex items-center gap-4 group"
              >
                <div
                  className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-lg"
                  style={{
                    background:
                      "linear-gradient(135deg, hsl(84 74% 58% / 0.15) 0%, hsl(119 35% 61% / 0.10) 100%)",
                  }}
                >
                  <Phone
                    className="h-5 w-5"
                    style={{ color: "hsl(88 59% 56%)" }}
                    aria-hidden="true"
                  />
                </div>
                <div>
                  <p className="text-xs uppercase tracking-wider text-muted-foreground mb-0.5">Phone</p>
                  <p className="text-sm font-medium text-foreground group-hover:underline underline-offset-2 transition-all">
                    Available via contact form
                  </p>
                </div>
              </a>
            </div>

            {/* Trust note */}
            <p className="text-xs text-muted-foreground text-center border-t border-border pt-6">
              Response within one business day · Free discovery call included · No commitment required
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
});

Page1CTA.displayName = "Page1CTA";

export default Page1CTA;
