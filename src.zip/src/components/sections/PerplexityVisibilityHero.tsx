import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Search, Globe, Brain } from "lucide-react";

const PerplexityVisibilityHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="perplexity-visibility-hero"
      className="relative isolate border-t border-border bg-[hsl(225_28%_14%)] overflow-hidden"
      aria-label="Perplexity AI Visibility — Hero"
    >
      {/* Subtle dot-grid background texture */}
      <div
        className="absolute inset-0 pointer-events-none opacity-30"
        aria-hidden="true"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(214 32% 60% / 0.35) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      {/* Gradient fade — left accent */}
      <div
        className="absolute inset-y-0 left-0 w-1/2 pointer-events-none"
        aria-hidden="true"
        style={{
          background:
            "linear-gradient(135deg, hsl(225 28% 11% / 0.9) 0%, transparent 70%)",
        }}
      />

      {/* Green glow — top-right accent */}
      <div
        className="absolute -top-32 -right-32 w-96 h-96 rounded-full pointer-events-none"
        aria-hidden="true"
        style={{
          background:
            "radial-gradient(circle, hsl(119 35% 61% / 0.12) 0%, transparent 70%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 py-24 md:py-36 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">

          {/* ── Left column: copy ── */}
          <div>
            {/* Eyebrow */}
            <motion.div
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0 }}
              className="flex flex-wrap gap-2 mb-6"
            >
              <Badge
                variant="outline"
                className="text-xs uppercase tracking-[0.18em] border-[hsl(214_32%_60%_/_0.5)] text-[hsl(214_32%_72%)] bg-transparent px-3 py-1"
              >
                AI Search
              </Badge>
              <Badge
                variant="outline"
                className="text-xs uppercase tracking-[0.18em] border-[hsl(84_74%_60%_/_0.4)] text-[hsl(84_74%_68%)] bg-transparent px-3 py-1"
              >
                Informational Guide
              </Badge>
            </motion.div>

            {/* H1 */}
            <motion.h1
              initial={{ opacity: 0, y: 22 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, ease: "easeOut", delay: 0.1 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold leading-[1.1] tracking-tight text-white max-w-xl"
            >
              Perplexity AI{" "}
              <span
                style={{
                  backgroundImage:
                    "linear-gradient(135deg, hsl(84 74% 60%), hsl(119 35% 61%))",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
              >
                Visibility
              </span>
            </motion.h1>

            {/* Subheadline */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, ease: "easeOut", delay: 0.2 }}
              className="mt-5 text-lg md:text-xl text-white/80 leading-relaxed max-w-lg"
            >
              Get your business cited and ranked inside Perplexity's AI-generated answers.
            </motion.p>

            {/* Supporting sentence */}
            <motion.p
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.28 }}
              className="mt-3 text-base text-white/60 leading-relaxed max-w-md"
            >
              Perplexity answers questions differently to Google. I help UK businesses
              understand — and improve — how they appear in its AI-sourced results.
            </motion.p>

            {/* CTA row */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.36 }}
              className="mt-9 flex flex-wrap gap-4 items-center"
            >
              <Button
                size="lg"
                asChild
                className="h-12 px-7 text-sm font-semibold tracking-wide text-[hsl(225_28%_14%)] rounded-md"
                style={{
                  backgroundImage:
                    "linear-gradient(135deg, hsl(84 74% 60%), hsl(119 35% 61%))",
                }}
              >
                <Link to="/contact">
                  FREE SEO AUDIT
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>

              <Button
                size="lg"
                variant="outline"
                asChild
                className="h-12 px-7 text-sm font-medium border-white/25 text-white bg-transparent hover:bg-white/8 rounded-md"
              >
                <Link to="/ai-search-optimisation">
                  AI Search Services
                </Link>
              </Button>
            </motion.div>

            {/* Trust micro-line */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.7, ease: "easeOut", delay: 0.48 }}
              className="mt-5 text-xs text-white/50 tracking-wide"
            >
              Independent SEO Consultant · Warrington, Cheshire · UK
            </motion.p>
          </div>

          {/* ── Right column: informational signal cards ── */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.75, ease: "easeOut", delay: 0.2 }}
            className="hidden lg:grid grid-cols-1 gap-4"
            aria-hidden="true"
          >
            {[
              {
                icon: Brain,
                label: "How Perplexity sources answers",
                body:
                  "Perplexity indexes the open web and selects authoritative sources to cite. Understanding its selection logic is the first step to appearing in its results.",
                accent: "hsl(214 32% 60%)",
              },
              {
                icon: Search,
                label: "Why standard SEO is insufficient",
                body:
                  "Ranking in Google doesn't guarantee visibility in Perplexity. Its answer engine favours structured content, entity clarity, and citation-worthy sources.",
                accent: "hsl(84 74% 60%)",
              },
              {
                icon: Globe,
                label: "The Perplexity citation signals",
                body:
                  "Schema markup, topical authority, clean entity relationships, and authoritative backlinks all influence whether Perplexity cites your content in its answers.",
                accent: "hsl(119 35% 61%)",
              },
            ].map((card, i) => {
              const Icon = card.icon;
              return (
                <motion.div
                  key={card.label}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    duration: 0.55,
                    ease: "easeOut",
                    delay: 0.35 + i * 0.1,
                  }}
                  className="rounded-md border border-white/10 bg-white/5 backdrop-blur-sm p-5 flex gap-4 items-start"
                >
                  <div
                    className="flex-shrink-0 flex h-9 w-9 items-center justify-center rounded-md"
                    style={{ background: `${card.accent}22` }}
                  >
                    <Icon
                      className="h-5 w-5"
                      style={{ color: card.accent }}
                    />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-white mb-1">
                      {card.label}
                    </p>
                    <p className="text-xs text-white/60 leading-relaxed">
                      {card.body}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </motion.div>
        </div>

        {/* ── Bottom meta strip ── */}
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.7, ease: "easeOut", delay: 0.55 }}
          className="mt-16 pt-8 border-t border-white/10 flex flex-wrap gap-x-8 gap-y-3"
        >
          {[
            { label: "Entity recognition" },
            { label: "Schema markup signals" },
            { label: "Topical authority" },
            { label: "Citation-worthy content" },
          ].map((item) => (
            <div
              key={item.label}
              className="flex items-center gap-2 text-xs text-white/50 tracking-wide"
            >
              <span
                className="inline-block h-1.5 w-1.5 rounded-full"
                style={{
                  background:
                    "linear-gradient(135deg, hsl(84 74% 60%), hsl(119 35% 61%))",
                }}
              />
              {item.label}
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
});

PerplexityVisibilityHero.displayName = "PerplexityVisibilityHero";

export default PerplexityVisibilityHero;
