import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Star, Quote, MapPin, ArrowRight, Stars, View } from "lucide-react";

const testimonials = [
  {
    quote:
      "We were invisible in Leeds search results despite being in the city for 15 years. Within six months, we're ranking on page one for our core terms and the phone hasn't stopped.",
    name: "Sarah M.",
    role: "Owner, Leeds Financial Advisors",
    avatar: "https://images.unsplash.com/photo-1699899657680-421c2c2d5064?w=400&h=400&fit=crop&crop=face",
    location: "Leeds City Centre",
  },
  {
    quote:
      "The local SEO work transformed our visibility across the LS postcodes. We're now getting enquiries from Headingley, Roundhay, and Morley — areas we could never reach before.",
    name: "James T.",
    role: "Director, West Yorkshire Law",
    avatar: "https://images.unsplash.com/photo-1734830268394-6c4a1f165af1?w=400&h=400&fit=crop&crop=face",
    location: "Leeds LS1",
  },
  {
    quote:
      "As a Leeds-based e-commerce brand, organic search is our primary channel. The strategy implemented grew our organic revenue by 140% in twelve months — outstanding results.",
    name: "Priya K.",
    role: "Founder, Yorkshire Gifts Co.",
    avatar: "https://images.unsplash.com/photo-1710778044102-56a3a6b69a1b?w=400&h=400&fit=crop&crop=face",
    location: "Horsforth, Leeds",
  },
];

const LeedsTestimonials = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="leeds-testimonials"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      {/* Subtle background dot grid */}
      <div
        className="pointer-events-none absolute inset-0 bg-dot-grid opacity-40"
        aria-hidden="true"
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="text-center max-w-2xl mx-auto mb-14"
        >
          <div className="flex items-center justify-center gap-2 mb-4">
            <Star className="h-4 w-4 text-primary flex-shrink-0" aria-hidden="true" />
            <span className="text-xs uppercase tracking-[0.2em] font-medium text-muted-foreground">
              Leeds client success stories
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-[1.15] mb-4 tracking-tight">
            Results Delivered for{" "}
            <span className="text-gradient-green">Leeds Businesses</span>
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Real outcomes from real Leeds companies — each with unique markets,
            competitive landscapes, and growth ambitions.
          </p>
        </motion.div>

        {/* Testimonial cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {testimonials.map(({ quote, name, role, avatar, location }, i) => (
            <motion.div
              key={name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.55, delay: i * 0.1, ease: "easeOut" }}
              className="relative rounded-2xl border border-border bg-card shadow-card p-6 flex flex-col"
            >
              {/* Quote icon */}
              <Quote
                className="h-6 w-6 text-primary/30 mb-4 flex-shrink-0"
                aria-hidden="true"
              />

              {/* Stars */}
              <div className="flex gap-0.5 mb-4" aria-label="5 out of 5 stars">
                {[...Array(5)].map((_, j) => (
                  <Star
                    key={j}
                    className="h-4 w-4 text-primary fill-primary"
                    aria-hidden="true"
                  />
                ))}
              </div>

              {/* Quote text */}
              <blockquote className="text-sm text-muted-foreground leading-relaxed italic flex-1 mb-6">
                "{quote}"
              </blockquote>

              {/* Author */}
              <div className="flex items-center gap-3">
                <img
                  src={avatar}
                  alt={`${name}, ${role}`}
                  width={40}
                  height={40}
                  loading="lazy"
                  className="rounded-full h-10 w-10 object-cover flex-shrink-0"
                />
                <div>
                  <p className="text-sm font-semibold text-foreground">{name}</p>
                  <p className="text-xs text-muted-foreground">{role}</p>
                </div>
                <div className="ml-auto flex items-center gap-1 text-xs text-muted-foreground">
                  <MapPin className="h-3 w-3 flex-shrink-0" aria-hidden="true" />
                  <span>{location}</span>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA link to case studies */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5, delay: 0.3 }}
          className="text-center"
        >
          <Link
            to="#case-studies-cta"
            className="inline-flex items-center gap-2 text-primary font-semibold hover:text-primary/80 transition-colors text-sm"
          >
            View full case studies from Yorkshire clients
            <ArrowRight className="h-4 w-4" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
});

LeedsTestimonials.displayName = "LeedsTestimonials";

export default LeedsTestimonials;
