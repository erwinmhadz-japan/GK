import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Gavel, Scale, Shield, Lock } from "lucide-react";

const LawFirmsHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      src="https://images.unsplash.com/photo-1573496130141-209d200cebd8?w=1920&h=1080&fit=crop"
      alt="Two women in suits standing in a professional legal office environment"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center"
      id="law-firms-hero"
      aria-label="Law Firms & Solicitors SEO hero section"
    >
      <div className="container relative z-10 py-24 md:py-32">
        <div className="max-w-3xl">
          <Badge className="mb-6 bg-primary/20 text-white border-primary/40 hover:bg-primary/30">
            SEO for Law Firms &amp; Solicitors
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Get Found by Clients Who{" "}
            <span className="text-gradient-green">Need Legal Help Now</span>
          </h1>
          <p className="text-lg md:text-xl text-white/90 mb-8 max-w-2xl leading-relaxed">
            Specialist SEO for law firms and solicitors across the UK. We help
            you rank for high-intent legal keywords, dominate local search in
            your practice area, and build the online authority that wins client
            trust — fully compliant with SRA advertising standards.
          </p>

          <div className="flex flex-wrap gap-4 mb-10">
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold" asChild>
              <a href="/contact">Get Your Legal SEO Audit</a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10"
              asChild
            >
              <a href="#case-studies-cta">See Client Results</a>
            </Button>
          </div>

          <div className="flex flex-wrap gap-6 text-white/80 text-sm">
            <div className="flex items-center gap-2">
              <Shield className="h-4 w-4 text-primary" />
              <span>SRA-Compliant Strategies</span>
            </div>
            <div className="flex items-center gap-2">
              <Scale className="h-4 w-4 text-primary" />
              <span>Legal Sector Specialists</span>
            </div>
            <div className="flex items-center gap-2">
              <Gavel className="h-4 w-4 text-primary" />
              <span>No Long-Term Lock-Ins</span>
            </div>
          </div>
        </div>
      </div>
    </ImageBackground>
  );
});

LawFirmsHero.displayName = "LawFirmsHero";

export default LawFirmsHero;
