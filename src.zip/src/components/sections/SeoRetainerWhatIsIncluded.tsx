import React from "react";
import { motion } from "framer-motion";
import { Wrench, FileText, Link2, Brain, Code2, Eye, BarChart2, MessageCircle, Link, Search, Section } from "lucide-react";

interface RetainerItem {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
}

const retainerItems: RetainerItem[] = [
  {
    icon: Wrench,
    title: "Technical SEO Monitoring",
    description:
      "Continuous oversight of crawlability, indexation, Core Web Vitals, and site health — issues flagged and resolved before they affect rankings.",
  },
  {
    icon: FileText,
    title: "Content Strategy Reviews",
    description:
      "Monthly assessment of content performance, topical gap identification, and editorial direction aligned to your target keyword landscape.",
  },
  {
    icon: Link2,
    title: "Link Acquisition Oversight",
    description:
      "Strategic direction for digital PR and link-building activity — ensuring every acquired link adds genuine authority and editorial weight.",
  },
  {
    icon: Brain,
    title: "Entity SEO & Knowledge Graph",
    description:
      "Ongoing refinement of your brand's entity footprint — structured data, named entity association, and knowledge panel management.",
  },
  {
    icon: Code2,
    title: "Schema Markup Updates",
    description:
      "Proactive schema implementation and maintenance as your content evolves — keeping structured data accurate, valid, and competitively rich.",
  },
  {
    icon: Eye,
    title: "AI Search Visibility",
    description:
      "Monitoring and optimising your presence across AI-driven search surfaces — including Google AI Overviews, ChatGPT, and Perplexity.",
  },
  {
    icon: BarChart2,
    title: "Monthly Reporting",
    description:
      "Clear, concise reporting on organic performance, keyword movements, and strategic priorities — presented without jargon or spin.",
  },
  {
    icon: MessageCircle,
    title: "Direct Consultant Access",
    description:
      "Direct, responsive access to me throughout the month — no account managers, no ticket queues, no delay between question and answer.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.55,
      ease: "easeOut",
    },
  },
};

const headingVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.65,
      ease: "easeOut",
    },
  },
};

const SeoRetainerWhatIsIncluded = React.forwardRef<HTMLElement>(
  (props, ref) => {
    return (
      <section
        ref={ref}
        id="seo-retainer-what-is-included"
        className="relative py-20 md:py-32 border-t border-border"
        style={{
          background:
            "hsl(225 28% 14%)",
        }}
        aria-label="What is included in an SEO retainer"
      >
        {/* Subtle dot-grid texture */}
        <div
          className="pointer-events-none absolute inset-0"
          style={{
            backgroundImage:
              "radial-gradient(circle, hsl(214 32% 60% / 0.08) 1px, transparent 1px)",
            backgroundSize: "28px 28px",
          }}
          aria-hidden="true"
        />

        <div className="container max-w-6xl mx-auto px-4 relative z-10">
          {/* Section header */}
          <motion.div
            className="mb-14 md:mb-20 max-w-2xl"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={containerVariants}
          >
            <motion.span
              variants={headingVariants}
              className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] mb-4 font-medium"
              style={{ color: "hsl(119 35% 61%)" }}
            >
              What's covered
            </motion.span>

            <motion.h2
              variants={headingVariants}
              className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight max-w-xl"
              style={{ fontFamily: "Sora, sans-serif" }}
            >
              Everything included in a retained engagement
            </motion.h2>

            <motion.p
              variants={headingVariants}
              className="mt-5 text-base md:text-lg leading-relaxed"
              style={{ color: "hsl(214 32% 72%)" }}
            >
              A retainer with me is not a vague monthly agreement. Every
              engagement covers a defined scope of strategic SEO work —
              executed consistently, reported clearly, and adjusted as your
              market evolves.
            </motion.p>
          </motion.div>

          {/* Card grid */}
          <motion.div
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5 md:gap-6"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-40px" }}
            variants={containerVariants}
          >
            {retainerItems.map((item) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.title}
                  variants={itemVariants}
                  className="group relative flex flex-col rounded-md border p-6 transition-all duration-300"
                  style={{
                    background: "hsl(231 9% 16% / 0.7)",
                    borderColor: "hsl(214 32% 30% / 0.6)",
                  }}
                  onMouseEnter={(e) => {
                    (e.currentTarget as HTMLDivElement).style.borderColor =
                      "hsl(119 35% 61% / 0.5)";
                    (e.currentTarget as HTMLDivElement).style.background =
                      "hsl(231 9% 18% / 0.9)";
                  }}
                  onMouseLeave={(e) => {
                    (e.currentTarget as HTMLDivElement).style.borderColor =
                      "hsl(214 32% 30% / 0.6)";
                    (e.currentTarget as HTMLDivElement).style.background =
                      "hsl(231 9% 16% / 0.7)";
                  }}
                >
                  {/* Icon */}
                  <div
                    className="mb-4 flex h-10 w-10 items-center justify-center rounded-md transition-colors duration-300"
                    style={{
                      background: "hsl(214 32% 60% / 0.12)",
                    }}
                    aria-hidden="true"
                  >
                    <Icon
                      className="h-5 w-5 transition-colors duration-300"
                      style={{ color: "hsl(214 32% 72%)" }}
                    />
                  </div>

                  {/* Title */}
                  <h3
                    className="text-base font-semibold text-white mb-3 leading-snug"
                    style={{ fontFamily: "Sora, sans-serif" }}
                  >
                    {item.title}
                  </h3>

                  {/* Description */}
                  <p
                    className="text-sm leading-relaxed"
                    style={{ color: "hsl(214 32% 65%)" }}
                  >
                    {item.description}
                  </p>
                </motion.div>
              );
            })}
          </motion.div>

          {/* Bottom note */}
          <motion.p
            className="mt-12 text-sm text-center"
            style={{ color: "hsl(214 32% 55%)" }}
            initial={{ opacity: 0, y: 10 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.4, ease: "easeOut" }}
          >
            Scope is agreed at the outset and reviewed monthly — no padding,
            no unnecessary deliverables.
          </motion.p>
        </div>
      </section>
    );
  }
);

SeoRetainerWhatIsIncluded.displayName = "SeoRetainerWhatIsIncluded";

export default SeoRetainerWhatIsIncluded;
