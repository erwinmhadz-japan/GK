import React from "react";
import { AlertTriangle, ShieldCheck, MapPin, HeartPulse, Search, Star, Contact } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

const challenges = [
  {
    icon: ShieldCheck,
    title: "YMYL Compliance & E-E-A-T",
    description:
      "Healthcare content falls under Google's Your Money or Your Life category. Pages must demonstrate real Experience, Expertise, Authoritativeness, and Trustworthiness — or rankings suffer. We audit your content against YMYL standards and implement E-E-A-T signals that satisfy Google's quality raters.",
    tag: "YMYL",
    color: "text-red-500",
    bg: "bg-red-50",
  },
  {
    icon: MapPin,
    title: "Local Visibility for Patients",
    description:
      "When someone searches 'GP near me' or 'private physio in Manchester', your clinic needs to appear in the Local Pack. Competitive local markets mean you must optimise Google Business Profile, local citations, and proximity signals correctly — or lose patients to competitors just streets away.",
    tag: "Local SEO",
    color: "text-blue-500",
    bg: "bg-blue-50",
  },
  {
    icon: Star,
    title: "Patient Trust Signals",
    description:
      "Patients research thoroughly before booking. Without visible reviews, practitioner credentials, and professional accreditations prominently displayed and properly marked up, your site fails to convert even when it ranks. Trust signals must be structured, verifiable, and consistent.",
    tag: "Trust",
    color: "text-yellow-500",
    bg: "bg-yellow-50",
  },
  {
    icon: Search,
    title: "Competing Against NHS & Directories",
    description:
      "Private providers and independent clinics compete for visibility against NHS.uk, Healthily, Doctify, and top-10 directories that dominate broad medical queries. The strategy is precision: rank for the specific conditions, services, and locations you serve — not generic terms you can't win.",
    tag: "Competition",
    color: "text-purple-500",
    bg: "bg-purple-50",
  },
  {
    icon: HeartPulse,
    title: "Thin or Non-Expert Medical Content",
    description:
      "Generic AI-written health content is actively penalised in the medic update era. Google rewards content authored or reviewed by credentialled professionals. We build patient-education content strategies anchored to your practitioners' real expertise and qualifications.",
    tag: "Content Quality",
    color: "text-green-600",
    bg: "bg-green-50",
  },
  {
    icon: AlertTriangle,
    title: "Technical SEO & Data Sensitivity",
    description:
      "Healthcare websites handle sensitive patient data. Contact forms, booking systems, and patient portals must be technically sound — fast, secure, crawlable, and GDPR/HIPAA aware. Technical errors or slow pages cost both rankings and patient confidence equally.",
    tag: "Technical",
    color: "text-orange-500",
    bg: "bg-orange-50",
  },
];

const HealthcareChallenges: React.FC = () => {
  return (
    <section className="relative py-20 md:py-32 border-t border-border bg-muted">
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Why Healthcare SEO Is Different
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">
            The Unique SEO Challenges Facing{" "}
            <span className="text-gradient-green">Clinics & Private Providers</span>
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Healthcare is one of the most scrutinised sectors in organic search. Google applies
            heightened quality standards to medical content — and the consequences of poor SEO are
            felt in both patient volumes and reputation.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {challenges.map((item) => {
            const Icon = item.icon;
            return (
              <Card
                key={item.title}
                className="hover-lift shadow-card border-border bg-card"
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div
                      className={`flex h-11 w-11 items-center justify-center rounded-lg ${item.bg}`}
                    >
                      <Icon className={`h-5 w-5 ${item.color}`} />
                    </div>
                    <Badge variant="outline" className="text-xs shrink-0">
                      {item.tag}
                    </Badge>
                  </div>
                  <CardTitle className="text-base font-semibold text-foreground leading-snug">
                    {item.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {item.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default HealthcareChallenges;
