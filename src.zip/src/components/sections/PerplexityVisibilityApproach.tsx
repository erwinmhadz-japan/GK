import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight, FileText, Network, Tag, Link2, BookOpen, CheckCircle, Building, Key, Section } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (delay: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut", delay },
  }),
};

interface ApproachStep {
  icon: React.ElementType;
  title: string;
  body: string;
  linkText?: string;
  linkHref?: string;
}

const steps: ApproachStep[] = [
  {
    icon: Tag,
    title: "Schema Markup & Structured Data",
    body: "Perplexity's citation engine favours content that is machine-readable and semantically unambiguous. Implementing precise schema markup — including Article, FAQPage, Person, Organisation, and BreadcrumbList types — signals to AI crawlers exactly what each piece of content represents. This reduces interpretive friction and increases the likelihood of accurate citation.",
    linkText: "Schema markup services",
    linkHref: "/schema-markup",
  },
  {
    icon: Network,
    title: "Entity Clarity & Knowledge Graph Alignment",
    body: "Perplexity resolves entities before it surfaces results. If your brand, its people, its topics, and its relationships are clearly defined in the semantic web, the model is more confident in citing you. Entity SEO — establishing named entities, their attributes, and their connections — is foundational to AI search visibility, not an afterthought.",
    linkText: "Entity SEO services",
    linkHref: "/entity-seo",
  },
  {
    icon: Link2,
    title: "Authoritative Backlink Signals",
    body: "Citation models are heavily influenced by who links to you and from where. Perplexity draws on the open web's authority graph — high-quality editorial links from credible domains indicate that your content is trustworthy enough to surface. Digital PR and strategic link acquisition are part of a coherent AI visibility strategy, not separate disciplines.",
    linkText: "AI search optimisation services",
    linkHref: "/services-ai-search-optimisation",
  },
  {
    icon: FileText,
    title: "Structured Content Formats",
    body: "Perplexity retrieves and cites content that answers specific questions clearly and in a format its model can parse. Long-form, unstructured prose is harder to cite precisely. Content structured with clear headings, concise paragraphs, and logical answer blocks — particularly around questions your audience is actively asking — is far more likely to appear as a cited source.",
    linkText: "Content strategy services",
    linkHref: "/content-strategy",
  },
  {
    icon: BookOpen,
    title: "Topical Depth & Coverage",
    body: "Perplexity tends to cite sources that demonstrate comprehensive authority on a topic, not just a single article. Building out a body of interlinked, accurate content around your core subject area — covering the topic at every relevant angle — signals to the model that you are a reliable, authoritative reference rather than a one-off source.",
    linkText: "See how I approach this",
    linkHref: "/services-ai-search-optimisation",
  },
];

const signals = [
  "Structured schema across content types",
  "Named entity recognition and disambiguation",
  "Credible editorial backlink profile",
  "Question-anchored content architecture",
  "Topical depth across interlinked pages",
  "Consistent brand and author entity signals",
];

const PerplexityVisibilityApproach = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="perplexity-visibility-approach"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          className="max-w-3xl mb-14 md:mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
        >
          <motion.span
            custom={0}
            variants={fadeUp}
            className="inline-block text-xs uppercase tracking-[0.2em] font-medium text-[hsl(214_32%_60%)] mb-4"
          >
            My Approach
          </motion.span>
          <motion.h2
            custom={0.1}
            variants={fadeUp}
            className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground leading-snug max-w-2xl"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            What Actually Improves Your Perplexity Visibility
          </motion.h2>
          <motion.p
            custom={0.2}
            variants={fadeUp}
            className="mt-5 text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed"
          >
            Appearing in Perplexity's AI-generated answers requires a different set of signals than ranking in a traditional search results page. Below is how I approach it — the practical levers that genuinely move the needle on citation likelihood.
          </motion.p>
        </motion.div>

        {/* Two-column layout: steps on left, signals sidebar on right */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10 lg:gap-16 items-start">

          {/* Left column: approach steps */}
          <div className="lg:col-span-2 space-y-10 md:space-y-12">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <motion.article
                  key={step.title}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, margin: "-60px" }}
                  custom={index * 0.08}
                  variants={fadeUp}
                  className="flex gap-5 md:gap-7"
                >
                  {/* Icon column */}
                  <div className="flex-shrink-0 mt-1">
                    <div className="flex h-10 w-10 items-center justify-center rounded-md border border-border bg-muted">
                      <Icon className="h-5 w-5 text-[hsl(214_32%_60%)]" />
                    </div>
                  </div>

                  {/* Content column */}
                  <div className="min-w-0">
                    <h3
                      className="text-base md:text-lg font-semibold text-foreground mb-2"
                      style={{ fontFamily: "Sora, sans-serif" }}
                    >
                      {step.title}
                    </h3>
                    <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-3">
                      {step.body}
                    </p>
                    {step.linkText && step.linkHref && (
                      <Link
                        to={step.linkHref}
                        className="inline-flex items-center gap-1.5 text-sm font-medium text-[hsl(119_35%_61%)] hover:text-[hsl(84_74%_58%)] transition-colors duration-200"
                      >
                        {step.linkText}
                        <ArrowRight className="h-3.5 w-3.5" />
                      </Link>
                    )}
                  </div>
                </motion.article>
              );
            })}
          </div>

          {/* Right column: signal summary card */}
          <motion.aside
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            custom={0.2}
            variants={fadeUp}
            className="lg:col-span-1"
          >
            <div className="sticky top-24 rounded-md border border-border bg-muted p-6 md:p-8">
              <h3
                className="text-sm font-semibold uppercase tracking-widest text-[hsl(214_32%_60%)] mb-5"
                style={{ fontFamily: "Sora, sans-serif" }}
              >
                Key Signals
              </h3>
              <p className="text-sm text-muted-foreground mb-6 leading-relaxed">
                These are the core technical and content signals I audit and optimise when working on Perplexity visibility for a client.
              </p>
              <ul className="space-y-3">
                {signals.map((signal) => (
                  <li key={signal} className="flex items-start gap-3">
                    <CheckCircle className="h-4 w-4 text-[hsl(119_35%_61%)] mt-0.5 flex-shrink-0" />
                    <span className="text-sm text-foreground leading-relaxed">{signal}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-8 pt-6 border-t border-border">
                <p className="text-xs text-muted-foreground leading-relaxed mb-4">
                  I work with UK businesses in competitive sectors — law, finance, healthcare, and professional services — where AI search visibility is becoming an essential part of search strategy.
                </p>
                <Link
                  to="/services-ai-search-optimisation"
                  className="inline-flex items-center gap-1.5 text-sm font-medium text-[hsl(119_35%_61%)] hover:text-[hsl(84_74%_58%)] transition-colors duration-200"
                >
                  AI search optimisation services
                  <ArrowRight className="h-3.5 w-3.5" />
                </Link>
              </div>
            </div>
          </motion.aside>
        </div>

        {/* Informational note */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          custom={0.1}
          variants={fadeUp}
          className="mt-16 md:mt-20 border-t border-border pt-10"
        >
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-start">
            <div>
              <h3
                className="text-base md:text-lg font-semibold text-foreground mb-3"
                style={{ fontFamily: "Sora, sans-serif" }}
              >
                Why This Requires a Joined-Up Approach
              </h3>
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                No single tactic guarantees Perplexity citation — it is the cumulative strength of your technical foundation, content quality, entity presence, and external authority that determines whether Perplexity's model trusts your content enough to surface it. I take a holistic view across all of these dimensions rather than optimising them in isolation.
              </p>
            </div>
            <div>
              <h3
                className="text-base md:text-lg font-semibold text-foreground mb-3"
                style={{ fontFamily: "Sora, sans-serif" }}
              >
                How This Relates to Broader SEO
              </h3>
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                The signals that improve Perplexity visibility are closely aligned with those that support strong organic rankings — semantic clarity, structured data, topical authority, and credible links. Work done in this area rarely conflicts with traditional SEO objectives; it reinforces them. That said, AI search requires specific attention and deliberate optimisation alongside conventional search strategy.
              </p>
            </div>
          </div>
        </motion.div>

      </div>
    </section>
  );
});

PerplexityVisibilityApproach.displayName = "PerplexityVisibilityApproach";

export default PerplexityVisibilityApproach;
