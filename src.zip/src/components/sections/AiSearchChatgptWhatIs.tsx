import React from "react";
import { Brain, Globe, Users, TrendingUp, Icon, Search } from "lucide-react";

const stats = [
  { value: "100M+", label: "Monthly active users", icon: Users },
  { value: "GPT-4", label: "Underlying model powering search", icon: Brain },
  { value: "50%+", label: "Queries with browsing / retrieval", icon: Globe },
  { value: "3x", label: "Faster adoption than prior web tools", icon: TrendingUp },
];

const AiSearchChatgptWhatIs = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section ref={ref} className="relative py-20 md:py-32 border-t border-border bg-background">
      <div className="container">
        <div className="grid lg:grid-cols-2 gap-12 xl:gap-20 items-center">
          {/* Left — text */}
          <div>
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
              Understanding the platform
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
              What Is ChatGPT and Why Does Its Reach Matter?
            </h2>
            <div className="space-y-4 text-muted-foreground leading-relaxed">
              <p>
                ChatGPT is OpenAI&apos;s conversational AI assistant, built on large language models (LLMs) that have been trained on vast corpora of public web content, books, and structured data. It answers natural-language questions, summarises topics, and increasingly — via its Browse and retrieval features — pulls real-time information from the web.
              </p>
              <p>
                Unlike a traditional search engine that returns a list of blue links, ChatGPT synthesises an answer and may cite specific sources inline. That fundamental difference changes the visibility equation: instead of ranking on page one, businesses now need to be the source ChatGPT chooses to reference.
              </p>
              <p>
                With over 100 million monthly active users and rapid enterprise adoption, ChatGPT has become a primary research tool for buyers evaluating services and products. If your website is not structured for AI consumption, you do not exist in this channel — regardless of how well you rank on Google.
              </p>
            </div>
            <div className="mt-8">
              <a
                href="#ai-search-cta"
                className="inline-flex items-center text-primary font-semibold hover:underline text-sm"
              >
                Explore the full AI Search landscape →
              </a>
            </div>
          </div>

          {/* Right — stats grid */}
          <div className="grid grid-cols-2 gap-6">
            {stats.map(({ value, label, icon: Icon }) => (
              <div
                key={label}
                className="bg-card border border-border rounded-xl p-6 flex flex-col gap-3 shadow-card hover-lift"
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <p className="text-3xl font-bold text-foreground">{value}</p>
                <p className="text-sm text-muted-foreground leading-snug">{label}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
});

AiSearchChatgptWhatIs.displayName = "AiSearchChatgptWhatIs";
export default AiSearchChatgptWhatIs;
