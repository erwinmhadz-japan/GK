import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";

const faqs = [
  {
    question: "Do you offer SEO services specifically for Warrington businesses?",
    answer:
      "Yes. I provide hands-on SEO consulting tailored to the Warrington market. This includes local SEO optimisation for Warrington-specific search terms, competitive analysis of other Warrington businesses in your sector, and Google Business Profile management for your local presence. Whether you're based in the town centre, Birchwood, or anywhere in the WA1–WA5 postcode area, I can help.",
  },
  {
    question: "How long does local SEO take to show results in Warrington?",
    answer:
      "Most Warrington businesses see meaningful improvements in local visibility within 3–6 months, with significant ranking gains by month 6–9. Quick wins — such as Google Business Profile optimisation and local citation building — can produce measurable results within 4–8 weeks. The timeline depends on how competitive your sector is locally and the current state of your website. I'll give you a realistic forecast during our initial consultation.",
  },
  {
    question: "Can you help my Warrington business appear in AI search results like ChatGPT and Google AI Overviews?",
    answer:
      "Absolutely. AI search optimisation is one of my core specialisms. I help Warrington businesses build the authority signals, structured data, and content depth that AI models like ChatGPT, Perplexity, and Google's AI Overviews rely on when generating answers. Many local businesses are missing out on this emerging channel — getting in early gives you a significant advantage over competitors who are slow to adapt.",
  },
  {
    question: "What makes you different from an SEO agency in Warrington?",
    answer:
      "As an independent consultant rather than an agency, you work directly with me — not a junior account manager. There are no long-term contracts, no opaque retainer fees, and no inflated agency overheads passed to you. Every strategy is bespoke to your business and your Warrington market context. I also bring broader North West market knowledge, having worked with clients across Cheshire, Greater Manchester, and Merseyside.",
  },
  {
    question: "Do you work with businesses outside the Warrington town centre?",
    answer:
      "Yes. I serve businesses across the entire Warrington borough — including Birchwood, Padgate, Latchford, Stockton Heath, Appleton, and Great Sankey — as well as nearby areas like Runcorn, Widnes, Newton-le-Willows, Lymm, and Northwich. Most work is delivered remotely, but I'm happy to meet in person for initial strategy sessions or quarterly reviews.",
  },
];

const WarringtonFAQ = React.forwardRef<HTMLElement>((props, ref) => {
  const faqJsonLd = {
    "@context": "https://schema.org",
    "@type": "FAQPage",
    mainEntity: faqs.map((faq) => ({
      "@type": "Question",
      name: faq.question,
      acceptedAnswer: {
        "@type": "Answer",
        text: faq.answer,
      },
    })),
  };

  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      {/* FAQ JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />

      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          {/* Left: heading */}
          <div>
            <span className="inline-block text-xs uppercase tracking-[0.2em] text-primary font-semibold mb-3">
              FAQs
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">
              Common Questions About SEO in Warrington
            </h2>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              Everything you need to know about working with an independent SEO
              consultant for your Warrington business.
            </p>
            <div className="mt-8 space-y-3">
              <Button size="lg" className="w-full" asChild>
                <a href="/contact">Book a Free Consultation</a>
              </Button>
              <Button size="lg" variant="outline" className="w-full" asChild>
                <a href="/services">Explore All Services</a>
              </Button>
            </div>
            <div className="mt-6 space-y-2 text-sm">
              <a
                href="/local-seo"
                className="block text-primary hover:underline"
              >
                → Local SEO Services
              </a>
              <a
                href="/locations"
                className="block text-primary hover:underline"
              >
                → All UK Locations
              </a>
              <a
                href="#case-studies-cta"
                className="block text-primary hover:underline"
              >
                → Client Case Studies
              </a>
            </div>
          </div>

          {/* Right: accordion */}
          <div className="lg:col-span-2">
            <Accordion type="single" collapsible className="w-full space-y-2">
              {faqs.map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="bg-card border border-border rounded-xl px-6 data-[state=open]:shadow-card"
                >
                  <AccordionTrigger className="text-left font-semibold text-foreground py-5 hover:no-underline">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground leading-relaxed pb-5">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </div>
    </section>
  );
});

WarringtonFAQ.displayName = "WarringtonFAQ";

export default WarringtonFAQ;
