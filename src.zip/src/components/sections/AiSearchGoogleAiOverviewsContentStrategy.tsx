import React from "react";
import { BookOpen, CheckCircle, Lightbulb, Target, TrendingUp } from "lucide-react";

const strategies = [
  {
    icon: Target,
    title: "Answer-First Content Structure",
    body:
      "AI Overviews favour pages that answer the query directly and early. Place your primary answer in the first 100–150 words, then expand with supporting evidence, examples, and related context further down the page.",
  },
  {
    icon: Lightbulb,
    title: "Topical Authority & Content Clusters",
    body:
      "Google cites sources it regards as topical authorities — websites that comprehensively cover a subject area rather than publishing isolated articles. Build interconnected content hubs that signal depth and breadth of knowledge.",
  },
  {
    icon: BookOpen,
    title: "Clearly Attributed, Expert-Led Content",
    body:
      "Every piece of content should carry a named author with a visible bio, relevant qualifications, and links to their wider professional presence. Google's systems look for author-entity connections to validate expertise claims.",
  },
  {
    icon: TrendingUp,
    title: "Fresh, Maintained Content",
    body:
      "AI Overviews prefer up-to-date information. Build a regular content review cadence to update statistics, examples, and references — and include a visible 'Last reviewed' date to signal freshness to both users and Google.",
  },
];

const caseData = {
  sector: "B2B Financial Services",
  challenge:
    "A London-based financial advisory firm had strong organic rankings but zero presence in Google AI Overviews for their primary transactional keywords.",
  approach: [
    "Conducted a full EEAT gap audit across 80+ pages",
    "Added named author bios with chartered qualifications to every article",
    "Implemented Article + Person schema sitewide",
    "Rebuilt the blog into a structured topical cluster around core product areas",
    "Secured 12 digital PR citations in financial trade publications within 90 days",
  ],
  outcome:
    "Within 120 days the firm appeared in AI Overviews for 14 of their top 30 tracked keywords, including three high-intent queries with 1,000–5,000 monthly searches.",
};

const AiSearchGoogleAiOverviewsContentStrategy = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        {/* Content Strategy */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Content Strategy
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">
            Content Strategy for AI Overview Inclusion
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            The content decisions you make today determine whether Google's AI selects
            your site as a trusted source tomorrow. These four strategic principles
            underpin every successful AI Overview optimisation programme.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-20">
          {strategies.map((strategy) => (
            <div
              key={strategy.title}
              className="rounded-xl border border-border bg-card p-8 shadow-soft hover-lift"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 mb-5">
                <strategy.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-3">{strategy.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{strategy.body}</p>
            </div>
          ))}
        </div>

        {/* Case Insight */}
        <div className="rounded-2xl border border-border bg-secondary text-secondary-foreground overflow-hidden">
          <div className="grid grid-cols-1 lg:grid-cols-2">
            {/* Left — image */}
            <div className="relative min-h-[280px] lg:min-h-full">
              <img
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=800&h=600&fit=crop"
                alt="Team reviewing AI search strategy and content performance metrics"
                width="800"
                height="600"
                loading="lazy"
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-br from-primary/80 via-primary/55 to-accent/60 pointer-events-none" />
              <div className="relative z-10 p-8 flex flex-col justify-end h-full">
                <span className="text-xs uppercase tracking-[0.2em] text-white/80 mb-2">
                  Case Insight
                </span>
                <p className="text-2xl font-bold text-white leading-tight">
                  {caseData.sector}
                </p>
              </div>
            </div>

            {/* Right — details */}
            <div className="p-8 lg:p-10">
              <p className="text-sm uppercase tracking-widest text-primary mb-4">
                Challenge
              </p>
              <p className="text-secondary-foreground/90 leading-relaxed mb-6">
                {caseData.challenge}
              </p>
              <p className="text-sm uppercase tracking-widest text-primary mb-3">
                Approach
              </p>
              <ul className="space-y-2 mb-6">
                {caseData.approach.map((item) => (
                  <li key={item} className="flex items-start gap-2 text-sm text-secondary-foreground/80">
                    <CheckCircle className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                    <span>{item}</span>
                  </li>
                ))}
              </ul>
              <p className="text-sm uppercase tracking-widest text-primary mb-3">
                Outcome
              </p>
              <p className="text-secondary-foreground/90 leading-relaxed text-sm">
                {caseData.outcome}
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

AiSearchGoogleAiOverviewsContentStrategy.displayName = "AiSearchGoogleAiOverviewsContentStrategy";

export default AiSearchGoogleAiOverviewsContentStrategy;
