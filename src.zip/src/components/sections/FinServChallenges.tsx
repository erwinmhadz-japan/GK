import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ShieldCheck, AlertTriangle, Target, FileText, Icon, Scale } from "lucide-react";

const challenges = [
  {
    icon: ShieldCheck,
    title: "YMYL Compliance & E-E-A-T",
    description:
      "Financial content falls squarely in Google's Your Money or Your Life category. We build the expertise, authoritativeness, and trustworthiness signals that quality raters and algorithms demand — from author credentials to fact-checked, sourced content that satisfies regulators and search engines alike.",
    link: "/entity-seo",
    linkLabel: "Learn about Entity SEO →",
  },
  {
    icon: AlertTriangle,
    title: "Competitive Keyword Landscape",
    description:
      "Terms like 'best mortgage rates', 'financial adviser' and 'ISA comparison' are dominated by large incumbents and comparison sites. We deploy long-tail and intent-driven keyword strategies that carve out profitable niche rankings even against well-funded competitors.",
    link: "/technical-seo",
    linkLabel: "See Technical SEO →",
  },
  {
    icon: FileText,
    title: "Regulatory Content Restrictions",
    description:
      "Financial promotions must comply with FCA, SEC, or relevant authority guidelines — leaving little room for creative licence. We craft compliant copy that still converts and ranks, balancing legal disclaimers with natural language patterns that Google rewards.",
    link: "/content-strategy",
    linkLabel: "Explore Content Strategy →",
  },
  {
    icon: Target,
    title: "Trust Signals at Scale",
    description:
      "Consumers researching financial products carry high anxiety and low trust. We engineer trust through structured data, review signals, featured-snippet optimisation, and authoritative backlink profiles that make your brand the obvious, safe choice.",
    link: "/schema-markup",
    linkLabel: "See Schema Markup →",
  },
];

const FinServChallenges: React.FC = () => {
  return (
    <section className="relative py-20 md:py-32 border-t border-border bg-background">
      <div className="container">
        <div className="max-w-2xl mx-auto text-center mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-3">
            The SEO Challenge
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Why Financial Services SEO Is Different
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
            Financial websites are held to the highest editorial standards in search.
            Algorithmic updates — from Medic to Helpful Content — have repeatedly
            targeted low-authority financial sites. Here's what sets the winners apart.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {challenges.map(({ icon: Icon, title, description, link, linkLabel }) => (
            <Card
              key={title}
              className="hover-lift border border-border bg-card shadow-card"
            >
              <CardHeader className="flex flex-row items-start gap-4 pb-2">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                  <Icon className="h-6 w-6 text-primary" />
                </div>
                <CardTitle className="text-lg leading-snug text-foreground">
                  {title}
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-2 space-y-3">
                <p className="text-muted-foreground leading-relaxed">{description}</p>
                <a
                  href={link}
                  className="inline-block text-sm font-medium text-primary hover:underline"
                >
                  {linkLabel}
                </a>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FinServChallenges;
