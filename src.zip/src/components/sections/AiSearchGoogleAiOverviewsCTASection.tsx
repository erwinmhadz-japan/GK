import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { ArrowRight, MessageSquare, Book, Search, View } from "lucide-react";

const AiSearchGoogleAiOverviewsCTASection = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=1920&h=1080&fit=crop"
      alt="Team collaborating around laptops to improve AI search visibility"
      imgProps={{ loading: "lazy" }}
      className="py-24 md:py-36"
    >
      <div className="container relative z-10 text-center max-w-3xl mx-auto">
        <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-6">
          Get Started Today
        </span>
        <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 leading-tight">
          Ready to Appear in Google AI Overviews?
        </h2>
        <p className="text-lg text-white/90 leading-relaxed mb-4">
          Our AI search optimisation service covers every layer of what it takes to
          get cited — from EEAT strategy and technical SEO to structured data and
          content architecture.
        </p>
        <p className="text-sm text-white/80 mb-10">
          Independent consultancy. No lock-in contracts. Results-focused.
        </p>
        <div className="flex flex-wrap gap-4 justify-center">
          <Button
            size="lg"
            className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold px-8"
            asChild
          >
            <a href="/services-ai-search-optimisation">
              View AI Search Services
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-transparent text-white border-white hover:bg-white/10 font-semibold px-8"
            asChild
          >
            <a href="/contact">
              <MessageSquare className="mr-2 h-5 w-5" />
              Book a Free Consultation
            </a>
          </Button>
        </div>
        <div className="mt-10 flex flex-wrap justify-center gap-x-8 gap-y-3 text-sm text-white/80">
          <span>
            <a href="#ai-search-cta" className="underline hover:text-primary transition-colors">
              AI Search Overview
            </a>
          </span>
          <span>
            <a href="/entity-seo" className="underline hover:text-primary transition-colors">
              Entity SEO
            </a>
          </span>
          <span>
            <a href="/technical-seo" className="underline hover:text-primary transition-colors">
              Technical SEO
            </a>
          </span>
        </div>
      </div>
    </ImageBackground>
  );
});

AiSearchGoogleAiOverviewsCTASection.displayName = "AiSearchGoogleAiOverviewsCTASection";

export default AiSearchGoogleAiOverviewsCTASection;
