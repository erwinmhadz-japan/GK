import React from "react";
import { motion } from "framer-motion";
import { Search, Globe, Zap, Network, FileCode, Monitor, Link2, BarChart3, Scan, GitBranch, Code, File, Layout, Section, Text } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

interface Discipline {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
}

const disciplines: Discipline[] = [
  {
    icon: Search,
    title: "Crawlability & Indexation",
    description:
      "Diagnosing and resolving crawl budget waste, blocked resources, noindex misconfigurations, and orphaned content — ensuring search engines can discover and index what matters.",
  },
  {
    icon: Scan,
    title: "Site Architecture",
    description:
      "Auditing URL structures, internal link depth, and information hierarchy to ensure link equity flows efficiently and users can navigate without friction.",
  },
  {
    icon: Zap,
    title: "Core Web Vitals",
    description:
      "Measuring and improving Largest Contentful Paint, Cumulative Layout Shift, and Interaction to Next Paint — the performance signals that directly influence organic rankings.",
  },
  {
    icon: FileCode,
    title: "Structured Data Foundations",
    description:
      "Implementing and validating schema markup at a technical level — ensuring correct syntax, appropriate types, and eligibility for rich result features in Google Search.",
  },
  {
    icon: Link2,
    title: "Canonicalisation",
    description:
      "Identifying duplicate content, misconfigured canonical tags, and self-referencing issues that dilute ranking signals or create conflicting indexation signals for search engines.",
  },
  {
    icon: Globe,
    title: "Hreflang & Internationalisation",
    description:
      "Auditing hreflang implementations for accuracy and completeness — resolving incorrect language or region codes, missing return tags, and conflicting URL declarations.",
  },
  {
    icon: Monitor,
    title: "Rendering & JavaScript SEO",
    description:
      "Evaluating how search engines render client-side JavaScript — identifying content or links invisible to crawlers and advising on server-side or hybrid rendering approaches.",
  },
  {
    icon: BarChart3,
    title: "Log File Analysis",
    description:
      "Analysing server log data to understand actual crawler behaviour: which pages are crawled, at what frequency, and where crawl budget is being wasted on low-value URLs.",
  },
  {
    icon: Network,
    title: "Internal Linking Audit",
    description:
      "Reviewing anchor text distribution, link depth, and equity flow across the site — identifying pages that are under-linked, over-linked, or disconnected from the crawl path.",
  },
  {
    icon: GitBranch,
    title: "Redirect & Status Code Audit",
    description:
      "Mapping redirect chains, identifying 4xx and 5xx errors, and resolving soft 404s — ensuring clean URL hygiene that does not fragment link equity or confuse crawlers.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.07,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 22 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: "easeOut" },
  },
};

const headingVariants = {
  hidden: { opacity: 0, y: 18 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const TechnicalSeoScope = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="technical-seo-scope"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          className="mb-12 md:mb-16 max-w-2xl"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={containerVariants}
        >
          <motion.span
            variants={headingVariants}
            className="inline-block text-xs md:text-sm uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium"
          >
            Scope of work
          </motion.span>
          <motion.h2
            variants={headingVariants}
            className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground font-sora leading-snug max-w-xl"
          >
            What technical SEO covers
          </motion.h2>
          <motion.p
            variants={headingVariants}
            className="mt-4 text-base md:text-lg text-muted-foreground leading-relaxed max-w-prose"
          >
            Technical SEO is diagnostic and remediation work — not a checklist
            exercise. Each engagement is specific to the site in question, the
            platform it runs on, and the indexation problems holding back
            organic performance.
          </motion.p>
        </motion.div>

        {/* Discipline grid — exactly 10 items in 2-column layout */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-5"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={containerVariants}
        >
          {disciplines.map((discipline) => {
            const Icon = discipline.icon;
            return (
              <motion.div key={discipline.title} variants={itemVariants}>
                <Card className="border border-border bg-background hover:bg-muted/40 transition-colors duration-300 h-full group">
                  <CardContent className="p-5 md:p-6">
                    <div className="flex items-start gap-4">
                      {/* Icon container */}
                      <div
                        className="flex-shrink-0 flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 group-hover:bg-primary/15 transition-colors duration-300"
                        aria-hidden="true"
                      >
                        <Icon className="h-5 w-5 text-primary" />
                      </div>

                      {/* Text content */}
                      <div className="min-w-0">
                        <h3 className="text-sm md:text-base font-semibold text-foreground leading-snug mb-1.5 font-sora">
                          {discipline.title}
                        </h3>
                        <p className="text-sm text-muted-foreground leading-relaxed">
                          {discipline.description}
                        </p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Subtle closing note */}
        <motion.p
          className="mt-10 md:mt-12 text-sm text-muted-foreground max-w-2xl"
          initial={{ opacity: 0, y: 12 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.5, ease: "easeOut", delay: 0.15 }}
        >
          Not every engagement will encompass all of the above. The scope is
          determined by an initial audit and prioritised according to the
          issues with the greatest potential impact on organic performance.
        </motion.p>
      </div>
    </section>
  );
});

TechnicalSeoScope.displayName = "TechnicalSeoScope";

export default TechnicalSeoScope;
