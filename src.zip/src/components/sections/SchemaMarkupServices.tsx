import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";

interface SchemaType {
  name: string;
  code: string;
  description: string;
  seoValue: string;
}

const schemaTypes: SchemaType[] = [
  {
    name: "Organisation",
    code: "@type: Organization",
    description:
      "Defines your business entity — name, URL, logo, contact details, and social profiles — in a format search engines can parse and trust.",
    seoValue:
      "Strengthens entity recognition in Google's Knowledge Graph and establishes your brand as a coherent, verifiable entity.",
  },
  {
    name: "LocalBusiness",
    code: "@type: LocalBusiness",
    description:
      "Extends Organisation with location-specific signals: address, opening hours, geo-coordinates, and service area.",
    seoValue:
      "Improves visibility in local pack results and Google Maps listings — critical for businesses targeting city-level or regional search intent.",
  },
  {
    name: "Person",
    code: "@type: Person",
    description:
      "Identifies an individual — name, job title, affiliation, and areas of expertise — as a structured entity within your content.",
    seoValue:
      "Supports E-E-A-T signals by linking author identity to published content, reinforcing expertise and trustworthiness in the eyes of search algorithms.",
  },
  {
    name: "FAQPage",
    code: "@type: FAQPage",
    description:
      "Marks up a page containing frequently asked questions and their answers in a structured question-and-answer format.",
    seoValue:
      "Eligible for FAQ rich results in the SERPs — expands your listing footprint and can surface answers directly in search without a click.",
  },
  {
    name: "Article",
    code: "@type: Article",
    description:
      "Classifies editorial content — blog posts, insights, or news — with metadata for headline, author, publication date, and publisher.",
    seoValue:
      "Enables article rich results, supports Top Stories eligibility, and reinforces authorship signals that feed into topical authority.",
  },
  {
    name: "BreadcrumbList",
    code: "@type: BreadcrumbList",
    description:
      "Describes the navigational hierarchy of a page — the ordered path from homepage to the current URL.",
    seoValue:
      "Renders breadcrumb trails in SERP listings, improving click-through rates and communicating site architecture clearly to crawlers.",
  },
  {
    name: "Service",
    code: "@type: Service",
    description:
      "Defines a specific service offered — its name, description, provider, area served, and service type.",
    seoValue:
      "Helps search engines distinguish and categorise your individual services, supporting rich results and improving contextual relevance for commercial queries.",
  },
  {
    name: "Review",
    code: "@type: Review",
    description:
      "Marks up individual testimonials or client reviews, including rating, author, and the entity being reviewed.",
    seoValue:
      "Enables star ratings in search results for eligible pages — a proven driver of higher click-through rates on competitive SERPs.",
  },
  {
    name: "Product",
    code: "@type: Product",
    description:
      "Describes a product listing with price, availability, brand, and associated reviews or ratings.",
    seoValue:
      "Unlocks rich product snippets in Google Shopping and organic search — particularly valuable for e-commerce and product-led businesses.",
  },
  {
    name: "HowTo",
    code: "@type: HowTo",
    description:
      "Structures step-by-step instructional content — each step, its description, and any supporting images or tools.",
    seoValue:
      "Eligible for HowTo rich results in the SERPs, increasing content discoverability for procedural queries and voice search responses.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.07,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 22 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const headingVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.65, ease: "easeOut" } },
};

const SchemaMarkupServices = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="schema-markup-services"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          className="mb-14 md:mb-16 max-w-2xl"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={headingVariants}
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Structured Data Types
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground mb-4 max-w-xl">
            Schema types I implement
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-prose">
            Each schema type serves a distinct purpose in how search engines
            interpret and surface your content. Below are the ten structured
            data types I use most frequently, and the specific SEO value each
            one delivers.
          </p>
        </motion.div>

        {/* Schema type grid — exactly 10 items in 2-column layout */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-px border border-border rounded-md overflow-hidden"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={containerVariants}
        >
          {schemaTypes.map((schema, index) => (
            <motion.div
              key={schema.name}
              variants={itemVariants}
              className="group bg-background hover:bg-muted transition-colors duration-300 p-6 md:p-8 border-b border-r border-border last:border-b-0 relative"
            >
              {/* Index number — subtle typographic accent */}
              <span
                className="absolute top-6 right-6 text-xs font-mono text-muted-foreground/40 select-none tabular-nums"
                aria-hidden="true"
              >
                {String(index + 1).padStart(2, "0")}
              </span>

              {/* Schema name */}
              <h3 className="text-base md:text-lg font-bold text-foreground mb-1 pr-8">
                {schema.name}
              </h3>

              {/* Machine-readable type label */}
              <p
                className="text-xs font-mono text-primary mb-4 tracking-tight"
                aria-label={`Schema type identifier: ${schema.code}`}
              >
                {schema.code}
              </p>

              {/* Description */}
              <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                {schema.description}
              </p>

              {/* SEO value callout */}
              <div className="border-l-2 border-primary/40 pl-3">
                <p className="text-xs text-muted-foreground leading-relaxed">
                  <span className="font-semibold text-foreground/80 uppercase tracking-wide text-[10px] block mb-1">
                    SEO value
                  </span>
                  {schema.seoValue}
                </p>
              </div>
            </motion.div>
          ))}
        </motion.div>

        {/* Closing note — single subtle text link, no CTA block */}
        <motion.p
          className="mt-10 text-sm text-muted-foreground max-w-2xl"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3, ease: "easeOut" }}
        >
          Not all schema types are appropriate for every website. I review your
          existing markup, identify errors and gaps, and implement only the
          types that are relevant and technically valid for your site.{" "}
          <Link
            to="/contact"
            className="text-primary underline underline-offset-4 hover:text-primary/80 transition-colors"
          >
            Discuss your structured data →
          </Link>
        </motion.p>
      </div>
    </section>
  );
});

SchemaMarkupServices.displayName = "SchemaMarkupServices";

export default SchemaMarkupServices;
