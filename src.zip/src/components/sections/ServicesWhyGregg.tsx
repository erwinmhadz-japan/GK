import React from "react";
import { motion } from "framer-motion";

const differentiators = [
  {
    label: "Single Point of Contact",
    body: "You deal directly with me, start to finish. No account managers relaying messages, no junior staff executing the work. Every strategy, every recommendation, and every deliverable comes from one senior consultant who understands your business.",
  },
  {
    label: "Sector-Specific Expertise",
    body: "I work predominantly with businesses in competitive, trust-led sectors — law firms, healthcare providers, financial services, and property companies. These are markets where credibility, authority signals, and technical precision matter most.",
  },
  {
    label: "Transparent Methodology",
    body: "My approach is documented, auditable, and explained in plain language. You will always know what I am doing, why I am doing it, and what outcome we are working toward. There is no opacity, no black-box reporting.",
  },
  {
    label: "National Reach from a Cheshire Base",
    body: "Based in Warrington, Cheshire, I work with businesses across the UK — from Manchester and Liverpool to London, Birmingham, and Leeds. Independence means I am not constrained by geography or office overhead.",
  },
];

const fadeUpVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.6,
      ease: "easeOut",
      delay: i * 0.12,
    },
  }),
};

const ServicesWhyGregg = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="services-why-gregg"
      className="relative py-20 md:py-32 border-t border-border bg-background overflow-hidden"
    >
      {/* Dark band background */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "linear-gradient(180deg, hsl(225 28% 14%) 0%, hsl(231 9% 16%) 100%)",
        }}
        aria-hidden="true"
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">

        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.65, ease: "easeOut" }}
          className="mb-14 md:mb-20 max-w-3xl"
        >
          <span className="block text-xs uppercase tracking-[0.2em] text-white/60 mb-5 font-medium">
            The independent advantage
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-5">
            Why Work With an Independent Consultant?
          </h2>
          <p className="text-base md:text-lg text-white/80 leading-relaxed max-w-2xl">
            No account managers, no junior teams — just direct, expert SEO counsel from Gregg King.
          </p>
        </motion.div>

        {/* Differentiator statements */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-0 border border-white/10">
          {differentiators.map((item, index) => (
            <motion.div
              key={item.label}
              custom={index}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-40px" }}
              variants={fadeUpVariants}
              className={[
                "p-8 md:p-10 border-white/10",
                // right border on left column items (odd indices in 2-col grid)
                index % 2 === 0 ? "md:border-r" : "",
                // top border on all except the first row
                index >= 2 ? "border-t" : "",
                // top border on mobile for all except first
                index > 0 ? "border-t md:border-t-0" : "",
                index >= 2 ? "md:border-t" : "",
              ]
                .filter(Boolean)
                .join(" ")}
            >
              <p className="text-xs uppercase tracking-[0.18em] text-white/50 mb-4 font-medium">
                0{index + 1}
              </p>
              <h3 className="text-lg md:text-xl font-semibold text-white mb-4 leading-snug">
                {item.label}
              </h3>
              <p className="text-sm md:text-base text-white/75 leading-relaxed">
                {item.body}
              </p>
            </motion.div>
          ))}
        </div>

        {/* Closing statement */}
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.6, ease: "easeOut", delay: 0.2 }}
          className="mt-12 md:mt-16 text-sm md:text-base text-white/60 max-w-2xl leading-relaxed border-l-2 pl-5"
          style={{ borderColor: "hsl(84 74% 60% / 0.6)" }}
        >
          Working with an independent consultant means your project is never deprioritised in favour of a larger account. It means the person who wins your business is the person who does the work — and who is accountable for the outcome.
        </motion.p>

      </div>
    </section>
  );
});

ServicesWhyGregg.displayName = "ServicesWhyGregg";

export default ServicesWhyGregg;
