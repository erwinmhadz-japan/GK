import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Badge } from "@/components/ui/badge";
import { HelpCircle, User } from "lucide-react";

const faqs = [
  {
    question: "How does Perplexity decide which sources to cite in an answer?",
    answer:
      "Perplexity runs a live web search for every query, retrieves the most relevant and recently indexed pages, then uses its AI layer to select and excerpt sources that are factually rich, clearly structured, and from credible domains. Source authority — measured through backlink profile, E-E-A-T signals, and domain trust — is a primary selection factor. Pages that are crawlable, fresh, and factually precise are most likely to be cited.",
  },
  {
    question: "Does Perplexity index websites differently from Google?",
    answer:
      "Yes. Perplexity uses its own crawler (PerplexityBot) and maintains a live index that is updated continuously, rather than periodically. This makes freshness a stronger ranking signal than it is in Google. Additionally, Perplexity evaluates pages for their citation potential — how quotable and factually structured the content is — not just topical relevance. Structured data and clear factual statements carry more weight in Perplexity's selection than they may in traditional SEO.",
  },
  {
    question: "What type of content is most likely to appear as a Perplexity citation?",
    answer:
      "Content that performs well as Perplexity citations tends to be: recently published or updated; written by identifiable experts with a clear author bio; structured with headings, bullet lists, and defined terms; rich in discrete, quotable factual claims; and hosted on domains with strong topical authority and a healthy backlink profile. How-to guides, definitional explainers, data-backed reports, and authoritative FAQ pages are among the highest-performing formats.",
  },
  {
    question: "Can I block Perplexity from crawling my site, and should I?",
    answer:
      "Yes — you can block PerplexityBot in your robots.txt using 'User-agent: PerplexityBot / Disallow: /'. However, doing so removes your site from Perplexity's citation pool entirely. Unless you have specific legal or business reasons to exclude your content from AI-generated answers, allowing Perplexity to crawl your site is strongly recommended. Being cited in Perplexity answers drives referral traffic from high-intent users and builds AI-era brand visibility.",
  },
  {
    question: "How is optimising for Perplexity different from optimising for ChatGPT?",
    answer:
      "The key difference is the data source. Perplexity retrieves live web pages per query, so standard SEO practices — crawlability, freshness, structured data, and domain authority — transfer directly. ChatGPT relies on its training data snapshot, so optimising for it requires building long-term brand presence in authoritative sources like Wikipedia, industry publications, and widely linked web resources. A Perplexity-optimised strategy focuses on real-time indexability and citation-friendly content; a ChatGPT strategy focuses on sustained entity authority.",
  },
  {
    question: "Does structured data (schema markup) help with Perplexity visibility?",
    answer:
      "Yes, meaningfully so. Perplexity's AI layer parses schema markup to understand the type and structure of your content. Article, FAQ, HowTo, and Organization schema all signal that a page is a formal, well-structured document suitable for citation. FAQ schema in particular helps Perplexity identify discrete question-answer pairs that can be surfaced directly in its responses. Implementing structured data is one of the highest-leverage technical actions for Perplexity visibility.",
  },
  {
    question: "How long does it take to start appearing in Perplexity answers?",
    answer:
      "Because Perplexity maintains a live index, newly published or updated content can appear in citations within days to weeks — significantly faster than traditional SEO timelines. However, consistent citation requires sustained domain authority, not just a single well-written page. A structured programme of content freshness, entity building, and technical SEO typically yields measurable Perplexity visibility improvements within four to eight weeks.",
  },
];

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map(({ question, answer }) => ({
    "@type": "Question",
    name: question,
    acceptedAnswer: {
      "@type": "Answer",
      text: answer,
    },
  })),
};

const AiSearchPerplexityFAQ = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="perplexity-faq"
      className="relative py-20 md:py-32 border-t border-border bg-background"
      aria-label="Frequently asked questions about Perplexity AI visibility"
    >
      {/* FAQ JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />

      <div className="container max-w-4xl mx-auto px-4">
        {/* Header */}
        <div className="text-center mb-12">
          <Badge variant="outline" className="mb-4 text-xs uppercase tracking-widest text-muted-foreground">
            FAQs
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Perplexity Visibility — Common Questions
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Everything you need to know about how Perplexity indexes content, evaluates source authority, and selects citations for its AI-generated answers.
          </p>
        </div>

        {/* Accordion */}
        <Accordion type="single" collapsible className="w-full space-y-2">
          {faqs.map((faq, index) => (
            <AccordionItem
              key={index}
              value={`item-${index}`}
              className="rounded-xl border border-border bg-card px-6 shadow-soft"
            >
              <AccordionTrigger className="text-left font-semibold text-foreground py-5 hover:no-underline">
                <span className="flex items-start gap-3">
                  <HelpCircle className="h-4 w-4 shrink-0 text-primary mt-0.5" />
                  {faq.question}
                </span>
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground leading-relaxed pb-5">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>
      </div>
    </section>
  );
});

AiSearchPerplexityFAQ.displayName = "AiSearchPerplexityFAQ";

export default AiSearchPerplexityFAQ;
