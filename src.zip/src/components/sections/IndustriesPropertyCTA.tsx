import React from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight, Building2, ChevronRight, Search, View } from "lucide-react";

const internalLinks = [
  { label: "Local SEO for Estate Agents", href: "/local-seo" },
  { label: "Schema Markup & Structured Data", href: "/schema-markup" },
  { label: "Entity SEO", href: "/entity-seo" },
  { label: "View All Industries", href: "#industries-cta" },
];

const IndustriesPropertyCTA = React.forwardRef<HTMLElement>((props, ref) => {
  // JSON-LD: Service + LocalBusiness + RealEstateAgent
  const structuredData = [
    {
      "@context": "https://schema.org",
      "@type": "Service",
      name: "SEO for Estate Agents & Property Services",
      description:
        "Specialist SEO services for estate agents, letting agencies, and property service providers. We deliver local SEO, schema markup, entity SEO, and content strategy to increase organic visibility, vendor instructions, and buyer enquiries.",
      provider: {
        "@type": "LocalBusiness",
        name: "Gregg Blanchard SEO Consulting",
        url: "https://greggblanchard.com",
        telephone: "+44-0000-000000",
        address: {
          "@type": "PostalAddress",
          addressCountry: "GB",
        },
      },
      areaServed: {
        "@type": "Country",
        name: "United Kingdom",
      },
      serviceType: [
        "Local SEO",
        "Schema Markup",
        "Entity SEO",
        "Content Strategy",
        "Property Listing SEO",
      ],
    },
    {
      "@context": "https://schema.org",
      "@type": "LocalBusiness",
      name: "Gregg Blanchard SEO Consulting",
      description:
        "Independent SEO consultant specialising in estate agents and property services. Offering local SEO, technical SEO, schema markup, and content strategy for UK property businesses.",
      url: "https://greggblanchard.com",
      address: {
        "@type": "PostalAddress",
        addressCountry: "GB",
      },
      knowsAbout: [
        "Estate Agent SEO",
        "Property Services SEO",
        "Local Search Optimisation",
        "Real Estate Schema Markup",
        "RealEstateAgent Structured Data",
        "Google Business Profile Optimisation",
      ],
    },
    {
      "@context": "https://schema.org",
      "@type": "RealEstateAgent",
      name: "Gregg Blanchard SEO — Property SEO Specialist",
      description:
        "SEO consulting service for real estate agents and property businesses in the United Kingdom. Expert in local SEO, schema markup, entity SEO, and property listing optimisation.",
      url: "https://greggblanchard.com/industries/estate-agents-property-services",
      areaServed: {
        "@type": "Country",
        name: "United Kingdom",
      },
    },
  ];

  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      {/* JSON-LD */}
      {structuredData.map((schema, i) => (
        <script
          key={i}
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
        />
      ))}

      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left — CTA */}
          <div>
            <div className="flex h-14 w-14 items-center justify-center rounded-xl bg-primary/10 mb-6">
              <Building2 className="h-7 w-7 text-primary" />
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-5">
              Ready to Win More Instructions from Search?
            </h2>
            <p className="text-lg text-muted-foreground mb-8 leading-relaxed">
              Whether you're a single-office independent, a growing regional chain, or a
              national property brand, we'll build an SEO strategy that's specifically
              calibrated to your market, your competition, and your growth targets.
              Start with a free property SEO audit — no obligation.
            </p>

            <div className="flex flex-wrap gap-4 mb-10">
              <Button size="lg" asChild>
                <a href="/contact">
                  Get Your Free Property SEO Audit
                  <ArrowRight className="ml-2 h-5 w-5" />
                </a>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="#case-studies-cta">View Case Studies</a>
              </Button>
            </div>

            <Button size="lg" variant="ghost" asChild className="text-muted-foreground hover:text-foreground">
              <a href="/contact">Discuss your requirements →</a>
            </Button>
          </div>

          {/* Right — Internal links */}
          <div>
            <h3 className="text-lg font-semibold text-foreground mb-6">
              Explore related services &amp; pages
            </h3>
            <div className="space-y-3">
              {internalLinks.map(({ label, href }) => (
                <a
                  key={href}
                  href={href}
                  className="flex items-center justify-between p-4 rounded-lg border border-border bg-muted hover:bg-card hover:border-primary/30 hover:shadow-soft transition-all group"
                >
                  <span className="font-medium text-foreground group-hover:text-primary transition-colors">
                    {label}
                  </span>
                  <ChevronRight className="h-4 w-4 text-muted-foreground group-hover:text-primary transition-colors" />
                </a>
              ))}
            </div>

            <div className="mt-8 p-5 rounded-xl bg-primary/5 border border-primary/15">
              <p className="text-sm text-muted-foreground leading-relaxed">
                <span className="font-semibold text-foreground">Not sure where to start?</span>{" "}
                A free SEO audit identifies your biggest opportunities — from Google Business Profile
                gaps to missing schema markup and keyword cannibalisation between your listing pages.
                Takes 48 hours to produce and comes with no strings attached.
              </p>
              <Button asChild className="mt-4" size="sm">
                <a href="/contact">
                  Request Free Audit
                  <ArrowRight className="ml-1.5 h-3.5 w-3.5" />
                </a>
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

IndustriesPropertyCTA.displayName = "IndustriesPropertyCTA";
export default IndustriesPropertyCTA;
