import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Braces, CheckCircle, Key, View } from "lucide-react";

const SchemaMarkupHero = React.forwardRef<HTMLElement>((props, ref) => {
  const pillars = [
    "Rich results implementation",
    "Entity recognition",
    "Structured data audit",
  ];

  return (
    <section
      ref={ref}
      id="schema-markup-hero"
      className="relative border-t border-border bg-[hsl(225_28%_14%)] py-24 md:py-36 overflow-hidden"
    >
      {/* Subtle background texture — dot grid */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(214 32% 60%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
        aria-hidden="true"
      />

      {/* Faint green accent blur — bottom right */}
      <div
        className="pointer-events-none absolute bottom-0 right-0 h-72 w-72 rounded-full blur-3xl opacity-10"
        style={{ background: "hsl(84 74% 58%)" }}
        aria-hidden="true"
      />

      <div className="container relative z-10 max-w-6xl mx-auto px-4">
        <div className="max-w-3xl">
          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0 }}
          >
            <Badge
              variant="outline"
              className="mb-6 border-[hsl(214_32%_60%)/40] bg-[hsl(214_32%_60%)/10] text-[hsl(214_32%_75%)] text-xs uppercase tracking-[0.18em] px-3 py-1 rounded-sm"
            >
              <Braces className="h-3 w-3 mr-2 opacity-80" />
              Specialist Service
            </Badge>
          </motion.div>

          {/* H1 */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-[1.08] tracking-tight"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Schema Markup{" "}
            <span className="text-[hsl(84_74%_60%)]">Consultant</span> UK
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.2 }}
            className="mt-6 text-lg md:text-xl text-white/80 leading-relaxed max-w-2xl"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Structured data implementation that helps search engines understand
            your content — and surfaces your business in rich results.
          </motion.p>

          {/* Trust pillars */}
          <motion.ul
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.3 }}
            className="mt-8 flex flex-wrap gap-x-6 gap-y-3"
            aria-label="Key deliverables"
          >
            {pillars.map((pillar) => (
              <li
                key={pillar}
                className="flex items-center gap-2 text-sm text-white/80"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                <CheckCircle className="h-4 w-4 text-[hsl(119_35%_61%)] flex-shrink-0" />
                {pillar}
              </li>
            ))}
          </motion.ul>

          {/* CTA row */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.4 }}
            className="mt-10 flex flex-wrap items-center gap-4"
          >
            <Button
              size="lg"
              asChild
              className="h-12 px-8 text-sm font-semibold rounded-md text-[hsl(225_28%_14%)] bg-gradient-to-r from-[hsl(84_74%_60%)] to-[hsl(119_35%_61%)] hover:opacity-90 transition-opacity shadow-none border-0"
            >
              <Link to="/contact">
                Free SEO Audit
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>

            <Button
              size="lg"
              variant="outline"
              asChild
              className="h-12 px-8 text-sm font-medium rounded-md bg-transparent border-white/20 text-white hover:bg-white/8 hover:border-white/40 transition-colors"
            >
              <Link to="/services">View All Services</Link>
            </Button>
          </motion.div>

          {/* Reassurance note */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.55 }}
            className="mt-6 text-xs text-white/80 tracking-wide"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Independent UK SEO consultant · Based in Warrington, Cheshire ·
            No agency overhead
          </motion.p>
        </div>

        {/* Decorative schema snippet block */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: "easeOut", delay: 0.5 }}
          className="mt-16 md:mt-20"
          aria-hidden="true"
        >
          <div className="inline-block rounded-md border border-white/10 bg-[hsl(231_9%_16%)] px-6 py-5 font-mono text-xs leading-relaxed text-[hsl(214_32%_60%)] max-w-lg overflow-x-auto shadow-lg">
            <span className="text-white/40 select-none">{"{"}</span>
            <br />
            <span className="pl-4 text-white/40 select-none">{'"@context"'}: </span>
            <span className="text-[hsl(119_35%_61%)]">{'"https://schema.org"'}</span>
            <span className="text-white/40">,</span>
            <br />
            <span className="pl-4 text-white/40 select-none">{'"@type"'}: </span>
            <span className="text-[hsl(84_74%_60%)]">{'"LocalBusiness"'}</span>
            <span className="text-white/40">,</span>
            <br />
            <span className="pl-4 text-white/40 select-none">{'"name"'}: </span>
            <span className="text-white/70">{'"Gregg King SEO"'}</span>
            <span className="text-white/40">,</span>
            <br />
            <span className="pl-4 text-white/40 select-none">{'"areaServed"'}: </span>
            <span className="text-white/70">{'"United Kingdom"'}</span>
            <br />
            <span className="text-white/40 select-none">{"}"}</span>
          </div>
        </motion.div>
      </div>
    </section>
  );
});

SchemaMarkupHero.displayName = "SchemaMarkupHero";

export default SchemaMarkupHero;
