import React from "react";
import { Star, ArrowRight, Quote, Stars } from "lucide-react";
import { Button } from "@/components/ui/button";

const B2BTestimonial = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="b2b-testimonial"
      className="relative isolate py-24 md:py-36"
      aria-label="B2B client testimonial and case study"
    >
      {/* Background image — professional services office */}
      <img
        src="https://images.unsplash.com/photo-1556761175-4b46a572b786?w=1920&h=1080&fit=crop"
        alt="Professional business team in a meeting room"
        className="absolute inset-0 w-full h-full object-cover"
        loading="lazy"
        width="1920"
        height="1080"
      />
      {/* Brand overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/80 via-primary/55 to-accent/60 pointer-events-none" />

      {/* Content */}
      <div className="container relative z-10">
        <div className="max-w-3xl mx-auto">
          {/* Eyebrow */}
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-8 font-medium">
            Client Case Study — Management Consulting Firm
          </span>

          {/* Stars */}
          <div className="flex gap-1 mb-6">
            {[...Array(5)].map((_, i) => (
              <Star
                key={i}
                className="h-5 w-5 fill-white text-white"
                aria-hidden="true"
              />
            ))}
          </div>

          {/* Quote */}
          <blockquote className="text-2xl md:text-3xl font-bold text-white leading-snug mb-8">
            "Within nine months, our organic pipeline grew by 340%. The entity
            SEO and content strategy work meant we were being cited in AI
            search results our competitors weren't even aware of. It changed
            how senior buyers found us."
          </blockquote>

          {/* Attribution */}
          <div className="flex items-center gap-4 mb-12">
            <img
              src="https://images.unsplash.com/photo-1730851357916-3802b6405271?w=400&h=400&fit=crop&crop=face"
              alt="Senior Partner at a management consulting firm"
              width="400"
              height="400"
              className="h-14 w-14 rounded-full object-cover ring-2 ring-white/30"
            />
            <div>
              <p className="font-semibold text-white">James Whitfield</p>
              <p className="text-sm text-white/80">
                Managing Partner — B2B Strategy Consultancy, London
              </p>
            </div>
          </div>

          {/* Results bar */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-12">
            {[
              { stat: "+340%", label: "Organic Pipeline Growth" },
              { stat: "4.2×", label: "Increase in Qualified Leads" },
              { stat: "9 Months", label: "To Measurable ROI" },
            ].map((item, i) => (
              <div
                key={i}
                className="bg-white/10 backdrop-blur-sm rounded-xl p-5 border border-white/20"
              >
                <p className="text-3xl font-bold text-white mb-1">
                  {item.stat}
                </p>
                <p className="text-sm text-white/80">{item.label}</p>
              </div>
            ))}
          </div>

          {/* CTA */}
          <Button
            size="lg"
            className="bg-white text-primary hover:bg-white/90 font-semibold"
            asChild
          >
            <a href="#case-studies-cta">
              Read the Full Case Study
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
});

B2BTestimonial.displayName = "B2BTestimonial";

export default B2BTestimonial;
