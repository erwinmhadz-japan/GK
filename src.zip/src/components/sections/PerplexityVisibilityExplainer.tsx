import React from "react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Search, Layers, Brain, Database, FileText, Globe, Network, CheckCircle, Eye, TrendingUp, Section, Signal } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (delay: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut", delay },
  }),
};

const mechanicsData = [
  {
    icon: Search,
    label: "Answer Engine — Not a Search Engine",
    body: "Perplexity doesn't return a list of blue links. It generates a synthesised answer and cites the sources it drew from. That shift in model fundamentally changes what 'ranking' means — your content either gets cited or it doesn't.",
  },
  {
    icon: Database,
    label: "Citation as the New Ranking Signal",
    body: "Being cited inside a Perplexity answer is the equivalent of ranking on page one. Perplexity selects sources based on perceived authority, structured clarity, and topical relevance — not simply PageRank or keyword density.",
  },
  {
    icon: Brain,
    label: "Entity Recognition Over Keywords",
    body: "Perplexity's retrieval model leans heavily on named entities — people, organisations, products, places. Pages that establish clear, structured entity signals are far more likely to be selected as a citation source.",
  },
  {
    icon: Layers,
    label: "Structured Content Wins",
    body: "Answer engines favour content that is clearly structured — defined sections, succinct answers, logical hierarchy. Dense prose without clear signposting is consistently overlooked in favour of pages that answer questions directly.",
  },
  {
    icon: Network,
    label: "Backlink Profile Still Matters — Differently",
    body: "Perplexity's source selection appears correlated with domain authority signals, but the emphasis differs from Google's. Links from topically adjacent authoritative sources carry disproportionate weight. Generic high-DR links are less relevant.",
  },
  {
    icon: Globe,
    label: "Freshness and Source Diversity",
    body: "Perplexity's crawl prioritises recently updated, frequently referenced content. Pages that are stale, rarely cited externally, or lack internal cross-linking are poor candidates for citation — regardless of their Google ranking.",
  },
];

const vsComparisonData = [
  {
    dimension: "Primary function",
    google: "Index and rank web pages by keyword relevance",
    chatgpt: "Generate conversational responses from a fixed training corpus",
    perplexity: "Retrieve and synthesise real-time sources into cited answers",
  },
  {
    dimension: "Source selection",
    google: "PageRank, on-page signals, link graph",
    chatgpt: "Pre-trained knowledge — no live retrieval by default",
    perplexity: "Live web retrieval + source authority + structured clarity",
  },
  {
    dimension: "Ranking signal",
    google: "Keyword match + authority + UX signals",
    chatgpt: "Training data frequency and recency",
    perplexity: "Entity clarity + content structure + topical authority",
  },
  {
    dimension: "SEO implication",
    google: "On-page optimisation + link acquisition",
    chatgpt: "Brand mentions in crawled training data",
    perplexity: "Schema, entity SEO, structured content, authoritative citations",
  },
];

const whyStandardSEOFallsShort = [
  {
    icon: FileText,
    point: "Keyword density is irrelevant",
    explanation:
      "Perplexity does not score pages by keyword frequency. It evaluates whether a page clearly and authoritatively answers a question in a format it can extract and cite.",
  },
  {
    icon: TrendingUp,
    point: "Google rankings do not guarantee citation",
    explanation:
      "A page that ranks on page one of Google may never appear in a Perplexity answer. The retrieval model applies different signals — entity clarity and content structure take precedence over search position alone.",
  },
  {
    icon: Eye,
    point: "Thin content is bypassed entirely",
    explanation:
      "Short, generalised pages are rarely selected as citation sources. Perplexity favours depth, specificity, and clear subject-matter authority over volume or breadth.",
  },
];

const PerplexityVisibilityExplainer = React.forwardRef<HTMLElement>(
  (props, ref) => {
    return (
      <section
        ref={ref}
        id="perplexity-visibility-explainer"
        className="relative py-20 md:py-32 border-t border-border bg-muted"
      >
        <div className="container max-w-6xl mx-auto px-4">

          {/* Section header */}
          <motion.div
            className="mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={fadeUp}
            custom={0}
          >
            <Badge
              variant="secondary"
              className="mb-4 text-xs uppercase tracking-widest font-medium"
            >
              How Perplexity Works
            </Badge>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground max-w-3xl leading-snug">
              Understanding Perplexity's Answer Engine
            </h2>
            <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
              Perplexity AI operates on fundamentally different principles to
              Google and ChatGPT. Understanding those mechanics is the
              prerequisite to improving your visibility inside it.
            </p>
          </motion.div>

          {/* Mechanics grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-20">
            {mechanicsData.map((item, index) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.label}
                  className="bg-background border border-border rounded-md p-6 flex flex-col gap-4 hover:shadow-md transition-shadow duration-300"
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true, margin: "-60px" }}
                  variants={fadeUp}
                  custom={index * 0.08}
                >
                  <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 shrink-0">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="text-sm font-semibold text-foreground leading-snug">
                    {item.label}
                  </h3>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {item.body}
                  </p>
                </motion.div>
              );
            })}
          </div>

          {/* Comparison table */}
          <motion.div
            className="mb-20"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={fadeUp}
            custom={0}
          >
            <h2 className="text-xl md:text-2xl font-bold text-foreground mb-2">
              Perplexity vs Google vs ChatGPT
            </h2>
            <p className="text-sm text-muted-foreground mb-8 max-w-xl leading-relaxed">
              Each AI platform retrieves and surfaces information through a
              different model. Standard SEO tactics are calibrated for Google —
              Perplexity requires a distinct approach.
            </p>

            {/* Mobile-friendly comparison — card stack on mobile, table on md+ */}
            <div className="hidden md:block overflow-x-auto rounded-md border border-border">
              <table className="w-full text-sm">
                <thead>
                  <tr className="bg-background border-b border-border">
                    <th className="text-left py-3 px-4 font-semibold text-muted-foreground w-1/4">
                      Dimension
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">
                      Google
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">
                      ChatGPT
                    </th>
                    <th className="text-left py-3 px-4 font-semibold text-foreground">
                      Perplexity
                    </th>
                  </tr>
                </thead>
                <tbody>
                  {vsComparisonData.map((row, index) => (
                    <tr
                      key={row.dimension}
                      className={
                        index % 2 === 0
                          ? "bg-muted/40 border-b border-border"
                          : "bg-background border-b border-border"
                      }
                    >
                      <td className="py-3 px-4 font-medium text-muted-foreground text-xs uppercase tracking-wide">
                        {row.dimension}
                      </td>
                      <td className="py-3 px-4 text-foreground leading-relaxed">
                        {row.google}
                      </td>
                      <td className="py-3 px-4 text-foreground leading-relaxed">
                        {row.chatgpt}
                      </td>
                      <td className="py-3 px-4 text-foreground leading-relaxed font-medium">
                        {row.perplexity}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Mobile card stack */}
            <div className="md:hidden space-y-4">
              {vsComparisonData.map((row) => (
                <div
                  key={row.dimension}
                  className="bg-background border border-border rounded-md p-4 space-y-3"
                >
                  <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
                    {row.dimension}
                  </p>
                  <div className="space-y-2">
                    <div>
                      <span className="text-xs font-medium text-foreground">
                        Google:{" "}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {row.google}
                      </span>
                    </div>
                    <div>
                      <span className="text-xs font-medium text-foreground">
                        ChatGPT:{" "}
                      </span>
                      <span className="text-xs text-muted-foreground">
                        {row.chatgpt}
                      </span>
                    </div>
                    <div className="border-t border-border pt-2">
                      <span className="text-xs font-semibold text-foreground">
                        Perplexity:{" "}
                      </span>
                      <span className="text-xs text-foreground">
                        {row.perplexity}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          {/* Why standard SEO falls short */}
          <motion.div
            className="mb-16"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            variants={fadeUp}
            custom={0}
          >
            <h2 className="text-xl md:text-2xl font-bold text-foreground mb-2">
              Why Standard SEO is Insufficient
            </h2>
            <p className="text-sm text-muted-foreground mb-8 max-w-xl leading-relaxed">
              The tactics that drive Google rankings do not translate directly to
              Perplexity citation. Here's where the gap appears.
            </p>

            <div className="space-y-5">
              {whyStandardSEOFallsShort.map((item, index) => {
                const Icon = item.icon;
                return (
                  <motion.div
                    key={item.point}
                    className="flex gap-4 bg-background border border-border rounded-md p-5 hover:shadow-sm transition-shadow duration-300"
                    initial="hidden"
                    whileInView="visible"
                    viewport={{ once: true, margin: "-40px" }}
                    variants={fadeUp}
                    custom={index * 0.1}
                  >
                    <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10 shrink-0 mt-0.5">
                      <Icon className="h-4 w-4 text-primary" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground text-sm mb-1">
                        {item.point}
                      </p>
                      <p className="text-sm text-muted-foreground leading-relaxed">
                        {item.explanation}
                      </p>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </motion.div>

          {/* Consultant perspective callout */}
          <motion.div
            className="border-l-4 border-primary bg-background rounded-r-md px-6 py-6"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            custom={0}
          >
            <div className="flex items-start gap-3">
              <CheckCircle className="h-5 w-5 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="text-sm font-semibold text-foreground mb-1">
                  A note on intent vs technique
                </p>
                <p className="text-sm text-muted-foreground leading-relaxed max-w-2xl">
                  Optimising for Perplexity is not a bolt-on tactic. It requires
                  a considered rethink of how content is structured, how
                  entities are established, and how authority is signalled at a
                  domain level. The pages that consistently earn citations are
                  those built with depth, clarity, and genuine subject-matter
                  authority — not those that have simply targeted a keyword.
                </p>
                <p className="text-sm text-muted-foreground leading-relaxed max-w-2xl mt-2">
                  That is where I focus my work with clients: building the
                  foundational signals that AI retrieval systems rely on, rather
                  than applying superficial optimisations that have no bearing on
                  how these systems select their sources.
                </p>
                <p className="mt-3 text-xs text-muted-foreground font-medium tracking-wide">
                  Gregg King — Independent SEO Consultant, Warrington, Cheshire
                </p>
              </div>
            </div>
          </motion.div>

        </div>
      </section>
    );
  }
);

PerplexityVisibilityExplainer.displayName = "PerplexityVisibilityExplainer";

export default PerplexityVisibilityExplainer;
