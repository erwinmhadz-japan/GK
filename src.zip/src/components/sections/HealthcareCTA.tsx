import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { CheckCircle, ArrowRight, Book, Search, View } from "lucide-react";

const benefits = [
  "Free initial healthcare SEO audit",
  "YMYL & E-E-A-T compliance review",
  "Local Pack visibility analysis",
  "Schema markup assessment",
  "No obligation, no sales pressure",
];

const HealthcareCTA: React.FC = () => {
  return (
    <ImageBackground
      src="https://images.unsplash.com/photo-1758691461516-7e716e0ca135?w=1920&h=1080&fit=crop"
      alt="Elderly doctor wearing glasses and stethoscope in office"
      imgProps={{ loading: "lazy" }}
      className="py-24 md:py-36"
    >
      <div className="container relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4">
            Start Today
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
            Ready to Attract More Patients Through Search?
          </h2>
          <p className="text-lg text-white/90 mb-8 max-w-2xl mx-auto leading-relaxed">
            Whether you run a single-site GP surgery, a multi-location private clinic, or a
            specialist practice, we'll show you exactly where you're losing patients in organic
            search — and how to fix it.
          </p>

          <ul className="flex flex-wrap justify-center gap-x-8 gap-y-3 mb-10">
            {benefits.map((b) => (
              <li key={b} className="flex items-center gap-2 text-sm text-white/80">
                <CheckCircle className="h-4 w-4 text-primary shrink-0" />
                {b}
              </li>
            ))}
          </ul>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold px-8"
              asChild
            >
              <a href="/contact">
                Book a Free Audit
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10"
              asChild
            >
              <a href="#case-studies-cta">View Healthcare Case Studies</a>
            </Button>
          </div>

          <p className="mt-8 text-sm text-white/80">
            Independent consultant · No agency overhead · UK-based · Regulated sector experience
          </p>
        </div>
      </div>
    </ImageBackground>
  );
};

export default HealthcareCTA;
