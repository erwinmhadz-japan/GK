import React from "react";
import { Search, Target, MapPin, TrendingUp, CheckCircle, Globe, Building, Link, Triangle } from "lucide-react";

const strategies = [
  {
    icon: Search,
    title: "Google Business Profile Optimisation",
    description:
      "Optimise your GBP listing so Liverpool searchers find you first — from Toxteth to Formby. We handle categories, posts, photos, Q&A and review strategy.",
    steps: ["Category & attribute optimisation", "Weekly GBP post strategy", "Photo & review management"],
  },
  {
    icon: MapPin,
    title: "Liverpool-Specific On-Page SEO",
    description:
      "We build location-targeted content that signals Liverpool relevance to Google — neighbourhood pages, local schema markup, and internally linked service area content.",
    steps: ["Location landing pages", "Liverpool schema markup", "Local citation building"],
  },
  {
    icon: Target,
    title: "Competitor Gap Analysis",
    description:
      "We analyse what your top Liverpool competitors are ranking for — then build a strategy that takes those positions and makes them yours.",
    steps: ["SERP competitor mapping", "Keyword gap identification", "Content and link gap analysis"],
  },
  {
    icon: TrendingUp,
    title: "Local Link Building",
    description:
      "Earn authoritative backlinks from Liverpool news sites, business directories, local chambers, and Merseyside industry associations that boost your domain authority.",
    steps: ["Merseyside press outreach", "Chamber & directory listings", "Digital PR for local brands"],
  },
];

const LiverpoolLocalSEO = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="liverpool-local-seo"
      className="relative py-20 md:py-32 border-t border-border bg-background"
      aria-label="Liverpool local SEO strategy"
    >
      <div className="container">
        <div className="max-w-2xl mb-16">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Our Approach
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">
            Local SEO Strategy Built for Liverpool
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Generic SEO doesn't cut it in a market like Liverpool. Every strategy is tailored to your specific area, your competition, and the Merseyside search landscape. Here's how we get you ranking.
          </p>
          <div className="mt-6">
            <a href="/local-seo" className="text-primary font-medium hover:underline text-sm">
              Learn more about our local SEO services →
            </a>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {strategies.map((strategy) => {
            const Icon = strategy.icon;
            return (
              <div
                key={strategy.title}
                className="bg-muted rounded-xl p-8 border border-border hover-lift transition-all duration-300"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10 mb-5">
                  <Icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3">{strategy.title}</h3>
                <p className="text-muted-foreground leading-relaxed mb-5">{strategy.description}</p>
                <ul className="space-y-2">
                  {strategy.steps.map((step) => (
                    <li key={step} className="flex items-center gap-2.5 text-sm text-foreground">
                      <CheckCircle className="h-4 w-4 text-primary shrink-0" />
                      {step}
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>

        {/* Regional reach callout */}
        <div className="mt-16 bg-gradient-hero-panel rounded-2xl p-8 md:p-12 flex flex-col md:flex-row items-start md:items-center gap-6">
          <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-xl bg-primary/20">
            <Globe className="h-7 w-7 text-primary" />
          </div>
          <div className="flex-1">
            <h3 className="text-xl font-bold text-white mb-2">Regional Service Area</h3>
            <p className="text-white/80 leading-relaxed">
              We serve businesses across the full Liverpool City Region — including Knowsley, St Helens, Halton, Sefton, and Wirral. Whether you're in Liverpool City Centre, the Baltic Triangle, or out towards Southport, we understand the local market dynamics.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
});

LiverpoolLocalSEO.displayName = "LiverpoolLocalSEO";

export default LiverpoolLocalSEO;
