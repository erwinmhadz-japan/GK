import React from "react";
import { Button } from "@/components/ui/button";
import { ArrowRight, Star } from "lucide-react";

const IndustriesCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative isolate py-24 md:py-36 border-t border-border overflow-hidden"
    >
      {/* Background image */}
      <img
        src="https://images.unsplash.com/photo-1730851357916-3802b6405271?w=1920&h=1080&fit=crop"
        alt="Professional in suit and tie standing in a modern office"
        width={1920}
        height={1080}
        loading="lazy"
        className="absolute inset-0 w-full h-full object-cover"
      />
      {/* Overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-black/85 via-black/80 to-black/70 pointer-events-none" />

      <div className="container relative z-10 text-center">
        <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4 font-medium">
          Get Started Today
        </span>
        <h2 className="text-3xl md:text-5xl font-bold text-white max-w-3xl mx-auto">
          Ready for SEO That Understands Your Sector?
        </h2>
        <p className="mt-5 text-lg text-white/90 max-w-xl mx-auto leading-relaxed">
          Whether you're a law firm, clinic, estate agency, or B2B consultancy — I'll build
          a bespoke SEO strategy that earns you visibility where your ideal clients are searching.
        </p>

        {/* Trust signals */}
        <div className="flex items-center justify-center gap-1.5 mt-6 mb-10">
          {[...Array(5)].map((_, i) => (
            <Star key={i} className="h-4 w-4 fill-primary text-primary" />
          ))}
          <span className="ml-2 text-white/80 text-sm font-medium">Trusted by professional firms across the UK</span>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            size="lg"
            className="bg-gradient-cta text-foreground font-semibold hover:opacity-90 transition-opacity px-8"
            asChild
          >
            <a href="/contact">
              Request a Free Strategy Call
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-transparent text-white border-white hover:bg-white/10"
            asChild
          >
            <a href="/contact">Get in Touch</a>
          </Button>
        </div>

        <p className="mt-6 text-white/80 text-sm">
          No long-term contracts required · Transparent pricing · UK-based specialist
        </p>
      </div>
    </section>
  );
});

IndustriesCTA.displayName = "IndustriesCTA";

export default IndustriesCTA;
