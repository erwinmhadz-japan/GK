import React from "react";
import { motion } from "framer-motion";
import { BrainCircuit, Search, Globe, MessageSquare, Eye, TrendingUp, Layers, ArrowRight, Section } from "lucide-react";
import { Link } from "react-router-dom";

const AiSearchOptimisationOverview = React.forwardRef<HTMLElement>((props, ref) => {
  const concepts = [
    {
      icon: BrainCircuit,
      heading: "How LLMs select their sources",
      body: "Large language models do not retrieve content the way a search engine does. They generate responses by drawing on patterns in their training data and, for real-time systems, by evaluating retrieved sources against signals of authority, entity consistency, and topical depth. Being indexed is not enough — your business needs to be recognised as a credible, well-defined entity within the model's understanding of your sector.",
    },
    {
      icon: Globe,
      heading: "Why traditional SEO falls short",
      body: "Ranking on page one of Google no longer guarantees visibility in AI-generated answers. ChatGPT, Perplexity, Google AI Overviews, Gemini, and Copilot each apply their own criteria when deciding which sources to cite, summarise, or recommend. A site that performs well in conventional search can still be entirely absent from AI responses — particularly if its entity structure, schema, and content authority signals are not calibrated for machine comprehension.",
    },
    {
      icon: MessageSquare,
      heading: "The consulting engagement in practice",
      body: "AI search optimisation begins with an audit of your current visibility across the major answer engines. From there, the work spans entity disambiguation, structured data implementation, citation signal analysis, and content authority development. Each engagement is specific to your business, your sector, and the query landscape in which your prospective clients are operating.",
    },
  ];

  const distinctions = [
    {
      icon: Eye,
      label: "Cited in AI responses",
      description: "Appearing in ChatGPT, Perplexity, or Google AI Overviews when a prospective client asks a relevant question",
    },
    {
      icon: TrendingUp,
      label: "Recommended with authority",
      description: "Being surfaced as a credible option — not merely mentioned — in AI-generated answer summaries and comparisons",
    },
    {
      icon: Layers,
      label: "Understood as an entity",
      description: "Having your business, services, and expertise accurately represented in the knowledge structures underlying AI systems",
    },
    {
      icon: Search,
      label: "Visible across platforms",
      description: "Maintaining consistent presence across the distinct ecosystems of ChatGPT, Perplexity, Gemini, Copilot, and Google's AI layer",
    },
  ];

  const fadeUp = {
    hidden: { opacity: 0, y: 22 },
    visible: { opacity: 1, y: 0 },
  };

  return (
    <section
      ref={ref}
      id="ai-search-optimisation-overview"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          className="mb-14 md:mb-20 max-w-3xl"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          transition={{ staggerChildren: 0.1 }}
        >
          <motion.span
            variants={fadeUp}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium"
          >
            What AI Search Optimisation Actually Involves
          </motion.span>
          <motion.h2
            variants={fadeUp}
            transition={{ duration: 0.55, ease: "easeOut" }}
            className="text-2xl md:text-3xl lg:text-4xl font-bold font-[Sora,sans-serif] text-foreground leading-snug max-w-2xl"
          >
            Understanding the problem space before committing to a solution
          </motion.h2>
          <motion.p
            variants={fadeUp}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="mt-5 text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl"
          >
            AI answer engines operate on different principles to conventional search. Before any optimisation work begins, it is worth understanding precisely what these systems are doing — and why the gap between search visibility and AI visibility can be significant even for well-established businesses.
          </motion.p>
        </motion.div>

        {/* Core concept cards */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mb-16 md:mb-24"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          transition={{ staggerChildren: 0.12 }}
        >
          {concepts.map((item, index) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={index}
                variants={fadeUp}
                transition={{ duration: 0.55, ease: "easeOut" }}
                className="group relative bg-background border border-border rounded-md p-7 flex flex-col gap-4"
                style={{ boxShadow: "0 4px 24px -6px hsl(222 28% 11% / 0.10), 0 1px 4px hsl(222 28% 11% / 0.05)" }}
              >
                {/* Icon */}
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 shrink-0">
                  <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
                </div>

                <h3 className="text-base md:text-lg font-semibold font-[Sora,sans-serif] text-foreground leading-snug">
                  {item.heading}
                </h3>
                <p className="text-sm md:text-base text-muted-foreground leading-relaxed flex-1">
                  {item.body}
                </p>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Divider prose block */}
        <motion.div
          className="mb-14 md:mb-20 max-w-3xl"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          transition={{ staggerChildren: 0.1 }}
        >
          <motion.h3
            variants={fadeUp}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="text-xl md:text-2xl font-semibold font-[Sora,sans-serif] text-foreground mb-5"
          >
            The distinction that matters commercially
          </motion.h3>
          <motion.p
            variants={fadeUp}
            transition={{ duration: 0.55, ease: "easeOut" }}
            className="text-base md:text-lg text-muted-foreground leading-relaxed mb-4"
          >
            For businesses in competitive, trust-led sectors — law, healthcare, finance, property — AI-generated answers increasingly shape first impressions before a prospective client ever reaches a website. The question is not whether your business ranks on Google. It is whether your business is understood, cited, and recommended by the systems that are increasingly mediating high-intent queries.
          </motion.p>
          <motion.p
            variants={fadeUp}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="text-base md:text-lg text-muted-foreground leading-relaxed"
          >
            That distinction requires a different set of signals: entity clarity, topical authority, structured data, citation patterns, and content that meets the comprehension standards of language models — not just the ranking criteria of conventional search algorithms.
          </motion.p>
        </motion.div>

        {/* Four-point distinction grid */}
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 gap-5 md:gap-6 mb-14 md:mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          transition={{ staggerChildren: 0.1 }}
        >
          {distinctions.map((item, index) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={index}
                variants={fadeUp}
                transition={{ duration: 0.5, ease: "easeOut" }}
                className="flex items-start gap-4 bg-background border border-border rounded-md p-5"
                style={{ boxShadow: "0 2px 12px -2px hsl(222 28% 11% / 0.06), 0 1px 3px hsl(222 28% 11% / 0.04)" }}
              >
                <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10 shrink-0 mt-0.5">
                  <Icon className="h-4 w-4 text-primary" aria-hidden="true" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-foreground mb-1">{item.label}</p>
                  <p className="text-sm text-muted-foreground leading-relaxed">{item.description}</p>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Informational link to /ai-search/ hub + child page nav */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.55, ease: "easeOut" }}
          className="border-t border-border pt-8"
        >
          <p className="text-sm text-muted-foreground mb-3">
            Looking for a deeper explanation of how individual AI platforms work?
          </p>
          <Link
            to="#ai-search-cta"
            className="inline-flex items-center gap-2 text-sm font-medium text-primary hover:text-primary/80 transition-colors duration-200 group mb-6"
          >
            Explore the AI search knowledge hub
            <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform duration-200" aria-hidden="true" />
          </Link>

          {/* Platform child page links */}
          <div className="mt-6 flex flex-wrap gap-2">
            {[
              { label: "ChatGPT Visibility", to: "/chatgpt-visibility" },
              { label: "Perplexity Visibility", to: "/perplexity-visibility" },
              { label: "Google AI Overviews", to: "/google-ai-overviews" },
              { label: "Gemini Visibility", to: "/gemini-visibility" },
              { label: "Copilot Visibility", to: "/copilot-visibility" },
            ].map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className="inline-flex items-center gap-1.5 rounded-full border border-border bg-background px-3 py-1.5 text-xs font-medium text-foreground hover:border-primary/40 hover:text-primary transition-colors duration-200"
              >
                {link.label}
              </Link>
            ))}
          </div>
        </motion.div>

      </div>
    </section>
  );
});

AiSearchOptimisationOverview.displayName = "AiSearchOptimisationOverview";

export default AiSearchOptimisationOverview;
