import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight, Search, ScanSearch, RefreshCw, Cpu, Tags, Network, PenLine, MapPin, Megaphone, BrainCircuit, List, Section, Text } from "lucide-react";

interface Service {
  label: string;
  /** Canonical route as it exists in pages.manifest.json */
  path: string;
  icon: React.ComponentType<{ className?: string }>;
  intent: string;
  description: string;
}

const services: Service[] = [
  {
    label: "SEO Consulting",
    path: "/seo-consulting",
    icon: Search,
    intent: "Strategic SEO direction for UK businesses",
    description:
      "Independent SEO counsel built around your business goals — no agency overhead, no junior hand-offs.",
  },
  {
    label: "SEO Audit",
    path: "/seo-audit",
    icon: ScanSearch,
    intent: "In-depth technical and strategic site review",
    description:
      "A thorough audit identifying what is holding your site back and a prioritised roadmap for improvement.",
  },
  {
    label: "SEO Retainer",
    path: "/seo-retainer",
    icon: RefreshCw,
    intent: "Ongoing monthly SEO support and delivery",
    description:
      "Sustained, senior-led SEO work each month — strategy, implementation, and reporting in a single engagement.",
  },
  {
    label: "Technical SEO",
    path: "/technical-seo",
    icon: Cpu,
    intent: "Technical SEO fixes and performance optimisation",
    description:
      "Crawlability, Core Web Vitals, structured data, and site architecture resolved at source.",
  },
  {
    label: "Schema Markup",
    path: "/schema-markup",
    icon: Tags,
    intent: "Structured data implementation for rich results",
    description:
      "JSON-LD schema deployed correctly to help search engines understand your content and earn rich results.",
  },
  {
    label: "Entity SEO",
    path: "/entity-seo",
    icon: Network,
    intent: "Entity and knowledge graph optimisation",
    description:
      "Establishing clear entity associations so Google understands who you are and what you represent.",
  },
  {
    label: "Content Strategy",
    path: "/content-strategy",
    icon: PenLine,
    intent: "Keyword-led content planning and editorial strategy",
    description:
      "A structured content plan built around genuine search demand and your commercial priorities.",
  },
  {
    label: "Local SEO",
    path: "/local-seo",
    icon: MapPin,
    intent: "Local search visibility for UK businesses",
    description:
      "Google Business Profile, local citations, and geo-targeted content — built for serious local competition.",
  },
  {
    label: "Digital PR",
    path: "/digital-pr",
    icon: Megaphone,
    intent: "Authority link building through earned media",
    description:
      "Editorially earned links from credible UK publications, built around your brand and expertise.",
  },
  {
    label: "AI Search Optimisation",
    path: "/ai-search-optimisation",
    icon: BrainCircuit,
    intent: "Visibility in AI-powered search and answer engines",
    description:
      "Structured, authoritative content that earns citations in ChatGPT, Perplexity, Google AI Overviews, and beyond.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.07,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: "easeOut" },
  },
};

const ServicesList = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="services-list"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mb-12 md:mb-16"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Services › Full Service List
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground max-w-2xl leading-snug">
            Ten specialist services. One point of contact.
          </h2>
          <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
            Every engagement is handled directly by Gregg King — no account managers, no
            junior teams. Select a service below to learn how it applies to your business.
          </p>
        </motion.div>

        {/* 10-card grid: 2 columns on md, 2 columns on lg (5 rows of 2) to honour expected_count:10 */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          className="grid grid-cols-1 md:grid-cols-2 gap-4 md:gap-5"
        >
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <motion.div key={service.label} variants={cardVariants}>
                <Link
                  to={service.path}
                  className="group flex items-start gap-5 p-6 md:p-7 rounded-md border border-border bg-card hover:border-primary/40 hover:shadow-[0_4px_24px_-4px_hsl(225_28%_14%/0.18)] transition-all duration-300 block"
                  aria-label={`Learn more about ${service.label}`}
                >
                  {/* Icon container */}
                  <div className="flex-shrink-0 flex items-center justify-center w-11 h-11 rounded-md bg-primary/10 group-hover:bg-primary/20 transition-colors duration-300">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>

                  {/* Text content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <h3 className="text-base md:text-[1.05rem] font-semibold text-foreground leading-snug group-hover:text-primary transition-colors duration-200">
                          {service.label}
                        </h3>
                        <p className="mt-0.5 text-xs font-medium uppercase tracking-wide text-muted-foreground">
                          {service.intent}
                        </p>
                      </div>
                      {/* Arrow affordance */}
                      <ArrowRight className="flex-shrink-0 h-4 w-4 text-muted-foreground group-hover:text-primary group-hover:translate-x-1 transition-all duration-200 mt-1" />
                    </div>
                    <p className="mt-2.5 text-sm text-muted-foreground leading-relaxed">
                      {service.description}
                    </p>
                  </div>
                </Link>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Subtle footer note — informational only, no CTA block */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.7, delay: 0.3, ease: "easeOut" }}
          className="mt-10 text-sm text-muted-foreground text-center"
        >
          Not sure where to start?{" "}
          <Link
            to="/contact"
            className="underline underline-offset-2 hover:text-foreground transition-colors duration-200"
          >
            Get in touch
          </Link>{" "}
          and I'll identify exactly where your SEO needs attention.
        </motion.p>
      </div>
    </section>
  );
});

ServicesList.displayName = "ServicesList";

export default ServicesList;
