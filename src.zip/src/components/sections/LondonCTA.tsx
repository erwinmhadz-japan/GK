import React from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, MapPin, CheckCircle, Search, View } from "lucide-react";
import { ImageBackground } from "@/components/ImageBackground";

const LondonCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="london-cta"
      aria-label="London SEO call to action"
      src="https://images.unsplash.com/photo-1633537066070-94bccfa10f05?w=1920&h=1080&fit=crop"
      alt="Looking up at a very tall modern building against a bright London sky"
      imgProps={{ loading: "lazy" }}
      className="py-24 md:py-36"
    >
      <div className="container relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <Badge className="bg-primary/20 text-white border border-primary/40 backdrop-blur-sm mb-6">
            <MapPin className="h-3 w-3 mr-1" />
            London-Based SEO Consulting
          </Badge>

          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 leading-tight">
            Ready to Dominate London's Search Landscape?
          </h2>

          <p className="text-lg text-white/90 mb-8 leading-relaxed max-w-2xl mx-auto">
            Whether you're an established London enterprise looking to protect and grow your
            organic market share, or a scaling business ready to invest in search authority —
            let's build a strategy that delivers measurable commercial results.
          </p>

          {/* Checklist */}
          <div className="flex flex-col sm:flex-row justify-center gap-4 sm:gap-8 mb-10">
            {[
              "No long-term lock-in contracts",
              "Senior-level strategy on every engagement",
              "Revenue-focused reporting, not vanity metrics",
            ].map((point) => (
              <div key={point} className="flex items-center gap-2 justify-center">
                <CheckCircle className="h-4 w-4 text-primary shrink-0" />
                <span className="text-sm text-white/80">{point}</span>
              </div>
            ))}
          </div>

          <div className="flex flex-wrap justify-center gap-4 mb-8">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold shadow-green-glow px-8"
              asChild
            >
              <a href="/contact">
                Start Your London SEO Strategy
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10"
              asChild
            >
              <a href="/services-seo-audit">View Consulting Services</a>
            </Button>
          </div>

          {/* Internal navigation links */}
          <div className="flex flex-wrap justify-center gap-3 pt-4 border-t border-white/20">
            <span className="text-xs text-white/80">Explore:</span>
            {[
              { label: "All Locations", href: "/locations" },
              { label: "Local SEO", href: "/local-seo" },
              { label: "SEO Consulting", href: "/services-seo-audit" },
              { label: "Case Studies", href: "#case-studies-cta" },
              { label: "Manchester", href: "#manchester-cta" },
              { label: "Birmingham", href: "#birmingham-cta" },
              { label: "Leeds", href: "#leeds-cta" },
            ].map(({ label, href }) => (
              <a
                key={label}
                href={href}
                className="text-xs text-white/80 hover:text-white underline underline-offset-2 transition-colors"
              >
                {label}
              </a>
            ))}
          </div>
        </div>
      </div>
    </ImageBackground>
  );
});

LondonCTA.displayName = "LondonCTA";

export default LondonCTA;
