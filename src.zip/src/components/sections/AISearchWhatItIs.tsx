import React from "react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Brain, Globe, Database, Layers, Sparkles, Search, Building, Key, Section } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (delay: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut", delay },
  }),
};

const platforms = [
  {
    name: "ChatGPT",
    icon: Brain,
    description:
      "OpenAI's conversational AI draws on entity authority and cited sources to surface recommendations. Brand presence in trusted publications and structured data are key signals.",
  },
  {
    name: "Perplexity",
    icon: Search,
    description:
      "A real-time answer engine that indexes the web continuously. It favours pages with clear entity associations, well-structured content, and domain authority.",
  },
  {
    name: "Google AI Overviews",
    icon: Globe,
    description:
      "Google's generative summaries sit above traditional results. Pages with strong E-E-A-T signals, schema markup, and factual authority have the best chance of inclusion.",
  },
  {
    name: "Gemini",
    icon: Sparkles,
    description:
      "Google's own AI model powers responses across Search, Workspace, and Android. It relies heavily on structured data, verified entities, and consistent brand signals.",
  },
  {
    name: "Microsoft Copilot",
    icon: Layers,
    description:
      "Integrated across Microsoft 365 and Bing, Copilot surfaces brands with strong citation profiles, clear topical authority, and well-organised content structures.",
  },
];

const signals = [
  {
    icon: Database,
    label: "Entity Authority",
    body:
      "AI engines understand entities — people, businesses, topics — rather than just keywords. Building a coherent entity footprint across the web is foundational to AI visibility.",
  },
  {
    icon: Layers,
    label: "Structured Data",
    body:
      "Schema markup helps AI models accurately interpret your content, your organisation, and your expertise. Without it, AI systems are left guessing what you do and who you are.",
  },
  {
    icon: Globe,
    label: "Brand Citation Signals",
    body:
      "AI engines attribute credibility to brands consistently cited in authoritative sources. Digital PR, link acquisition, and brand mention strategy feed directly into AI ranking potential.",
  },
];

const AISearchWhatItIs = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="aisearch-what-it-is"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          className="max-w-3xl mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={fadeUp}
          custom={0}
        >
          <Badge
            variant="secondary"
            className="mb-4 text-xs uppercase tracking-widest font-medium"
          >
            The Discipline Explained
          </Badge>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground tracking-tight leading-tight mb-6">
            What Is AI Search Optimisation?
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground leading-relaxed">
            AI search optimisation is the practice of ensuring your brand surfaces within AI-generated answers and recommendations — not just traditional search results. As ChatGPT, Perplexity, Gemini, Google AI Overviews, and Microsoft Copilot become primary discovery channels for high-intent audiences, the signals that drive visibility have shifted fundamentally.
          </p>
        </motion.div>

        {/* Two-column explanatory block */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-10 mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={fadeUp}
          custom={0.1}
        >
          <div>
            <h3 className="text-xl font-semibold text-foreground mb-3">
              How AI search differs from traditional SEO
            </h3>
            <p className="text-muted-foreground leading-relaxed mb-4">
              Traditional SEO optimises for ranked lists of blue links. AI search engines generate direct answers, citing the brands and sources they consider most authoritative. A business can rank on page one of Google and still be entirely absent from AI-generated responses — because the two systems use different signals.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              Keyword density and backlink volume are insufficient on their own. AI engines evaluate entity clarity, citation breadth, structured data richness, and topical authority — the kind of signals built through a deliberate, consultancy-led approach rather than tactical quick fixes.
            </p>
          </div>
          <div>
            <h3 className="text-xl font-semibold text-foreground mb-3">
              Why it matters for UK businesses now
            </h3>
            <p className="text-muted-foreground leading-relaxed mb-4">
              AI-generated overviews and conversational search results are already changing how UK consumers and decision-makers discover professional services. In sectors where trust and authority are primary buying signals — law, finance, healthcare, property — being cited by AI systems carries significant commercial weight.
            </p>
            <p className="text-muted-foreground leading-relaxed">
              I work with businesses that want to establish AI visibility before it becomes a saturated space. This is not a future consideration; it is an active ranking factor today, particularly for brands operating in competitive, high-stakes verticals.
            </p>
          </div>
        </motion.div>

        {/* Key signals */}
        <motion.div
          className="mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={fadeUp}
          custom={0}
        >
          <p className="text-xs uppercase tracking-widest text-muted-foreground font-medium mb-8">
            The signals that drive AI visibility
          </p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {signals.map((signal, i) => {
              const Icon = signal.icon;
              return (
                <motion.div
                  key={signal.label}
                  className="border border-border rounded-md p-6 bg-background hover:shadow-md transition-shadow duration-300"
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.55, ease: "easeOut", delay: i * 0.1 }}
                >
                  <div className="flex items-center justify-center h-10 w-10 rounded-md bg-primary/10 mb-4">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <h4 className="text-base font-semibold text-foreground mb-2">
                    {signal.label}
                  </h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {signal.body}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Platform breakdown */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={fadeUp}
          custom={0}
          className="mb-16"
        >
          <p className="text-xs uppercase tracking-widest text-muted-foreground font-medium mb-2">
            The AI platforms I optimise for
          </p>
          <p className="text-muted-foreground text-sm mb-8 max-w-2xl">
            Each AI engine uses a subtly different ranking and citation model. Effective AI search optimisation accounts for all of them rather than treating them as a monolith.
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {platforms.map((platform, i) => {
              const Icon = platform.icon;
              return (
                <motion.div
                  key={platform.name}
                  className="flex gap-4 border border-border rounded-md p-5 bg-background hover:border-primary/40 transition-colors duration-200"
                  initial={{ opacity: 0, y: 16 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, ease: "easeOut", delay: i * 0.08 }}
                >
                  <div className="flex-shrink-0">
                    <div className="flex items-center justify-center h-9 w-9 rounded-md bg-primary/10">
                      <Icon className="h-4 w-4 text-primary" />
                    </div>
                  </div>
                  <div>
                    <h4 className="text-sm font-semibold text-foreground mb-1">
                      {platform.name}
                    </h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {platform.description}
                    </p>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Consultant framing quote */}
        <motion.div
          className="border-l-4 border-primary pl-6 py-1 max-w-2xl"
          initial={{ opacity: 0, x: -16 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
        >
          <p className="text-muted-foreground leading-relaxed text-base italic">
            "This is a consultancy-led service, not a software tool or automated platform. I analyse your entity footprint, audit your structured data, and build a tailored strategy to improve your presence across AI-generated results — working directly with you throughout the process."
          </p>
          <p className="text-sm text-foreground font-medium mt-3 not-italic">
            Gregg King — Independent SEO Consultant, Warrington, Cheshire
          </p>
        </motion.div>

      </div>
    </section>
  );
});

AISearchWhatItIs.displayName = "AISearchWhatItIs";

export default AISearchWhatItIs;
