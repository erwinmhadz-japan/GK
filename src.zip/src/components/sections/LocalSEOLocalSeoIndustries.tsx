import React from "react";
import { motion } from "framer-motion";
import { Stethoscope, Gavel, Building2, Wrench, HandCoins, Home, Tags } from "lucide-react";

const industries = [
  {
    icon: Stethoscope,
    title: "Healthcare & Private Clinics",
    description:
      "Patients searching for a GP, dentist, or specialist overwhelmingly use local search. Ranking well for 'private clinic near me' or 'physiotherapist [city]' depends on a well-optimised Google Business Profile, consistent citations, and structured local content — areas I specialise in.",
    examples: ["Private GP practices", "Dental surgeries", "Physiotherapy & specialist clinics"],
  },
  {
    icon: Gavel,
    title: "Law Firms & Solicitors",
    description:
      "Legal searches carry high commercial intent and strong local preference. Prospective clients want to find a solicitor they can meet in person. Local SEO for law firms requires careful keyword targeting, authoritative local citations, and trust signals that reflect the seriousness of the sector.",
    examples: ["Family law solicitors", "Conveyancing practices", "Personal injury firms"],
  },
  {
    icon: Building2,
    title: "Estate Agents & Property Services",
    description:
      "Property is inherently local. Buyers, sellers, and landlords search by area — and they compare multiple agents before making contact. Ranking consistently across map-pack results and organic local listings is a direct competitive advantage in a saturated market.",
    examples: ["Residential estate agents", "Letting agents", "Property management firms"],
  },
  {
    icon: Wrench,
    title: "Trades & Home Services",
    description:
      "Plumbers, electricians, roofers, and builders are discovered almost exclusively through local search. Proximity ranking, review volume, and Google Business Profile completeness determine who wins the call. I help trades businesses build a durable local presence rather than depending solely on paid ads.",
    examples: ["Plumbers & electricians", "Builders & roofers", "Heating & boiler engineers"],
  },
  {
    icon: HandCoins,
    title: "Financial Advisers & Accountants",
    description:
      "Financial services clients value trust and proximity. Whether searching for an IFA, mortgage broker, or local accountant, they expect to find professionals with clear credentials and a visible local footprint. Local SEO helps financial advisers attract qualified, high-intent enquiries from their target geographies.",
    examples: ["Independent financial advisers", "Mortgage brokers", "Local accounting practices"],
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.12,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const LocalSEOLocalSeoIndustries = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="local-seolocal-seo-industries"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mb-14 md:mb-18"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Sector Experience
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground max-w-2xl leading-tight">
            Industries That Benefit From Local SEO
          </h2>
          <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
            Local search intent is concentrated in a handful of sectors where customers are actively looking for a nearby provider and trust is paramount. These are the industries where focused local SEO delivers the clearest, most measurable returns.
          </p>
        </motion.div>

        {/* Industry Tiles */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="grid grid-cols-1 md:grid-cols-2 gap-6"
        >
          {industries.map((industry, index) => {
            const Icon = industry.icon;
            return (
              <motion.div
                key={industry.title}
                variants={itemVariants}
                className={`group relative border border-border rounded-md bg-card p-7 md:p-8 transition-shadow duration-300 hover:shadow-md${
                  index === 4 ? " md:col-span-2 md:max-w-xl md:mx-auto w-full" : ""
                }`}
              >
                {/* Icon + Title Row */}
                <div className="flex items-start gap-4 mb-4">
                  <div className="flex-shrink-0 flex h-11 w-11 items-center justify-center rounded-md bg-primary/10 transition-colors duration-300 group-hover:bg-primary/20">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="text-base md:text-lg font-semibold text-foreground leading-snug pt-1">
                    {industry.title}
                  </h3>
                </div>

                {/* Description */}
                <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-5">
                  {industry.description}
                </p>

                {/* Example Tags */}
                <ul className="flex flex-wrap gap-2">
                  {industry.examples.map((example) => (
                    <li
                      key={example}
                      className="text-xs text-muted-foreground border border-border rounded-sm px-2.5 py-1 bg-muted/50"
                    >
                      {example}
                    </li>
                  ))}
                </ul>

                {/* Subtle left accent bar on hover */}
                <div
                  className="absolute left-0 top-6 bottom-6 w-0.5 rounded-full bg-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                  aria-hidden="true"
                />
              </motion.div>
            );
          })}
        </motion.div>

        {/* Closing note */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.6, delay: 0.3, ease: "easeOut" }}
          className="mt-10 text-sm text-muted-foreground text-center max-w-xl mx-auto leading-relaxed"
        >
          These sectors share a common characteristic: customers are searching with high intent and a clear preference for proximity. Ranking prominently in local search is not a nice-to-have — it is a core part of their acquisition model.
        </motion.p>
      </div>
    </section>
  );
});

LocalSEOLocalSeoIndustries.displayName = "LocalSEOLocalSeoIndustries";

export default LocalSEOLocalSeoIndustries;
