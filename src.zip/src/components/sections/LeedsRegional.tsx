import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Globe, MapPin, ArrowRight, Building2, Image } from "lucide-react";

const yorkshireAreas = [
  { city: "Sheffield", slug: "/locations/sheffield", note: "South Yorkshire's industrial heartland" },
  { city: "Bradford", slug: "/locations/bradford", note: "West Yorkshire's second city" },
  { city: "Harrogate", slug: "/locations/harrogate", note: "Premium North Yorkshire market" },
  { city: "Wakefield", slug: "/locations/wakefield", note: "Historic cathedral city" },
  { city: "Huddersfield", slug: "/locations/huddersfield", note: "Kirklees business hub" },
  { city: "York", slug: "/locations/york", note: "Tourism and heritage destination" },
];

const keywordExamples = [
  "SEO agency Leeds",
  "Leeds solicitor",
  "accountant Leeds LS1",
  "web design Headingley",
  "plumber Leeds near me",
  "Leeds estate agents reviews",
  "Yorkshire marketing agency",
  "Leeds digital marketing",
];

const LeedsRegional = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="leeds-regional"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        <div className="grid lg:grid-cols-2 gap-12 md:gap-16">
          {/* Left — regional expansion */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          >
            <div className="flex items-center gap-2 mb-4">
              <Globe className="h-4 w-4 text-primary flex-shrink-0" aria-hidden="true" />
              <span className="text-xs uppercase tracking-[0.2em] font-medium text-muted-foreground">
                Yorkshire region coverage
              </span>
            </div>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground leading-[1.15] mb-4 tracking-tight">
              Leeds and the Wider{" "}
              <span className="text-gradient-green">Yorkshire Region</span>
            </h2>
            <p className="text-muted-foreground leading-relaxed mb-8">
              Many Leeds businesses also serve customers across West Yorkshire and the
              wider region. Local SEO strategy for Leeds can extend to capture intent
              across the full Yorkshire market — from Bradford to Sheffield, Harrogate
              to Hull.
            </p>

            {/* Yorkshire areas grid */}
            <div className="grid grid-cols-2 gap-3 mb-8">
              {yorkshireAreas.map(({ city, slug, note }) => (
                <Link
                  key={city}
                  to={slug}
                  className="group flex items-start gap-3 rounded-xl border border-border bg-card p-4 shadow-soft hover:border-primary/30 hover:shadow-card transition-all duration-200"
                >
                  <MapPin className="h-4 w-4 text-primary flex-shrink-0 mt-0.5 group-hover:scale-110 transition-transform" aria-hidden="true" />
                  <div>
                    <span className="text-sm font-semibold text-foreground block group-hover:text-primary transition-colors">
                      {city}
                    </span>
                    <span className="text-xs text-muted-foreground">{note}</span>
                  </div>
                </Link>
              ))}
            </div>

            <Link
              to="#"
              className="inline-flex items-center gap-2 text-sm text-primary font-semibold hover:text-primary/80 transition-colors"
            >
              Explore Sheffield SEO services
              <ArrowRight className="h-4 w-4" />
            </Link>
          </motion.div>

          {/* Right — keyword landscape */}
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6, delay: 0.15, ease: "easeOut" }}
          >
            <div className="flex items-center gap-2 mb-4">
              <Building2 className="h-4 w-4 text-primary flex-shrink-0" aria-hidden="true" />
              <span className="text-xs uppercase tracking-[0.2em] font-medium text-muted-foreground">
                Leeds search landscape
              </span>
            </div>
            <h3 className="text-2xl md:text-3xl font-bold text-foreground leading-[1.15] mb-4 tracking-tight">
              Regional Keywords Your Leeds Business Needs to Own
            </h3>
            <p className="text-muted-foreground leading-relaxed mb-6">
              Leeds search intent is highly location-specific. From LS postcode searches
              to suburb-level queries and Yorkshire-wide commercial terms — we map and
              target the full local keyword landscape.
            </p>

            {/* Keyword pills */}
            <div className="flex flex-wrap gap-2 mb-8">
              {keywordExamples.map((kw) => (
                <span
                  key={kw}
                  className="inline-flex items-center px-3 py-1.5 rounded-full text-xs font-medium bg-card border border-border text-foreground shadow-soft"
                >
                  {kw}
                </span>
              ))}
            </div>

            {/* Image of Leeds architecture */}
            <div className="relative rounded-2xl overflow-hidden h-52 md:h-60">
              <img
                src="https://images.unsplash.com/photo-1633537066002-336ea0ff2a16?w=800&h=600&fit=crop"
                alt="Leeds city architecture with modern buildings"
                width={800}
                height={600}
                loading="lazy"
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent pointer-events-none" />
              <div className="absolute bottom-4 left-4">
                <span className="text-white text-sm font-semibold drop-shadow">Leeds, West Yorkshire</span>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
});

LeedsRegional.displayName = "LeedsRegional";

export default LeedsRegional;
