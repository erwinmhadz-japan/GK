import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { ArrowRight, TrendingUp, MapPin, Search, FileText, Zap, Group, Image, Section, View } from "lucide-react";

const caseStudies = [
  {
    slug: "legal-firm-local-seo",
    industry: "Legal",
    service: "Local SEO",
    serviceIcon: MapPin,
    title: "Manchester Law Firm Grows Enquiries by 280% in 9 Months",
    summary:
      "A mid-sized personal injury firm was invisible in local search despite years of trading. After a complete local SEO overhaul — including Google Business Profile optimisation, citation clean-up, and localised landing pages — they now rank in the top 3 for 47 high-intent keywords.",
    result: "+280% organic enquiries",
    timeline: "9 months",
    image: "https://images.unsplash.com/photo-1573496130141-209d200cebd8?w=800&h=600&fit=crop",
    imageAlt: "Legal professionals discussing SEO strategy in meeting room",
    tags: ["Local SEO", "Legal", "Google Business Profile"],
    href: "#insights-cta",
  },
  {
    slug: "healthcare-technical-seo",
    industry: "Healthcare",
    service: "Technical SEO",
    serviceIcon: Search,
    title: "Private Healthcare Group Doubles Organic Traffic with Technical SEO",
    summary:
      "A private GP and specialist network had critical indexing issues, slow Core Web Vitals, and duplicate content across 12 clinic location pages. A full technical SEO audit and remediation programme restored crawl budget and improved their average position from 14 to 4.2.",
    result: "+210% organic sessions",
    timeline: "6 months",
    image: "https://images.unsplash.com/photo-1758691463384-771db2f192b3?w=800&h=600&fit=crop",
    imageAlt: "Doctor reviewing healthcare website analytics on laptop",
    tags: ["Technical SEO", "Healthcare", "Core Web Vitals"],
    href: "#insights-cta",
  },
  {
    slug: "property-content-strategy",
    industry: "Property",
    service: "Content Strategy",
    serviceIcon: FileText,
    title: "Property Consultancy Achieves 5× Lead Growth Through Content Strategy",
    summary:
      "A boutique property investment consultancy wanted to attract high-net-worth buyers searching for commercial property in the UK. A 12-month content strategy targeting entity-rich, intent-aligned topics generated featured snippets and AI Overview mentions across Google, Perplexity, and ChatGPT.",
    result: "5× qualified lead growth",
    timeline: "12 months",
    image: "https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=800&h=600&fit=crop",
    imageAlt: "Property professionals reviewing content strategy results on laptops",
    tags: ["Content Strategy", "Property", "AI Search"],
    href: "#insights-cta",
  },
  {
    slug: "b2b-saas-ai-search",
    industry: "B2B",
    service: "AI Search Optimisation",
    serviceIcon: Zap,
    title: "B2B SaaS Company Gains Visibility in AI Overviews and Perplexity",
    summary:
      "A B2B fintech SaaS had strong technical fundamentals but zero presence in generative AI search results. An entity SEO and AI search programme built structured authority signals, secured Knowledge Panel status, and achieved consistent citation in ChatGPT, Perplexity, and Google AI Overviews within 8 months.",
    result: "Top 3 AI citations in niche",
    timeline: "8 months",
    image: "https://images.unsplash.com/photo-1556761175-4b46a572b786?w=800&h=600&fit=crop",
    imageAlt: "B2B team reviewing AI search visibility on monitors",
    tags: ["AI Search", "B2B", "Entity SEO"],
    href: "#insights-cta",
  },
];

const CaseStudiesFeatured = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="featured-case-studies"
      className="relative py-20 md:py-32 border-t border-border bg-background"
      aria-label="Featured case studies"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-2xl mb-12">
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Featured Results
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Case Studies Across Every Sector We Serve
          </h2>
          <p className="text-muted-foreground text-base md:text-lg leading-relaxed">
            These are real engagements with real outcomes. Each case study outlines the
            challenge, the strategy deployed, and the measurable results delivered.
            Browse by{" "}
            <a href="#industries-cta" className="text-primary underline-offset-4 hover:underline font-medium">
              industry
            </a>{" "}
            or{" "}
            <a href="/services" className="text-primary underline-offset-4 hover:underline font-medium">
              service type
            </a>{" "}
            to find the most relevant examples.
          </p>
        </div>

        {/* Case study cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {caseStudies.map((cs) => {
            const ServiceIcon = cs.serviceIcon;
            return (
              <Card
                key={cs.slug}
                className="group hover-lift border border-border bg-card overflow-hidden flex flex-col"
                style={{ boxShadow: "var(--shadow-card)" }}
              >
                {/* Image */}
                <div className="relative h-52 overflow-hidden">
                  <img
                    src={cs.image}
                    alt={cs.imageAlt}
                    width={800}
                    height={600}
                    loading="lazy"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent pointer-events-none" />
                  <div className="absolute bottom-3 left-4 flex gap-2 flex-wrap">
                    {cs.tags.map((tag) => (
                      <span
                        key={tag}
                        className="bg-primary/90 text-primary-foreground text-[10px] font-semibold uppercase tracking-wider px-2 py-0.5 rounded-full"
                      >
                        {tag}
                      </span>
                    ))}
                  </div>
                </div>

                <CardHeader className="pb-2">
                  <div className="flex items-center gap-2 mb-2">
                    <div className="flex h-7 w-7 items-center justify-center rounded-md bg-primary/10">
                      <ServiceIcon className="h-3.5 w-3.5 text-primary" />
                    </div>
                    <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">
                      {cs.industry} · {cs.service}
                    </span>
                  </div>
                  <h3 className="text-lg md:text-xl font-bold text-foreground leading-snug group-hover:text-primary transition-colors duration-200">
                    {cs.title}
                  </h3>
                </CardHeader>

                <CardContent className="flex flex-col flex-1 gap-4">
                  <p className="text-muted-foreground text-sm leading-relaxed flex-1">
                    {cs.summary}
                  </p>

                  {/* Result bar */}
                  <div className="flex items-center gap-4 bg-muted rounded-lg px-4 py-3 border border-border">
                    <TrendingUp className="h-5 w-5 text-primary shrink-0" />
                    <div>
                      <p className="text-base font-bold text-foreground">{cs.result}</p>
                      <p className="text-xs text-muted-foreground">Over {cs.timeline}</p>
                    </div>
                  </div>

                  <Button
                    variant="outline"
                    size="sm"
                    className="w-full border-primary/30 text-primary hover:bg-primary hover:text-primary-foreground transition-all group-hover:border-primary"
                    asChild
                  >
                    <a href={cs.href}>
                      Read Full Case Study <ArrowRight className="ml-2 h-4 w-4" />
                    </a>
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* View all link */}
        <div className="mt-12 text-center">
          <Button size="lg" asChild>
            <a href="#insights-cta">
              View All Case Studies & Insights <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
});

CaseStudiesFeatured.displayName = "CaseStudiesFeatured";

export default CaseStudiesFeatured;
