import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, Globe, ArrowRight, ChevronRight, Home } from "lucide-react";

const cities = [
  { label: "Warrington", slug: "/locations-warrington" },
  { label: "Manchester",  slug: "/locations-manchester" },
  { label: "Liverpool",   slug: "/locations-liverpool" },
  { label: "Birmingham",  slug: "/locations-birmingham" },
  { label: "Leeds",       slug: "/locations-leeds" },
  { label: "Sheffield",   slug: "/locations-sheffield" },
  { label: "London",      slug: "/locations-london" },
];

const LocationsHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="locations-hero"
      className="relative py-20 md:py-32 border-t border-border bg-background overflow-hidden"
    >
      {/* Subtle dot-grid texture */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(var(--border)) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
          opacity: 0.55,
        }}
      />

      {/* Green gradient accent — top-right */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-32 -right-32 h-80 w-80 rounded-full blur-3xl"
        style={{
          background:
            "radial-gradient(circle, hsl(84 74% 58% / 0.12) 0%, transparent 70%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl">

          {/* Breadcrumb */}
          <motion.nav
            aria-label="Breadcrumb"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, ease: "easeOut" }}
            className="mb-6 flex items-center gap-1.5 text-xs text-muted-foreground"
          >
            <Link to="/" className="hover:text-foreground transition-colors duration-150">
              Home
            </Link>
            <ChevronRight className="h-3 w-3 shrink-0" aria-hidden="true" />
            <span className="text-foreground font-medium" aria-current="page">
              Locations
            </span>
          </motion.nav>

          {/* Eyebrow label */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut" }}
          >
            <Badge
              variant="outline"
              className="mb-6 inline-flex items-center gap-1.5 border-border text-muted-foreground text-xs uppercase tracking-widest font-medium px-3 py-1"
            >
              <Globe className="h-3 w-3" />
              UK-Wide Consultancy
            </Badge>
          </motion.div>

          {/* H1 headline */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.08 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight tracking-tight"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            SEO Consultant{" "}
            <span
              className="inline-block"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              Across the UK
            </span>
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.18 }}
            className="mt-6 text-lg md:text-xl text-muted-foreground leading-relaxed max-w-2xl"
          >
            Independent SEO consultancy serving businesses in Warrington,
            Manchester, Liverpool, Birmingham, Leeds, Sheffield, and London.
          </motion.p>

          {/* City pill row — each links to its location page */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.28 }}
            className="mt-8 flex flex-wrap gap-2"
            aria-label="Cities served"
          >
            {cities.map((city, i) => (
              <Link
                key={city.label}
                to={city.slug}
                className="inline-flex items-center gap-1 rounded-md border border-border bg-muted px-3 py-1 text-xs font-medium text-foreground hover:border-primary/50 hover:bg-primary/10 hover:text-primary transition-colors duration-200"
                style={{ animationDelay: `${0.28 + i * 0.05}s` }}
              >
                <MapPin className="h-3 w-3 text-muted-foreground" />
                {city.label}
              </Link>
            ))}
          </motion.div>

          {/* CTA block */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.42 }}
            className="mt-10 flex flex-wrap items-center gap-4"
          >
            {/* Primary CTA — scroll to city grid */}
            <Button
              size="lg"
              asChild
              className="text-sm font-semibold h-11 px-7"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                color: "hsl(225 28% 14%)",
                border: "none",
              }}
            >
              <a href="#city-locations" className="inline-flex items-center gap-2">
                Find Your City
                <ArrowRight className="h-4 w-4" />
              </a>
            </Button>

            {/* Secondary CTA — FREE GBP AUDIT verbatim */}
            <Button
              size="lg"
              variant="outline"
              asChild
              className="text-sm font-semibold h-11 px-7 border-border text-foreground hover:bg-muted"
            >
              <a href="/contact" className="inline-flex items-center gap-2">
                FREE GBP AUDIT
              </a>
            </Button>
          </motion.div>

          {/* Trust note */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.56 }}
            className="mt-6 text-xs text-muted-foreground"
          >
            I work directly with your business — no account managers, no
            subcontractors. Just independent SEO expertise.
          </motion.p>
        </div>
      </div>
    </section>
  );
});

LocationsHero.displayName = "LocationsHero";

export default LocationsHero;
