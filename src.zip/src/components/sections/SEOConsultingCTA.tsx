import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle, MessageSquare, Book, Key } from "lucide-react";

const trustPoints = [
  "No account managers — you work directly with me",
  "Independent consultant, not an agency",
  "Based in Warrington, Cheshire — serving UK businesses nationwide",
];

const SEOConsultingCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seoconsulting-cta"
      className="relative py-20 md:py-32 border-t border-border bg-[hsl(225_28%_14%)]"
    >
      {/* Subtle dot-grid texture */}
      <div
        className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(84 74% 60%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
        aria-hidden="true"
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          {/* Eyebrow */}
          <motion.span
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut" }}
            className="inline-block text-xs uppercase tracking-[0.2em] text-white/80 mb-5 font-medium"
          >
            SEO Consulting Enquiry
          </motion.span>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 18 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.08 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight max-w-2xl mx-auto"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Ready to Discuss Your SEO?
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.16 }}
            className="mt-5 text-base md:text-lg text-white/80 leading-relaxed max-w-xl mx-auto"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Book a no-obligation conversation with Gregg to explore whether SEO
            consulting is the right fit for your business.
          </motion.p>

          {/* Trust points */}
          <motion.ul
            initial={{ opacity: 0, y: 14 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.24 }}
            className="mt-8 flex flex-col sm:flex-row sm:flex-wrap justify-center gap-3 sm:gap-4"
            aria-label="Key consultant facts"
          >
            {trustPoints.map((point) => (
              <li
                key={point}
                className="flex items-center gap-2 text-sm text-white/80"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                <CheckCircle
                  className="h-4 w-4 shrink-0"
                  style={{ color: "hsl(84 74% 60%)" }}
                  aria-hidden="true"
                />
                <span>{point}</span>
              </li>
            ))}
          </motion.ul>

          {/* CTA buttons */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.32 }}
            className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            {/* Primary CTA */}
            <Button
              size="lg"
              asChild
              className="h-12 px-8 text-base font-semibold rounded-md border-0 text-[hsl(225_28%_14%)] hover:opacity-90 transition-opacity shadow-[0_0_32px_hsl(84_74%_60%_/_0.28)] hover:shadow-[0_0_40px_hsl(84_74%_60%_/_0.42)]"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 60%), hsl(119 35% 61%))",
                fontFamily: "Inter, sans-serif",
              }}
            >
              <Link to="/contact">
                <MessageSquare className="mr-2 h-4 w-4" aria-hidden="true" />
                Enquire Now
              </Link>
            </Button>

            {/* Secondary CTA */}
            <Button
              size="lg"
              variant="outline"
              asChild
              className="h-12 px-8 text-base font-medium rounded-md bg-transparent text-white border-white/25 hover:border-white/50 hover:bg-white/5 transition-all"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              <Link to="/services-seo-audit">
                Free SEO Audit
                <ArrowRight className="ml-2 h-4 w-4" aria-hidden="true" />
              </Link>
            </Button>
          </motion.div>

          {/* Reassurance note */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.7, ease: "easeOut", delay: 0.42 }}
            className="mt-6 text-sm text-white/80"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            No obligation. No sales pitch. Just a straightforward conversation
            about your SEO.
          </motion.p>
        </div>
      </div>
    </section>
  );
});

SEOConsultingCTA.displayName = "SEOConsultingCTA";

export default SEOConsultingCTA;
