import React from "react";
import { TrendingUp, Users, Target, Briefcase, Search, University } from "lucide-react";

const stats = [
  { value: "70,000+", label: "Active businesses in Sheffield city region" },
  { value: "£17bn", label: "Sheffield City Region economy GVA" },
  { value: "1.8M+", label: "Population in South Yorkshire" },
  { value: "Top 5", label: "UK cities for tech startup growth" },
];

const insights = [
  {
    icon: TrendingUp,
    title: "Competitive but Winnable",
    body: "Sheffield's SEO landscape is competitive in sectors like manufacturing, professional services, and hospitality — but nowhere near as saturated as London or Manchester. There is real opportunity for businesses that invest in structured, strategic SEO now.",
  },
  {
    icon: Users,
    title: "Locally-Driven Search Behaviour",
    body: "Sheffield consumers actively search for local providers. Queries like 'Sheffield accountant', 'solicitor Sheffield' and 'best restaurant near me Sheffield' drive high purchase intent traffic every day — and most local businesses are not capturing it.",
  },
  {
    icon: Target,
    title: "Rich in High-Value Niches",
    body: "From advanced manufacturing and cutlery heritage to digital agencies and healthcare, Sheffield has deep sector clusters. Targeting niche, industry-specific keywords in this city yields excellent organic conversion rates.",
  },
  {
    icon: Briefcase,
    title: "Growing Digital Adoption",
    body: "Sheffield's business community is rapidly embracing digital marketing. University spin-outs, creative agencies, and professional firms are all competing for the same search real estate — making expert SEO a critical investment.",
  },
];

const SheffieldEcosystem = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-3">
            Sheffield Business Ecosystem
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground">
            Why Sheffield Businesses Need Expert SEO
          </h2>
          <p className="mt-4 text-muted-foreground text-lg leading-relaxed">
            Sheffield is one of the UK's fastest-evolving cities. Understanding the local digital landscape — its search patterns, competitive gaps, and audience behaviours — is the foundation of effective SEO here.
          </p>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="bg-background rounded-xl p-6 text-center shadow-card border border-border"
            >
              <div className="text-3xl md:text-4xl font-bold text-primary mb-2">
                {stat.value}
              </div>
              <div className="text-sm text-muted-foreground leading-snug">
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Insights grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {insights.map((insight) => {
            const Icon = insight.icon;
            return (
              <div
                key={insight.title}
                className="bg-background rounded-xl p-8 shadow-card border border-border hover-lift"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 mb-4">
                  <Icon className="h-6 w-6 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-foreground mb-3">
                  {insight.title}
                </h3>
                <p className="text-muted-foreground leading-relaxed">
                  {insight.body}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
});

SheffieldEcosystem.displayName = "SheffieldEcosystem";
export default SheffieldEcosystem;
