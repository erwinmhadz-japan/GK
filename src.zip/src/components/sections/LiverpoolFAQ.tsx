import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { HelpCircle, Triangle } from "lucide-react";

const faqs = [
  {
    question: "How long does local SEO take to show results in Liverpool?",
    answer:
      "Most Liverpool businesses see meaningful improvements in local rankings within 3–6 months, with the most significant gains typically occurring between months 4 and 9. Factors like your current domain authority, competitive density in your sector, and the technical health of your site all influence the timeline. We provide monthly reporting so you can track progress transparently throughout.",
  },
  {
    question: "Do you work with businesses outside Liverpool city centre?",
    answer:
      "Absolutely. We serve the full Liverpool City Region — including Wirral, Knowsley, Sefton, Halton, and St Helens — as well as surrounding areas like Warrington, Chester, and across the wider North West. Whether you're based in the Baltic Triangle, Birkenhead, or Bootle, our local SEO strategy is tailored to your specific location and target audience.",
  },
  {
    question: "What makes your Liverpool SEO approach different from larger agencies?",
    answer:
      "As an independent consultant, you work directly with a senior SEO strategist — not a junior account manager passing messages up the chain. There's no overhead from a large agency model, which means more of your budget goes into actual work. Our deep understanding of the Liverpool market, its search behaviours, and the competitive dynamics across Merseyside sectors gives you a genuine local edge.",
  },
  {
    question: "Can you help my Liverpool business appear in AI search results (ChatGPT, Perplexity, Google AI Overviews)?",
    answer:
      "Yes. Alongside traditional local SEO, we specialise in AI search optimisation — ensuring your Liverpool business is cited and referenced by AI tools. This includes structured data implementation, entity-based SEO, and building the kind of authoritative content signals that AI platforms draw from. It's an increasingly important channel for local visibility.",
  },
  {
    question: "What does a Liverpool SEO project typically cost?",
    answer:
      "SEO investment varies based on your goals, competition level, and the scope of work required. We offer flexible engagement models — from one-off technical SEO audits and strategy packages to ongoing monthly retainers. For most Liverpool SMEs, monthly retainers start from £750–£1,500. We're transparent about pricing from the first conversation — no surprise invoices.",
  },
];

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((faq) => ({
    "@type": "Question",
    name: faq.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: faq.answer,
    },
  })),
};

const LiverpoolFAQ = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="liverpool-faq"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
      aria-label="Liverpool SEO frequently asked questions"
    >
      {/* FAQ JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />

      <div className="container">
        <div className="max-w-2xl mx-auto text-center mb-16">
          <div className="flex justify-center mb-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-primary/10">
              <HelpCircle className="h-6 w-6 text-primary" />
            </div>
          </div>
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Common Questions
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">
            Liverpool SEO — Frequently Asked Questions
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Answers to the questions we hear most from Liverpool businesses exploring SEO for the first time or looking to switch consultant.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full space-y-3">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="bg-background border border-border rounded-xl px-6 shadow-soft"
              >
                <AccordionTrigger className="text-left font-medium text-foreground py-5 hover:no-underline">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed pb-5">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          <div className="mt-10 text-center">
            <p className="text-muted-foreground text-sm">
              Have a question not answered here?{" "}
              <a href="/contact" className="text-primary font-medium hover:underline">
                Get in touch directly →
              </a>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
});

LiverpoolFAQ.displayName = "LiverpoolFAQ";

export default LiverpoolFAQ;
