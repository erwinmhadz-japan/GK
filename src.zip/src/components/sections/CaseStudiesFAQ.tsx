import React from "react";
import { HelpCircle } from "lucide-react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "What types of case studies do you publish?",
    answer:
      "We publish detailed case studies across five primary sectors: legal, healthcare, property, financial services, and B2B technology. Each case study documents the initial SEO challenge, the strategic approach taken (local SEO, technical SEO, content strategy, AI search optimisation, or entity SEO), the timeline, and the measurable outcomes — including organic traffic growth, ranking improvements, and lead volume changes. Anonymised versions are available for clients who prefer confidentiality.",
  },
  {
    question: "How quickly can I expect similar results for my business?",
    answer:
      "Results vary by starting position, industry competition, and the scope of the engagement. Most clients on a monthly retainer see meaningful ranking improvements within 3–6 months, with substantial traffic gains by month 9–12. Technical SEO fixes often produce quicker wins (6–12 weeks), while content strategy and entity SEO programmes deliver compounding results over 12–18 months. Every case study includes a timeline so you can benchmark expectations for your specific sector.",
  },
  {
    question: "How do I get started — do you take on all types of businesses?",
    answer:
      "We work with established businesses that are serious about long-term organic growth — typically professional services firms, healthcare providers, property companies, financial services, and B2B organisations. We do not work with businesses that require black-hat or manipulative tactics. If you'd like to discuss whether your business is a good fit, the best next step is to visit the contact page and request a consultation. We'll review your current SEO position and outline what a realistic results-driven engagement could look like.",
  },
];

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map(({ question, answer }) => ({
    "@type": "Question",
    name: question,
    acceptedAnswer: {
      "@type": "Answer",
      text: answer,
    },
  })),
};

const CaseStudiesFAQ = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="case-studies-faq"
      className="relative py-20 md:py-32 border-t border-border bg-background"
      aria-label="Frequently asked questions about case studies"
    >
      {/* FAQ JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />

      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start">
          {/* Left column */}
          <div>
            <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4">
              Common Questions
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-6">
              Frequently Asked Questions
            </h2>
            <p className="text-muted-foreground text-base md:text-lg leading-relaxed mb-8">
              Before committing to an engagement, most clients want to understand what kind
              of results they can realistically expect. These answers cover the most common
              questions we receive about our case study work and client engagement process.
            </p>

            {/* Quick links */}
            <div className="flex flex-col gap-3">
              <p className="text-sm font-semibold text-foreground">Explore further:</p>
              <ul className="flex flex-col gap-2 text-sm">
                <li>
                  <a href="#industries-cta" className="text-primary hover:underline underline-offset-4 font-medium">
                    Industries we serve →
                  </a>
                </li>
                <li>
                  <a href="/services" className="text-primary hover:underline underline-offset-4 font-medium">
                    Services overview →
                  </a>
                </li>
                <li>
                  <a href="#insights-cta" className="text-primary hover:underline underline-offset-4 font-medium">
                    All insights &amp; case studies →
                  </a>
                </li>
              </ul>
            </div>
          </div>

          {/* Right column — accordion */}
          <div>
            <Accordion type="single" collapsible className="w-full space-y-1">
              {faqs.map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="border border-border rounded-lg px-2 data-[state=open]:bg-muted/50"
                >
                  <AccordionTrigger className="text-left font-semibold text-foreground text-sm md:text-base py-5 gap-3">
                    <span className="flex items-center gap-3">
                      <HelpCircle className="h-4 w-4 shrink-0 text-primary" />
                      {faq.question}
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground text-sm md:text-base leading-relaxed pb-5 pr-2">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </div>
    </section>
  );
});

CaseStudiesFAQ.displayName = "CaseStudiesFAQ";

export default CaseStudiesFAQ;
