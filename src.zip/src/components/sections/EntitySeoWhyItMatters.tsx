import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Network, Brain, Globe, Sparkles, ArrowRight, Layers, Building, Search } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (delay: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut", delay },
  }),
};

const signals = [
  {
    icon: Network,
    label: "Knowledge Graph",
    body:
      "Google's Knowledge Graph contains billions of real-world entities — people, organisations, places, and concepts. When your brand is recognised as a verified entity, it gains a persistent, trustworthy presence that keyword-optimised pages alone cannot achieve.",
  },
  {
    icon: Brain,
    label: "MUM & Gemini",
    body:
      "Google's Multitask Unified Model and Gemini process language by understanding relationships between entities, not by matching strings of text. Businesses with well-defined, cross-referenced entity signals are interpreted with greater accuracy and relevance.",
  },
  {
    icon: Sparkles,
    label: "AI Overviews",
    body:
      "Google's AI Overviews draw directly from the entity graph. To appear in AI-generated responses, your brand must be an established, corroborated entity — cited consistently across authoritative sources, structured data, and co-occurrence signals.",
  },
  {
    icon: Globe,
    label: "LLM Citation",
    body:
      "Large language models including ChatGPT, Perplexity, and Copilot generate answers by drawing on content that references named entities. Brands with strong entity presence are cited more often, increasing visibility in AI-driven discovery channels.",
  },
];

const EntitySeoWhyItMatters = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="entity-seo-why-it-matters"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Two-column editorial header */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 mb-16 md:mb-20 items-start">

          {/* Left: heading column */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            custom={0}
            variants={fadeUp}
          >
            <span
              className="inline-block text-xs uppercase tracking-[0.2em] font-medium mb-5"
              style={{ color: "hsl(214 32% 60%)" }}
            >
              The Shift in Search
            </span>
            <h2 className="text-3xl md:text-4xl lg:text-[2.6rem] font-bold leading-tight text-foreground max-w-xl">
              Why Entity SEO Matters Now
            </h2>
          </motion.div>

          {/* Right: editorial intro */}
          <motion.div
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-80px" }}
            custom={0.12}
            variants={fadeUp}
            className="flex flex-col justify-start"
          >
            <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
              Search has moved well beyond keyword matching. Google's understanding of the
              web is now fundamentally entity-based — built on a structured graph of
              real-world things and the relationships between them. Businesses that treat SEO
              as keyword optimisation alone are working against an engine that has already
              moved on.
            </p>
            <p className="text-base md:text-lg text-muted-foreground leading-relaxed mt-4">
              Entity SEO is about ensuring your brand, your expertise, and your content are
              understood — not just indexed. That distinction is becoming the single most
              important factor in organic and AI-driven search visibility for competitive UK
              sectors.
            </p>
          </motion.div>

        </div>

        {/* Feature callout band — 4 signal cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {signals.map((signal, i) => {
            const Icon = signal.icon;
            return (
              <motion.div
                key={signal.label}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-60px" }}
                custom={i * 0.1}
                variants={fadeUp}
                className="group relative rounded-md border border-border bg-background p-7 md:p-8 transition-all duration-300 hover:shadow-[0_4px_24px_rgba(25,31,56,0.10)]"
              >
                {/* Muted blue accent line */}
                <div
                  className="absolute top-0 left-0 w-1 h-full rounded-l-md"
                  style={{ background: "hsl(214 32% 60% / 0.35)" }}
                />

                <div className="flex items-start gap-4">
                  <div
                    className="flex-shrink-0 flex items-center justify-center w-10 h-10 rounded-md"
                    style={{ background: "hsl(214 32% 60% / 0.12)" }}
                  >
                    <Icon
                      className="h-5 w-5"
                      style={{ color: "hsl(214 32% 60%)" }}
                    />
                  </div>

                  <div>
                    <h3 className="text-base font-semibold text-foreground mb-2">
                      {signal.label}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {signal.body}
                    </p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Editorial bridge section */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          custom={0.1}
          variants={fadeUp}
          className="mt-14 md:mt-16 grid grid-cols-1 lg:grid-cols-2 gap-10 lg:gap-16 items-center"
        >
          {/* Left: contextual callout */}
          <div
            className="rounded-md border border-border p-8 md:p-10"
            style={{ background: "hsl(225 28% 14% / 0.04)" }}
          >
            <div className="flex items-center gap-3 mb-5">
              <Layers
                className="h-5 w-5 flex-shrink-0"
                style={{ color: "hsl(214 32% 60%)" }}
              />
              <span
                className="text-xs uppercase tracking-[0.18em] font-medium"
                style={{ color: "hsl(214 32% 60%)" }}
              >
                From Keywords to Entities
              </span>
            </div>
            <p className="text-foreground font-medium text-base md:text-lg leading-relaxed">
              "Google no longer just ranks pages that contain a keyword. It ranks entities
              it understands — brands and concepts with consistent, corroborated signals
              across the web."
            </p>
            <p className="mt-4 text-sm text-muted-foreground">
              This shift is most consequential in sectors where trust and authority are
              central buying factors — law, healthcare, finance, and professional services —
              precisely the UK markets where entity-based visibility offers the clearest
              competitive advantage.
            </p>
          </div>

          {/* Right: connection to AI search */}
          <div>
            <h3 className="text-xl md:text-2xl font-semibold text-foreground mb-4 leading-snug">
              The connection to AI search visibility
            </h3>
            <p className="text-muted-foreground text-base leading-relaxed">
              Entity authority is not only a traditional ranking signal — it is the
              foundation of visibility in AI-generated results. When ChatGPT, Perplexity, or
              Google's AI Overviews compose an answer, they draw on entities they can verify
              and contextualise. Businesses with a weak entity footprint are routinely
              omitted, regardless of how well their pages rank for individual keywords.
            </p>
            <p className="text-muted-foreground text-base leading-relaxed mt-4">
              Building entity authority now means preparing for the AI-dominated search
              landscape that is already here for many UK sectors — and approaching fast for
              the rest.
            </p>
            <Link
              to="/ai-search-optimisation"
              className="inline-flex items-center gap-2 mt-6 text-sm font-medium transition-colors duration-200"
              style={{ color: "hsl(214 32% 60%)" }}
            >
              Explore my AI Search Optimisation service
              <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </motion.div>

      </div>
    </section>
  );
});

EntitySeoWhyItMatters.displayName = "EntitySeoWhyItMatters";

export default EntitySeoWhyItMatters;
