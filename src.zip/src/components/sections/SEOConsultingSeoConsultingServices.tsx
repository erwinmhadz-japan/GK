import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ChevronRight, Search, FileText, Settings, Code, Globe, Lightbulb, MapPin, Zap, BarChart, Building, Section } from "lucide-react";

interface ServiceItem {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  route: string;
  index: number;
}

const services: ServiceItem[] = [
  {
    icon: Search,
    title: "SEO Consulting",
    description:
      "Strategic SEO direction tailored to your business goals — delivered directly by Gregg, not delegated to a junior team. From initial audit through to long-term growth strategy.",
    route: "/seo-consulting",
    index: 0,
  },
  {
    icon: FileText,
    title: "SEO Audit",
    description:
      "A thorough, independent audit of your site's current SEO performance — covering technical health, content gaps, backlink profile, and commercial opportunity.",
    route: "/seo-audit",
    index: 1,
  },
  {
    icon: BarChart,
    title: "SEO Retainer",
    description:
      "Ongoing consulting on a monthly retainer basis — consistent strategic input, priority access, and a clear reporting framework without agency overhead.",
    route: "/seo-retainer",
    index: 2,
  },
  {
    icon: Settings,
    title: "Technical SEO",
    description:
      "Resolving the foundational technical issues that prevent Google from crawling, indexing, and ranking your site — including Core Web Vitals, crawl architecture, and structured data.",
    route: "/technical-seo",
    index: 3,
  },
  {
    icon: Code,
    title: "Schema Markup",
    description:
      "Implementation of structured data to help search engines — and AI systems — understand your content accurately. Particularly valuable for regulated sectors such as law and healthcare.",
    route: "/schema-markup",
    index: 4,
  },
  {
    icon: Lightbulb,
    title: "Entity SEO",
    description:
      "Building topical authority and entity recognition so Google understands who you are, what you do, and which concepts your site should rank for — beyond individual keywords.",
    route: "/entity-seo",
    index: 5,
  },
  {
    icon: FileText,
    title: "Content Strategy",
    description:
      "A structured content plan aligned with your keyword landscape, user intent, and conversion goals — designed to build lasting organic visibility rather than volume for its own sake.",
    route: "/content-strategy",
    index: 6,
  },
  {
    icon: MapPin,
    title: "Local SEO",
    description:
      "Improving visibility in local and near-me searches — for businesses serving clients across specific UK cities or regions where geographic relevance is commercially critical.",
    route: "/local-seo",
    index: 7,
  },
  {
    icon: Globe,
    title: "Digital PR",
    description:
      "Earning high-quality editorial coverage and links from relevant UK publications — building domain authority and brand credibility simultaneously.",
    route: "/digital-pr",
    index: 8,
  },
  {
    icon: Zap,
    title: "AI Search Optimisation",
    description:
      "Positioning your brand to appear in AI-generated answers across ChatGPT, Perplexity, Google AI Overviews, and Gemini — an emerging discipline that rewards early, structured investment.",
    route: "/ai-search-optimisation",
    index: 9,
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.07,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.5,
      ease: "easeOut",
    },
  },
};

const SEOConsultingSeoConsultingServices = React.forwardRef<HTMLElement>(
  (props, ref) => {
    return (
      <section
        ref={ref}
        id="seoconsulting-seo-consulting-services"
        className="relative py-20 md:py-32 border-t border-border bg-muted"
      >
        <div className="container max-w-6xl mx-auto px-4">
          {/* Section header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="mb-14 md:mb-16"
          >
            <span className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium">
              Consulting disciplines
            </span>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground font-[Sora,sans-serif] max-w-2xl leading-tight">
              Ten areas of SEO practice — all delivered by Gregg directly
            </h2>
            <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
              Each engagement is handled personally. There are no account
              managers, no handoffs, and no junior teams. Clients engage
              directly with a senior practitioner across every one of these
              disciplines.
            </p>
          </motion.div>

          {/* Services list */}
          <motion.ol
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            className="grid grid-cols-1 md:grid-cols-2 gap-px bg-border rounded-md overflow-hidden shadow-[0_4px_24px_-6px_hsl(222_28%_11%_/_0.10),_0_1px_4px_hsl(222_28%_11%_/_0.05)]"
          >
            {services.map((service) => (
              <motion.li key={service.title} variants={itemVariants}>
                <Link
                  to={service.route}
                  className="group flex items-start gap-5 p-6 md:p-7 bg-background hover:bg-[hsl(220_16%_97%)] transition-colors duration-200 h-full"
                  aria-label={`Learn more about ${service.title}`}
                >
                  {/* Number + icon column */}
                  <div className="flex-shrink-0 flex flex-col items-center gap-2 pt-0.5">
                    <span
                      className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 group-hover:bg-primary/16 transition-colors duration-200"
                      aria-hidden="true"
                    >
                      <service.icon className="h-5 w-5 text-primary" />
                    </span>
                    <span className="text-xs font-medium tabular-nums text-muted-foreground">
                      {String(service.index + 1).padStart(2, "0")}
                    </span>
                  </div>

                  {/* Content */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2 mb-2">
                      <h3 className="text-base md:text-[1.05rem] font-semibold text-foreground leading-snug group-hover:text-primary transition-colors duration-200">
                        {service.title}
                      </h3>
                      <ChevronRight
                        className="h-4 w-4 text-muted-foreground flex-shrink-0 group-hover:text-primary group-hover:translate-x-0.5 transition-all duration-200"
                        aria-hidden="true"
                      />
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {service.description}
                    </p>
                  </div>
                </Link>
              </motion.li>
            ))}
          </motion.ol>

          {/* Footer note */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3, ease: "easeOut" }}
            className="mt-10 text-sm text-muted-foreground text-center"
          >
            Each of these disciplines can be engaged independently or as part
            of a broader consulting retainer.{" "}
            <Link
              to="/contact"
              className="text-foreground underline underline-offset-2 hover:text-primary transition-colors duration-200"
            >
              Discuss your requirements with Gregg →
            </Link>
          </motion.p>
        </div>
      </section>
    );
  }
);

SEOConsultingSeoConsultingServices.displayName =
  "SEOConsultingSeoConsultingServices";

export default SEOConsultingSeoConsultingServices;
