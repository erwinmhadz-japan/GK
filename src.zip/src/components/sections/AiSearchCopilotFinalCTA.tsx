import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle, Book, Search, View } from "lucide-react";

const benefits = [
  "Full Bing crawl and indexing audit",
  "Structured data review and implementation",
  "Copilot citation monitoring setup",
  "Content strategy for AI search inclusion",
];

const AiSearchCopilotFinalCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="copilot-cta"
      aria-label="Copilot visibility call to action"
      src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=1920&h=1080&fit=crop"
      alt="Team collaborating around laptops in a modern office"
      imgProps={{ fetchpriority: "auto", loading: "lazy" }}
      className="py-24 md:py-36"
    >
      <div className="container relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4 font-medium">
            Get Started Today
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-5">
            Start Appearing in Microsoft Copilot Responses
          </h2>
          <p className="text-white/90 text-base md:text-lg leading-relaxed mb-8 max-w-2xl mx-auto">
            Your competitors are already being cited by Copilot. Get a tailored Copilot visibility audit and action plan — designed around your industry, your site's current technical state, and your target queries.
          </p>

          <div className="flex flex-wrap justify-center gap-3 mb-10">
            {benefits.map((b) => (
              <div key={b} className="flex items-center gap-2 text-sm text-white/90">
                <CheckCircle className="h-4 w-4 text-primary shrink-0" />
                {b}
              </div>
            ))}
          </div>

          <div className="flex flex-wrap justify-center gap-4">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold px-8"
              asChild
            >
              <a href="/services-ai-search-optimisation">
                View AI Search Services
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10 font-semibold px-8"
              asChild
            >
              <a href="/contact">Book a Free Consultation</a>
            </Button>
          </div>

          <p className="mt-6 text-sm text-white/80">
            Independent specialist · No retainer lock-in · Transparent pricing
          </p>
        </div>
      </div>
    </ImageBackground>
  );
});

AiSearchCopilotFinalCTA.displayName = "AiSearchCopilotFinalCTA";
export default AiSearchCopilotFinalCTA;
