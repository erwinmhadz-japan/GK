import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, CheckCircle, Search, Contact } from "lucide-react";

const trustPoints = [
  "Prioritised, actionable issue log — not a raw data dump",
  "Direct access to the consultant, not an account manager",
  "Independent advice with no tool or retainer upsell",
  "UK-based, serving businesses nationwide from Warrington",
];

const TechnicalSEOCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="technical-seocta"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      {/* Subtle dot-grid texture */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-30"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(var(--border)) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left — headline + trust list */}
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.65, ease: "easeOut" }}
          >
            {/* Eyebrow */}
            <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
              Technical SEO Consultant UK
            </span>

            <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight mb-5 max-w-xl">
              Get a Technical SEO Audit
            </h2>

            <p className="text-base md:text-lg text-muted-foreground leading-relaxed mb-8 max-w-lg">
              Identify exactly what is holding your site back — with a
              prioritised, actionable report.
            </p>

            {/* Trust points */}
            <ul className="space-y-3 mb-8">
              {trustPoints.map((point) => (
                <li key={point} className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <span className="text-sm text-foreground">{point}</span>
                </li>
              ))}
            </ul>

            {/* CTA buttons */}
            <div className="flex flex-col sm:flex-row gap-3">
              <Button
                asChild
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 shadow-md transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5"
              >
                <Link to="/contact">
                  Contact Gregg
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>

              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-border text-foreground hover:bg-accent hover:text-accent-foreground transition-all duration-300"
              >
                <Link to="/contact">
                  <Search className="mr-2 h-4 w-4" />
                  Free SEO Audit
                </Link>
              </Button>
            </div>

            {/* Reassurance line */}
            <p className="mt-5 text-xs text-muted-foreground">
              Independent consultant — no agency overhead, no obligation.
            </p>
          </motion.div>

          {/* Right — dark panel with qualifier text */}
          <motion.div
            initial={{ opacity: 0, y: 28 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.15 }}
          >
            <div
              className="relative rounded-md overflow-hidden"
              style={{
                background:
                  "linear-gradient(160deg, hsl(225 28% 14%) 0%, hsl(231 9% 16%) 60%, hsl(214 32% 30%) 100%)",
              }}
            >
              {/* Accent line top */}
              <div
                className="absolute top-0 left-0 right-0 h-[3px] rounded-t-md"
                style={{
                  background:
                    "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                }}
              />

              <div className="p-8 md:p-10">
                <span className="inline-block text-xs uppercase tracking-[0.2em] text-white/60 mb-4 font-medium">
                  Who this is for
                </span>

                <h3 className="text-xl md:text-2xl font-bold text-white mb-6 leading-snug">
                  Businesses with a technically sound site rank more reliably —
                  and convert more consistently.
                </h3>

                <div className="space-y-5">
                  {[
                    {
                      label: "Law firms &amp; solicitors",
                      body: "Competitive practice-area keywords demand flawless crawlability and strong Core Web Vitals.",
                    },
                    {
                      label: "Healthcare &amp; private clinics",
                      body: "YMYL content requires clean technical signals to earn and maintain ranking in trust-led searches.",
                    },
                    {
                      label: "Financial services",
                      body: "Complex site architectures and compliance constraints need a specialist to unblock indexation at scale.",
                    },
                    {
                      label: "B2B professional services",
                      body: "Slow rendering, poor structured data, and crawl waste are silent conversion killers in B2B.",
                    },
                  ].map((item) => (
                    <div
                      key={item.label}
                      className="border-l-2 pl-4"
                      style={{
                        borderColor: "hsl(84 74% 58% / 0.5)",
                      }}
                    >
                      <p
                        className="text-sm font-semibold text-white mb-1"
                        dangerouslySetInnerHTML={{ __html: item.label }}
                      />
                      <p className="text-sm text-white/80 leading-relaxed">
                        {item.body}
                      </p>
                    </div>
                  ))}
                </div>

                {/* Bottom inline link */}
                <div className="mt-8 pt-6 border-t border-white/10">
                  <p className="text-xs text-white/60">
                    I work with UK businesses of all sizes — from growing SMEs
                    to established national brands. Based in Warrington, Cheshire.{" "}
                    <Link
                      to="/about"
                      className="text-white/80 underline underline-offset-2 hover:text-white transition-colors"
                    >
                      About Gregg →
                    </Link>
                  </p>
                </div>
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
});

TechnicalSEOCTA.displayName = "TechnicalSEOCTA";

export default TechnicalSEOCTA;
