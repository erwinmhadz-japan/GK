import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, CheckCircle, Contact, Key } from "lucide-react";

const DigitalPrCTA = React.forwardRef<HTMLElement>((props, ref) => {
  const proofPoints = [
    "Bespoke strategy — no templated outreach",
    "Editorial link acquisition in publications that matter",
    "Senior consultant oversight on every campaign",
  ];

  return (
    <section
      ref={ref}
      id="digital-pr-cta"
      className="relative py-20 md:py-32 border-t border-border bg-[hsl(225_28%_14%)] overflow-hidden"
    >
      {/* Subtle background texture — dot grid pattern */}
      <div
        className="absolute inset-0 opacity-[0.06] pointer-events-none"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(84 74% 58%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
        aria-hidden="true"
      />

      {/* Subtle green glow accent top-right */}
      <div
        className="absolute -top-32 -right-32 w-96 h-96 rounded-full pointer-events-none"
        style={{
          background:
            "radial-gradient(circle, hsl(84 74% 58% / 0.12) 0%, transparent 70%)",
        }}
        aria-hidden="true"
      />

      {/* Subtle green glow accent bottom-left */}
      <div
        className="absolute -bottom-24 -left-24 w-80 h-80 rounded-full pointer-events-none"
        style={{
          background:
            "radial-gradient(circle, hsl(119 35% 61% / 0.10) 0%, transparent 70%)",
        }}
        aria-hidden="true"
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">

          {/* Eyebrow label */}
          <motion.span
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut" }}
            className="inline-block text-xs uppercase tracking-[0.2em] text-white/80 mb-6 font-medium"
          >
            Digital PR — Independent Consultant
          </motion.span>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight max-w-2xl mx-auto"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Let&rsquo;s Build Your Link Authority
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.2 }}
            className="mt-5 text-lg md:text-xl text-white/80 max-w-xl mx-auto leading-relaxed"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Talk to Gregg about a bespoke digital PR strategy for your business.
          </motion.p>

          {/* Proof points */}
          <motion.ul
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
            className="mt-8 flex flex-col sm:flex-row flex-wrap items-center justify-center gap-x-6 gap-y-3"
            aria-label="Key benefits"
          >
            {proofPoints.map((point, index) => (
              <li
                key={index}
                className="flex items-center gap-2 text-sm text-white/80"
                style={{ fontFamily: "Inter, sans-serif" }}
              >
                <CheckCircle
                  className="h-4 w-4 flex-shrink-0"
                  style={{ color: "hsl(84 74% 58%)" }}
                  aria-hidden="true"
                />
                <span>{point}</span>
              </li>
            ))}
          </motion.ul>

          {/* CTA button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.4 }}
            className="mt-10 flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Button
              size="lg"
              asChild
              className="text-base h-12 px-8 font-semibold rounded-md transition-all duration-300"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                color: "hsl(225 28% 14%)",
                boxShadow: "0 0 0 0 transparent",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.boxShadow =
                  "0 0 32px hsl(84 74% 58% / 0.28)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.boxShadow =
                  "0 0 0 0 transparent";
              }}
            >
              <Link to="/contact" className="flex items-center gap-2">
                Contact Me
                <ArrowRight className="h-4 w-4" aria-hidden="true" />
              </Link>
            </Button>

            <p className="text-sm text-white/80" style={{ fontFamily: "Inter, sans-serif" }}>
              No obligation — I&rsquo;ll respond within one working day.
            </p>
          </motion.div>

        </div>
      </div>
    </section>
  );
});

DigitalPrCTA.displayName = "DigitalPrCTA";

export default DigitalPrCTA;
