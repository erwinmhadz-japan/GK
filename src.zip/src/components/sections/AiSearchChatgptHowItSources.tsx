import React from "react";
import { Database, Globe, FileText, Network, Layers, Icon } from "lucide-react";

const sourcingSteps = [
  {
    icon: Database,
    title: "Pre-training Knowledge",
    description:
      "ChatGPT's base knowledge comes from its training data — a snapshot of the web, books, and structured sources up to its knowledge cut-off. Authoritative, frequently cited content is weighted more heavily in this foundation.",
  },
  {
    icon: Globe,
    title: "Real-Time Web Browsing",
    description:
      "With Browse enabled, ChatGPT fetches live web pages via Bing's index. Crawlable, well-structured pages with fast load times are far more likely to be retrieved and cited in a browsing session.",
  },
  {
    icon: Network,
    title: "Retrieval-Augmented Generation (RAG)",
    description:
      "ChatGPT uses RAG to pull relevant chunks of text from retrieved pages and weave them into its response. Clear headings, concise paragraphs, and logically structured content dramatically improve chunk relevance.",
  },
  {
    icon: FileText,
    title: "Structured Data & Schema",
    description:
      "Schema.org markup (FAQPage, HowTo, Article, LocalBusiness) signals machine-readable intent, helping AI systems identify and extract the most relevant facts and answers from your page.",
  },
  {
    icon: Layers,
    title: "Citation & Source Attribution",
    description:
      "When ChatGPT cites a source, it links to the specific URL. Canonical URLs, clean site architecture, and clear entity signals increase the probability of attribution rather than paraphrase without credit.",
  },
];

const AiSearchChatgptHowItSources = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section ref={ref} className="relative py-20 md:py-32 border-t border-border bg-muted">
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            How it works
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            How ChatGPT Sources and Displays Information
          </h2>
          <p className="text-muted-foreground leading-relaxed">
            Understanding the mechanics behind ChatGPT&apos;s information retrieval is the first step toward optimising for it. Here are the five key sourcing layers.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {sourcingSteps.slice(0, 3).map(({ icon: Icon, title, description }) => (
            <div
              key={title}
              className="bg-card border border-border rounded-xl p-7 shadow-card hover-lift"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-5">
                <Icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="text-lg font-bold text-foreground mb-3">{title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
            </div>
          ))}
        </div>

        <div className="grid md:grid-cols-2 gap-6 mt-6 max-w-3xl mx-auto">
          {sourcingSteps.slice(3).map(({ icon: Icon, title, description }) => (
            <div
              key={title}
              className="bg-card border border-border rounded-xl p-7 shadow-card hover-lift"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-5">
                <Icon className="h-5 w-5 text-primary" />
              </div>
              <h3 className="text-lg font-bold text-foreground mb-3">{title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{description}</p>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <a
            href="/schema-markup"
            className="inline-flex items-center text-primary font-semibold hover:underline text-sm"
          >
            Learn about Schema Markup for AI visibility →
          </a>
        </div>
      </div>
    </section>
  );
});

AiSearchChatgptHowItSources.displayName = "AiSearchChatgptHowItSources";
export default AiSearchChatgptHowItSources;
