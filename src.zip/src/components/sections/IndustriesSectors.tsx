import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight, Gavel, HeartPulse, Home, TrendingUp, Briefcase, Building, Section, Text } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface Sector {
  label: string;
  target: string;
  icon: React.ComponentType<{ className?: string }>;
  tagline: string;
  challenge: string;
  keyword: string;
  ctaLabel: string;
}

const sectors: Sector[] = [
  {
    label: "Law Firms & Solicitors",
    target: "/law-firms",
    icon: Gavel,
    tagline: "SEO for regulated legal practices",
    challenge:
      "Legal SEO demands more than keyword targeting. Competing for high-stakes queries in a YMYL environment requires demonstrable E-E-A-T, robust schema markup, and a consultant who understands compliance constraints — not a generic agency approach.",
    keyword: "SEO for law firms UK",
    ctaLabel: "Explore Law Firm SEO",
  },
  {
    label: "Healthcare Clinics & Private Providers",
    target: "/healthcare-clinics",
    icon: HeartPulse,
    tagline: "SEO for private healthcare and clinics",
    challenge:
      "Private clinics and healthcare providers face exceptional scrutiny from Google's Quality Rater Guidelines. Building organic visibility requires clinical credibility signals, precise local SEO, and content that meets the highest YMYL standards.",
    keyword: "healthcare SEO UK",
    ctaLabel: "Explore Healthcare SEO",
  },
  {
    label: "Estate Agents & Property Services",
    target: "/estate-agents",
    icon: Home,
    tagline: "SEO for property professionals",
    challenge:
      "Estate agents operate in one of the most geographically competitive search landscapes in the UK. Ranking across multiple locations while maintaining a trustworthy brand presence requires a structured, locally-informed SEO strategy.",
    keyword: "estate agent SEO UK",
    ctaLabel: "Explore Estate Agent SEO",
  },
  {
    label: "Financial Services",
    target: "/financial-services",
    icon: TrendingUp,
    tagline: "SEO for FCA-regulated firms",
    challenge:
      "Financial services firms navigate both aggressive competition and strict regulatory boundaries. Organic growth in this sector demands deep sector knowledge, careful content governance, and authority-building that regulators and users alike can trust.",
    keyword: "financial services SEO UK",
    ctaLabel: "Explore Financial Services SEO",
  },
  {
    label: "B2B Professional Services",
    target: "/b2-b-professional-services",
    icon: Briefcase,
    tagline: "SEO for consultancies and professional firms",
    challenge:
      "B2B professional services firms sell expertise, not products. SEO here is about establishing individual authority, targeting decision-maker search intent, and building a pipeline of qualified enquiries — not chasing high-volume consumer traffic.",
    keyword: "B2B professional services SEO",
    ctaLabel: "Explore B2B SEO",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const headingVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
};

const IndustriesSectors = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="industries-sectors"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          className="max-w-2xl mb-14 md:mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={headingVariants}
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Sectors served
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-semibold text-foreground font-[Sora,sans-serif] leading-snug mb-4">
            SEO consulting for UK professional services
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-prose">
            Each sector below has its own page detailing the specific challenges, search dynamics,
            and approach Gregg King takes. Select your sector to explore the competitive landscape,
            E-E-A-T requirements, and how specialist SEO consulting is applied in your market.
          </p>
        </motion.div>

        {/* Sector cards — exactly 5, 2-column then full-width last on desktop */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-6"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          variants={containerVariants}
        >
          {sectors.map((sector, index) => {
            const Icon = sector.icon;
            const isLastOdd = index === sectors.length - 1 && sectors.length % 2 !== 0;

            return (
              <motion.div
                key={sector.label}
                variants={cardVariants}
                className={isLastOdd ? "md:col-span-2 md:max-w-[calc(50%-12px)]" : ""}
              >
                <Link
                  to={sector.target}
                  className="group block h-full"
                  aria-label={`Explore SEO consulting for ${sector.label}`}
                >
                  <article
                    className="
                      relative h-full bg-background border border-border rounded-md p-6 md:p-8
                      transition-all duration-300
                      hover:border-primary/50
                      hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%_/_0.10),0_1px_4px_hsl(222_28%_11%_/_0.05)]
                      hover:-translate-y-0.5
                    "
                  >
                    {/* Icon + badge row */}
                    <div className="flex items-start justify-between mb-5">
                      <div className="flex items-center justify-center h-11 w-11 rounded-md bg-primary/10 text-primary flex-shrink-0">
                        <Icon className="h-5 w-5" />
                      </div>
                      <Badge
                        variant="outline"
                        className="text-xs font-normal text-muted-foreground border-border hidden sm:inline-flex"
                      >
                        {sector.keyword}
                      </Badge>
                    </div>

                    {/* Text content */}
                    <h3 className="text-lg md:text-xl font-semibold text-foreground font-[Sora,sans-serif] mb-1 leading-snug">
                      {sector.label}
                    </h3>
                    <p className="text-xs uppercase tracking-[0.15em] text-muted-foreground mb-4 font-medium">
                      {sector.tagline}
                    </p>
                    <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                      {sector.challenge}
                    </p>

                    {/* Footer link row */}
                    <div className="mt-6 flex items-center gap-1.5 text-sm font-medium text-primary">
                      <span>{sector.ctaLabel}</span>
                      <ArrowRight
                        className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1"
                        aria-hidden="true"
                      />
                    </div>

                    {/* Subtle left accent bar */}
                    <span
                      className="absolute left-0 top-6 bottom-6 w-[3px] rounded-full bg-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300"
                      aria-hidden="true"
                    />
                  </article>
                </Link>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Subtle editorial footnote */}
        <motion.p
          className="mt-10 text-xs text-muted-foreground max-w-lg"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4, ease: "easeOut" }}
        >
          Working in a sector not listed here?{" "}
          <Link
            to="/contact"
            className="text-foreground underline underline-offset-2 hover:text-primary transition-colors duration-200"
          >
            Get in touch
          </Link>{" "}
          to discuss whether Gregg King's independent SEO consulting is the right fit for your business.
        </motion.p>
      </div>
    </section>
  );
});

IndustriesSectors.displayName = "IndustriesSectors";

export default IndustriesSectors;
