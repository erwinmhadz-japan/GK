import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ArrowRight, Bot, Brain, Globe, Sparkles, Cpu, Search, Section } from "lucide-react";
import { Badge } from "@/components/ui/badge";

interface Platform {
  name: string;
  description: string;
  editorial: string;
  icon: React.ComponentType<{ className?: string }>;
  to: string;
  tag: string;
}

const platforms: Platform[] = [
  {
    name: "ChatGPT",
    description: "OpenAI's conversational AI",
    editorial:
      "ChatGPT draws on a vast training corpus and live browsing to surface authoritative answers. Understanding how it selects and cites sources is increasingly relevant for UK businesses whose audiences use it for research and recommendations.",
    icon: Bot,
    to: "/chatgpt-visibility",
    tag: "OpenAI",
  },
  {
    name: "Perplexity",
    description: "Real-time AI search with citations",
    editorial:
      "Perplexity indexes the live web and surfaces cited answers in a format that differs materially from traditional search. Its citation model rewards content that is structured, substantive, and clearly attributed to a credible source.",
    icon: Globe,
    to: "/perplexity-visibility",
    tag: "Perplexity AI",
  },
  {
    name: "Google AI Overviews",
    description: "Google's generative search summaries",
    editorial:
      "AI Overviews appear above traditional results for a growing share of queries in the UK. Google synthesises content from a small pool of trusted sources — making topical authority and on-page clarity more consequential than ever.",
    icon: Brain,
    to: "/google-ai-overviews",
    tag: "Google",
  },
  {
    name: "Gemini",
    description: "Google's multimodal AI assistant",
    editorial:
      "Gemini integrates across Google's ecosystem — Search, Workspace, and Android — making it one of the most widely encountered AI surfaces for UK professionals. Its answer generation is closely tied to Google's existing quality signals.",
    icon: Sparkles,
    to: "/gemini-visibility",
    tag: "Google DeepMind",
  },
  {
    name: "Microsoft Copilot",
    description: "Microsoft's AI integrated across Bing and Windows",
    editorial:
      "Copilot draws on Bing's index and is embedded across Microsoft 365 and Edge. For B2B audiences working within the Microsoft ecosystem, Copilot is a significant and often overlooked AI discovery surface.",
    icon: Cpu,
    to: "/copilot-visibility",
    tag: "Microsoft",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: "easeOut" },
  },
};

const AISearchPlatforms = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="aisearch-platforms"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mb-12 md:mb-16"
        >
          <span className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground font-medium mb-4">
            The platforms reshaping search
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground font-[Sora,sans-serif] max-w-2xl leading-snug mb-4">
            Five AI Platforms. Five Distinct Visibility Challenges.
          </h2>
          <p className="text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
            Each AI search platform operates differently — different data sources, different citation logic, different ranking signals. Select a platform below to understand how it works and what shapes visibility within it.
          </p>
        </motion.div>

        {/* Platform cards grid — exactly 5 items */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {platforms.map((platform) => {
            const Icon = platform.icon;
            return (
              <motion.div key={platform.name} variants={itemVariants}>
                <Link
                  to={platform.to}
                  className="group flex flex-col h-full bg-background border border-border rounded-md p-6 transition-all duration-300 hover:border-primary/40 hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%_/_0.10),_0_1px_4px_hsl(222_28%_11%_/_0.05)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/60"
                  aria-label={`Learn about visibility in ${platform.name}`}
                >
                  {/* Icon + badge row */}
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 transition-colors duration-300 group-hover:bg-primary/20">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <Badge
                      variant="outline"
                      className="text-xs text-muted-foreground border-border font-normal"
                    >
                      {platform.tag}
                    </Badge>
                  </div>

                  {/* Platform name + sub-description */}
                  <div className="mb-3">
                    <h3 className="text-base md:text-lg font-semibold text-foreground font-[Sora,sans-serif] leading-snug mb-1">
                      {platform.name}
                    </h3>
                    <p className="text-xs text-muted-foreground uppercase tracking-wide">
                      {platform.description}
                    </p>
                  </div>

                  {/* Editorial paragraph */}
                  <p className="text-sm text-muted-foreground leading-relaxed flex-1 mb-5">
                    {platform.editorial}
                  </p>

                  {/* Inline link */}
                  <span className="inline-flex items-center gap-1.5 text-sm font-medium text-foreground group-hover:text-primary transition-colors duration-200">
                    Read the guide
                    <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-1" />
                  </span>
                </Link>
              </motion.div>
            );
          })}

          {/* Fifth card fills the last slot; on a 3-col grid the 5th sits in the final row.
              The grid is md:grid-cols-2 lg:grid-cols-3 so on lg the 5th card is alone in
              the third row. Centre it with a spacer approach handled via CSS order below. */}
        </motion.div>

        {/* Contextual editorial note */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3, ease: "easeOut" }}
          className="mt-10 text-sm text-muted-foreground max-w-xl"
        >
          These pages are intended as independent editorial references. For guidance on how to improve your brand's presence across these platforms,{" "}
          <Link
            to="/ai-search-optimisation"
            className="text-foreground underline underline-offset-2 hover:text-primary transition-colors duration-200"
          >
            see the AI search optimisation service
          </Link>
          .
        </motion.p>
      </div>
    </section>
  );
});

AISearchPlatforms.displayName = "AISearchPlatforms";

export default AISearchPlatforms;
