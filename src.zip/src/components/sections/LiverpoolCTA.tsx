import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { Phone, Mail, MapPin, ArrowRight, Clock, Contact, Search } from "lucide-react";

const contactDetails = [
  {
    icon: MapPin,
    label: "Liverpool Service Area",
    value: "Liverpool, Merseyside & North West",
  },
  {
    icon: Phone,
    label: "Phone",
    value: "+44 (0) 151 000 0000",
  },
  {
    icon: Mail,
    label: "Email",
    value: "hello@gregg-seo.co.uk",
  },
  {
    icon: Clock,
    label: "Response Time",
    value: "Within 1 business day",
  },
];

// LocalBusiness + Organization JSON-LD for Liverpool
const liverpoolSchema = [
  {
    "@context": "https://schema.org",
    "@type": ["LocalBusiness", "ProfessionalService"],
    name: "Gregg SEO Consulting — Liverpool",
    description:
      "Independent SEO consulting for Liverpool businesses. Local SEO, technical SEO, content strategy, and AI search optimisation serving Merseyside and the North West.",
    url: "https://gregg-seo.co.uk/locations/liverpool",
    telephone: "+441510000000",
    email: "hello@gregg-seo.co.uk",
    areaServed: [
      { "@type": "City", name: "Liverpool" },
      { "@type": "AdministrativeArea", name: "Merseyside" },
      { "@type": "AdministrativeArea", name: "North West England" },
    ],
    address: {
      "@type": "PostalAddress",
      addressLocality: "Liverpool",
      addressRegion: "Merseyside",
      addressCountry: "GB",
    },
    geo: {
      "@type": "GeoCoordinates",
      latitude: 53.4084,
      longitude: -2.9916,
    },
    openingHoursSpecification: [
      {
        "@type": "OpeningHoursSpecification",
        dayOfWeek: ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday"],
        opens: "09:00",
        closes: "18:00",
      },
    ],
    priceRange: "££",
    serviceArea: {
      "@type": "GeoCircle",
      geoMidpoint: {
        "@type": "GeoCoordinates",
        latitude: 53.4084,
        longitude: -2.9916,
      },
      geoRadius: "50000",
    },
  },
  {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "Gregg SEO Consulting",
    url: "https://gregg-seo.co.uk",
    logo: "https://gregg-seo.co.uk/logo.png",
    contactPoint: {
      "@type": "ContactPoint",
      contactType: "customer service",
      telephone: "+441510000000",
      email: "hello@gregg-seo.co.uk",
      areaServed: "GB",
      availableLanguage: "English",
    },
    sameAs: [
      "https://www.linkedin.com/company/gregg-seo",
    ],
  },
];

const LiverpoolCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="liverpool-cta"
      aria-label="Liverpool SEO contact and CTA section"
      src="https://images.unsplash.com/photo-1730851357916-3802b6405271?w=1920&h=1080&fit=crop"
      alt="Professional in a suit standing in an office — ready to help Liverpool businesses grow"
      imgProps={{ loading: "lazy" }}
      className="py-24 md:py-36"
    >
      {/* LocalBusiness + Organization JSON-LD */}
      {liverpoolSchema.map((schema, i) => (
        <script
          key={i}
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }}
        />
      ))}

      <div className="container relative z-10">
        <div className="max-w-4xl mx-auto">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-start">
            {/* Left — CTA copy */}
            <div>
              <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4 font-medium">
                Liverpool SEO Consultant
              </span>
              <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 leading-tight">
                Ready to Dominate Liverpool Search?
              </h2>
              <p className="text-lg text-white/90 mb-8 leading-relaxed">
                Whether you need a one-off audit or an ongoing SEO partner, let's talk about what's holding your Liverpool business back from page one — and how we fix it.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 mb-10">
                <Button
                  size="lg"
                  className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold px-8"
                  asChild
                >
                  <a href="/contact">
                    Start the Conversation
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </a>
                </Button>
                <Button
                  size="lg"
                  variant="outline"
                  className="bg-transparent text-white border-white hover:bg-white/10 font-semibold px-8"
                  asChild
                >
                  <a href="/services">Browse Services</a>
                </Button>
              </div>

              {/* Internal links */}
              <div className="flex flex-wrap gap-4 text-sm text-white/80">
                <a href="/locations" className="hover:text-white transition-colors hover:underline">
                  ← All Locations
                </a>
                <a href="/local-seo" className="hover:text-white transition-colors hover:underline">
                  Local SEO Services
                </a>
                <a href="#case-studies-cta" className="hover:text-white transition-colors hover:underline">
                  Case Studies
                </a>
              </div>
            </div>

            {/* Right — contact details card */}
            <div className="bg-background/90 backdrop-blur-sm rounded-2xl p-8 border border-border shadow-card">
              <h3 className="text-xl font-bold text-foreground mb-6">Liverpool Contact Details</h3>
              <div className="space-y-5">
                {contactDetails.map((detail) => {
                  const Icon = detail.icon;
                  return (
                    <div key={detail.label} className="flex items-start gap-4">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                      <div>
                        <div className="text-xs text-muted-foreground font-medium uppercase tracking-wide mb-0.5">
                          {detail.label}
                        </div>
                        <div className="text-foreground font-medium">{detail.value}</div>
                      </div>
                    </div>
                  );
                })}
              </div>
              <div className="mt-8 pt-6 border-t border-border">
                <Button
                  className="w-full bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
                  asChild
                >
                  <a href="/contact">Get Your Free Liverpool SEO Review</a>
                </Button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </ImageBackground>
  );
});

LiverpoolCTA.displayName = "LiverpoolCTA";

export default LiverpoolCTA;
