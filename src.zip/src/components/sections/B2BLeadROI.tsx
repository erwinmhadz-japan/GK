import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { DollarSign, TrendingUp, Users, BarChart, BadgeCheck, Handshake, Building } from "lucide-react";

const roiStats = [
  {
    icon: DollarSign,
    stat: "£150K+",
    label: "Avg. annual deal value in enterprise B2B",
    description:
      "A single enterprise consulting engagement secured through organic search can deliver returns far exceeding a year's SEO investment.",
  },
  {
    icon: TrendingUp,
    stat: "6–18 months",
    label: "Typical B2B SEO compound growth window",
    description:
      "Unlike paid ads that stop the moment billing stops, SEO compounds over time — ranking gains and entity authority accumulate month over month.",
  },
  {
    icon: Users,
    stat: "3× higher",
    label: "Close rate for inbound vs. outbound leads",
    description:
      "Prospects who discover you through organic search have self-qualified against your content. They arrive pre-sold on your expertise and far more likely to convert.",
  },
  {
    icon: BarChart,
    stat: "Top 3",
    label: "Organic positions capture 55%+ of clicks",
    description:
      "Decision-makers searching for specialist consultants rarely scroll past the first few results. Ranking authority determines which firms get evaluated.",
  },
  {
    icon: BadgeCheck,
    stat: "92%",
    label: "B2B buyers research online before contact",
    description:
      "Enterprise procurement teams validate firms through search before any outreach. Your organic visibility is your first commercial impression.",
  },
  {
    icon: Handshake,
    stat: "60%+ lift",
    label: "Increase in qualified lead quality with thought leadership SEO",
    description:
      "Firms that rank for substantive thought leadership content attract buyers who are further through the decision process and have larger project budgets.",
  },
];

const B2BLeadROI = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="b2b-lead-roi"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            The Commercial Case
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Enterprise Lead ROI: Why SEO Is the Right Channel
          </h2>
          <p className="text-muted-foreground leading-relaxed">
            Professional services firms with long sales cycles and high average
            deal values are uniquely well-positioned to achieve exceptional
            returns from organic search. The maths are compelling.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {roiStats.map((item, index) => {
            const Icon = item.icon;
            return (
              <Card
                key={index}
                className="bg-card border border-border shadow-card hover-lift"
              >
                <CardContent className="pt-6 flex flex-col gap-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10">
                    <Icon className="h-6 w-6 text-primary" />
                  </div>
                  <p className="text-3xl font-bold text-foreground">
                    {item.stat}
                  </p>
                  <p className="text-sm font-semibold text-primary">
                    {item.label}
                  </p>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {item.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Strategy summary block */}
        <div
          className="rounded-2xl p-8 md:p-12 text-white relative overflow-hidden"
          style={{ background: "var(--gradient-hero-panel)" }}
        >
          <div className="relative z-10 max-w-3xl mx-auto text-center">
            <span className="inline-block text-xs uppercase tracking-[0.2em] text-white/80 mb-4">
              The B2B SEO Flywheel
            </span>
            <h3 className="text-2xl md:text-3xl font-bold text-white mb-5">
              Thought Leadership → Rankings → Enterprise Trust → Closed Deals
            </h3>
            <p className="text-white/90 leading-relaxed mb-6">
              Effective B2B SEO creates a compounding flywheel: substantive
              content earns rankings; rankings deliver visibility to
              decision-makers; decision-makers consume your thought leadership;
              trust is established before any conversation begins; deals close
              faster with higher average values. Each element reinforces the
              next — and unlike outbound prospecting, it runs continuously
              without additional cost per lead.
            </p>
            <div className="flex flex-wrap justify-center gap-6 mt-4">
              {[
                "Entity Authority Building",
                "Topical Expertise Signals",
                "Qualified Inbound Pipeline",
                "Shorter Deal Cycles",
                "Higher Deal Values",
              ].map((item, i) => (
                <span
                  key={i}
                  className="bg-white/10 border border-white/20 rounded-full px-4 py-1.5 text-white text-sm"
                >
                  {item}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

B2BLeadROI.displayName = "B2BLeadROI";

export default B2BLeadROI;
