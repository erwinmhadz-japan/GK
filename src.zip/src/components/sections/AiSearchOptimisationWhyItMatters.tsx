import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { TrendingUp, Eye, Search, Brain, AlertTriangle, ChevronRight, BookOpen, Key, Section } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (delay: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut", delay },
  }),
};

const insights = [
  {
    icon: Search,
    stat: "~40%",
    label: "of high-intent queries",
    body: "Research indicates a significant and growing proportion of searches for professional services begin with an AI-generated answer — before a user ever clicks through to a website.",
  },
  {
    icon: Eye,
    stat: "Position zero",
    label: "is now AI-owned",
    body: "For many competitive queries in law, finance, healthcare, and property, the AI Overview or chatbot summary occupies the most prominent position. Traditional rankings no longer guarantee visibility.",
  },
  {
    icon: Brain,
    stat: "LLMs curate",
    label: "— they don't just retrieve",
    body: "ChatGPT, Perplexity, Gemini, and Copilot actively select which sources to cite and recommend. Businesses without clear entity signals and content authority are systematically excluded.",
  },
  {
    icon: TrendingUp,
    stat: "First-mover advantage",
    label: "is closing quickly",
    body: "AI search optimisation is still emerging. Businesses that establish citation presence, entity clarity, and structured content authority now will be significantly harder to displace once the landscape matures.",
  },
];

const stakes = [
  {
    heading: "Enquiries are diverted before your site is seen",
    body: "When an AI engine answers a high-intent query — 'best SEO consultant in Manchester', 'solicitor specialising in commercial property', 'private GP clinic Warrington' — the recommended names receive the enquiry. If your brand is absent, a competitor's is present.",
  },
  {
    heading: "Traditional SEO rankings are a necessary but insufficient condition",
    body: "Ranking on page one no longer guarantees AI inclusion. LLMs draw on a combination of entity recognition, structured data, brand authority signals, and content depth — many of which are distinct from standard on-page ranking factors.",
  },
  {
    heading: "Trust-led sectors are disproportionately affected",
    body: "In law, healthcare, finance, and property, AI engines are used precisely because users want a credible shortcut to trustworthy providers. If your business lacks the entity signals that AI systems associate with credibility, you are invisible at the highest-intent moment.",
  },
];

const AiSearchOptimisationWhyItMatters = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="ai-search-optimisation-why-it-matters"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <div className="max-w-2xl mb-16 md:mb-20">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            custom={0}
            viewport={{ once: true, margin: "-60px" }}
          >
            <Badge
              variant="outline"
              className="mb-5 text-xs uppercase tracking-widest font-medium border-border text-muted-foreground"
            >
              The strategic case
            </Badge>
          </motion.div>

          <motion.h2
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            custom={0.08}
            viewport={{ once: true, margin: "-60px" }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground tracking-tight leading-tight mb-5"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Why AI search visibility is{" "}
            <span className="text-[hsl(88_59%_42%)]">a commercial priority</span>
          </motion.h2>

          <motion.p
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            custom={0.16}
            viewport={{ once: true, margin: "-60px" }}
            className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-prose"
          >
            AI answer engines are reshaping how high-intent buyers discover professional services. 
            For UK businesses in competitive, trust-led sectors, being cited and recommended by 
            ChatGPT, Perplexity, or Google AI Overviews is no longer incidental — it is a 
            direct determinant of where enquiries go.
          </motion.p>
        </div>

        {/* Key insight cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16 md:mb-20">
          {insights.map((item, index) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.stat}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                custom={0.1 + index * 0.09}
                viewport={{ once: true, margin: "-60px" }}
                className="group relative rounded-md border border-border bg-background p-6 md:p-8 hover:border-[hsl(88_59%_56%/0.4)] transition-all duration-300"
                style={{ boxShadow: "0 2px 12px -2px hsl(222 28% 11% / 0.06), 0 1px 3px hsl(222 28% 11% / 0.04)" }}
              >
                {/* Icon */}
                <div className="flex items-center gap-3 mb-4">
                  <div className="flex h-9 w-9 items-center justify-center rounded-md bg-[hsl(88_59%_56%/0.10)]">
                    <Icon className="h-4 w-4 text-[hsl(88_59%_42%)]" />
                  </div>
                </div>

                {/* Stat + label */}
                <div className="mb-3">
                  <span
                    className="block text-2xl md:text-3xl font-bold text-foreground leading-none mb-1"
                    style={{ fontFamily: "Sora, sans-serif" }}
                  >
                    {item.stat}
                  </span>
                  <span className="text-sm font-medium text-muted-foreground">
                    {item.label}
                  </span>
                </div>

                {/* Body */}
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {item.body}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Stakes section */}
        <div className="mb-16 md:mb-20">
          <motion.div
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            custom={0}
            viewport={{ once: true, margin: "-60px" }}
            className="flex items-center gap-3 mb-10"
          >
            <div className="flex h-8 w-8 items-center justify-center rounded-md bg-[hsl(358_65%_52%/0.10)]">
              <AlertTriangle className="h-4 w-4 text-[hsl(358_65%_52%)]" />
            </div>
            <h3
              className="text-lg md:text-xl font-semibold text-foreground"
              style={{ fontFamily: "Sora, sans-serif" }}
            >
              What is at stake for your business
            </h3>
          </motion.div>

          <div className="grid grid-cols-1 gap-5">
            {stakes.map((stake, index) => (
              <motion.div
                key={stake.heading}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                custom={0.08 + index * 0.1}
                viewport={{ once: true, margin: "-60px" }}
                className="flex gap-5 items-start rounded-md border border-border bg-background p-6 hover:border-[hsl(88_59%_56%/0.3)] transition-colors duration-300"
                style={{ boxShadow: "0 2px 12px -2px hsl(222 28% 11% / 0.06), 0 1px 3px hsl(222 28% 11% / 0.04)" }}
              >
                <div
                  className="flex-shrink-0 mt-0.5 flex h-6 w-6 items-center justify-center rounded-full text-[10px] font-bold"
                  style={{
                    background: "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                    color: "hsl(222 42% 8%)",
                  }}
                >
                  {index + 1}
                </div>
                <div>
                  <h4
                    className="text-sm md:text-base font-semibold text-foreground mb-2 leading-snug"
                    style={{ fontFamily: "Sora, sans-serif" }}
                  >
                    {stake.heading}
                  </h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {stake.body}
                  </p>
                </div>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Consultant framing — closing paragraph + link to informational hub */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          custom={0.1}
          viewport={{ once: true, margin: "-60px" }}
          className="max-w-3xl border-l-2 border-[hsl(88_59%_56%)] pl-6"
        >
          <p className="text-base text-muted-foreground leading-relaxed mb-4">
            This is not a trend to monitor and revisit next year. Businesses in law, healthcare, 
            finance, and property that act now — by building proper entity presence, structured 
            content authority, and platform-specific citation signals — will occupy the positions 
            that matter before competitors understand what those positions are.
          </p>
          <p className="text-sm text-muted-foreground leading-relaxed mb-5">
            As an independent SEO consultant, I work directly with UK businesses to diagnose 
            current AI search visibility gaps and implement a structured programme to address them. 
            There is no account management layer, no junior execution. Every analysis and 
            recommendation comes from direct, senior-level consulting.
          </p>
          <Link
            to="#ai-search-cta"
            className="inline-flex items-center gap-2 text-sm font-medium text-[hsl(88_59%_38%)] hover:text-[hsl(88_59%_30%)] transition-colors duration-200 group"
          >
            <BookOpen className="h-4 w-4 flex-shrink-0" />
            <span>Explore the informational AI search hub</span>
            <ChevronRight className="h-4 w-4 group-hover:translate-x-0.5 transition-transform duration-200" />
          </Link>
        </motion.div>

      </div>
    </section>
  );
});

AiSearchOptimisationWhyItMatters.displayName = "AiSearchOptimisationWhyItMatters";

export default AiSearchOptimisationWhyItMatters;
