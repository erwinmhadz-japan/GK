import React from "react";
import { motion } from "framer-motion";
import { MapPin, Globe, ArrowRight, View } from "lucide-react";
import { Link } from "react-router-dom";

const locations = [
  {
    city: "Warrington",
    descriptor: "Based here",
    detail: "Primary base. Cheshire, WA4.",
    to: "#warrington-cta",
    isBase: true,
  },
  {
    city: "Manchester",
    descriptor: "Regular client work",
    detail: "City-centre and Greater Manchester.",
    to: "#manchester-cta",
    isBase: false,
  },
  {
    city: "Liverpool",
    descriptor: "Regular client work",
    detail: "Merseyside and surrounding area.",
    to: "#liverpool-cta",
    isBase: false,
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 22 },
  visible: (delay: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay },
  }),
};

const HomeLocationCoverage = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="home-location-coverage"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className="grid md:grid-cols-2 gap-12 md:gap-20 items-start">
          {/* Left: headline block */}
          <div>
            <motion.span
              custom={0}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-60px" }}
              variants={fadeUp}
              className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-5 font-medium"
            >
              Location &amp; reach
            </motion.span>

            <motion.h2
              custom={0.1}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-60px" }}
              variants={fadeUp}
              className="font-heading text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight max-w-xl"
            >
              UK-Wide SEO Consulting
            </motion.h2>

            <motion.p
              custom={0.2}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-60px" }}
              variants={fadeUp}
              className="mt-5 text-base md:text-lg text-muted-foreground leading-relaxed max-w-md"
            >
              Based in Warrington, Cheshire. Working with clients across the UK.
            </motion.p>

            <motion.p
              custom={0.3}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-60px" }}
              variants={fadeUp}
              className="mt-4 text-sm text-muted-foreground leading-relaxed max-w-md"
            >
              Most engagements are conducted remotely, which means geography is
              rarely a constraint. Whether you are a law firm in Manchester, a
              private clinic in Liverpool, or a B2B business anywhere in
              England, the work is the same: direct, senior-led SEO consulting
              with no handoffs and no account managers.
            </motion.p>

            {/* Address */}
            <motion.div
              custom={0.4}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-60px" }}
              variants={fadeUp}
              className="mt-8 flex items-start gap-2.5"
            >
              <MapPin className="h-4 w-4 text-primary mt-0.5 shrink-0" />
              <address className="not-italic text-sm text-muted-foreground leading-snug">
                22 Foxdale Court, Warrington WA4 5BS, Cheshire, GB
              </address>
            </motion.div>
          </div>

          {/* Right: location cards + UK-wide note */}
          <div className="flex flex-col gap-5">
            {/* Location cards */}
            {locations.map((loc, i) => (
              <motion.div
                key={loc.city}
                custom={0.15 + i * 0.1}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-60px" }}
                variants={fadeUp}
              >
                <div
                  className={`group relative rounded-md border bg-card px-6 py-5 flex items-start gap-4 transition-all duration-300 hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%_/_0.10),_0_1px_4px_hsl(222_28%_11%_/_0.05)] ${
                    loc.isBase
                      ? "border-primary/40"
                      : "border-border"
                  }`}
                >
                  {/* Green accent bar for base */}
                  {loc.isBase && (
                    <span className="absolute left-0 top-4 bottom-4 w-0.5 rounded-full bg-primary" />
                  )}

                  <MapPin
                    className={`h-5 w-5 mt-0.5 shrink-0 ${
                      loc.isBase ? "text-primary" : "text-muted-foreground"
                    }`}
                  />

                  <div className="flex-1 min-w-0">
                    <div className="flex items-baseline gap-2 flex-wrap">
                      <span className="font-heading font-semibold text-foreground text-base">
                        {loc.city}
                      </span>
                      <span className="text-xs text-muted-foreground tracking-wide">
                        — {loc.descriptor}
                      </span>
                    </div>
                    <p className="mt-0.5 text-sm text-muted-foreground">
                      {loc.detail}
                    </p>
                  </div>

                  <Link
                    to={loc.to}
                    className="shrink-0 text-muted-foreground hover:text-primary transition-colors duration-200 mt-0.5"
                    aria-label={`SEO consultant in ${loc.city}`}
                  >
                    <ArrowRight className="h-4 w-4 group-hover:translate-x-0.5 transition-transform duration-200" />
                  </Link>
                </div>
              </motion.div>
            ))}

            {/* UK-wide panel */}
            <motion.div
              custom={0.5}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-60px" }}
              variants={fadeUp}
              className="rounded-md border border-border bg-muted/40 px-6 py-5 flex items-start gap-4"
            >
              <Globe className="h-5 w-5 text-primary mt-0.5 shrink-0" />
              <div>
                <p className="font-heading font-semibold text-foreground text-base">
                  UK-wide, remote
                </p>
                <p className="mt-0.5 text-sm text-muted-foreground leading-relaxed mb-3">
                  All services available remotely. Clients span the UK.
                </p>
                <div className="flex flex-wrap gap-x-3 gap-y-1.5">
                  {[
                    { label: "London", href: "#london-cta" },
                    { label: "Birmingham", href: "#birmingham-cta" },
                    { label: "Leeds", href: "#leeds-cta" },
                    { label: "Sheffield", href: "#sheffield-cta" },
                    { label: "Bristol", href: "#" },
                    { label: "Edinburgh", href: "#" },
                  ].map(({ label, href }) => (
                    <Link
                      key={label}
                      to={href}
                      className="text-xs text-primary hover:text-primary/80 font-medium underline-offset-2 hover:underline transition-colors duration-200"
                    >
                      {label}
                    </Link>
                  ))}
                </div>
              </div>
            </motion.div>

            {/* Locations hub link */}
            <motion.div
              custom={0.6}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-60px" }}
              variants={fadeUp}
              className="pt-1"
            >
              <Link
                to="/locations"
                className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors duration-200"
              >
                View all locations
                <ArrowRight className="h-4 w-4" />
              </Link>
            </motion.div>
          </div>
        </div>
      </div>
    </section>
  );
});

HomeLocationCoverage.displayName = "HomeLocationCoverage";

export default HomeLocationCoverage;
