import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { CheckCircle, Search, Globe, Zap, Shield, Target, ArrowRight, Icon, View } from "lucide-react";

const solutions = [
  {
    icon: Search,
    title: "Sheffield Local SEO",
    description:
      "Dominate Google's local pack for Sheffield-specific searches — from 'SEO Sheffield' and 'marketing agency Sheffield' to hyper-local S-postcode terms. We optimise your Google Business Profile, local citations, and on-page signals for maximum South Yorkshire visibility.",
    bullets: [
      "Google Business Profile optimisation",
      "Local citation building across S postcodes",
      "Sheffield-specific keyword targeting",
      "Neighbourhood-level search visibility",
    ],
    cta: { label: "Explore Local SEO", href: "#" },
  },
  {
    icon: Globe,
    title: "Technical SEO & Site Health",
    description:
      "Sheffield's manufacturing and B2B firms often have complex, legacy websites that hold back search performance. We audit, fix, and future-proof the technical foundations so search engines can crawl, index, and rank your pages.",
    bullets: [
      "Full technical site audits",
      "Core Web Vitals optimisation",
      "Schema markup for local business",
      "Crawlability & indexation fixes",
    ],
    cta: { label: "View SEO Services", href: "/services" },
  },
  {
    icon: Zap,
    title: "B2B Content & Entity SEO",
    description:
      "Sheffield's advanced manufacturing and engineering sectors are driven by B2B buyer intent. We build topical authority through expert content strategies that position your business as the go-to answer for the queries your buyers actually type.",
    bullets: [
      "B2B keyword and intent mapping",
      "Sector-specific content strategy",
      "Entity-based SEO for authority",
      "Lead-generating long-tail content",
    ],
    cta: { label: "Content Strategy", href: "/services" },
  },
];

const SheffieldSolutions = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="sheffield-solutions"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="max-w-2xl mb-14"
        >
          <div className="flex items-center gap-2 mb-4">
            <Target className="h-4 w-4 text-primary flex-shrink-0" aria-hidden="true" />
            <span className="text-xs uppercase tracking-[0.2em] font-medium text-muted-foreground">
              Local SEO solutions
            </span>
          </div>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-[1.15] mb-4 tracking-tight">
            Sheffield SEO That Drives{" "}
            <span className="text-gradient-green">Measurable Results</span>
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Every Sheffield business has a different competitive landscape. Our SEO
            solutions are tailored to the specific market dynamics of South Yorkshire —
            whether you're a manufacturer targeting national buyers or a local service
            business capturing nearby demand.
          </p>
        </motion.div>

        {/* Solution cards */}
        <div className="grid md:grid-cols-3 gap-6 mb-12">
          {solutions.map(({ icon: Icon, title, description, bullets, cta }, i) => (
            <motion.div
              key={title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.55, delay: i * 0.1, ease: "easeOut" }}
              className="rounded-2xl border border-border bg-card shadow-card p-6 flex flex-col hover-lift"
            >
              <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-4">
                <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-3">{title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed mb-4 flex-1">
                {description}
              </p>

              {/* Bullet list */}
              <ul className="space-y-2 mb-6">
                {bullets.map((bullet) => (
                  <li key={bullet} className="flex items-start gap-2 text-sm text-foreground">
                    <CheckCircle
                      className="h-4 w-4 text-primary flex-shrink-0 mt-0.5"
                      aria-hidden="true"
                    />
                    {bullet}
                  </li>
                ))}
              </ul>

              <Button variant="outline" size="sm" asChild className="w-full">
                <Link to={cta.href}>
                  {cta.label}
                  <ArrowRight className="ml-2 h-3.5 w-3.5" />
                </Link>
              </Button>
            </motion.div>
          ))}
        </div>

        {/* Bottom trust note */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.5, ease: "easeOut" }}
          className="flex flex-wrap items-center justify-center gap-6 text-sm text-muted-foreground"
        >
          {[
            "No long-term contracts",
            "Transparent monthly reporting",
            "Sheffield-first strategy",
          ].map((item) => (
            <span key={item} className="flex items-center gap-1.5">
              <Shield className="h-4 w-4 text-primary" aria-hidden="true" />
              {item}
            </span>
          ))}
        </motion.div>
      </div>
    </section>
  );
});

SheffieldSolutions.displayName = "SheffieldSolutions";

export default SheffieldSolutions;
