import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Quote, Star, MapPin, ArrowRight, Group, Stars, View } from "lucide-react";

const testimonials = [
  {
    quote:
      "We went from page four to position two for 'commercial solicitor Manchester' in under six months. The ROI has been transformational — organic enquiries now account for 60% of our new business pipeline.",
    author: "James Whitfield",
    role: "Managing Partner",
    company: "Whitfield Legal Group",
    location: "Manchester City Centre",
    image: "https://images.unsplash.com/photo-1734830268394-6c4a1f165af1?w=400&h=400&fit=crop&crop=face",
    rating: 5,
  },
  {
    quote:
      "The technical SEO audit revealed issues we had no idea existed. Page speed improvements alone increased our conversion rate by 23%. The Manchester-specific keyword strategy has brought in clients from across Greater Manchester.",
    author: "Sarah Chen",
    role: "Head of Marketing",
    company: "Northern Digital Solutions",
    location: "Spinningfields, Manchester",
    image: "https://images.unsplash.com/photo-1710778044102-56a3a6b69a1b?w=400&h=400&fit=crop&crop=face",
    rating: 5,
  },
  {
    quote:
      "We needed an SEO consultant who understood the Manchester market — not a London agency treating us as an afterthought. The depth of local knowledge and the measurable results speak for themselves.",
    author: "Marcus Okafor",
    role: "CEO",
    company: "Okafor Consulting",
    location: "Deansgate, Manchester",
    image: "https://images.unsplash.com/photo-1678282955795-200c1e18bc7d?w=400&h=400&fit=crop&crop=face",
    rating: 5,
  },
];

const caseHighlights = [
  {
    metric: "+312%",
    label: "Organic traffic growth",
    context: "Manchester e-commerce retailer, 9 months",
  },
  {
    metric: "Position 1",
    label: "For target keyword",
    context: "'accountant Manchester' — from position 34",
  },
  {
    metric: "£180K",
    label: "Pipeline attributed to SEO",
    context: "B2B tech firm, 12-month retainer",
  },
  {
    metric: "68%",
    label: "Reduction in cost-per-lead",
    context: "Manchester law firm, 6-month campaign",
  },
];

const ManchesterTestimonials = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="manchester-testimonials"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className="max-w-2xl mb-14">
          <motion.span
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="inline-block text-xs uppercase tracking-[0.2em] text-primary font-semibold mb-4"
          >
            Manchester Client Results
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, delay: 0.06 }}
            className="text-3xl md:text-4xl font-bold text-foreground mb-5"
          >
            What Manchester Businesses Say
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, delay: 0.12 }}
            className="text-lg text-muted-foreground leading-relaxed"
          >
            Real results from Manchester clients — from Deansgate law firms to Spinningfields
            financial services and Northern Quarter tech businesses.
          </motion.p>
        </div>

        {/* Case Highlights */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-14"
        >
          {caseHighlights.map((item) => (
            <div
              key={item.label}
              className="rounded-xl border border-border bg-muted px-5 py-6 text-center"
            >
              <div className="text-2xl md:text-3xl font-bold text-primary mb-1">{item.metric}</div>
              <div className="text-sm font-semibold text-foreground mb-1">{item.label}</div>
              <div className="text-xs text-muted-foreground">{item.context}</div>
            </div>
          ))}
        </motion.div>

        {/* Testimonials */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {testimonials.map((t, idx) => (
            <motion.div
              key={t.author}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.1 }}
              className="bg-card rounded-xl border border-border p-7 flex flex-col hover-lift shadow-card"
            >
              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-primary text-primary" />
                ))}
              </div>

              {/* Quote icon */}
              <Quote className="h-6 w-6 text-primary/30 mb-3" />

              {/* Quote text */}
              <p className="text-sm text-muted-foreground leading-relaxed flex-1 mb-6 italic">
                "{t.quote}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-3 border-t border-border pt-4">
                <img
                  src={t.image}
                  alt={`${t.author}, ${t.role} at ${t.company}`}
                  width={40}
                  height={40}
                  className="w-10 h-10 rounded-full object-cover"
                  loading="lazy"
                />
                <div>
                  <div className="text-sm font-semibold text-foreground">{t.author}</div>
                  <div className="text-xs text-muted-foreground">{t.role}, {t.company}</div>
                  <div className="flex items-center gap-1 mt-0.5">
                    <MapPin className="h-3 w-3 text-primary" />
                    <span className="text-xs text-muted-foreground">{t.location}</span>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="flex flex-wrap gap-4"
        >
          <Button size="lg" asChild>
            <Link to="#case-studies-cta">
              View Full Case Studies
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button size="lg" variant="outline" asChild>
            <Link to="/contact">Start Your Manchester Project</Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
});

ManchesterTestimonials.displayName = "ManchesterTestimonials";

export default ManchesterTestimonials;
