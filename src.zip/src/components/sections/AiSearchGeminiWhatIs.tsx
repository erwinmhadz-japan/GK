import React from "react";
import { Bot, Globe, Users, Brain, Zap, Network, Search, User } from "lucide-react";

const stats = [
  { value: "1B+", label: "Monthly active users across Gemini-powered products" },
  { value: "180+", label: "Countries where Gemini features are available" },
  { value: "AI-first", label: "Google's flagship multimodal AI reasoning model" },
];

const capabilities = [
  {
    icon: Brain,
    title: "Multimodal Reasoning",
    description:
      "Gemini processes text, images, code, and documents together — enabling richer, more contextual answers than keyword-based search.",
  },
  {
    icon: Globe,
    title: "Deep Google Integration",
    description:
      "Embedded across Google Search, Google Workspace, Android, and the Gemini app — giving it unparalleled reach into everyday digital interactions.",
  },
  {
    icon: Users,
    title: "Massive & Growing User Base",
    description:
      "With over a billion users across Google's ecosystem, Gemini's answer surfaces carry significant brand-impression and traffic implications.",
  },
  {
    icon: Network,
    title: "Connected to the Web",
    description:
      "Unlike closed LLMs, Gemini actively retrieves and cites live web content — making your site's crawlability and authority directly relevant.",
  },
  {
    icon: Zap,
    title: "Powering AI Overviews",
    description:
      "Gemini is the engine behind Google AI Overviews in Search results, meaning Gemini visibility and AI Overview inclusion overlap significantly.",
  },
  {
    icon: Bot,
    title: "Conversational Search",
    description:
      "Users interact with Gemini through natural language queries — rewarding content that answers specific questions directly and authoritatively.",
  },
];

const AiSearchGeminiWhatIs = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="what-is-gemini"
      className="relative py-20 md:py-32 border-t border-border bg-background"
      aria-labelledby="what-is-gemini-heading"
    >
      <div className="container">
        {/* Header */}
        <div className="max-w-2xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            What is Google Gemini?
          </span>
          <h2
            id="what-is-gemini-heading"
            className="text-3xl md:text-5xl font-bold text-foreground mb-5"
          >
            Google's Most Powerful AI — and Its Growing User Base
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Google Gemini is a family of multimodal large language models developed
            by Google DeepMind. It sits at the heart of Google's AI strategy —
            powering Search AI Overviews, the Gemini app, and intelligent features
            across Workspace. For SEO professionals and businesses, Gemini's reach
            means your content strategy now needs to account for AI-mediated discovery.
          </p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-16">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="bg-muted rounded-xl p-6 border border-border text-center"
            >
              <div className="text-3xl md:text-4xl font-bold text-primary mb-2">
                {stat.value}
              </div>
              <p className="text-sm text-muted-foreground leading-snug">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Capability Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {capabilities.map((cap) => {
            const Icon = cap.icon;
            return (
              <div
                key={cap.title}
                className="bg-card border border-border rounded-xl p-6 hover-lift shadow-card"
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-4">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="text-base font-semibold text-foreground mb-2">
                  {cap.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {cap.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
});

AiSearchGeminiWhatIs.displayName = "AiSearchGeminiWhatIs";

export default AiSearchGeminiWhatIs;
