import React from "react";
import { CheckCircle, FileText, Globe, Shield, RefreshCw, Award, Target, Link, Grid, Search } from "lucide-react";

const tactics = [
  {
    icon: FileText,
    title: "Write Answer-First Content",
    description:
      "Structure content so the direct answer to a query appears in the first 1–2 sentences, followed by supporting detail. Gemini favours direct, unambiguous answers — not buried conclusions.",
    tags: ["Content structure", "Directness"],
  },
  {
    icon: Shield,
    title: "Demonstrate E-E-A-T",
    description:
      "Experience, Expertise, Authoritativeness, and Trustworthiness remain the foundation of Gemini's source evaluation. Author credentials, first-hand experience signals, and institutional trust markers all influence citation likelihood.",
    tags: ["E-E-A-T", "Author authority"],
  },
  {
    icon: Globe,
    title: "Ensure Full Crawlability",
    description:
      "Gemini pulls from Google's index — meaning pages blocked by robots.txt, hidden behind login walls, or loaded via client-side JavaScript without SSR will be invisible to it. Solid technical SEO is non-negotiable.",
    tags: ["Technical SEO", "Crawlability"],
    link: { label: "Technical SEO →", href: "/technical-seo" },
  },
  {
    icon: CheckCircle,
    title: "Add Structured Data (Schema)",
    description:
      "Implement Schema.org markup — Article, FAQPage, HowTo, Organisation, and Product schemas. Structured data makes your content machine-readable and increases the chance Gemini accurately interprets and cites your entities.",
    tags: ["Schema markup", "Structured data"],
    link: { label: "Schema markup guide →", href: "/schema-markup" },
  },
  {
    icon: RefreshCw,
    title: "Publish Fresh, Updated Content",
    description:
      "Gemini weights recency for rapidly evolving topics. Maintain a content refresh cadence — update statistics, expand sections, and revise outdated guidance to signal freshness to Google's crawlers.",
    tags: ["Content freshness", "Indexing"],
  },
  {
    icon: Award,
    title: "Build Topical Authority",
    description:
      "Covering a subject in depth — from fundamentals to advanced nuances — signals topical authority. Gemini is more likely to cite a resource that answers the full range of questions in a domain.",
    tags: ["Topical depth", "Entity SEO"],
    link: { label: "Entity SEO →", href: "/entity-seo" },
  },
  {
    icon: Target,
    title: "Target Conversational Query Formats",
    description:
      "Optimise for how people actually ask questions — 'What is...', 'How does...', 'Best way to...'. Include natural-language variations and question headings throughout your content.",
    tags: ["Query targeting", "Natural language"],
  },
  {
    icon: Link,
    title: "Earn High-Authority Backlinks",
    description:
      "Domain authority — reflected in your backlink profile — remains a trust signal Gemini's source evaluation inherits from Google's ranking algorithms. Digital PR and editorial links strengthen your position.",
    tags: ["Digital PR", "Authority signals"],
  },
];

const AiSearchGeminiOptimisation = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="gemini-optimisation-tactics"
      className="relative py-20 md:py-32 border-t border-border bg-background"
      aria-labelledby="gemini-optimisation-heading"
    >
      <div className="container">
        {/* Header */}
        <div className="max-w-2xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            Optimisation Tactics
          </span>
          <h2
            id="gemini-optimisation-heading"
            className="text-3xl md:text-5xl font-bold text-foreground mb-5"
          >
            How to Optimise for Google Gemini Visibility
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Gemini visibility isn't a separate discipline — it's built on the
            intersection of strong technical SEO, authoritative content, and
            structured data. These eight tactics target the specific signals Gemini
            uses when selecting which sources to surface and cite.
          </p>
        </div>

        {/* Tactics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {tactics.map((tactic) => {
            const Icon = tactic.icon;
            return (
              <div
                key={tactic.title}
                className="bg-card border border-border rounded-xl p-6 hover-lift shadow-soft"
              >
                <div className="flex items-start gap-4">
                  <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 shrink-0">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-base font-semibold text-foreground mb-2">
                      {tactic.title}
                    </h3>
                    <p className="text-sm text-muted-foreground leading-relaxed mb-3">
                      {tactic.description}
                    </p>
                    <div className="flex flex-wrap items-center gap-2">
                      {tactic.tags.map((tag) => (
                        <span
                          key={tag}
                          className="inline-block bg-muted text-muted-foreground text-xs px-2.5 py-1 rounded-full border border-border"
                        >
                          {tag}
                        </span>
                      ))}
                      {tactic.link && (
                        <a
                          href={tactic.link.href}
                          className="text-xs font-semibold text-primary hover:underline ml-auto"
                        >
                          {tactic.link.label}
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Internal link block */}
        <div className="mt-12 p-6 bg-muted border border-border rounded-xl">
          <p className="text-sm font-semibold text-foreground mb-2">
            Need a holistic AI search strategy across all platforms?
          </p>
          <p className="text-sm text-muted-foreground mb-4">
            Gemini is one piece of the puzzle. See how a full AI search optimisation
            strategy covers ChatGPT, Perplexity, Copilot, and Google AI Overviews.
          </p>
          <a
            href="#ai-search-cta"
            className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline"
          >
            AI Search Optimisation Hub →
          </a>
        </div>
      </div>
    </section>
  );
});

AiSearchGeminiOptimisation.displayName = "AiSearchGeminiOptimisation";

export default AiSearchGeminiOptimisation;
