import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { Bot, Globe, Sparkles, ArrowRight, Icon, Search } from "lucide-react";

const CopilotVisibilityHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="copilot-visibility-hero"
      className="relative py-20 md:py-32 border-t border-border bg-background overflow-hidden"
    >
      {/* Subtle background texture — dot grid via radial gradient */}
      <div
        className="absolute inset-0 pointer-events-none opacity-30"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(214 32% 60% / 0.25) 1px, transparent 1px)",
          backgroundSize: "32px 32px",
        }}
        aria-hidden="true"
      />

      {/* Soft accent glow — top right */}
      <div
        className="absolute -top-40 right-0 w-[480px] h-[480px] rounded-full pointer-events-none"
        style={{
          background:
            "radial-gradient(circle, hsl(84 74% 60% / 0.08) 0%, transparent 70%)",
        }}
        aria-hidden="true"
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">

          {/* Left column — copy */}
          <div>
            {/* Eyebrow badge */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, ease: "easeOut", delay: 0 }}
            >
              <Badge
                variant="outline"
                className="mb-6 text-xs uppercase tracking-widest border-border text-muted-foreground font-medium px-3 py-1"
              >
                AI Search · Informational Guide
              </Badge>
            </motion.div>

            {/* H1 */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, ease: "easeOut", delay: 0.1 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight tracking-tight max-w-xl"
              style={{ fontFamily: "Sora, sans-serif" }}
            >
              Microsoft Copilot{" "}
              <span
                className="bg-clip-text text-transparent"
                style={{
                  backgroundImage:
                    "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                }}
              >
                Visibility
              </span>
            </motion.h1>

            {/* Subheadline */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, ease: "easeOut", delay: 0.2 }}
              className="mt-5 text-base md:text-lg text-muted-foreground leading-relaxed max-w-lg"
            >
              Optimise your brand to appear in Microsoft Copilot AI responses —
              informational guidance for UK businesses navigating the next wave of
              AI search.
            </motion.p>

            {/* Informational note */}
            <motion.p
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, ease: "easeOut", delay: 0.3 }}
              className="mt-4 text-sm text-muted-foreground"
            >
              This page is an educational guide. For a managed AI search
              optimisation service, see my{" "}
              <Link
                to="/ai-search-optimisation"
                className="underline underline-offset-2 hover:text-foreground transition-colors duration-200"
              >
                AI Search Optimisation service&nbsp;→
              </Link>
            </motion.p>

            {/* CTA */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, ease: "easeOut", delay: 0.38 }}
              className="mt-8 flex flex-wrap gap-4 items-center"
            >
              <Button
                size="lg"
                className="h-12 px-8 text-sm font-semibold tracking-wide rounded-md text-foreground"
                style={{
                  background:
                    "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                }}
                asChild
              >
                <Link to="/ai-search-optimisation">
                  Get AI Search Help
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>

              <Button
                size="lg"
                variant="outline"
                className="h-12 px-8 text-sm font-medium rounded-md border-border text-foreground hover:bg-muted transition-colors"
                asChild
              >
                <Link to="/contact">Speak with Gregg</Link>
              </Button>
            </motion.div>

            {/* Trust micro-copy */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.55, ease: "easeOut", delay: 0.5 }}
              className="mt-5 text-xs text-muted-foreground"
            >
              Independent UK SEO consultant · Based in Warrington, Cheshire
            </motion.p>
          </div>

          {/* Right column — visual panel */}
          <motion.div
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.75, ease: "easeOut", delay: 0.15 }}
            className="relative"
          >
            {/* Card panel */}
            <div
              className="rounded-xl border border-border p-6 md:p-8 space-y-6"
              style={{
                background:
                  "linear-gradient(160deg, hsl(225 28% 14% / 0.04) 0%, hsl(214 32% 60% / 0.06) 100%)",
              }}
            >
              {/* Icon header */}
              <div className="flex items-center gap-3">
                <div
                  className="flex h-10 w-10 items-center justify-center rounded-lg"
                  style={{
                    background:
                      "linear-gradient(135deg, hsl(84 74% 58% / 0.15), hsl(119 35% 61% / 0.12))",
                  }}
                >
                  <Bot className="h-5 w-5 text-foreground" />
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-widest font-medium">
                    Microsoft Copilot
                  </p>
                  <p className="text-sm font-semibold text-foreground leading-tight">
                    AI-Powered Search Assistant
                  </p>
                </div>
              </div>

              {/* Divider */}
              <div className="border-t border-border" />

              {/* Three info rows */}
              {[
                {
                  icon: Globe,
                  label: "Bing-Powered Retrieval",
                  desc:
                    "Copilot draws on Bing's index — your Bing indexation health matters.",
                },
                {
                  icon: Sparkles,
                  label: "Entity & Authority Signals",
                  desc:
                    "Brands with strong entity authority are cited more frequently in AI responses.",
                },
                {
                  icon: Bot,
                  label: "UK Business Relevance",
                  desc:
                    "Copilot is widely used across UK enterprise — visibility here builds commercial credibility.",
                },
              ].map(({ icon: Icon, label, desc }, i) => (
                <motion.div
                  key={label}
                  initial={{ opacity: 0, y: 12 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{
                    duration: 0.5,
                    ease: "easeOut",
                    delay: 0.35 + i * 0.1,
                  }}
                  className="flex gap-4 items-start"
                >
                  <div
                    className="mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-md"
                    style={{
                      background: "hsl(214 32% 60% / 0.1)",
                    }}
                  >
                    <Icon className="h-4 w-4 text-muted-foreground" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground leading-snug">
                      {label}
                    </p>
                    <p className="mt-0.5 text-xs text-muted-foreground leading-relaxed">
                      {desc}
                    </p>
                  </div>
                </motion.div>
              ))}

              {/* Bottom accent strip */}
              <div className="border-t border-border pt-4">
                <p className="text-xs text-muted-foreground">
                  <span className="font-medium text-foreground">Note:</span>{" "}
                  This guide covers informational best practices. For a fully
                  managed AI visibility service, explore my{" "}
                  <Link
                    to="/ai-search-optimisation"
                    className="underline underline-offset-2 hover:text-foreground transition-colors duration-200"
                  >
                    AI Search Optimisation
                  </Link>{" "}
                  page.
                </p>
              </div>
            </div>

            {/* Floating label badge */}
            <div className="absolute -top-3 -right-3 hidden md:block">
              <Badge
                className="text-xs font-semibold px-3 py-1 rounded-full shadow-sm text-foreground"
                style={{
                  background:
                    "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                }}
              >
                Informational Guide
              </Badge>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
});

CopilotVisibilityHero.displayName = "CopilotVisibilityHero";

export default CopilotVisibilityHero;
