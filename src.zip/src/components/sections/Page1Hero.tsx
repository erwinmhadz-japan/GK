import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, ArrowRight, Search, TrendingUp, Home, Icon, View } from "lucide-react";
import { Link } from "react-router-dom";
import { ImageBackground } from "@/components/ImageBackground";

const credentials = [
  { icon: CheckCircle, label: "Independent Consultant" },
  { icon: Search, label: "Technical & Strategic SEO" },
  { icon: TrendingUp, label: "Proven Organic Results" },
  { icon: ArrowRight, label: "No Agency Overhead" },
];

const Page1Hero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="page1-hero"
      aria-label="How I Work hero section"
      src="https://images.unsplash.com/photo-1568649704650-a6ab20e84311?w=1920&h=1080&fit=crop"
      alt="Professionals walking through a modern city environment"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[80vh] md:min-h-[85vh] flex items-center"
    >
      <div className="container max-w-6xl mx-auto px-4 relative z-10 py-24 md:py-36">
        {/* Breadcrumb */}
        <nav aria-label="Breadcrumb" className="mb-8">
          <ol className="flex items-center gap-2 text-xs text-white/60">
            <li><Link to="/" className="hover:text-white/90 transition-colors">Home</Link></li>
            <li aria-hidden="true" className="select-none">/</li>
            <li className="text-white/90 font-medium">How I Work</li>
          </ol>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">

          {/* Left column — copy */}
          <div>
            <motion.div
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, ease: "easeOut" }}
            >
              <Badge
                variant="outline"
                className="inline-flex items-center gap-1.5 text-xs font-medium tracking-wide uppercase border-white/30 text-white/80 bg-white/10 mb-6"
              >
                <span
                  className="w-1.5 h-1.5 rounded-full"
                  style={{ background: "hsl(84 74% 58%)" }}
                  aria-hidden="true"
                />
                How I Work · Gregg Holloway SEO
              </Badge>
            </motion.div>

            <motion.h1
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.08 }}
              className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight tracking-tight max-w-xl mb-5"
              style={{ fontFamily: "Sora, sans-serif" }}
            >
              SEO Consulting Built on{" "}
              <span
                style={{
                  backgroundImage:
                    "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
              >
                Transparency &amp; Results
              </span>
            </motion.h1>

            <motion.p
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.16 }}
              className="text-base md:text-lg text-white/90 leading-relaxed max-w-lg mb-8"
            >
              I take a straightforward, results-first approach to SEO. No jargon, no account-manager layers — just clear strategy, honest reporting, and measurable organic growth for your business.
            </motion.p>

            <motion.div
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, ease: "easeOut", delay: 0.24 }}
              className="flex flex-col sm:flex-row gap-3 mb-10"
            >
              <Button
                size="lg"
                asChild
                className="text-base h-12 px-8 font-semibold"
                style={{
                  background: "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                  color: "hsl(222 42% 8%)",
                  border: "none",
                }}
              >
                <Link to="/contact">Start a Conversation</Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                asChild
                className="text-base h-12 px-8 bg-transparent text-white border-white/40 hover:bg-white/10"
              >
                <Link to="/services">View All Services</Link>
              </Button>
            </motion.div>

            {/* Credential pills */}
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, delay: 0.36 }}
              className="flex flex-wrap gap-3"
            >
              {credentials.map(({ icon: Icon, label }) => (
                <span
                  key={label}
                  className="inline-flex items-center gap-1.5 text-xs text-white/80 bg-white/10 border border-white/20 rounded-full px-3 py-1.5"
                >
                  <Icon className="h-3.5 w-3.5 flex-shrink-0" aria-hidden="true" />
                  {label}
                </span>
              ))}
            </motion.div>
          </div>

          {/* Right column — stat cards */}
          <motion.div
            initial={{ opacity: 0, x: 30 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, ease: "easeOut", delay: 0.2 }}
            className="hidden lg:grid grid-cols-2 gap-4"
          >
            {[
              { value: "10+", label: "Years of SEO Experience", sub: "Across B2B, local & enterprise" },
              { value: "100%", label: "Independent Consulting", sub: "No agency, no layers" },
              { value: "UK-Based", label: "Warrington, Cheshire", sub: "Serving clients nationally" },
              { value: "Direct", label: "Senior Consultant Access", sub: "From discovery to delivery" },
            ].map((stat, i) => (
              <motion.div
                key={stat.label}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.5, delay: 0.3 + i * 0.08 }}
                className="rounded-xl border border-white/20 bg-white/10 backdrop-blur-sm p-5"
              >
                <p
                  className="text-2xl font-bold mb-1"
                  style={{
                    backgroundImage: "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    backgroundClip: "text",
                    fontFamily: "Sora, sans-serif",
                  }}
                >
                  {stat.value}
                </p>
                <p className="text-sm font-semibold text-white mb-0.5">{stat.label}</p>
                <p className="text-xs text-white/80">{stat.sub}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </div>
    </ImageBackground>
  );
});

Page1Hero.displayName = "Page1Hero";

export default Page1Hero;
