import React from "react";
import { Star, TrendingUp, CheckCircle, Building, Stars } from "lucide-react";

const results = [
  { metric: "+182%", label: "Organic traffic in 6 months" },
  { metric: "#1", label: "'Solicitors Leeds' — Google local pack" },
  { metric: "3×", label: "Increase in qualified enquiries" },
];

const LocationsLeedsTestimonial = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative isolate py-24 md:py-36"
    >
      {/* Background image — general category */}
      <img
        src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=1920&h=1080&fit=crop"
        alt="Team collaborating around laptops in a modern office environment"
        className="absolute inset-0 w-full h-full object-cover"
        loading="lazy"
        width="1920"
        height="1080"
      />
      {/* Brand tint overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/80 via-primary/55 to-accent/60 pointer-events-none" />

      <div className="container relative z-10">
        <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4">
          Leeds Client Case Study
        </span>
        <h2 className="text-3xl md:text-4xl font-bold text-white max-w-2xl mb-12">
          How We Helped a Leeds Law Firm Triple Their Organic Enquiries
        </h2>

        {/* Results row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {results.map(({ metric, label }) => (
            <div
              key={label}
              className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-xl p-6 text-center"
            >
              <p className="text-4xl font-bold text-white">{metric}</p>
              <p className="mt-2 text-sm text-white/80">{label}</p>
            </div>
          ))}
        </div>

        {/* Testimonial card */}
        <div className="max-w-3xl bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-8">
          {/* Stars */}
          <div className="flex gap-1 mb-4">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="h-5 w-5 fill-primary text-primary" />
            ))}
          </div>
          <blockquote className="text-white text-lg leading-relaxed italic mb-6">
            "Before working with Gregg, we were invisible in local search.
            Within six months we were ranking number one in the Leeds map pack
            for our most competitive terms. The enquiries have been consistent
            and high quality — exactly the kind of clients we want. I wouldn't
            hesitate to recommend this approach to any Leeds professional
            services firm."
          </blockquote>
          <div className="flex items-center gap-4">
            <img
              src="https://images.unsplash.com/photo-1734830268394-6c4a1f165af1?w=400&h=400&fit=crop&crop=face"
              alt="Portrait of Marcus Webb, Managing Partner at Webb & Associates Leeds"
              className="h-12 w-12 rounded-full object-cover border-2 border-white/30"
              width="400"
              height="400"
              loading="lazy"
            />
            <div>
              <p className="font-semibold text-white">Marcus Webb</p>
              <p className="text-sm text-white/80">
                Managing Partner, Webb &amp; Associates — Leeds
              </p>
            </div>
          </div>
          <div className="mt-6 flex flex-wrap gap-3">
            {[
              "Local SEO Strategy",
              "Google Business Profile Optimisation",
              "Citation Building",
              "Content Authority",
            ].map((tag) => (
              <span
                key={tag}
                className="inline-flex items-center gap-1 text-xs text-white/80 bg-white/10 border border-white/20 rounded-full px-3 py-1"
              >
                <CheckCircle className="h-3 w-3 text-primary" />
                {tag}
              </span>
            ))}
          </div>
        </div>

        <p className="mt-8 text-sm text-white/80">
          See more results in our{" "}
          <a
            href="#case-studies-cta"
            className="underline underline-offset-4 hover:text-white transition-colors"
          >
            case studies
          </a>{" "}
          or{" "}
          <a
            href="/local-seo"
            className="underline underline-offset-4 hover:text-white transition-colors"
          >
            learn how local SEO works
          </a>
          .
        </p>
      </div>

      {/* Divider */}
      <svg
        className="absolute bottom-0 left-0 w-full h-12 md:h-16 z-10 pointer-events-none"
        viewBox="0 0 1200 80"
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <path
          d="M0,40 C300,80 900,0 1200,40 L1200,80 L0,80 Z"
          fill="hsl(var(--background))"
        />
      </svg>
    </section>
  );
});

LocationsLeedsTestimonial.displayName = "LocationsLeedsTestimonial";
export default LocationsLeedsTestimonial;
