import React from "react";
import { Check, Code, Settings, Shield, Globe, FileText, Icon, Phone, User } from "lucide-react";

const technicalRequirements = [
  {
    icon: Globe,
    category: "Crawlability",
    items: [
      "Allow GPTBot (OpenAI's crawler) in robots.txt — blocking it removes you from ChatGPT's index entirely",
      "Ensure all key pages return HTTP 200 with no redirect chains longer than two hops",
      "Submit an up-to-date XML sitemap and verify it is being crawled regularly",
      "Avoid JavaScript-only content; critical text must be in the HTML source",
    ],
  },
  {
    icon: Settings,
    category: "Technical Indexing",
    items: [
      "Core Web Vitals: LCP under 2.5s, CLS under 0.1 — slow pages are deprioritised in retrieval",
      "Mobile-first responsive layout with no horizontal overflow or content clipping",
      "Canonical tags correctly set to avoid duplicate content dilution",
      "Internal linking with descriptive anchor text to signal topical authority",
    ],
  },
  {
    icon: Code,
    category: "Structured Data",
    items: [
      "FAQPage schema for question-and-answer content — directly consumed by AI answer engines",
      "Article or BlogPosting schema with datePublished and author entity markup",
      "LocalBusiness or Organization schema with NAP (Name, Address, Phone) data",
      "HowTo schema for step-by-step instructional content",
    ],
  },
];

const AiSearchChatgptTechnical = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section ref={ref} className="relative py-20 md:py-32 border-t border-border bg-background">
      <div className="container">
        <div className="max-w-2xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Technical requirements
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Technical Requirements for ChatGPT Visibility
          </h2>
          <p className="text-muted-foreground leading-relaxed">
            Before your content can be cited, it must be accessible to OpenAI&apos;s crawlers, indexable, and structured in a way machines can understand. These are the non-negotiables.
          </p>
          <div className="mt-5 flex flex-wrap gap-4">
            <a href="/technical-seo" className="text-sm text-primary font-semibold hover:underline">
              Technical SEO services →
            </a>
            <a href="/schema-markup" className="text-sm text-primary font-semibold hover:underline">
              Schema Markup services →
            </a>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {technicalRequirements.map(({ icon: Icon, category, items }) => (
            <div
              key={category}
              className="bg-card border border-border rounded-xl p-7 shadow-card"
            >
              <div className="flex items-center gap-3 mb-6">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="text-lg font-bold text-foreground">{category}</h3>
              </div>
              <ul className="space-y-3">
                {items.map((item) => (
                  <li key={item} className="flex items-start gap-3">
                    <Check className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                    <span className="text-sm text-muted-foreground leading-relaxed">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* GPTBot robots.txt note */}
        <div className="mt-10 bg-muted border border-border rounded-xl p-6 flex gap-4 items-start">
          <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary/10 shrink-0">
            <Shield className="h-4 w-4 text-primary" />
          </div>
          <div>
            <p className="font-semibold text-foreground text-sm mb-1">GPTBot Access Is Opt-In by Default</p>
            <p className="text-sm text-muted-foreground leading-relaxed">
              Many sites inadvertently block GPTBot via wildcard disallow rules. Check your robots.txt now: if it contains{" "}
              <code className="bg-muted-foreground/10 px-1 py-0.5 rounded text-xs font-mono">User-agent: * / Disallow: /</code>{" "}
              without a specific allow for GPTBot, OpenAI cannot crawl your site. Add{" "}
              <code className="bg-muted-foreground/10 px-1 py-0.5 rounded text-xs font-mono">User-agent: GPTBot / Allow: /</code>{" "}
              to re-enable access.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
});

AiSearchChatgptTechnical.displayName = "AiSearchChatgptTechnical";
export default AiSearchChatgptTechnical;
