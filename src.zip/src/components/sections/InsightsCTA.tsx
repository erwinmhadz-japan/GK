import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, BookOpen, Mail } from "lucide-react";

const InsightsCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="insights-cta"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">

          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.55, ease: "easeOut" }}
          >
            <span className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.18em] font-medium text-muted-foreground mb-6">
              <BookOpen className="h-3.5 w-3.5 text-primary" />
              Independent SEO Consultancy
            </span>
          </motion.div>

          {/* Headline */}
          <motion.h2
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight tracking-tight mb-5"
            style={{ fontFamily: "Sora, sans-serif" }}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.08 }}
          >
            Work With an Independent{" "}
            <span
              className="bg-clip-text text-transparent"
              style={{
                backgroundImage:
                  "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
              }}
            >
              SEO Consultant
            </span>
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-xl mx-auto mb-10"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.16 }}
          >
            Enquire about a free GBP audit or an initial consultation to discuss
            your search visibility.
          </motion.p>

          {/* CTA buttons */}
          <motion.div
            className="flex flex-col sm:flex-row items-center justify-center gap-3"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.24 }}
          >
            <Button
              size="lg"
              className="h-11 px-8 text-sm font-semibold rounded-md"
              style={{
                backgroundImage:
                  "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                color: "hsl(222 42% 8%)",
              }}
              asChild
            >
              <Link to="/contact">
                Get in Touch
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>

            <Button
              size="lg"
              variant="outline"
              className="h-11 px-8 text-sm font-medium rounded-md border-border text-foreground hover:bg-muted transition-colors"
              asChild
            >
              <Link to="/contact">
                <Mail className="mr-2 h-4 w-4 text-primary" />
                FREE GBP AUDIT
              </Link>
            </Button>
          </motion.div>

          {/* Reassurance line */}
          <motion.p
            className="mt-7 text-xs text-muted-foreground"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.5, ease: "easeOut", delay: 0.35 }}
          >
            Independent consultant · Based in Warrington, Cheshire · UK businesses only
          </motion.p>
        </div>
      </div>
    </section>
  );
});

InsightsCTA.displayName = "InsightsCTA";

export default InsightsCTA;
