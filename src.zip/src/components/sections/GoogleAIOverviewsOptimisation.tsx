import React from "react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CheckCircle, Brain, Layers, Shield, FileText, Link2, Eye, Tags, ChevronRight, Link, Search, Section, Target, View } from "lucide-react";

const optimisationAreas = [
  {
    icon: Layers,
    title: "Structured Content Architecture",
    description:
      "AI Overviews draw from well-organised content. Use clear heading hierarchies (H1–H3), logical content flow, and concise factual paragraphs that directly answer search queries. Avoid dense blocks of unbroken prose.",
    tips: [
      "Lead with the answer, then elaborate",
      "Use descriptive subheadings for each section",
      "Keep paragraphs focused on a single idea",
    ],
  },
  {
    icon: Shield,
    title: "EEAT Signals",
    description:
      "Google's AI Overviews heavily favour content demonstrating Experience, Expertise, Authoritativeness, and Trustworthiness. For UK businesses, this means publishing attributed content, citing credentials, and building a credible authorship trail.",
    tips: [
      "Named authors with verifiable credentials",
      "Cite primary sources and industry data",
      "Demonstrate hands-on experience in the subject matter",
    ],
  },
  {
    icon: Tags,
    title: "Schema Markup and Structured Data",
    description:
      "Schema markup helps Google understand the entities, relationships, and factual claims within your content. Properly implemented structured data — particularly Article, FAQPage, and HowTo schemas — increases the likelihood of surfacing in AI-generated summaries.",
    tips: [
      "Implement Article schema with author and datePublished",
      "Use FAQPage schema for question-format content",
      "Apply HowTo schema for step-by-step guides",
    ],
  },
  {
    icon: Brain,
    title: "Entity Clarity and Topical Authority",
    description:
      "AI Overviews are entity-aware. Your site must clearly establish the entities it represents — your brand, the services you offer, and the topics you cover — and demonstrate consistent, authoritative coverage of those topics across interconnected pages.",
    tips: [
      "Build a coherent internal topic cluster",
      "Ensure consistent entity naming across all pages",
      "Link related content to reinforce topical coverage",
    ],
  },
  {
    icon: FileText,
    title: "Factual, Citable Content",
    description:
      "Google's AI synthesises facts it can verify and attribute. Content that states clear, defensible claims — backed by data, research, or first-hand expertise — is more likely to be drawn on than vague or promotional copy.",
    tips: [
      "Include specific statistics or case data where possible",
      "Avoid weasel words and vague superlatives",
      "Write for the informed reader, not the search engine",
    ],
  },
  {
    icon: Link2,
    title: "Authoritative Inbound Signals",
    description:
      "Sites referenced by AI Overviews tend to carry strong domain authority signals. Earning links from credible UK publications, professional bodies, and industry sources signals to Google that your content is a reliable source worth surfacing.",
    tips: [
      "Target editorial coverage from relevant UK media",
      "Seek references from professional or sector bodies",
      "Digital PR is among the most effective routes to citation",
    ],
  },
  {
    icon: Eye,
    title: "Query-Specific Optimisation",
    description:
      "AI Overviews are triggered by specific query patterns — often informational questions or how-to searches. Mapping your content to these query types, and ensuring each page answers a distinct intent clearly, is fundamental to appearing in generated summaries.",
    tips: [
      "Create dedicated pages for high-value question queries",
      "Include the query verbatim in headings or opening paragraphs",
      "One clear topic focus per page — avoid over-broad coverage",
    ],
  },
  {
    icon: Layers,
    title: "Page Speed and Core Web Vitals",
    description:
      "Technical performance remains a prerequisite. Slow-loading pages or those with poor Core Web Vitals scores are less likely to surface in AI-generated results, even with strong content. A technically sound page provides the foundation everything else depends on.",
    tips: [
      "Achieve a Largest Contentful Paint under 2.5s",
      "Address layout shift with explicit image dimensions",
      "Prioritise server response time and render-blocking resources",
    ],
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
      delayChildren: 0.2,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const headingVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut" },
  },
};

const GoogleAIOverviewsOptimisation = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="google-aioverviews-optimisation"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          className="max-w-3xl mb-14 md:mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={headingVariants}
        >
          <Badge
            variant="outline"
            className="mb-4 text-xs uppercase tracking-widest border-[hsl(214_32%_60%)] text-[hsl(214_32%_60%)]"
          >
            Practical Optimisation Guidance
          </Badge>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-semibold text-foreground mt-2 mb-4">
            How to Optimise for Google AI Overviews
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
            Appearing in Google's AI-generated summaries is not a single tactic — it is the outcome
            of several interconnected signals working together. Below are the areas I focus on when
            helping UK businesses improve their visibility in AI Overviews.
          </p>
        </motion.div>

        {/* Optimisation areas grid */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={containerVariants}
        >
          {optimisationAreas.map((area, index) => {
            const Icon = area.icon;
            return (
              <motion.div key={area.title} variants={itemVariants}>
                <Card className="h-full border border-border shadow-sm hover:shadow-md transition-shadow duration-300 rounded-md bg-card group">
                  <CardHeader className="pb-3">
                    <div className="flex items-start gap-4">
                      <div
                        className="flex-shrink-0 flex h-10 w-10 items-center justify-center rounded-md"
                        style={{
                          background: "hsl(214 32% 60% / 0.12)",
                        }}
                      >
                        <Icon
                          className="h-5 w-5"
                          style={{ color: "hsl(214 32% 60%)" }}
                        />
                      </div>
                      <CardTitle className="text-base md:text-lg font-semibold text-foreground leading-snug pt-1">
                        {area.title}
                      </CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                      {area.description}
                    </p>
                    <ul className="space-y-2">
                      {area.tips.map((tip) => (
                        <li key={tip} className="flex items-start gap-2">
                          <CheckCircle
                            className="h-4 w-4 mt-0.5 flex-shrink-0 text-[hsl(119_35%_61%)]"
                          />
                          <span className="text-sm text-muted-foreground">{tip}</span>
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Closing note */}
        <motion.div
          className="mt-14 md:mt-20 max-w-2xl"
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6, ease: "easeOut", delay: 0.2 }}
        >
          <p className="text-sm md:text-base text-muted-foreground leading-relaxed border-l-2 border-[hsl(214_32%_60%)] pl-4 italic">
            These are not isolated quick fixes. Sustainable AI Overview visibility comes from
            building a technically sound, content-rich, and credibly authoritative website over
            time. I work with UK businesses to address each of these areas in a structured,
            evidence-led way.
          </p>
          <a
            href="/ai-search-optimisation"
            className="inline-flex items-center gap-1.5 mt-6 text-sm font-medium text-[hsl(214_32%_60%)] hover:text-foreground transition-colors duration-200 group"
          >
            View my AI Search Optimisation service
            <ChevronRight className="h-4 w-4 group-hover:translate-x-0.5 transition-transform duration-200" />
          </a>
        </motion.div>
      </div>
    </section>
  );
});

GoogleAIOverviewsOptimisation.displayName = "GoogleAIOverviewsOptimisation";

export default GoogleAIOverviewsOptimisation;
