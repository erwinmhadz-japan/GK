import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Bot, ArrowRight, Search } from "lucide-react";

const AiSearchCopilotHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="copilot-hero"
      aria-label="Microsoft Copilot Visibility Hero"
      src="https://images.unsplash.com/photo-1573496528298-f0e9d3c7ce55?w=1920&h=1080&fit=crop"
      alt="Professional working at computer with AI interface"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center"
    >
      <div className="container relative z-10 py-24 md:py-36">
        <div className="max-w-3xl">
          <div className="flex items-center gap-3 mb-6">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/20 backdrop-blur-sm border border-primary/30">
              <Bot className="h-5 w-5 text-primary" />
            </div>
            <Badge className="bg-primary/20 text-primary border-primary/30 backdrop-blur-sm text-xs uppercase tracking-widest font-medium">
              Microsoft Copilot
            </Badge>
          </div>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Microsoft Copilot Visibility &amp; AI Search Optimisation
          </h1>
          <p className="text-lg md:text-xl text-white/90 mb-8 leading-relaxed max-w-2xl">
            Millions of users rely on Microsoft Copilot to surface answers, recommendations, and business information. Is your brand being cited? Learn how Copilot indexes content and how to make your site a trusted source.
          </p>
          <div className="flex flex-wrap gap-4">
            <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold" asChild>
              <a href="/services-ai-search-optimisation">
                Get Copilot Optimisation
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10"
              asChild
            >
              <a href="/contact">Discuss Your Visibility</a>
            </Button>
          </div>
          <p className="mt-6 text-sm text-white/80">
            Independent AI search specialist · No agency overhead · Results-focused
          </p>
        </div>
      </div>
    </ImageBackground>
  );
});

AiSearchCopilotHero.displayName = "AiSearchCopilotHero";
export default AiSearchCopilotHero;
