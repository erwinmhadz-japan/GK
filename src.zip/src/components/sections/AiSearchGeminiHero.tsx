import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Brain, CheckCircle } from "lucide-react";

const AiSearchGeminiHero = React.forwardRef<HTMLElement>((props, ref) => {
  const highlights = [
    "Gemini indexing signals",
    "Authority & E-E-A-T",
    "AI Overview alignment",
  ];

  return (
    <ImageBackground
      ref={ref}
      id="gemini-hero"
      aria-label="Gemini Visibility Hero section"
      src="https://images.unsplash.com/photo-1573496528298-f0e9d3c7ce55?w=1920&h=1080&fit=crop"
      alt="Professional working on AI search optimisation strategy"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center"
    >
      <div className="container relative z-10 py-24 md:py-36">
        <div className="max-w-3xl">
          <Badge
            variant="secondary"
            className="mb-6 bg-primary/20 text-white border-primary/30 backdrop-blur-sm"
          >
            <Brain className="h-3.5 w-3.5 mr-1.5" />
            Google Gemini Visibility
          </Badge>

          <h1 className="text-4xl md:text-6xl font-bold text-white leading-tight mb-6">
            Get Found by{" "}
            <span className="text-gradient-green">Google Gemini</span>
          </h1>

          <p className="text-lg md:text-xl text-white/90 leading-relaxed mb-8 max-w-2xl">
            Google Gemini is reshaping how millions of users discover information.
            Learn how to optimise your content so Gemini cites, surfaces, and
            recommends your brand — and how an independent SEO consultant can
            make it happen for your business.
          </p>

          <ul className="flex flex-col sm:flex-row flex-wrap gap-3 mb-10">
            {highlights.map((item) => (
              <li
                key={item}
                className="flex items-center gap-2 text-white/80 text-sm font-medium"
              >
                <CheckCircle className="h-4 w-4 text-primary shrink-0" />
                {item}
              </li>
            ))}
          </ul>

          <div className="flex flex-wrap gap-4">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
              asChild
            >
              <a href="/services-ai-search-optimisation">
                Explore Gemini Optimisation
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10"
              asChild
            >
              <a href="/contact">Talk to an Expert</a>
            </Button>
          </div>
        </div>
      </div>
    </ImageBackground>
  );
});

AiSearchGeminiHero.displayName = "AiSearchGeminiHero";

export default AiSearchGeminiHero;
