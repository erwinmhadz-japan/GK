import React from "react";
import { motion } from "framer-motion";
import { Newspaper, Target, Zap, Mic, TrendingUp, Link, CheckCircle, Building, Section } from "lucide-react";

const approaches = [
  {
    icon: Target,
    title: "Strategic Pitch-Led Outreach",
    body: "Every campaign begins with a clearly defined link target — publication tier, domain authority, and topical relevance. I identify which journalists and editors cover your sector, then build pitches tailored to their beat, not broadcast to a generic list. The goal is a small number of high-value placements, not volume for its own sake.",
  },
  {
    icon: Zap,
    title: "Reactive PR and Newsjacking",
    body: "When a story breaks that intersects with your industry, I move quickly to position you — or your business — as a credible source of expert commentary. Reactive PR is one of the most efficient routes to coverage in national and trade titles. It requires preparation, genuine expertise, and the ability to respond within hours, not days.",
  },
  {
    icon: TrendingUp,
    title: "Data-Led Campaigns",
    body: "Original data is consistently one of the most linkable formats in digital PR. I work with clients to surface proprietary data — survey findings, internal metrics, industry analysis — and package it into compelling stories that journalists can use. The result is editorial coverage with a natural, editorially-placed link.",
  },
  {
    icon: Mic,
    title: "Expert Commentary Placement",
    body: "Journalists need authoritative sources. I build ongoing relationships with writers and editors in your sector so that when they need a knowledgeable voice — for a feature, a reaction piece, or an explainer — your name is on their shortlist. This generates consistent coverage without a new campaign each time.",
  },
  {
    icon: Link,
    title: "Link Equity and SEO Alignment",
    body: "Digital PR without an SEO lens is just PR. Every campaign I plan is grounded in link equity strategy — which pages need authority, which anchor text patterns support topical relevance, and which publications carry the most weight with Google. Coverage and rankings are treated as a unified objective, not separate workstreams.",
  },
  {
    icon: Newspaper,
    title: "Journalist Relationship Building",
    body: "Churn-and-burn outreach — mass-emailing a press release to thousands of contacts — is not how I work. I invest in real relationships with journalists, editors, and podcast producers across your target sector. Those relationships compound over time, making each subsequent campaign faster and more effective.",
  },
];

const distinctions = [
  "Campaign strategy built around your SEO objectives, not vanity metrics",
  "Pitches written for individual journalists, not distributed to lists",
  "Coverage measured by link equity and domain relevance, not press clipping volume",
  "I manage every campaign personally — no junior team, no handoffs",
  "Campaigns designed to complement your broader SEO and content strategy",
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 22 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const DigitalPrApproach = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="digital-pr-approach"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mb-14 md:mb-20"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            How I work
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground max-w-3xl leading-tight">
            My approach to digital PR
          </h2>
          <p className="mt-5 text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
            Digital PR done properly is a discipline that combines editorial judgement, relationship
            management, and a clear understanding of how link equity works. What follows is how I
            approach each component of a campaign — and why it differs from what most agencies do.
          </p>
        </motion.div>

        {/* Approach grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8 mb-16 md:mb-24"
        >
          {approaches.map((item) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.title}
                variants={itemVariants}
                className="bg-background border border-border rounded-md p-7 flex flex-col gap-4 group hover:shadow-md transition-shadow duration-300"
              >
                <div className="flex items-center justify-center h-11 w-11 rounded-md bg-primary/10 shrink-0">
                  <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
                </div>
                <h3 className="text-base md:text-lg font-semibold text-foreground leading-snug">
                  {item.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{item.body}</p>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Distinction panel */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="bg-background border border-border rounded-md px-8 py-10 md:px-12 md:py-12"
        >
          <div className="max-w-3xl">
            <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
              What makes this different
            </span>
            <h3 className="text-xl md:text-2xl font-bold text-foreground mb-2 leading-snug">
              Consultant-led, not agency-processed
            </h3>
            <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-8">
              Most digital PR is delivered at scale by junior teams working from templated processes.
              I work differently. Every campaign I run is built from scratch around your business
              objectives, your sector, and the specific publications that carry weight with your
              audience and with Google.
            </p>
            <ul className="space-y-3" role="list">
              {distinctions.map((point) => (
                <li key={point} className="flex items-start gap-3">
                  <CheckCircle
                    className="h-5 w-5 text-primary shrink-0 mt-0.5"
                    aria-hidden="true"
                  />
                  <span className="text-sm md:text-base text-foreground leading-relaxed">
                    {point}
                  </span>
                </li>
              ))}
            </ul>
          </div>
        </motion.div>
      </div>
    </section>
  );
});

DigitalPrApproach.displayName = "DigitalPrApproach";

export default DigitalPrApproach;
