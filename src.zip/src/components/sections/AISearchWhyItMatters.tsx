import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { TrendingUp, Eye, BrainCircuit, ArrowRight, Layers, Building, Search, Section } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (delay: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay },
  }),
};

const reasons = [
  {
    icon: TrendingUp,
    heading: "AI answers are replacing blue links",
    body:
      "For a growing share of queries — particularly in competitive sectors such as law, finance, and healthcare — users are receiving synthesised AI answers before they ever see a traditional results page. If your brand is not being cited, you are losing visibility you may not yet be measuring.",
  },
  {
    icon: BrainCircuit,
    heading: "Citation depends on topical authority",
    body:
      "Platforms such as ChatGPT, Perplexity, and Gemini draw on sources they deem credible and authoritative within a given topic. Building that authority requires consistent, well-structured content that establishes genuine expertise — the same foundations that underpin strong organic rankings.",
  },
  {
    icon: Eye,
    heading: "Visibility gaps are already widening",
    body:
      "Businesses that invest early in AI search optimisation are accruing a compounding advantage. Those that wait are allowing competitors to occupy the answer space first. The window for establishing early authority is narrowing month by month.",
  },
  {
    icon: Layers,
    heading: "Traditional SEO and AI search are complementary",
    body:
      "AI platforms surface content from trusted, well-structured sources. A sound technical foundation, strong entity signals, and authoritative content all serve both traditional organic search and AI-generated answers. The disciplines reinforce one another.",
  },
];

const AISearchWhyItMatters = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="aisearch-why-it-matters"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <div className="max-w-3xl mb-14 md:mb-18">
          <motion.span
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            custom={0}
            viewport={{ once: true, margin: "-60px" }}
            className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium"
          >
            Context &amp; significance
          </motion.span>

          <motion.h2
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            custom={0.08}
            viewport={{ once: true, margin: "-60px" }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground font-[Sora,sans-serif] leading-tight tracking-tight mb-6"
          >
            Why AI Search Visibility Matters Now
          </motion.h2>

          <motion.p
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            custom={0.16}
            viewport={{ once: true, margin: "-60px" }}
            className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl"
          >
            The way people find information online is undergoing a structural shift. Search engines
            are evolving into answer engines — and the brands cited within those answers are
            determined not by paid placement, but by perceived authority. Understanding this
            transition is the first step to navigating it.
          </motion.p>
        </div>

        {/* Reason cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-14">
          {reasons.map((reason, index) => {
            const Icon = reason.icon;
            return (
              <motion.div
                key={reason.heading}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                custom={0.1 + index * 0.1}
                viewport={{ once: true, margin: "-60px" }}
                className="group relative border border-border rounded-md bg-background p-7 md:p-8 transition-all duration-300 hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%/0.10),_0_1px_4px_hsl(222_28%_11%/0.05)] hover:border-primary/30"
              >
                {/* Icon */}
                <div className="flex items-center justify-center w-10 h-10 rounded-md bg-primary/10 mb-5">
                  <Icon className="h-5 w-5 text-primary" />
                </div>

                <h3 className="text-base md:text-lg font-semibold text-foreground mb-3 leading-snug font-[Sora,sans-serif]">
                  {reason.heading}
                </h3>
                <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                  {reason.body}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Contextual bridge paragraph */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          custom={0.5}
          viewport={{ once: true, margin: "-60px" }}
          className="max-w-2xl border-l-2 border-primary/40 pl-6"
        >
          <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
            The pages in this hub explore how individual AI platforms — ChatGPT, Perplexity, Google
            AI Overviews, Gemini, and Copilot — surface information, and what factors influence
            whether your business is included. For UK businesses seeking to act on these insights
            through structured consultancy, the{" "}
            <Link
              to="/ai-search-optimisation"
              className="text-foreground font-medium underline underline-offset-4 decoration-primary/60 hover:decoration-primary transition-colors duration-200"
            >
              AI search optimisation service
            </Link>{" "}
            outlines Gregg's approach to improving your presence across AI-generated answers.
          </p>
        </motion.div>

        {/* Subtle inline navigation cue */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          custom={0.62}
          viewport={{ once: true, margin: "-60px" }}
          className="mt-8"
        >
          <Link
            to="/ai-search-optimisation"
            className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors duration-200 group"
          >
            <span>Explore the AI search optimisation service</span>
            <ArrowRight className="h-4 w-4 text-primary group-hover:translate-x-0.5 transition-transform duration-200" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
});

AISearchWhyItMatters.displayName = "AISearchWhyItMatters";

export default AISearchWhyItMatters;
