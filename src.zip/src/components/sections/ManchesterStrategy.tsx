import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Check, Search, MapPin, Layers, Network, ArrowRight, Zap, Grid, Map as MapIcon, Scale, View } from "lucide-react";

const strategyPillars = [
  {
    icon: MapPin,
    heading: "Manchester Local SEO & Map Pack",
    body: "Optimise your Google Business Profile for Manchester city centre and suburb queries. Capture the Map Pack for high-intent local searches — 'accountant Manchester', 'solicitor Deansgate', 'IT support Salford' — where visibility directly converts to enquiries.",
    items: [
      "Google Business Profile optimisation",
      "Manchester borough landing pages",
      "Local citation building & NAP consistency",
      "Review strategy for Manchester clients",
    ],
  },
  {
    icon: Search,
    heading: "City-Specific Keyword Architecture",
    body: "Manchester search behaviour differs from national patterns. We map the full keyword universe — from head terms to long-tail commercial queries — and build a content architecture that captures intent across the Greater Manchester conurbation.",
    items: [
      "Manchester, Salford, Trafford, Stockport geo-targeting",
      "Commercial intent keyword prioritisation",
      "Competitor gap analysis for Manchester SERPs",
      "Semantic topic cluster development",
    ],
  },
  {
    icon: Layers,
    heading: "Enterprise Technical SEO",
    body: "Manchester's enterprise market demands technical SEO quality that matches the investment scale of FTSE-listed competitors. Core Web Vitals, crawl efficiency, and structured data are foundational — not optional — at this level.",
    items: [
      "Core Web Vitals & page speed optimisation",
      "LocalBusiness & Service schema markup",
      "International hreflang for multi-market clients",
      "JavaScript rendering & indexability audits",
    ],
  },
  {
    icon: Network,
    heading: "Authority & Digital PR",
    body: "Manchester's media ecosystem — including Manchester Evening News, The Business Desk, and Prolific North — offers rich link-building opportunities. A targeted digital PR strategy builds the domain authority required to rank for competitive Manchester queries.",
    items: [
      "Manchester media outreach & link acquisition",
      "Industry association citations",
      "Expert commentary & thought leadership",
      "Northern Powerhouse sector PR",
    ],
  },
  {
    icon: Zap,
    heading: "AI Search & Zero-Click Visibility",
    body: "Manchester businesses increasingly need to appear in AI-generated answers on ChatGPT, Perplexity, and Google AI Overviews. We optimise your entity signals so you feature in AI responses for Manchester-specific queries, not just traditional search.",
    items: [
      "Entity optimisation for AI search engines",
      "E-E-A-T signal development",
      "Featured snippet & PAA targeting",
      "Google AI Overviews optimisation",
    ],
  },
  {
    icon: Layers,
    heading: "ROI-Focused Reporting",
    body: "Every Manchester client receives transparent, commercially-focused reporting. We track the metrics that matter — organic revenue, lead volume, cost-per-lead reduction — not vanity statistics.",
    items: [
      "Monthly ranking & traffic reports",
      "Lead & conversion attribution",
      "Competitor ranking tracking",
      "Quarterly strategy reviews",
    ],
  },
];

const ManchesterStrategy = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="manchester-strategy"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className="max-w-2xl mb-14">
          <motion.span
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="inline-block text-xs uppercase tracking-[0.2em] text-primary font-semibold mb-4"
          >
            SEO Strategy — Manchester
          </motion.span>
          <motion.h2
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, delay: 0.06 }}
            className="text-3xl md:text-4xl font-bold text-foreground mb-5"
          >
            A Local SEO Strategy Built for Manchester's Scale
          </motion.h2>
          <motion.p
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, delay: 0.12 }}
            className="text-lg text-muted-foreground leading-relaxed"
          >
            Ranking in Manchester requires more than basic local SEO. The city's competitive
            density, enterprise-level rivals, and sophisticated buyers demand a multi-pillar strategy
            that covers technical depth, content authority, and local prominence simultaneously.
          </motion.p>
        </div>

        {/* Strategy Pillars Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {strategyPillars.map((pillar, idx) => (
            <motion.div
              key={pillar.heading}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: idx * 0.07 }}
              className="bg-background rounded-xl border border-border p-7 hover-lift shadow-card"
            >
              <div className="flex items-center gap-3 mb-4">
                <div className="flex items-center justify-center w-10 h-10 rounded-lg bg-primary/10">
                  <pillar.icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="text-base font-semibold text-foreground leading-snug">{pillar.heading}</h3>
              </div>
              <p className="text-sm text-muted-foreground leading-relaxed mb-4">{pillar.body}</p>
              <ul className="space-y-2">
                {pillar.items.map((item) => (
                  <li key={item} className="flex items-start gap-2">
                    <Check className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                    <span className="text-sm text-muted-foreground">{item}</span>
                  </li>
                ))}
              </ul>
            </motion.div>
          ))}
        </div>

        {/* Internal Links + CTA */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="flex flex-wrap gap-4 items-center"
        >
          <Button size="lg" asChild>
            <Link to="/contact">
              Discuss Your Manchester SEO Strategy
              <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
          </Button>
          <Button size="lg" variant="outline" asChild>
            <Link to="/services">View All SEO Services</Link>
          </Button>
          <Badge variant="outline" className="text-xs border-border text-muted-foreground">
            <Link to="/local-seo" className="hover:text-primary transition-colors">
              Local SEO Service →
            </Link>
          </Badge>
        </motion.div>
      </div>
    </section>
  );
});

ManchesterStrategy.displayName = "ManchesterStrategy";

export default ManchesterStrategy;
