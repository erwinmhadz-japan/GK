import React from "react";
import { Factory, Briefcase, Building2, ArrowRight, Icon, Image, Section, View } from "lucide-react";
import { Button } from "@/components/ui/button";

const industries = [
  {
    icon: Factory,
    sector: "Advanced Manufacturing & Engineering",
    image: "https://images.unsplash.com/photo-1633537065982-712792c23798?w=800&h=600&fit=crop",
    imageAlt: "Birmingham modern architecture representing manufacturing sector",
    challenge:
      "Supply chain companies, precision engineers, and OEM suppliers often have invisible online presences. Procurement managers use Google to shortlist vendors — if you're not on page 1, you're not in the room.",
    approach: [
      "Product and service category pages built around buyer intent queries",
      "ISO and accreditation schema markup for instant trust signals",
      "Case study content targeting industry-specific problem searches",
      "B2B directory listings and trade publication link building",
    ],
    results: "Manufacturers we work with typically see 40–80% growth in qualified B2B enquiries within 6 months.",
  },
  {
    icon: Briefcase,
    sector: "Professional Services & B2B",
    image: "https://images.unsplash.com/photo-1685492259744-f42597aac776?w=800&h=600&fit=crop",
    imageAlt: "Modern Birmingham office buildings representing professional services",
    challenge:
      "The competition for 'accountant Birmingham' or 'commercial solicitor West Midlands' is intense. With 15+ national firms and dozens of local players, ranking requires authority, content depth, and hyperlocal signals.",
    approach: [
      "Practice area pages with semantic depth and E-E-A-T signals",
      "Thought leadership content positioning principals as Midlands experts",
      "Local citation building across legal, financial, and business directories",
      "Review strategy to build social proof at scale",
    ],
    results: "B2B service clients typically achieve top-5 local pack positions within 4–6 months of retainer start.",
  },
  {
    icon: Building2,
    sector: "Retail, Hospitality & Consumer Services",
    image: "https://images.unsplash.com/photo-1568649704650-a6ab20e84311?w=800&h=600&fit=crop",
    imageAlt: "People walking near Birmingham commercial district buildings",
    challenge:
      "Footfall-dependent businesses face competition from aggregators, national chains, and Google's own features. Capturing 'near me' searches and local discovery requires a distinct strategy from e-commerce or B2B.",
    approach: [
      "Neighbourhood landing pages targeting specific Birmingham postcodes and districts",
      "GBP photo optimisation, posts strategy, and attribute completion",
      "Event and offer schema for enhanced SERP visibility",
      "Review velocity management for consistent 4.5+ star presence",
    ],
    results: "Consumer service clients see an average 55% increase in GBP profile views and 3× call volume growth.",
  },
];

const BirminghamIndustries = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="birmingham-industries"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-3xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            Industry-Specific Approaches
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-5">
            Birmingham SEO Tailored to Your Sector
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Generic SEO strategies underperform in Birmingham's diverse economy.
            Each sector has its own search intent patterns, competition profile,
            and trust signals. Here's how we adapt our approach for the city's
            three dominant business types.
          </p>
        </div>

        {/* Industry cards */}
        <div className="space-y-10">
          {industries.map(({ icon: Icon, sector, image, imageAlt, challenge, approach, results }, index) => (
            <div
              key={sector}
              className={`grid grid-cols-1 lg:grid-cols-2 gap-8 items-center bg-card border border-border rounded-2xl overflow-hidden shadow-card ${
                index % 2 === 1 ? "lg:grid-flow-dense" : ""
              }`}
            >
              {/* Image */}
              <div className={`relative h-64 lg:h-full min-h-[280px] ${index % 2 === 1 ? "lg:col-start-2" : ""}`}>
                <img
                  src={image}
                  alt={imageAlt}
                  loading="lazy"
                  width="800"
                  height="600"
                  className="w-full h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-r from-card/60 to-transparent lg:hidden" />
              </div>

              {/* Content */}
              <div className={`p-8 ${index % 2 === 1 ? "lg:col-start-1 lg:row-start-1" : ""}`}>
                <div className="flex items-center gap-3 mb-4">
                  <div className="h-10 w-10 rounded-lg bg-primary/10 flex items-center justify-center">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <h3 className="text-xl font-bold text-foreground">{sector}</h3>
                </div>

                <p className="text-muted-foreground text-sm leading-relaxed mb-5">
                  {challenge}
                </p>

                <h4 className="text-sm font-semibold text-foreground uppercase tracking-wider mb-3">
                  Our Approach
                </h4>
                <ul className="space-y-2 mb-6">
                  {approach.map((item) => (
                    <li key={item} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <ArrowRight className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                      {item}
                    </li>
                  ))}
                </ul>

                <div className="bg-primary/10 border border-primary/20 rounded-lg px-4 py-3">
                  <p className="text-sm text-foreground font-medium">{results}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Industries CTA */}
        <div className="mt-12 text-center">
          <p className="text-muted-foreground mb-6 text-sm">
            Operating in a different sector? Explore our full industry coverage.
          </p>
          <Button variant="outline" asChild>
            <a href="#industries-cta" className="inline-flex items-center gap-2">
              View All Industries We Serve
              <ArrowRight className="h-4 w-4" />
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
});

BirminghamIndustries.displayName = "BirminghamIndustries";

export default BirminghamIndustries;
