import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Phone, Mail, MapPin, ArrowRight, CheckCircle, Contact, Search, View } from "lucide-react";

// LocalBusiness + Organization JSON-LD for Birmingham
const localBusinessJsonLd = {
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "LocalBusiness",
      "@id": "https://greggcoppen.com/locations/birmingham",
      name: "Gregg Coppen SEO — Birmingham",
      description:
        "Independent SEO consultancy serving businesses in Birmingham, West Midlands. Specialising in local SEO, technical SEO, and AI search optimisation.",
      url: "https://greggcoppen.com/locations/birmingham",
      telephone: "+44-7XXX-XXXXXX",
      email: "hello@greggcoppen.com",
      address: {
        "@type": "PostalAddress",
        addressLocality: "Birmingham",
        addressRegion: "West Midlands",
        postalCode: "B1",
        addressCountry: "GB",
      },
      geo: {
        "@type": "GeoCoordinates",
        latitude: 52.4862,
        longitude: -1.8904,
      },
      areaServed: {
        "@type": "City",
        name: "Birmingham",
      },
      serviceType: [
        "SEO Consulting",
        "Local SEO",
        "Technical SEO",
        "AI Search Optimisation",
        "SEO Audit",
        "Content Strategy",
      ],
      priceRange: "££",
    },
    {
      "@type": "Organization",
      "@id": "https://greggcoppen.com",
      name: "Gregg Coppen SEO",
      url: "https://greggcoppen.com",
      sameAs: [
        "https://www.linkedin.com/in/greggcoppen",
        "https://twitter.com/greggcoppen",
      ],
      contactPoint: {
        "@type": "ContactPoint",
        contactType: "customer service",
        email: "hello@greggcoppen.com",
        availableLanguage: "English",
      },
    },
  ],
};

const BirminghamCTA: React.FC = () => {
  return (
    <ImageBackground
      src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?w=1920&h=1080&fit=crop"
      alt="Team collaborating around laptops — representing Birmingham SEO partnerships"
      imgProps={{ loading: "lazy" }}
      className="py-24 md:py-36"
      id="birmingham-contact"
    >
      {/* JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(localBusinessJsonLd) }}
      />

      <div className="container relative z-10">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          {/* Left: contact info */}
          <div>
            <Badge className="bg-primary/20 text-white border-primary/30 mb-5 text-xs uppercase tracking-widest">
              Birmingham Contact
            </Badge>
            <h2 className="text-3xl md:text-5xl font-bold text-white mb-5">
              Ready to Grow Your Birmingham Business?
            </h2>
            <p className="text-white/90 text-lg mb-8 leading-relaxed">
              Get in touch for a free initial consultation. I'll review your current
              SEO position, identify quick wins, and outline a realistic path to
              improved visibility in the Birmingham market.
            </p>

            <div className="space-y-4 mb-8">
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center h-9 w-9 rounded-lg bg-white/10">
                  <MapPin className="h-4 w-4 text-primary" />
                </div>
                <span className="text-white/90 text-sm">
                  Serving Birmingham, West Midlands & wider UK
                </span>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center h-9 w-9 rounded-lg bg-white/10">
                  <Mail className="h-4 w-4 text-primary" />
                </div>
                <a
                  href="mailto:hello@greggcoppen.com"
                  className="text-white/90 text-sm hover:text-white transition-colors"
                >
                  hello@greggcoppen.com
                </a>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center justify-center h-9 w-9 rounded-lg bg-white/10">
                  <Phone className="h-4 w-4 text-primary" />
                </div>
                <a
                  href="tel:+447XXXXXXXXX"
                  className="text-white/90 text-sm hover:text-white transition-colors"
                >
                  Available for Birmingham consultations
                </a>
              </div>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
                asChild
              >
                <a href="/contact">
                  Get Your Free Audit
                  <ArrowRight className="ml-2 h-5 w-5" />
                </a>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="bg-transparent text-white border-white hover:bg-white/10"
                asChild
              >
                <a href="/services">View All Services</a>
              </Button>
            </div>
          </div>

          {/* Right: trust points */}
          <div className="bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-8">
            <h3 className="text-white font-semibold text-lg mb-6">
              What to Expect When You Reach Out
            </h3>
            <ul className="space-y-4">
              {[
                "A free 30-minute discovery call with no obligation",
                "An honest review of your current Birmingham SEO position",
                "A clear outline of priority actions and expected impact",
                "No jargon — straightforward, plain-English recommendations",
                "No lock-in contracts — flexible monthly engagements",
              ].map((point) => (
                <li key={point} className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <span className="text-white/90 text-sm leading-relaxed">{point}</span>
                </li>
              ))}
            </ul>

            <div className="mt-8 pt-6 border-t border-white/20">
              <p className="text-white/80 text-xs">
                Serving businesses across Birmingham — from the Jewellery Quarter to
                Sutton Coldfield and beyond.{" "}
                <a href="/locations" className="text-primary hover:underline font-medium">
                  See all locations →
                </a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </ImageBackground>
  );
};

export default BirminghamCTA;
