import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { MapPin, ArrowRight, Search, View } from "lucide-react";

const WarringtonHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      src="https://images.unsplash.com/photo-1573496528298-f0e9d3c7ce55?w=1920&h=1080&fit=crop"
      alt="Professional SEO consultant working at a desk"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center"
    >
      {/* LocalBusiness + Organization JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify([
            {
              "@context": "https://schema.org",
              "@type": "LocalBusiness",
              name: "Gregg SEO Consulting — Warrington",
              description:
                "Expert SEO consulting services for businesses in Warrington. Specialising in local SEO, technical SEO, content strategy, and AI search optimisation.",
              url: "https://greggseo.com/locations/warrington",
              telephone: "+44-1925-000000",
              address: {
                "@type": "PostalAddress",
                streetAddress: "Centre Park",
                addressLocality: "Warrington",
                addressRegion: "Cheshire",
                postalCode: "WA1 1QG",
                addressCountry: "GB",
              },
              geo: {
                "@type": "GeoCoordinates",
                latitude: 53.3879,
                longitude: -2.5974,
              },
              areaServed: [
                "Warrington",
                "Cheshire",
                "Runcorn",
                "Widnes",
                "Newton-le-Willows",
                "Lymm",
                "Northwich",
              ],
              serviceType: "SEO Consulting",
              priceRange: "££",
              openingHoursSpecification: {
                "@type": "OpeningHoursSpecification",
                dayOfWeek: [
                  "Monday",
                  "Tuesday",
                  "Wednesday",
                  "Thursday",
                  "Friday",
                ],
                opens: "09:00",
                closes: "18:00",
              },
              sameAs: [
                "https://www.linkedin.com/in/greggseo",
                "https://twitter.com/greggseo",
              ],
            },
            {
              "@context": "https://schema.org",
              "@type": "Organization",
              name: "Gregg SEO Consulting",
              url: "https://greggseo.com",
              logo: "https://greggseo.com/logo.png",
              contactPoint: {
                "@type": "ContactPoint",
                telephone: "+44-1925-000000",
                contactType: "customer service",
                areaServed: "GB",
                availableLanguage: "English",
              },
            },
          ]),
        }}
      />

      <div className="container relative z-10 py-20 md:py-32">
        <div className="flex items-center gap-2 mb-6">
          <MapPin className="h-4 w-4 text-primary" aria-hidden="true" />
          <span className="text-sm uppercase tracking-[0.2em] text-white/80 font-medium">
            Warrington, Cheshire
          </span>
        </div>

        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-white max-w-3xl leading-tight">
          SEO Consulting in{" "}
          <span className="text-gradient-green">Warrington</span>
        </h1>

        <p className="mt-6 text-lg md:text-xl text-white/90 max-w-2xl leading-relaxed">
          Independent SEO expertise tailored to Warrington businesses. Whether
          you're a growing SME in the town centre or an established firm near
          Birchwood Business Park, I help you rank higher, attract more local
          customers, and outperform competitors.
        </p>

        <div className="mt-4 flex flex-wrap gap-3">
          {[
            "Local SEO",
            "Technical SEO",
            "AI Search",
            "Content Strategy",
          ].map((tag) => (
            <span
              key={tag}
              className="px-3 py-1 rounded-full bg-white/10 border border-white/20 text-sm text-white/80"
            >
              {tag}
            </span>
          ))}
        </div>

        <div className="flex flex-wrap gap-4 mt-10">
          <Button
            size="lg"
            className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
            asChild
          >
            <a href="/contact">
              Get a Free Consultation
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-transparent text-white border-white hover:bg-white/10"
            asChild
          >
            <a href="/services">View Services</a>
          </Button>
        </div>

        <p className="mt-6 text-sm text-white/80">
          Serving Warrington and surrounding areas · No long-term contracts · Results-focused
        </p>
      </div>
    </ImageBackground>
  );
});

WarringtonHero.displayName = "WarringtonHero";

export default WarringtonHero;
