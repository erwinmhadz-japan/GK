import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { ArrowRight, Search, Sparkles } from "lucide-react";

const AiSearchGoogleAiOverviewsHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      src="https://images.unsplash.com/photo-1573496528298-f0e9d3c7ce55?w=1920&h=1080&fit=crop"
      alt="Professional working on SEO and AI search strategy at a computer"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center"
    >
      <div className="container relative z-10 py-24 md:py-32">
        <div className="max-w-3xl">
          <Badge className="mb-6 bg-primary/20 text-primary border-primary/30 text-sm px-4 py-1.5">
            <Sparkles className="h-3.5 w-3.5 mr-2" />
            AI Search Optimisation
          </Badge>
          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
            Google AI Overviews —{" "}
            <span className="text-gradient-green">What They Are & How to Rank in Them</span>
          </h1>
          <p className="text-xl md:text-2xl text-white/90 mb-4 leading-relaxed">
            Formerly known as Search Generative Experience (SGE), Google AI Overviews
            now appear at the top of millions of UK search results — reshaping how
            users discover businesses online.
          </p>
          <p className="text-lg text-white/80 mb-10">
            Learn how Google generates these AI-powered summaries, the EEAT signals
            that determine inclusion, and the technical and content strategies that
            give your site the best chance of being cited.
          </p>
          <div className="flex flex-wrap gap-4">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold px-8"
              asChild
            >
              <a href="/services-ai-search-optimisation">
                AI Search Services
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10 font-semibold px-8"
              asChild
            >
              <a href="/contact">
                <Search className="mr-2 h-5 w-5" />
                Get a Free Audit
              </a>
            </Button>
          </div>
          <p className="mt-8 text-sm text-white/80">
            Internal links: <a href="#ai-search-cta" className="underline hover:text-primary transition-colors">AI Search</a> · <a href="/entity-seo" className="underline hover:text-primary transition-colors">Entity SEO</a> · <a href="/technical-seo" className="underline hover:text-primary transition-colors">Technical SEO</a>
          </p>
        </div>
      </div>
    </ImageBackground>
  );
});

AiSearchGoogleAiOverviewsHero.displayName = "AiSearchGoogleAiOverviewsHero";

export default AiSearchGoogleAiOverviewsHero;
