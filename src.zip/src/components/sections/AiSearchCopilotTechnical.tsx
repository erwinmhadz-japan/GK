import React from "react";
import { CheckCircle, Code, Database, FileText, Link, Shield, Search, Network } from "lucide-react";

const technicalFactors = [
  {
    icon: Search,
    title: "Bing Crawlability",
    description:
      "Copilot's web sourcing runs through Bing's index — if Bingbot cannot access your pages, your content cannot be cited. Ensure your robots.txt does not block Bingbot and that your XML sitemap is submitted to Bing Webmaster Tools.",
    checks: [
      "robots.txt allows Bingbot",
      "XML sitemap submitted to Bing Webmaster Tools",
      "No crawl-blocking JavaScript rendering issues",
      "Canonical tags correctly implemented",
    ],
  },
  {
    icon: Code,
    title: "Structured Data & Schema Markup",
    description:
      "Copilot uses structured data to understand entity relationships and content type. Implementing Schema.org markup — particularly Article, FAQPage, Organization, and LocalBusiness — helps Copilot contextualise and correctly attribute your content.",
    checks: [
      "Article or BlogPosting schema on editorial content",
      "FAQPage schema for question-answer content",
      "Organization schema with correct name, URL, and sameAs",
      "BreadcrumbList schema for hierarchical pages",
    ],
  },
  {
    icon: FileText,
    title: "Page Quality Signals",
    description:
      "Microsoft's content quality evaluation considers E-E-A-T signals similar to Google — but with a stronger emphasis on Bing's Webmaster Guidelines. Pages with thin content, excessive ads, or poor readability are deprioritised in Copilot's sourcing.",
    checks: [
      "Substantive, expert-level content depth",
      "Clear author attribution and credentials",
      "Minimal intrusive advertising or pop-ups",
      "Fast page load speed (Core Web Vitals)",
    ],
  },
  {
    icon: Database,
    title: "Entity Recognition & Indexing",
    description:
      "Copilot recognises entities — your brand, key people, products, and services — and maps them to knowledge graph entries. Content that consistently references and defines these entities helps Copilot associate your brand with specific topics.",
    checks: [
      "Consistent brand name usage across pages",
      "Named entity references in content (people, places, organisations)",
      "Wikipedia or Wikidata entity alignment where applicable",
      "Internal linking reinforces topic clusters",
    ],
  },
  {
    icon: Link,
    title: "Authority Signals & Digital PR",
    description:
      "Like traditional SEO, Copilot prioritises content from sources that have earned authority through external citations, backlinks, and brand mentions. A strong digital PR strategy builds the trust signals that make Copilot more likely to surface your content.",
    checks: [
      "High-quality editorial backlinks",
      "Brand mentions in industry publications",
      "Consistent NAP data for local business entities",
      "Social proof through third-party reviews and citations",
    ],
  },
  {
    icon: Shield,
    title: "Security & Technical Trust",
    description:
      "Copilot will not surface content from sites flagged for security issues or poor technical hygiene. HTTPS, no malware flags, and stable server uptime are baseline requirements for Copilot indexing consideration.",
    checks: [
      "HTTPS implemented site-wide",
      "No Bing Webmaster security flags",
      "Stable server uptime and response times",
      "No cloaking or deceptive content patterns",
    ],
  },
];

const AiSearchCopilotTechnical = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="technical-copilot"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Technical Requirements
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Technical Factors for Copilot Visibility
          </h2>
          <p className="text-muted-foreground text-base md:text-lg leading-relaxed">
            Copilot visibility is not accidental. It requires deliberate technical foundations — from Bing crawl access to structured data signals and entity authority. Here's what matters most.
          </p>
          <div className="flex flex-wrap justify-center gap-4 mt-6">
            <a
              href="/technical-seo"
              className="text-sm text-primary font-medium hover:underline underline-offset-4"
            >
              Explore Technical SEO →
            </a>
            <a
              href="/content-strategy"
              className="text-sm text-primary font-medium hover:underline underline-offset-4"
            >
              Content Strategy Services →
            </a>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {technicalFactors.map((factor) => (
            <div
              key={factor.title}
              className="p-7 rounded-xl bg-card border border-border hover-lift shadow-card"
            >
              <div className="flex items-start gap-4 mb-4">
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-lg bg-primary/10">
                  <factor.icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="text-lg font-bold text-foreground pt-1">{factor.title}</h3>
              </div>
              <p className="text-muted-foreground text-sm leading-relaxed mb-5">
                {factor.description}
              </p>
              <ul className="space-y-2">
                {factor.checks.map((check) => (
                  <li key={check} className="flex items-start gap-2.5 text-sm text-foreground">
                    <CheckCircle className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                    <span>{check}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
});

AiSearchCopilotTechnical.displayName = "AiSearchCopilotTechnical";
export default AiSearchCopilotTechnical;
