import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Fingerprint, Tag, Sparkles, MessageSquare, ScanSearch, Globe, Bot, BrainCircuit, Layers, Radar, Building, Search, Section } from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";

interface ServiceArea {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
}

const serviceAreas: ServiceArea[] = [
  {
    icon: Fingerprint,
    title: "Brand Entity Disambiguation",
    description:
      "I clarify and reinforce your brand as a distinct, well-defined entity across the knowledge graph — resolving ambiguities so AI models reliably identify and cite your business by name, not by coincidence.",
  },
  {
    icon: Layers,
    title: "Entity Optimisation for LLMs",
    description:
      "I build and strengthen the semantic entity profile that large language models use to understand who you are, what you do, and why you matter — ensuring your business is represented accurately within AI knowledge structures.",
  },
  {
    icon: Tag,
    title: "Structured Data & Schema for AI Parsing",
    description:
      "I implement precise, context-rich schema markup that enables AI answer engines to extract, interpret, and surface your content with confidence — making your pages machine-readable at the level AI systems require.",
  },
  {
    icon: Sparkles,
    title: "Content Authority Signals",
    description:
      "I strengthen the topical depth, expertise signals, and trustworthiness cues within your content — the qualities AI models assess when deciding which sources to draw from and recommend in generated responses.",
  },
  {
    icon: Globe,
    title: "Citation Building & Source Authority",
    description:
      "I develop a credible citation footprint across authoritative, indexed sources — the external references AI models rely on when forming an understanding of your brand and deciding whether to surface it as a recommendation.",
  },
  {
    icon: ScanSearch,
    title: "Prompt-Response Analysis",
    description:
      "I audit how AI platforms currently respond to queries relevant to your business — identifying where you appear, where competitors are cited instead, and what structural or content changes are needed to improve your presence.",
  },
  {
    icon: BrainCircuit,
    title: "ChatGPT Visibility Optimisation",
    description:
      "I analyse and improve how your brand is represented in ChatGPT's responses — working on the entity signals, content depth, and reference quality that influence whether OpenAI's models cite your business in relevant answers.",
  },
  {
    icon: Radar,
    title: "Perplexity & Google AI Overviews",
    description:
      "I address the distinct retrieval logic of Perplexity and Google's AI Overviews — both of which surface real-time sources differently to ChatGPT — ensuring your content is structured to qualify for inclusion in these answer formats.",
  },
  {
    icon: Bot,
    title: "Gemini & Copilot Visibility",
    description:
      "I extend AI search visibility work to Google Gemini and Microsoft Copilot, each with different indexing and citation behaviours — ensuring your brand presence is consistent across the full landscape of AI answer platforms.",
  },
  {
    icon: MessageSquare,
    title: "Platform-Specific Visibility Strategy",
    description:
      "Rather than applying a single generic approach, I develop tailored recommendations for each AI platform — recognising that ChatGPT, Perplexity, Google AI Overviews, Gemini, and Copilot each have distinct retrieval and citation mechanisms.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.08,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: {
      duration: 0.55,
      ease: "easeOut",
    },
  },
};

const AiSearchOptimisationServices = React.forwardRef<HTMLElement>(
  (props, ref) => {
    return (
      <section
        ref={ref}
        id="ai-search-optimisation-services"
        className="relative py-20 md:py-32 border-t border-border bg-background"
      >
        <div className="container max-w-6xl mx-auto px-4">
          {/* Section header */}
          <motion.div
            className="max-w-2xl mb-14 md:mb-16"
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-60px" }}
            transition={{ duration: 0.6, ease: "easeOut" }}
          >
            <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
              Service Scope
            </span>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-semibold text-foreground font-[Sora,sans-serif] leading-snug mb-5">
              What AI Search Optimisation Involves
            </h2>
            <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
              AI search optimisation is not a single tactic. It draws on a
              range of interconnected disciplines — from entity SEO and
              structured data through to content authority and
              platform-specific citation strategies. Below is an overview of
              the key areas I work across for clients.
            </p>
          </motion.div>

          {/* Service cards grid — exactly 10 items */}
          <motion.div
            className="grid grid-cols-1 md:grid-cols-2 gap-5 md:gap-6"
            variants={containerVariants}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-40px" }}
          >
            {serviceAreas.map((service) => {
              const Icon = service.icon;
              return (
                <motion.div key={service.title} variants={itemVariants}>
                  <Card
                    className="group h-full border border-border bg-background hover:bg-[image:var(--gradient-card-hover)] transition-all duration-300"
                    style={{
                      boxShadow: "var(--shadow-soft)",
                    }}
                  >
                    <CardHeader className="pb-3 pt-6 px-6">
                      <div className="flex items-start gap-4">
                        {/* Icon container */}
                        <div
                          className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-primary/10 group-hover:bg-primary/15 transition-colors duration-300"
                        >
                          <Icon className="h-5 w-5 text-primary" />
                        </div>
                        <h3 className="text-base md:text-[1.05rem] font-semibold text-foreground font-[Sora,sans-serif] leading-snug pt-1">
                          {service.title}
                        </h3>
                      </div>
                    </CardHeader>
                    <CardContent className="px-6 pb-6 pt-1 pl-[4.5rem]">
                      <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                        {service.description}
                      </p>
                    </CardContent>
                  </Card>
                </motion.div>
              );
            })}
          </motion.div>

          {/* Subtle closing note */}
          <motion.p
            className="mt-12 text-sm text-muted-foreground max-w-2xl"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.3, ease: "easeOut" }}
          >
            Each engagement is shaped around your specific situation — the
            platforms where your audience is searching, the query types relevant
            to your sector, and the current state of your entity and content
            footprint.{" "}
            <Link
              to="#ai-search-cta"
              className="text-primary underline underline-offset-4 hover:text-primary/80 transition-colors duration-200"
            >
              Explore the AI search knowledge hub →
            </Link>
          </motion.p>

          {/* Platform-specific page links */}
          <motion.div
            className="mt-10 border-t border-border pt-8"
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.2, ease: "easeOut" }}
          >
            <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground font-medium mb-4">
              Platform-Specific Guides
            </p>
            <div className="flex flex-wrap gap-2">
              {[
                { label: "ChatGPT Visibility", to: "/chatgpt-visibility" },
                { label: "Perplexity Visibility", to: "/perplexity-visibility" },
                { label: "Google AI Overviews", to: "/google-ai-overviews" },
                { label: "Gemini Visibility", to: "/gemini-visibility" },
                { label: "Copilot Visibility", to: "/copilot-visibility" },
              ].map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  className="inline-flex items-center gap-1.5 rounded-full border border-border bg-muted/60 px-3 py-1.5 text-xs font-medium text-foreground hover:border-primary/40 hover:text-primary transition-colors duration-200"
                >
                  {link.label}
                </Link>
              ))}
            </div>
          </motion.div>
        </div>
      </section>
    );
  }
);

AiSearchOptimisationServices.displayName = "AiSearchOptimisationServices";

export default AiSearchOptimisationServices;
