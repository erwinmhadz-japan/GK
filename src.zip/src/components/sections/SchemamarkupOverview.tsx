import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Search, Layers, Eye, Network, Braces, TrendingUp, CheckCircle2, ListTree, Globe, Lightbulb, Map as MapIcon } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (delay: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay },
  }),
};

const concepts = [
  {
    icon: Braces,
    title: "Structured data",
    body: "Schema markup is a standardised vocabulary — based on Schema.org — that annotates your HTML with machine-readable signals. It tells search engines precisely what your content represents: a business, a product, a review, a person, an event.",
  },
  {
    icon: Search,
    title: "Rich results in Google",
    body: "When implemented correctly, structured data unlocks rich results: star ratings in organic listings, FAQ accordions beneath your snippet, HowTo steps, breadcrumb trails, and product details — all of which increase click-through rate and search visibility.",
  },
  {
    icon: Eye,
    title: "Knowledge panels and entity recognition",
    body: "Google uses schema markup to build its Knowledge Graph. Consistent, accurate structured data strengthens entity recognition — improving your eligibility for knowledge panels and branded search features.",
  },
  {
    icon: Network,
    title: "AI-powered answer engines",
    body: "ChatGPT, Perplexity, Google AI Overviews, and Gemini all rely on structured, entity-rich data to answer queries with confidence. Schema markup signals that your content is authoritative and well-defined — making it more likely to be cited.",
  },
  {
    icon: Layers,
    title: "Content clarity for crawlers",
    body: "Search engines are sophisticated but not infallible. Structured data removes ambiguity: a law firm's website becomes unambiguously a legal services business, not just a collection of text about law. That clarity has direct SEO value.",
  },
  {
    icon: TrendingUp,
    title: "Competitive differentiation",
    body: "In competitive sectors — law, healthcare, finance, property — most sites either skip schema entirely or implement it poorly. Correct, comprehensive markup is a meaningful edge that is visible in the SERPs and measurable in performance.",
  },
];

const howItWorks = [
  {
    icon: ListTree,
    step: "01",
    heading: "Audit existing markup",
    detail: "Before implementing anything, the existing structured data — if any — is reviewed for errors, omissions, and conflicts. Google Search Console and third-party validators are used to surface issues.",
  },
  {
    icon: Globe,
    step: "02",
    heading: "Map schema types to your content",
    detail: "Not every page needs the same schema. A service page calls for Service or ProfessionalService markup; a blog article needs Article; a clinic needs MedicalBusiness. The correct types are identified per page and per content category.",
  },
  {
    icon: Lightbulb,
    step: "03",
    heading: "Implementation and testing",
    detail: "Markup is implemented in JSON-LD format — the approach recommended by Google — and validated against the Rich Results Test and Schema.org specifications before going live.",
  },
  {
    icon: CheckCircle2,
    step: "04",
    heading: "Monitoring and iteration",
    detail: "Post-implementation, Search Console is monitored for rich result eligibility changes, errors, and enhancements. Schema markup is iterated as content evolves or Google's requirements change.",
  },
];

const SchemamarkupOverview = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="schemamarkup-overview"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Header */}
        <motion.div
          className="max-w-3xl mb-14 md:mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          custom={0}
          variants={fadeUp}
        >
          <span className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium">
            Structured Data Explained
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight tracking-tight mb-5">
            What Schema Markup Does for Your SEO
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed max-w-2xl">
            Schema markup — also known as structured data — is one of the most
            technically underutilised areas of search optimisation. When implemented
            correctly, it improves how search engines read your content, unlocks rich
            result features, and strengthens your presence in AI-powered answer
            engines. Here is what it is and why it matters.
          </p>
        </motion.div>

        {/* Six concept cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16 md:mb-24">
          {concepts.map((concept, i) => {
            const Icon = concept.icon;
            return (
              <motion.div
                key={concept.title}
                className="group rounded-md border border-border bg-background p-6 transition-all duration-300"
                style={{ boxShadow: "var(--shadow-card)" }}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-60px" }}
                custom={i * 0.08}
                variants={fadeUp}
                whileHover={{ y: -3, boxShadow: "var(--shadow-card-hover)" }}
              >
                <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mb-4">
                  <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
                </div>
                <h3 className="text-base font-semibold text-foreground mb-2">
                  {concept.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {concept.body}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* Divider */}
        <div className="border-t border-border mb-16 md:mb-24" />

        {/* How It Works — 4-step process */}
        <motion.div
          className="max-w-2xl mb-12"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          custom={0}
          variants={fadeUp}
        >
          <span className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium">
            The consultancy approach
          </span>
          <h3 className="text-2xl md:text-3xl font-bold text-foreground leading-tight mb-3">
            How structured data work is carried out
          </h3>
          <p className="text-base text-muted-foreground leading-relaxed">
            Implementing schema markup is not simply adding a code snippet. Each
            engagement follows a structured process that ensures accuracy, completeness,
            and alignment with Google's evolving specifications.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16 md:mb-24">
          {howItWorks.map((item, i) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.step}
                className="flex gap-5 rounded-md border border-border bg-background p-6"
                style={{ boxShadow: "var(--shadow-soft)" }}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-60px" }}
                custom={i * 0.1}
                variants={fadeUp}
              >
                <div className="shrink-0 flex flex-col items-center gap-3">
                  <span className="text-xs font-semibold text-primary/70 tracking-widest tabular-nums">
                    {item.step}
                  </span>
                  <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10">
                    <Icon className="h-4 w-4 text-primary" aria-hidden="true" />
                  </div>
                </div>
                <div>
                  <h4 className="text-sm font-semibold text-foreground mb-2">
                    {item.heading}
                  </h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {item.detail}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Informational callout — links to AI search informational pages */}
        <motion.div
          className="rounded-md border border-border bg-muted/40 p-7 md:p-9 flex flex-col md:flex-row md:items-start gap-6"
          style={{ boxShadow: "var(--shadow-soft)" }}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          custom={0.1}
          variants={fadeUp}
        >
          <div className="shrink-0 flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 mt-0.5">
            <Network className="h-5 w-5 text-primary" aria-hidden="true" />
          </div>
          <div>
            <h4 className="text-base font-semibold text-foreground mb-2">
              Schema markup and AI search visibility
            </h4>
            <p className="text-sm text-muted-foreground leading-relaxed mb-4 max-w-2xl">
              The connection between structured data and AI-powered answer engines
              is increasingly direct. Entities that are clearly defined through
              schema — businesses, people, services, locations — are better
              positioned to be cited by ChatGPT, Perplexity, and Google's AI
              Overviews. This intersection between technical SEO and generative AI
              is covered in more depth across the AI search knowledge hub.
            </p>
            <div className="flex flex-wrap gap-4 text-sm">
              <Link
                to="#ai-search-cta"
                className="text-primary underline-offset-4 hover:underline font-medium transition-colors"
              >
                AI search knowledge hub →
              </Link>
              <Link
                to="/ai-search-optimisation"
                className="text-primary underline-offset-4 hover:underline font-medium transition-colors"
              >
                AI search optimisation service →
              </Link>
            </div>
          </div>
        </motion.div>

      </div>
    </section>
  );
});

SchemamarkupOverview.displayName = "SchemamarkupOverview";

export default SchemamarkupOverview;
