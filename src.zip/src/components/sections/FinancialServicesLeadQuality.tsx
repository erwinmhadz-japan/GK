import React from "react";
import { Target, TrendingUp, BadgeCheck, DollarSign, Search, Section } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const metrics = [
  {
    icon: Target,
    stat: "2.4×",
    label: "Higher Conversion Rate",
    description:
      "Organic leads from E-E-A-T-optimised financial content convert at more than double the rate of paid search traffic — because search users have already validated your expertise before clicking.",
  },
  {
    icon: DollarSign,
    stat: "68%",
    label: "Lower Cost Per Acquisition",
    description:
      "Once established, organic authority compounds. Financial services firms that invest in sustainable SEO typically reduce their cost per qualified lead by over two-thirds versus paid channels within 18 months.",
  },
  {
    icon: TrendingUp,
    stat: "+312%",
    label: "Organic Enquiry Growth",
    description:
      "Our financial services clients see transformative growth in qualified organic enquiries — driven by intent-matched content that reaches prospects at the precise moment they're evaluating options.",
  },
  {
    icon: BadgeCheck,
    stat: "91%",
    label: "Compliance Pass Rate",
    description:
      "Our content briefs are built around regulatory guidelines from day one. Over 91% of content pieces pass compliance review without significant amendment — saving your team time and protecting your FCA permissions.",
  },
];

const strategies = [
  {
    heading: "Intent Architecture for High-Value Queries",
    body: "We map your financial products to the precise search queries used by high-net-worth individuals, business owners and corporate decision-makers — not just generic financial terms. Each content asset is positioned at the right funnel stage to capture decision-ready intent.",
  },
  {
    heading: "Local SEO for Adviser and Branch Networks",
    body: "For financial advisory firms with regional offices or individual advisers, local SEO creates a powerful client acquisition channel. Optimised Google Business Profiles, localised landing pages and local citation strategies combine to surface your advisers at the moment of local financial need.",
  },
  {
    heading: "AI Search Visibility for Financial Queries",
    body: "As AI Overviews, Perplexity and ChatGPT become primary research tools for financial decisions, being cited as an authoritative source is increasingly valuable. Our entity and content strategy positions your firm to appear in AI-generated financial answers — at zero cost per impression.",
  },
];

const FinancialServicesLeadQuality = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="financial-lead-quality"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-2xl mx-auto text-center mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            Lead Quality &amp; Client Acquisition
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            More Qualified Enquiries, Lower Cost Per Client
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            SEO for financial services isn't just about traffic — it's about attracting the right
            prospects at the right moment. Our data shows that E-E-A-T-aligned organic traffic
            consistently outperforms paid channels on lead quality metrics.
          </p>
        </div>

        {/* Metrics grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
          {metrics.map((metric, index) => {
            const Icon = metric.icon;
            return (
              <Card
                key={index}
                className="bg-card border-border shadow-card hover-lift transition-all duration-300 text-center"
              >
                <CardContent className="p-6">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10 mx-auto mb-4">
                    <Icon className="h-6 w-6 text-primary" />
                  </div>
                  <p className="text-3xl font-bold text-primary mb-1">{metric.stat}</p>
                  <p className="text-foreground font-semibold text-sm mb-3">{metric.label}</p>
                  <p className="text-muted-foreground text-xs leading-relaxed">
                    {metric.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Strategy breakdown */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {strategies.map((strategy, index) => (
            <div
              key={index}
              className="bg-muted rounded-xl p-6 border border-border"
            >
              <h3 className="text-foreground font-bold text-base mb-3 leading-snug">
                {strategy.heading}
              </h3>
              <p className="text-muted-foreground text-sm leading-relaxed">{strategy.body}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
});

FinancialServicesLeadQuality.displayName = "FinancialServicesLeadQuality";

export default FinancialServicesLeadQuality;
