import React from "react";
import { motion } from "framer-motion";
import { Sparkles, Eye, Search, Globe, BarChart2, Lightbulb, AlertCircle, CheckCircle, Brain, FileText, TrendingUp, Icon, Key, Section } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (delay: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut", delay },
  }),
};

const GoogleAIOverviewsExplainer = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="google-aioverviews-explainer"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section intro */}
        <motion.div
          className="max-w-3xl mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={fadeUp}
          custom={0}
        >
          <span className="inline-flex items-center gap-2 text-xs uppercase tracking-[0.18em] text-muted-foreground font-medium mb-5">
            <Sparkles className="h-3.5 w-3.5 text-primary" />
            Understanding AI Overviews
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight mb-6">
            What Are Google AI Overviews — and Why Do They Matter?
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Google AI Overviews represent one of the most significant changes to organic search in a decade. If your business depends on search visibility, understanding how these summaries work — and how they are triggered — is no longer optional.
          </p>
        </motion.div>

        {/* Main explainer grid — two columns of editorial prose */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 mb-20">

          {/* Left column */}
          <motion.div
            className="space-y-10"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            custom={0.1}
          >
            {/* What they are */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10 shrink-0">
                  <Brain className="h-[18px] w-[18px] text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">What Are AI Overviews?</h3>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                Google AI Overviews — previously known as Search Generative Experience (SGE) during testing — are AI-generated summaries that appear at the very top of certain search results pages. They are produced by Google's Gemini large language model and synthesise information from multiple sources to provide a direct, structured answer to a user's query.
              </p>
              <p className="text-muted-foreground leading-relaxed mt-4">
                Unlike traditional featured snippets, which pull a passage verbatim from a single page, AI Overviews generate original prose that draws on several sources simultaneously. The websites cited within those summaries are listed as reference links — often receiving a prominent placement above the standard ten organic results.
              </p>
            </div>

            {/* Where they appear */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10 shrink-0">
                  <Search className="h-[18px] w-[18px] text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">Where Do They Appear in Search Results?</h3>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                AI Overviews appear above the organic results — in a prominent, visually distinct panel — for queries where Google's systems determine that a synthesised answer would genuinely help the user. They are most commonly triggered by informational and research-led queries: questions beginning with "how", "what", "why", and "which" tend to surface them more frequently than purely transactional searches.
              </p>
              <p className="text-muted-foreground leading-relaxed mt-4">
                In the UK, AI Overviews rolled out more gradually than in the United States, but they are now active and increasingly visible across Google.co.uk for a wide range of query types — including many directly relevant to sectors such as law, finance, healthcare, and property.
              </p>
            </div>
          </motion.div>

          {/* Right column */}
          <motion.div
            className="space-y-10"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            custom={0.2}
          >
            {/* What triggers them */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10 shrink-0">
                  <Lightbulb className="h-[18px] w-[18px] text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">What Triggers an AI Overview?</h3>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                Google does not publish a definitive list of triggers, but patterns from analysis and testing point to a consistent set of conditions. AI Overviews are more likely to appear when:
              </p>
              <ul className="mt-4 space-y-3">
                {[
                  "The query has a clear informational intent — the user is seeking to understand something rather than immediately purchase",
                  "The topic is multi-faceted, meaning a single-source answer would be insufficient or misleading",
                  "High-quality, well-structured content from authoritative sources exists at scale on the subject",
                  "The query involves subject areas where Google has sufficient confidence in its training data and source quality",
                  "The topic benefits from synthesis — comparing perspectives, summarising processes, or explaining nuanced concepts",
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                    <span className="text-muted-foreground leading-relaxed text-sm">{item}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Sensitive verticals */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10 shrink-0">
                  <AlertCircle className="h-[18px] w-[18px] text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">Sensitive Verticals and Suppression</h3>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                Google applies additional scrutiny — and in some cases actively suppresses AI Overviews — for queries in what it classifies as sensitive or "Your Money or Your Life" (YMYL) categories. Legal advice, medical information, and financial guidance are the most prominent examples. If your business operates in these sectors, AI Overviews may appear less frequently for your core commercial queries — but informational content in adjacent areas can still earn a citation.
              </p>
            </div>
          </motion.div>
        </div>

        {/* Impact stats band */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-3 gap-5 mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={fadeUp}
          custom={0.15}
        >
          {[
            {
              Icon: Eye,
              stat: "Above the fold",
              detail:
                "AI Overviews occupy the most prominent position on the search results page — above paid ads and the standard organic listing.",
            },
            {
              Icon: Globe,
              stat: "Live on Google.co.uk",
              detail:
                "AI Overviews are now active across a growing range of query types on the UK version of Google Search.",
            },
            {
              Icon: BarChart2,
              stat: "Click behaviour shifting",
              detail:
                "Early data indicates that cited sources within AI Overviews can receive meaningful referral traffic — but only when they are actually referenced.",
            },
          ].map((item, i) => (
            <div
              key={i}
              className="bg-background border border-border rounded-md p-6 flex flex-col gap-3"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                <item.Icon className="h-5 w-5 text-primary" />
              </div>
              <p className="text-base font-semibold text-foreground">{item.stat}</p>
              <p className="text-sm text-muted-foreground leading-relaxed">{item.detail}</p>
            </div>
          ))}
        </motion.div>

        {/* Second prose block */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 mb-20">

          <motion.div
            className="space-y-10"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            custom={0.1}
          >
            {/* How Google selects sources */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10 shrink-0">
                  <FileText className="h-[18px] w-[18px] text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">How Does Google Select Sources to Cite?</h3>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                The sources cited in an AI Overview are not drawn at random from the top-ranking results. Google's systems evaluate a combination of signals to determine which pages merit a reference:
              </p>
              <ul className="mt-4 space-y-3">
                {[
                  "E-E-A-T signals: pages that demonstrate direct experience and verifiable expertise are consistently favoured over generic commentary",
                  "Structured, clearly organised content: well-formatted pages with logical headings, concise paragraphs, and scannable layout are easier for the AI to parse and quote accurately",
                  "Entity clarity: pages where the author, organisation, and subject matter are clearly defined and consistent with wider web knowledge",
                  "Topical depth: comprehensive coverage of a subject signals authority — thin or surface-level content is unlikely to be cited",
                  "Schema markup and structured data: these technical signals help Google understand the type, context, and credibility of your content",
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle className="h-4 w-4 text-primary mt-0.5 shrink-0" />
                    <span className="text-muted-foreground leading-relaxed text-sm">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>

          <motion.div
            className="space-y-10"
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true, margin: "-60px" }}
            variants={fadeUp}
            custom={0.2}
          >
            {/* Why it matters for UK businesses */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10 shrink-0">
                  <TrendingUp className="h-[18px] w-[18px] text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">Why This Matters for UK Businesses</h3>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                For UK businesses in competitive sectors — law firms, healthcare providers, financial services, estate agents — AI Overviews represent a new and consequential battleground for organic visibility. A business whose content is cited occupies the most prominent position on the page, above both paid results and the traditional organic listings.
              </p>
              <p className="text-muted-foreground leading-relaxed mt-4">
                Conversely, a business that is not cited — even if it ranks in the top three organic positions — may find its click-through rate materially reduced as users engage with the AI summary without scrolling further.
              </p>
              <p className="text-muted-foreground leading-relaxed mt-4">
                It is no longer sufficient to simply rank. The quality, structure, and authority signals of your content must also satisfy the requirements of Google's generative AI systems. This is a meaningfully different optimisation challenge from traditional SEO — and one that relatively few UK businesses have yet begun to address systematically.
              </p>
            </div>

            {/* Difference from traditional SEO */}
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="flex h-9 w-9 items-center justify-center rounded-md bg-primary/10 shrink-0">
                  <Sparkles className="h-[18px] w-[18px] text-primary" />
                </div>
                <h3 className="text-lg font-semibold text-foreground">How This Differs from Traditional SEO</h3>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                Traditional SEO focuses primarily on ranking signals: backlinks, keyword relevance, page experience, and technical health. These remain important. But AI Overviews introduce an additional requirement: your content must also be legible to a language model, structured to allow accurate attribution, and authored by a credible, clearly identified source.
              </p>
              <p className="text-muted-foreground leading-relaxed mt-4">
                Some pages that rank well organically may still fail to earn a citation in AI Overviews — if the content lacks depth, if entity signals are weak, or if the information is too generic to be worth quoting. Bridging that gap requires a specific and deliberate approach to content structure, authority building, and technical SEO.
              </p>
            </div>
          </motion.div>
        </div>

        {/* Key concepts glossary panel */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={fadeUp}
          custom={0.1}
          className="bg-background border border-border rounded-md p-8 md:p-10"
        >
          <div className="mb-8">
            <span className="text-xs uppercase tracking-[0.18em] text-muted-foreground font-medium">Reference</span>
            <h3 className="text-xl md:text-2xl font-semibold text-foreground mt-3">
              Key Terms — Quick Reference
            </h3>
            <p className="text-sm text-muted-foreground mt-2">
              A concise glossary of the core concepts covered above.
            </p>
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              {
                term: "AI Overview",
                definition:
                  "An AI-generated summary produced by Google's Gemini model, displayed above organic results for eligible queries.",
              },
              {
                term: "Citation",
                definition:
                  "A reference link to a specific web page whose content contributed to the AI-generated summary.",
              },
              {
                term: "Trigger query",
                definition:
                  "A search query judged by Google to benefit from an AI-generated answer — typically informational, multi-faceted, or research-oriented.",
              },
              {
                term: "E-E-A-T",
                definition:
                  "Experience, Expertise, Authoritativeness, and Trustworthiness — the quality signals Google uses to assess content credibility.",
              },
              {
                term: "YMYL suppression",
                definition:
                  "The practice of limiting or suppressing AI Overviews for sensitive topics such as legal, medical, or financial queries.",
              },
              {
                term: "Entity clarity",
                definition:
                  "The degree to which Google's systems can identify and confirm the author, subject, and organisation behind a piece of content.",
              },
            ].map((item, i) => (
              <div key={i} className="border-l-2 border-primary/30 pl-4">
                <p className="text-sm font-semibold text-foreground mb-1">{item.term}</p>
                <p className="text-sm text-muted-foreground leading-relaxed">{item.definition}</p>
              </div>
            ))}
          </div>
        </motion.div>

      </div>
    </section>
  );
});

GoogleAIOverviewsExplainer.displayName = "GoogleAIOverviewsExplainer";

export default GoogleAIOverviewsExplainer;
