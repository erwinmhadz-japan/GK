import React from "react";
import { motion } from "framer-motion";
import { MapPin, ArrowRight, Grid, Section, View } from "lucide-react";
import { Link } from "react-router-dom";

interface Location {
  city: string;
  descriptor: string;
  slug: string;
  route: string;
  description: string;
  image: string;
  imageAlt: string;
}

const locations: Location[] = [
  {
    city: "Warrington",
    descriptor: "SEO Consultant Warrington",
    slug: "warrington",
    route: "/warrington",
    description:
      "Gregg's home base. Specialist SEO support for Warrington businesses looking to dominate local and regional search.",
    image: "https://images.unsplash.com/photo-1633537066002-336ea0ff2a16?w=800&h=600&fit=crop",
    imageAlt: "Warrington town centre architecture",
  },
  {
    city: "Manchester",
    descriptor: "SEO Consultant Manchester",
    slug: "manchester",
    route: "/manchester",
    description:
      "Independent SEO consulting for Manchester businesses — cutting through the noise in one of the UK's most competitive markets.",
    image: "https://images.unsplash.com/photo-1633537065982-ef16506d42b8?w=800&h=600&fit=crop",
    imageAlt: "Manchester city skyline with modern office buildings",
  },
  {
    city: "Liverpool",
    descriptor: "SEO Consultant Liverpool",
    slug: "liverpool",
    route: "/liverpool",
    description:
      "Strategic SEO for Liverpool-based businesses — from the waterfront to the wider city region, driving qualified organic traffic.",
    image: "https://images.unsplash.com/photo-1633537065985-c65a413f5961?w=800&h=600&fit=crop",
    imageAlt: "Liverpool waterfront buildings",
  },
  {
    city: "Birmingham",
    descriptor: "SEO Consultant Birmingham",
    slug: "birmingham",
    route: "/birmingham",
    description:
      "SEO strategy for Birmingham's ambitious businesses — improving rankings, authority, and sustainable organic growth.",
    image: "https://images.unsplash.com/photo-1685492259744-f42597aac776?w=800&h=600&fit=crop",
    imageAlt: "Birmingham city centre tall buildings",
  },
  {
    city: "Leeds",
    descriptor: "SEO Consultant Leeds",
    slug: "leeds",
    route: "/leeds",
    description:
      "Independent SEO consulting in Leeds — helping professional services, e-commerce, and B2B firms build lasting search visibility.",
    image: "https://images.unsplash.com/photo-1633537065929-4f1c4c65c022?w=800&h=600&fit=crop",
    imageAlt: "Leeds city skyline with office buildings",
  },
  {
    city: "Sheffield",
    descriptor: "SEO Consultant Sheffield",
    slug: "sheffield",
    route: "/sheffield",
    description:
      "SEO for Sheffield businesses that want to compete — technically robust, editorially sharp, and built for long-term results.",
    image: "https://images.unsplash.com/photo-1633537066070-94bccfa10f05?w=800&h=600&fit=crop",
    imageAlt: "Sheffield city buildings against open sky",
  },
  {
    city: "London",
    descriptor: "SEO Consultant London",
    slug: "london",
    route: "/london",
    description:
      "Senior SEO consultancy for London businesses — the same expert rigour as a top agency, without the overhead or the hand-offs.",
    image: "https://images.unsplash.com/photo-1559659386-5b78a2a4290c?w=800&h=600&fit=crop",
    imageAlt: "London architectural photography of a historic brown building",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.08,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: "easeOut" },
  },
};

const LocationGrid = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="location-grid"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mb-12 md:mb-16"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-3 font-medium">
            Service Locations
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground font-[Sora] max-w-2xl">
            Find Your City
          </h2>
          <p className="mt-3 text-base text-muted-foreground max-w-xl leading-relaxed">
            Each location page outlines what independent SEO consulting looks like for businesses in that city — the competitive landscape, local search signals, and how Gregg works with clients remotely and in person across the region.
          </p>
        </motion.div>

        {/* Grid: 7 cards — 2-col on mobile, 3-col on md, 4-col on lg with last row centred */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-5 md:gap-6"
        >
          {locations.map((location) => (
            <motion.div key={location.slug} variants={cardVariants}>
              <Link
                to={location.route}
                aria-label={`${location.descriptor} — view SEO services in ${location.city}`}
                className="group flex flex-col h-full rounded-md overflow-hidden border border-border bg-background hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%_/_0.10),_0_1px_4px_hsl(222_28%_11%_/_0.05)] transition-all duration-300 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2"
              >
                {/* City image */}
                <div className="relative overflow-hidden aspect-[4/3]">
                  <img
                    src={location.image}
                    alt={location.imageAlt}
                    width={800}
                    height={600}
                    loading="lazy"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  {/* Subtle dark gradient at the bottom of image */}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/40 via-transparent to-transparent pointer-events-none" />
                </div>

                {/* Card content */}
                <div className="p-4 md:p-5 flex flex-col flex-1">
                  <div className="flex items-start gap-2 mb-1">
                    <MapPin className="h-3.5 w-3.5 text-primary mt-0.5 shrink-0" />
                    <span className="text-xs uppercase tracking-[0.15em] text-muted-foreground font-medium">
                      {location.city}
                    </span>
                  </div>
                  <p className="text-sm font-semibold text-foreground leading-snug font-[Sora] group-hover:text-primary transition-colors duration-200 mb-2">
                    {location.descriptor}
                  </p>
                  <p className="text-xs text-muted-foreground leading-relaxed flex-1">
                    {location.description}
                  </p>
                  <div className="mt-4 flex items-center gap-1 text-xs text-primary font-medium">
                    <span>View local SEO services</span>
                    <ArrowRight className="h-3 w-3 transition-transform duration-200 group-hover:translate-x-1" />
                  </div>
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>

        {/* Subtle note */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4, ease: "easeOut" }}
          className="mt-10 text-xs text-muted-foreground text-center"
        >
          Based in Warrington, Cheshire — working with businesses across the UK.
        </motion.p>
      </div>
    </section>
  );
});

LocationGrid.displayName = "LocationGrid";

export default LocationGrid;
