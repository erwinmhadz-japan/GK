import React from "react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Fingerprint, Database, FileText, Network, AtSign, MapPin, CheckCircle2, Heading, Monitor, Section } from "lucide-react";

interface Factor {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  heading: string;
  body: string;
  tips: string[];
}

const factors: Factor[] = [
  {
    icon: Fingerprint,
    label: "Entity Authority",
    heading: "Build a clear entity identity",
    body: "ChatGPT relies on training data that reflects how well a business is defined as a distinct, knowable entity. A business with consistent name, description, and category signals across the web is far more likely to be surfaced accurately in AI-generated responses than one with fragmented or conflicting information.",
    tips: [
      "Establish a Google Knowledge Panel with verified business details",
      "Ensure consistent entity descriptions across Wikipedia, Wikidata, and Crunchbase where applicable",
      "Use the same business name and category framing across all platforms",
    ],
  },
  {
    icon: Database,
    label: "Structured Data",
    heading: "Mark up your content with structured data",
    body: "Schema markup helps AI systems understand what a piece of content is about, who produced it, and what it covers. Well-structured pages using Organisation, Person, Service, and FAQPage schema give language models clearer signals about who you are and what you do.",
    tips: [
      "Implement Organisation and Person schema on core pages",
      "Use Service schema to define individual service offerings",
      "Add FAQPage schema to question-based content that answers likely queries",
    ],
  },
  {
    icon: FileText,
    label: "Content Clarity",
    heading: "Write content that directly answers questions",
    body: "AI language models favour content that clearly, concisely, and authoritatively answers a specific question. Pages that beat around the bush, rely heavily on jargon, or bury key information in dense prose are less likely to be drawn upon when ChatGPT constructs a response.",
    tips: [
      "Open each key page with a direct, plain-English answer to the question it targets",
      "Use clear headings that match the questions your audience is asking",
      "Avoid padding — AI systems reward signal density, not word count",
    ],
  },
  {
    icon: Network,
    label: "Authoritative Citations",
    heading: "Earn mentions from credible sources",
    body: "ChatGPT's training data skews heavily towards content from high-authority publishers, industry bodies, and well-established websites. If credible third parties reference your business by name in the context of what you do, that reinforces your entity as a relevant source for those topics.",
    tips: [
      "Seek coverage in trade publications and sector-specific media",
      "Contribute guest articles or expert commentary to respected industry outlets",
      "Build digital PR that generates genuine editorial links and brand mentions",
    ],
  },
  {
    icon: AtSign,
    label: "Brand Mentions",
    heading: "Increase unlinked and linked brand mentions",
    body: "Mentions of your brand — even without a hyperlink — contribute to the web's collective understanding of who you are and what you're associated with. Consistent, positive brand mentions across a range of domains help AI systems build a clearer picture of your relevance and authority in a given topic area.",
    tips: [
      "Monitor and encourage brand mentions through digital PR and thought leadership",
      "Ensure any mentions correctly reflect your name, location, and area of expertise",
      "Build a consistent narrative across press, directories, forums, and community platforms",
    ],
  },
  {
    icon: MapPin,
    label: "NAP & Entity Consistency",
    heading: "Maintain consistent NAP and entity data",
    body: "Name, address, and phone number consistency is foundational for any business that operates in a specific location. Inconsistent entity data across directories, citations, and your own website creates noise that makes it harder for AI systems to confidently identify and reference your business.",
    tips: [
      "Audit all directory and citation listings for name, address, and phone consistency",
      "Ensure your Google Business Profile matches your website and schema markup exactly",
      "Remove or correct duplicate or outdated listings that may introduce conflicting signals",
    ],
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay: i * 0.08 },
  }),
};

const ChatgptVisibilityHowToImprove = React.forwardRef<HTMLElement>(
  (props, ref) => {
    return (
      <section
        ref={ref}
        id="chatgpt-visibility-how-to-improve"
        className="relative py-20 md:py-32 border-t border-border bg-muted"
      >
        <div className="container max-w-6xl mx-auto px-4">
          {/* Section header */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut" }}
            className="mb-14 md:mb-20"
          >
            <Badge
              variant="outline"
              className="mb-5 text-xs uppercase tracking-widest border-border text-muted-foreground font-medium"
            >
              How to improve
            </Badge>
            <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground max-w-3xl leading-tight mb-5">
              The six factors that determine your ChatGPT visibility
            </h2>
            <p className="text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
              Appearing in ChatGPT responses is not luck or keyword density — it
              is a function of how clearly and consistently your business is
              defined across the web. These are the signals that matter most.
            </p>
          </motion.div>

          {/* Factors grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8">
            {factors.map((factor, index) => {
              const Icon = factor.icon;
              return (
                <motion.div
                  key={factor.label}
                  custom={index}
                  variants={fadeUp}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  className="group relative bg-background border border-border rounded-md p-6 md:p-7 flex flex-col gap-4 hover:shadow-md transition-shadow duration-300"
                >
                  {/* Icon + label row */}
                  <div className="flex items-start gap-3">
                    <div className="flex-shrink-0 flex h-10 w-10 items-center justify-center rounded-md bg-primary/10">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <Badge
                      variant="secondary"
                      className="text-xs mt-1.5 font-medium tracking-wide"
                    >
                      {factor.label}
                    </Badge>
                  </div>

                  {/* Heading */}
                  <h3 className="text-base md:text-lg font-semibold text-foreground leading-snug">
                    {factor.heading}
                  </h3>

                  {/* Body */}
                  <p className="text-sm text-muted-foreground leading-relaxed flex-1">
                    {factor.body}
                  </p>

                  {/* Tips */}
                  <ul className="space-y-2 pt-1 border-t border-border">
                    {factor.tips.map((tip) => (
                      <li key={tip} className="flex items-start gap-2">
                        <CheckCircle2 className="h-4 w-4 flex-shrink-0 mt-0.5 text-primary" />
                        <span className="text-xs text-muted-foreground leading-relaxed">
                          {tip}
                        </span>
                      </li>
                    ))}
                  </ul>
                </motion.div>
              );
            })}
          </div>

          {/* Contextual note */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.3 }}
            className="mt-14 md:mt-20 bg-background border border-border rounded-md px-6 py-6 md:px-8 md:py-7 max-w-3xl"
          >
            <p className="text-sm text-muted-foreground leading-relaxed">
              <span className="font-semibold text-foreground">
                A note on intent:
              </span>{" "}
              The factors outlined here are informational. If you are looking
              for active support in implementing these signals for your
              business, my{" "}
              <a
                href="/ai-search-optimisation"
                className="text-primary underline underline-offset-4 hover:opacity-80 transition-opacity"
              >
                AI search optimisation service
              </a>{" "}
              covers entity-building, structured data, and citation strategy as
              part of a structured engagement.
            </p>
          </motion.div>
        </div>
      </section>
    );
  }
);

ChatgptVisibilityHowToImprove.displayName = "ChatgptVisibilityHowToImprove";

export default ChatgptVisibilityHowToImprove;
