import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, FileSearch, CheckCircle, Contact } from "lucide-react";

const features = [
  {
    icon: FileSearch,
    label: "Free SEO audit included",
    description: "I offer a complimentary audit to identify your most pressing SEO opportunities before we commit to anything.",
  },
  {
    icon: CheckCircle,
    label: "No agency overhead",
    description: "You work directly with me — not an account manager or junior. Every conversation is with the person doing the work.",
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (delay: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut", delay },
  }),
};

const AboutConsultation = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="about-consultation"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">
          {/* Eyebrow */}
          <motion.span
            className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-5 font-medium"
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={0}
          >
            Let&apos;s Talk
          </motion.span>

          {/* Headline */}
          <motion.h2
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight tracking-tight mb-5"
            style={{ fontFamily: "Sora, sans-serif" }}
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={0.1}
          >
            Ready to Work Together?
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-10 max-w-2xl mx-auto"
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={0.2}
          >
            Get in touch to discuss your SEO challenges or request a free audit. I work directly with UK businesses — no intermediaries, no hand-offs. Just straightforward, senior-level SEO consultancy.
          </motion.p>

          {/* Feature callouts */}
          <motion.div
            className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-10 text-left"
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={0.3}
          >
            {features.map((feature) => {
              const Icon = feature.icon;
              return (
                <div
                  key={feature.label}
                  className="flex items-start gap-4 rounded-md border border-border bg-background p-5 shadow-sm"
                >
                  <span className="flex-shrink-0 mt-0.5 flex h-9 w-9 items-center justify-center rounded-md bg-primary/10">
                    <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
                  </span>
                  <div>
                    <p className="text-sm font-semibold text-foreground mb-1">
                      {feature.label}
                    </p>
                    <p className="text-sm text-muted-foreground leading-relaxed">
                      {feature.description}
                    </p>
                  </div>
                </div>
              );
            })}
          </motion.div>

          {/* CTA */}
          <motion.div
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={0.4}
          >
            <Button
              size="lg"
              className="h-12 px-8 text-base font-semibold bg-[hsl(84_74%_60%)] hover:bg-[hsl(84_74%_53%)] text-[hsl(225_28%_14%)] border-0 shadow-none transition-all duration-200 hover:shadow-[0_0_32px_hsl(84_74%_60%/0.3)]"
              asChild
            >
              <Link to="/contact">
                Contact Me
                <ArrowRight className="ml-2 h-4 w-4" aria-hidden="true" />
              </Link>
            </Button>

            <p className="text-sm text-muted-foreground">
              Based in Warrington, Cheshire — serving UK businesses nationally
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
});

AboutConsultation.displayName = "AboutConsultation";

export default AboutConsultation;
