import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { HelpCircle } from "lucide-react";

const faqs = [
  {
    question: "What is YMYL and how does it affect financial services SEO?",
    answer:
      "YMYL stands for 'Your Money or Your Life' — a classification Google uses for content that can significantly impact a person's financial security, health, or wellbeing. Financial services content (advice, rates, products, regulations) is firmly in this category. Google applies heightened quality standards to YMYL pages, which means rankings are heavily influenced by demonstrated expertise, authoritativeness, and trustworthiness (E-E-A-T). For financial firms, this means credentialled authors, cited sources, up-to-date regulatory information, and a strong brand entity presence are not optional — they are ranking prerequisites.",
  },
  {
    question: "How do you ensure our content meets FCA and regulatory requirements?",
    answer:
      "We work within your existing compliance workflow, not around it. Our content strategists are briefed on FCA guidelines, MiFID II requirements, and relevant jurisdiction-specific rules before producing any asset. All content is drafted with clear risk warnings, appropriate disclaimers, and factual accuracy. We can integrate with your in-house compliance team or approved compliance reviewer so every piece is signed off before publication. We also avoid language that constitutes a financial promotion where approval has not been granted.",
  },
  {
    question: "Can you help with highly competitive keywords like 'best mortgage rates' or 'financial adviser'?",
    answer:
      "Yes — but the strategy is rarely to target those head terms directly from the outset. Instead, we build topical authority through comprehensive supporting content (calculators, guides, comparison tools, regulatory explainers) so that Google recognises your site as a genuine expert destination. As authority builds, competitive head terms become attainable. We also identify high-intent, lower-competition variants — such as location-specific or niche-product terms — that deliver qualified traffic quickly while the broader campaign matures.",
  },
  {
    question: "What schema markup is most valuable for financial services websites?",
    answer:
      "For financial services, we prioritise Organisation and LocalBusiness schema to establish entity identity; FinancialService and FinancialProduct schema to describe your offerings; FAQPage schema for Q&A content that can earn rich results; BreadcrumbList for site structure; and Review / AggregateRating where permitted. Where applicable, we also implement Article schema with named author entities to reinforce E-E-A-T signals. All structured data is validated against Schema.org and Google's Rich Results Test before deployment.",
  },
  {
    question: "How long does it take to see SEO results in the financial sector?",
    answer:
      "Financial services SEO is a medium-to-long-term investment. Most clients see measurable improvements in crawl coverage, indexation, and lower-competition keyword rankings within three to four months. Competitive commercial keywords — especially in high-value niches like wealth management or mortgage brokerage — typically require six to twelve months of consistent, compliant content production and authority-building. The payoff is significant: financial keywords carry very high commercial intent, so organic traffic converts well and justifies the investment.",
  },
  {
    question: "Do you work with regulated financial firms outside the UK?",
    answer:
      "Yes. While our team is based in the UK and has deep familiarity with FCA regulation, we have successfully delivered SEO programmes for financial firms operating under SEC, ASIC, MAS, and other regulatory frameworks. We adapt our content and compliance processes to the applicable jurisdiction and work closely with local legal or compliance advisers when needed. Technical SEO, entity SEO, and schema implementation are largely jurisdiction-agnostic.",
  },
];

// FAQ JSON-LD for structured data
const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map(({ question, answer }) => ({
    "@type": "Question",
    name: question,
    acceptedAnswer: {
      "@type": "Answer",
      text: answer,
    },
  })),
};

const FinServFAQ: React.FC = () => {
  return (
    <section className="relative py-20 md:py-32 border-t border-border bg-background">
      {/* FAQ JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />

      <div className="container">
        <div className="max-w-2xl mx-auto text-center mb-12">
          <div className="flex justify-center mb-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
              <HelpCircle className="h-6 w-6 text-primary" />
            </div>
          </div>
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-3">
            Common Questions
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Financial Services SEO — FAQ
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
            Answers to the questions financial marketers and digital teams ask most
            about YMYL compliance, regulatory content, and competitive SEO.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full space-y-2">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="border border-border rounded-lg bg-card px-6"
              >
                <AccordionTrigger className="text-left font-medium text-foreground py-5 hover:no-underline">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed pb-5">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        <div className="mt-12 text-center">
          <p className="text-muted-foreground mb-2">
            Have a more specific question?
          </p>
          <a
            href="/contact"
            className="inline-block text-primary font-medium hover:underline"
          >
            Get in touch for a free consultation →
          </a>
        </div>
      </div>
    </section>
  );
};

export default FinServFAQ;
