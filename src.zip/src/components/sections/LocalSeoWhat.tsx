import React from "react";
import { motion } from "framer-motion";
import { MapPin, Building2, Star, Link, Search, CheckCircle, Building, Map as MapIcon, Section } from "lucide-react";

const pillars = [
  {
    icon: Building2,
    title: "Google Business Profile Optimisation",
    body: "Your GBP listing is the centrepiece of local visibility. I audit and optimise every element — categories, service areas, attributes, photos, and posts — to maximise prominence in the map pack and local organic results.",
  },
  {
    icon: Link,
    title: "Local Citations & NAP Consistency",
    body: "Citations are mentions of your business name, address, and phone number across directories, data aggregators, and industry platforms. Inconsistent NAP data is one of the most common causes of suppressed local rankings — and one of the most overlooked.",
  },
  {
    icon: Star,
    title: "Review Signals & Reputation",
    body: "Google weighs the volume, recency, and sentiment of reviews as a local ranking factor. I develop practical review acquisition strategies that work within your operations — and help you respond to reviews in a way that reinforces trust.",
  },
  {
    icon: MapPin,
    title: "Proximity & Map Pack Ranking Factors",
    body: "Proximity to the searcher matters, but it is not the only variable. Relevance and prominence can be built. Understanding how Google's local algorithm weights distance against authority allows targeted, evidence-based optimisation.",
  },
  {
    icon: Search,
    title: "Local Link Building",
    body: "Links from locally relevant and topically authoritative sites strengthen your position in local search. I identify link opportunities through local press, business associations, directories, and community partnerships — building signals that reflect genuine local presence.",
  },
  {
    icon: CheckCircle,
    title: "Local Content Strategy",
    body: "Locally-oriented content — service area pages, location-specific guides, and sector-relevant articles — helps search engines understand where you operate and who you serve. The content also supports conversion once a searcher lands on the page.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const LocalSeoWhat = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="local-seo-what"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.65, ease: "easeOut" }}
          className="max-w-3xl mb-14 md:mb-20"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            The discipline explained
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight mb-6">
            What Local SEO Actually Involves
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl">
            Local SEO is a distinct discipline within search engine optimisation. It is not simply
            a matter of adding a city name to a page title. It involves a specific set of signals —
            many of them outside the website itself — that Google uses to determine which businesses
            to surface when someone searches with local intent.
          </p>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl mt-4">
            Below is an honest account of the core components. Each plays a different role in the
            local ranking ecosystem, and each requires a different approach depending on your
            sector, your location, and the competitive landscape you are operating in.
          </p>
        </motion.div>

        {/* Pillars grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 md:gap-8"
        >
          {pillars.map((pillar) => {
            const Icon = pillar.icon;
            return (
              <motion.div
                key={pillar.title}
                variants={itemVariants}
                className="group bg-background border border-border rounded-md p-6 md:p-8 hover:border-primary/40 hover:shadow-md transition-all duration-300"
              >
                <div className="flex items-center justify-center w-10 h-10 rounded-md bg-primary/10 mb-5">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="text-base md:text-lg font-semibold text-foreground mb-3 leading-snug">
                  {pillar.title}
                </h3>
                <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                  {pillar.body}
                </p>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Closing prose note */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6, ease: "easeOut", delay: 0.2 }}
          className="mt-14 md:mt-20 max-w-2xl"
        >
          <p className="text-sm md:text-base text-muted-foreground leading-relaxed border-l-2 border-primary/40 pl-5">
            These components do not operate in isolation. Local SEO works as a system — citations
            reinforce GBP signals, reviews strengthen prominence, and content supports both
            relevance and user intent. A piecemeal approach will produce piecemeal results. I work
            across all of these areas as part of a coherent strategy tailored to your business and
            its competitive environment.
          </p>
        </motion.div>
      </div>
    </section>
  );
});

LocalSeoWhat.displayName = "LocalSeoWhat";

export default LocalSeoWhat;
