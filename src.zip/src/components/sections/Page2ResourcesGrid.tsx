import React from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { BookOpen, FileText, GraduationCap, TrendingUp, Target, Zap, ArrowRight, Building, Combine, File, Library, Link, Search, Section } from "lucide-react";

const resources = [
  {
    icon: GraduationCap,
    title: "SEO Foundations Guide",
    description:
      "A comprehensive introduction to how modern search engines work, what Google's algorithms reward, and the pillars of a high-performing SEO strategy.",
    topics: ["Crawling & Indexing", "Ranking Factors", "Keyword Research", "On-Page SEO"],
    badge: "Beginner",
    badgeVariant: "secondary" as const,
    href: "/services",
  },
  {
    icon: Zap,
    title: "AI Search Optimisation Playbook",
    description:
      "Learn how to get cited by ChatGPT, Perplexity, Google AI Overviews, and Copilot. The complete guide to optimising for AI-driven search experiences.",
    topics: ["Entity Building", "Structured Data", "Authority Signals", "AI Visibility Metrics"],
    badge: "Advanced",
    badgeVariant: "default" as const,
    href: "/ai-search-optimisation",
  },
  {
    icon: FileText,
    title: "Technical SEO Checklist",
    description:
      "A practitioner's checklist covering Core Web Vitals, crawl optimisation, log file analysis, JavaScript rendering, and more — for agencies and in-house teams.",
    topics: ["Core Web Vitals", "Log File Analysis", "Crawl Budget", "JavaScript SEO"],
    badge: "Technical",
    badgeVariant: "outline" as const,
    href: "/technical-seo",
  },
  {
    icon: Target,
    title: "Local SEO Strategy Guide",
    description:
      "Everything UK businesses need to dominate local search — from Google Business Profile optimisation to local citation building and review strategy.",
    topics: ["Google Business Profile", "Local Citations", "Review Strategy", "Local Pack"],
    badge: "Local",
    badgeVariant: "secondary" as const,
    href: "/local-seo",
  },
  {
    icon: TrendingUp,
    title: "Content Strategy Framework",
    description:
      "Build topical authority with a structured content strategy. Learn how to map content to intent, identify gaps, and create assets that earn links and citations.",
    topics: ["Topical Authority", "Content Mapping", "Search Intent", "Content Clusters"],
    badge: "Strategy",
    badgeVariant: "outline" as const,
    href: "/content-strategy",
  },
  {
    icon: BookOpen,
    title: "Digital PR for SEO",
    description:
      "Combine the power of PR and SEO to earn high-authority backlinks, build brand mentions, and improve your site's trust signals with targeted media outreach.",
    topics: ["Link Earning", "Media Outreach", "Data Journalism", "Brand Authority"],
    badge: "Link Building",
    badgeVariant: "default" as const,
    href: "/digital-pr",
  },
];

const Page2ResourcesGrid = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="resources-grid"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        {/* Section header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="inline-flex items-center gap-1.5 text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            <BookOpen className="h-3.5 w-3.5" />
            Resource Library
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Guides &amp; Playbooks to Grow Your Search Presence
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Practical, strategy-led resources developed from working with hundreds of UK businesses
            across competitive industries.
          </p>
        </div>

        {/* Resource cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {resources.map((resource) => {
            const Icon = resource.icon;
            return (
              <Card
                key={resource.title}
                className="bg-card border border-border shadow-soft hover-lift flex flex-col"
              >
                <CardHeader className="pb-3">
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 shrink-0">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <Badge variant={resource.badgeVariant} className="shrink-0 text-xs">
                      {resource.badge}
                    </Badge>
                  </div>
                  <CardTitle className="text-lg leading-snug">{resource.title}</CardTitle>
                  <CardDescription className="text-sm leading-relaxed mt-1">
                    {resource.description}
                  </CardDescription>
                </CardHeader>

                <CardContent className="pt-0 flex flex-col flex-1">
                  <ul className="flex flex-wrap gap-2 mb-6">
                    {resource.topics.map((topic) => (
                      <li
                        key={topic}
                        className="text-xs bg-muted border border-border rounded-full px-3 py-1 text-muted-foreground"
                      >
                        {topic}
                      </li>
                    ))}
                  </ul>

                  <div className="mt-auto">
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full group"
                      asChild
                    >
                      <a href={resource.href}>
                        Explore Topic
                        <ArrowRight className="ml-2 h-3.5 w-3.5 transition-transform group-hover:translate-x-0.5" />
                      </a>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </div>
    </section>
  );
});

Page2ResourcesGrid.displayName = "Page2ResourcesGrid";

export default Page2ResourcesGrid;
