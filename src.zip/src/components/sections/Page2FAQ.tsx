import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { HelpCircle } from "lucide-react";

const faqs = [
  {
    question: "How long does SEO take to produce results?",
    answer:
      "For most competitive industries, meaningful ranking improvements and traffic gains typically emerge within 3–6 months of consistent, well-targeted SEO work. However, the timeline depends on your starting authority, the competitiveness of your target keywords, and how quickly technical issues are resolved. New websites or those recovering from penalties may take longer. The most important thing is that SEO compounds — results accelerate over time as authority builds.",
  },
  {
    question: "What is the difference between SEO consulting and an SEO retainer?",
    answer:
      "SEO consulting is typically project-based or advisory — you engage a consultant for strategic direction, audits, or to fix specific problems. An SEO retainer is an ongoing engagement where the consultant actively manages, optimises, and grows your organic search performance month by month. A retainer suits businesses that want consistent progress; consulting suits those who need expert input on a defined challenge.",
  },
  {
    question: "Do I need technical SEO or content SEO — or both?",
    answer:
      "Almost always both. Technical SEO ensures search engines can efficiently crawl, index, and understand your site. Content SEO ensures you have the right pages targeting the right topics with the right depth. Neither alone is sufficient for competitive rankings. The priority depends on your site's current state — a technically broken site needs fixing first; an otherwise healthy site with thin content needs content investment.",
  },
  {
    question: "What is AI search optimisation and why does it matter?",
    answer:
      "AI search optimisation refers to strategies that help your brand appear as a cited, trusted source in AI-generated answer engines like ChatGPT, Perplexity, Google AI Overviews, and Microsoft Copilot. As a growing share of search journeys now involve AI-synthesised answers rather than traditional blue-link results, brands that fail to optimise for AI visibility risk losing significant traffic and awareness — even as their traditional rankings remain intact.",
  },
  {
    question: "How do I choose the right SEO consultant?",
    answer:
      "Look for a consultant with demonstrable experience in your industry or niche, a transparent methodology, and clear case studies with measurable results. Avoid anyone guaranteeing specific rankings — no ethical consultant can promise a position 1 ranking. The best consultants will perform a thorough audit before recommending a strategy, explain their reasoning clearly, and integrate with your existing team rather than working in isolation.",
  },
  {
    question: "Is local SEO different from national SEO?",
    answer:
      "Yes, significantly. Local SEO focuses on ranking in geographically targeted searches — including the Google Local Pack (map results) — and depends heavily on your Google Business Profile, local citations, reviews, and proximity signals. National SEO prioritises broad keyword reach, domain authority, and topical coverage across the entire country. Many businesses benefit from both: a national strategy for brand awareness and a local strategy to capture high-intent, location-specific demand.",
  },
  {
    question: "What does a technical SEO audit include?",
    answer:
      "A thorough technical SEO audit typically covers: crawl accessibility and bot behaviour (via log file analysis), indexation status and coverage errors, site speed and Core Web Vitals, mobile usability, internal linking structure, duplicate content issues, canonicalisation, JavaScript rendering, structured data implementation, and HTTPS/security configuration. The output should be a prioritised action plan with clear business impact for each recommendation.",
  },
];

const Page2FAQ = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seo-faq"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-start">
          {/* Left column — header */}
          <div className="lg:col-span-4">
            <span className="inline-flex items-center gap-1.5 text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
              <HelpCircle className="h-3.5 w-3.5" />
              FAQ
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Common Questions About SEO
            </h2>
            <p className="text-muted-foreground text-base leading-relaxed mb-6">
              Honest, straightforward answers to the questions clients ask most often before engaging
              an SEO consultant.
            </p>
            <div className="rounded-xl bg-muted border border-border p-5">
              <p className="text-sm text-muted-foreground leading-relaxed">
                <strong className="text-foreground">Can't find your answer?</strong> Every situation
                is different. Get a direct answer by reaching out — no obligation, no sales pitch.
              </p>
              <a
                href="/contact"
                className="inline-block mt-3 text-sm font-semibold text-primary hover:underline"
              >
                Ask a question →
              </a>
            </div>
          </div>

          {/* Right column — accordion */}
          <div className="lg:col-span-8">
            <Accordion type="single" collapsible className="w-full space-y-3">
              {faqs.map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="bg-card border border-border rounded-xl px-5 shadow-soft"
                >
                  <AccordionTrigger className="text-left font-semibold text-foreground py-5 hover:no-underline">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground text-sm leading-relaxed pb-5">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </div>
    </section>
  );
});

Page2FAQ.displayName = "Page2FAQ";

export default Page2FAQ;
