import React from "react";
import { motion } from "framer-motion";
import { MapPin, Building2, Star, Globe, Search, FileText, TrendingUp, MessageSquare, Layers, Target, Building, Grid, Link, Map as MapIcon, Section } from "lucide-react";
import { Card, CardContent, CardHeader } from "@/components/ui/card";

interface ServiceItem {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  description: string;
  detail: string;
}

const services: ServiceItem[] = [
  {
    icon: Building2,
    title: "Google Business Profile Optimisation",
    description:
      "Your GBP listing is the cornerstone of local search visibility. I audit, optimise, and maintain your profile to maximise map pack performance and drive qualified local enquiries.",
    detail: "Categories, attributes, Q&A, posts, and photo strategy",
  },
  {
    icon: MapPin,
    title: "Local Citation Building & Cleanup",
    description:
      "Consistent NAP (name, address, phone) data across authoritative UK directories is a foundational local ranking signal. I build and correct citations on the directories that matter in your sector and location.",
    detail: "Yell, Thomson Local, Scoot, sector-specific directories",
  },
  {
    icon: FileText,
    title: "Localised Content Strategy",
    description:
      "Thin, templated location pages do not rank competitively. I develop a content strategy that builds genuine topical authority for your target areas — pages that earn rankings because they deserve them.",
    detail: "Location landing pages, area guides, service-area content",
  },
  {
    icon: Search,
    title: "On-Page Local Signals",
    description:
      "Title tags, heading structure, localised copy, and internal linking all send explicit geo-relevance signals to Google. I implement these with precision, avoiding the keyword stuffing that passes for 'local SEO' elsewhere.",
    detail: "Title optimisation, structured headings, NAP on-page",
  },
  {
    icon: Layers,
    title: "Schema Markup for Local Entities",
    description:
      "Structured data communicates business identity directly to search engines. I implement LocalBusiness, Service, and related schema types to reinforce your entity signals and support rich result eligibility.",
    detail: "LocalBusiness, Service, Review, FAQPage schema",
  },
  {
    icon: Star,
    title: "Review Strategy & Acquisition",
    description:
      "Review velocity, recency, and sentiment are significant local ranking factors. I develop a practical, compliant strategy for acquiring and managing reviews across Google and sector-relevant platforms.",
    detail: "Google Reviews, sector review platforms, response strategy",
  },
  {
    icon: Globe,
    title: "Local Link Acquisition",
    description:
      "Links from locally relevant, authoritative sources remain one of the strongest local ranking signals. I identify and pursue link opportunities that are genuinely within reach and genuinely worth having.",
    detail: "Local press, business associations, sponsor placements",
  },
  {
    icon: Target,
    title: "Competitor & Map Pack Analysis",
    description:
      "Understanding who occupies the map pack — and why — informs every strategic decision. I conduct detailed competitor analysis to identify the gaps your local SEO strategy needs to close.",
    detail: "SERP benchmarking, GBP gap analysis, keyword mapping",
  },
  {
    icon: TrendingUp,
    title: "Local Rank Tracking & Reporting",
    description:
      "Transparent, meaningful reporting is non-negotiable. I track local rankings by location, provide clear monthly summaries, and interpret what the data means for your business — not just what it shows.",
    detail: "Grid-based rank tracking, GBP insights, monthly review",
  },
  {
    icon: MessageSquare,
    title: "Local SEO Consultancy & Strategy",
    description:
      "Sometimes you need a clear, independent view — not a retainer. I offer standalone local SEO consultancy sessions for businesses that want expert strategic input without an ongoing commitment.",
    detail: "One-to-one sessions, actionable recommendations, no fluff",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.07,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const LocalSeoServices = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="local-seo-services"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          className="mb-14 md:mb-20 max-w-2xl"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.65, ease: "easeOut" }}
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            What I Deliver
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight mb-5">
            Local SEO Services
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-prose">
            Local SEO is not a single tactic — it is a coordinated set of
            signals. Below is a breakdown of the components I work across when
            helping UK businesses improve their visibility in local and map pack
            results.
          </p>
        </motion.div>

        {/* Services grid — exactly 10 items */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-6 md:gap-7"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
        >
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <motion.div key={service.title} variants={cardVariants}>
                <Card className="h-full bg-background border border-border shadow-sm hover:shadow-md transition-shadow duration-300 group">
                  <CardHeader className="pb-3 pt-6 px-6">
                    <div className="flex items-start gap-4">
                      {/* Icon block */}
                      <div className="flex-shrink-0 flex items-center justify-center w-10 h-10 rounded-md bg-primary/10 group-hover:bg-primary/15 transition-colors duration-300">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                      {/* Title */}
                      <h3 className="text-base md:text-lg font-semibold text-foreground leading-snug pt-1">
                        {service.title}
                      </h3>
                    </div>
                  </CardHeader>
                  <CardContent className="px-6 pb-6">
                    <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-4">
                      {service.description}
                    </p>
                    {/* Detail line */}
                    <p className="text-xs text-muted-foreground/75 leading-relaxed border-t border-border pt-3 font-medium tracking-wide">
                      {service.detail}
                    </p>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Subtle closing note */}
        <motion.p
          className="mt-12 text-sm text-muted-foreground max-w-xl"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.7, delay: 0.3, ease: "easeOut" }}
        >
          Not every business needs every component. I scope each engagement
          individually — starting with a clear audit of where you stand before
          recommending what to prioritise.
        </motion.p>
      </div>
    </section>
  );
});

LocalSeoServices.displayName = "LocalSeoServices";

export default LocalSeoServices;
