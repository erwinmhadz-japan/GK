import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ChartNetwork, Fingerprint, Layers, Globe, Link2, AtSign, FileText, Tags, CheckCircle2, Cross, Phone, Search, Section } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const deliverables = [
  {
    icon: ChartNetwork,
    title: "Knowledge Graph Optimisation",
    description:
      "I audit your current Knowledge Graph footprint and work to ensure Google's entity graph represents your brand accurately — consolidating disparate signals into a coherent, authoritative entity record.",
    details: [
      "Knowledge Graph presence audit",
      "Entity claim and consolidation",
      "Disambiguation of brand vs. personal entity",
      "Monitoring and ongoing entity health checks",
    ],
  },
  {
    icon: Fingerprint,
    title: "Entity Disambiguation",
    description:
      "Where your brand, name, or business exists in more than one context, I work to clarify the correct entity to search engines — separating you from unrelated entities sharing similar identifiers.",
    details: [
      "Multi-entity conflict analysis",
      "Canonical entity signal reinforcement",
      "Cross-platform identity alignment",
      "Disambiguation schema implementation",
    ],
  },
  {
    icon: FileText,
    title: "Schema Markup for Entities",
    description:
      "Structured data is the clearest language you can speak to search engines. I implement Organisation, Person, LocalBusiness, and related schema types to formally declare your entity attributes and relationships.",
    details: [
      "Organisation and Person schema markup",
      "sameAs property implementation across authoritative sources",
      "LocalBusiness entity schema",
      "Schema validation and ongoing refinement",
    ],
  },
  {
    icon: Tags,
    title: "Brand Entity Consolidation",
    description:
      "Your entity is only as strong as its consistency across the web. I audit and consolidate your brand entity signals — NAP data, social profiles, directory listings, and authoritative mentions — to build a unified, coherent identity.",
    details: [
      "Cross-platform brand identity audit",
      "NAP (Name, Address, Phone) consistency review",
      "Social profile and bio alignment",
      "Authoritative directory presence",
    ],
  },
  {
    icon: Link2,
    title: "Co-Citation and Co-Occurrence Strategy",
    description:
      "Being mentioned alongside the right entities strengthens your position in Google's knowledge graph. I build a deliberate strategy around where and how your brand appears alongside relevant entities in your sector.",
    details: [
      "Topical co-citation mapping",
      "Co-occurrence keyword clustering",
      "Relevant entity association strategy",
      "Editorial mention placement",
    ],
  },
  {
    icon: Globe,
    title: "Wikipedia and Wikidata Presence",
    description:
      "Wikipedia and Wikidata remain among the most trusted entity sources for Google's Knowledge Graph. Where eligible, I guide the process of establishing or improving your presence on these platforms.",
    details: [
      "Wikipedia notability and eligibility assessment",
      "Wikidata entity creation and enrichment",
      "Linked Open Data integration",
      "Source and citation strategy for editorial standards",
    ],
  },
  {
    icon: AtSign,
    title: "Author Entity Signals",
    description:
      "For consultants, practitioners, and thought leaders, author entities matter. I implement and strengthen the signals that confirm your professional identity — connecting your content to a credible, verified authorship entity.",
    details: [
      "Google author entity signal implementation",
      "E-E-A-T author profile alignment",
      "Authorship schema (Person type) with professional attributes",
      "Bio and profile page consistency strategy",
    ],
  },
  {
    icon: Layers,
    title: "Structured Identity Across the Web",
    description:
      "Entity SEO is not a single task — it is a persistent, cross-channel discipline. I manage the structured identity layer across your digital presence: website, social, press, directories, and third-party platforms.",
    details: [
      "Digital presence audit across all entity touchpoints",
      "Structured data implementation on owned properties",
      "Third-party profile and listing alignment",
      "Ongoing monitoring for entity drift or inconsistency",
    ],
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const cardVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const EntitySeoServices = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="entity-seo-services"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mb-14 md:mb-18"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            What I Deliver
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 max-w-2xl">
            Entity SEO Services
          </h2>
          <p className="text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
            Entity SEO is a precise, technical discipline. Below is a detailed
            breakdown of what I cover when working with a client on their entity
            authority — from Knowledge Graph consolidation through to structured
            identity across the web. Every engagement is consultant-led: no
            account managers, no handoffs.
          </p>
        </motion.div>

        {/* Deliverables grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="grid grid-cols-1 md:grid-cols-2 gap-6 lg:gap-8"
        >
          {deliverables.map((item) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.title}
                variants={cardVariants}
                className="group relative rounded-md border border-border bg-card p-6 md:p-7 shadow-sm hover:shadow-md transition-all duration-300 hover:-translate-y-0.5"
              >
                {/* Icon + title row */}
                <div className="flex items-start gap-4 mb-4">
                  <div className="flex-shrink-0 flex h-11 w-11 items-center justify-center rounded-md bg-[hsl(225_28%_14%)]">
                    <Icon className="h-5 w-5 text-[hsl(84_74%_60%)]" />
                  </div>
                  <h3 className="text-lg font-semibold text-foreground leading-snug pt-1">
                    {item.title}
                  </h3>
                </div>

                {/* Description */}
                <p className="text-sm text-muted-foreground leading-relaxed mb-5">
                  {item.description}
                </p>

                {/* Detail checklist */}
                <ul className="space-y-2">
                  {item.details.map((detail) => (
                    <li
                      key={detail}
                      className="flex items-start gap-2.5 text-sm text-foreground"
                    >
                      <CheckCircle2 className="h-4 w-4 flex-shrink-0 text-[hsl(119_35%_61%)] mt-0.5" />
                      <span>{detail}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Closing note — editorial, no CTA button */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.55, ease: "easeOut", delay: 0.2 }}
          className="mt-14 md:mt-18 border-t border-border pt-10"
        >
          <div className="flex flex-col md:flex-row md:items-start md:gap-12">
            <div className="md:w-1/3 mb-4 md:mb-0">
              <Badge
                variant="outline"
                className="text-xs uppercase tracking-widest border-[hsl(214_32%_60%)] text-[hsl(214_32%_60%)]"
              >
                Consultant-led
              </Badge>
              <p className="mt-3 text-sm font-semibold text-foreground">
                Every deliverable above is handled directly by me — not
                delegated to a junior or outsourced.
              </p>
            </div>
            <div className="md:w-2/3 text-sm text-muted-foreground leading-relaxed space-y-3">
              <p>
                Entity SEO sits at the intersection of technical structure,
                editorial authority, and semantic search. The services listed
                above are not a rigid package — I scope each engagement based on
                where your entity authority currently stands, what the Knowledge
                Graph reflects, and where the greatest gains are available.
              </p>
              <p>
                If you are interested in how entity SEO connects to AI search
                visibility and LLM citation, I cover that in more detail on the{" "}
                <Link
                  to="/ai-search-optimisation"
                  className="text-[hsl(119_35%_61%)] underline underline-offset-2 hover:text-[hsl(84_74%_60%)] transition-colors duration-200"
                >
                  AI Search Optimisation
                </Link>{" "}
                service page.
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
});

EntitySeoServices.displayName = "EntitySeoServices";

export default EntitySeoServices;
