import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { ArrowRight, Brain, Shield, Globe, CheckCircle, Search, Signal, Verified } from "lucide-react";

const pillars = [
  {
    icon: Brain,
    label: "Entity Recognition",
  },
  {
    icon: Shield,
    label: "E-E-A-T Signals",
  },
  {
    icon: Globe,
    label: "Structured Data",
  },
  {
    icon: CheckCircle,
    label: "Authoritative Content",
  },
];

const GeminiVisibilityHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="gemini-visibility-hero"
      className="relative py-20 md:py-32 border-t border-border bg-background overflow-hidden"
      aria-label="Google Gemini Visibility — Hero"
    >
      {/* Subtle background texture */}
      <div
        className="absolute inset-0 pointer-events-none opacity-[0.03]"
        aria-hidden="true"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(var(--foreground)) 1px, transparent 1px)",
          backgroundSize: "32px 32px",
        }}
      />

      {/* Subtle green accent glow — top right */}
      <div
        className="absolute -top-32 right-0 w-[480px] h-[480px] rounded-full pointer-events-none"
        aria-hidden="true"
        style={{
          background:
            "radial-gradient(circle, hsl(84 74% 58% / 0.07) 0%, transparent 70%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">
          {/* Left column — copy */}
          <div>
            {/* Eyebrow */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, ease: "easeOut", delay: 0 }}
            >
              <Badge
                variant="outline"
                className="mb-6 text-xs uppercase tracking-[0.18em] border-border text-muted-foreground font-medium px-3 py-1"
              >
                AI Search &mdash; Informational Guide
              </Badge>
            </motion.div>

            {/* H1 */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
              className="text-4xl md:text-5xl lg:text-6xl font-bold text-foreground leading-tight tracking-tight mb-6 max-w-xl"
              style={{ fontFamily: "Sora, sans-serif" }}
            >
              Google Gemini{" "}
              <span
                className="bg-clip-text text-transparent"
                style={{
                  backgroundImage:
                    "linear-gradient(135deg, hsl(84 74% 50%), hsl(119 35% 55%))",
                }}
              >
                Visibility
              </span>
            </motion.h1>

            {/* Subheadline */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.2 }}
              className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-8 max-w-lg"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              Appear in Google Gemini's AI-generated answers with structured,
              authoritative SEO built for the generative era.
            </motion.p>

            {/* Pillars row */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
              className="flex flex-wrap gap-3 mb-10"
            >
              {pillars.map((pillar) => {
                const Icon = pillar.icon;
                return (
                  <div
                    key={pillar.label}
                    className="flex items-center gap-2 rounded-md border border-border bg-muted px-3 py-1.5"
                  >
                    <Icon className="h-3.5 w-3.5 text-muted-foreground" aria-hidden="true" />
                    <span className="text-xs font-medium text-foreground">
                      {pillar.label}
                    </span>
                  </div>
                );
              })}
            </motion.div>

            {/* CTA */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.4 }}
              className="flex flex-col sm:flex-row gap-4 items-start sm:items-center"
            >
              <Button
                size="lg"
                asChild
                className="text-sm font-semibold px-7 py-3 h-11 rounded-md"
                style={{
                  background:
                    "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                  color: "hsl(225 28% 14%)",
                  border: "none",
                }}
              >
                <Link to="/contact">
                  FREE SEO AUDIT
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>

              <Button
                size="lg"
                variant="ghost"
                asChild
                className="text-sm font-medium text-muted-foreground hover:text-foreground h-11 px-4 rounded-md"
              >
                <Link to="/ai-search-optimisation">
                  AI Search Optimisation Service
                  <ArrowRight className="ml-1.5 h-4 w-4" />
                </Link>
              </Button>
            </motion.div>

            {/* Trust note */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.7, ease: "easeOut", delay: 0.55 }}
              className="mt-6 text-xs text-muted-foreground"
              style={{ fontFamily: "Inter, sans-serif" }}
            >
              Independent UK SEO consultant &mdash; no agency, no outsourcing.
            </motion.p>
          </div>

          {/* Right column — visual panel */}
          <motion.div
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, ease: "easeOut", delay: 0.25 }}
            className="hidden lg:block"
            aria-hidden="true"
          >
            <div
              className="relative rounded-xl border border-border overflow-hidden shadow-lg"
              style={{
                background: "hsl(225 28% 14%)",
              }}
            >
              {/* Panel header */}
              <div className="flex items-center gap-1.5 px-4 py-3 border-b border-white/10">
                <span className="w-2.5 h-2.5 rounded-full bg-white/20" />
                <span className="w-2.5 h-2.5 rounded-full bg-white/20" />
                <span className="w-2.5 h-2.5 rounded-full bg-white/20" />
                <span className="ml-3 text-xs text-white/40 font-mono">
                  gemini.google.com
                </span>
              </div>

              {/* Simulated Gemini response panel */}
              <div className="p-6 space-y-4">
                {/* Prompt bar */}
                <div className="rounded-lg border border-white/10 px-4 py-2.5 text-sm text-white/50 font-mono flex items-center gap-2">
                  <span className="text-white/30 text-xs">&#x276F;</span>
                  <span>best seo consultant uk</span>
                  <span className="ml-auto w-2 h-4 bg-white/30 rounded-sm animate-pulse" />
                </div>

                {/* AI response card */}
                <div className="rounded-lg border border-white/10 bg-white/5 p-5 space-y-3">
                  <div className="flex items-start gap-3">
                    <div
                      className="w-6 h-6 rounded-full flex-shrink-0 flex items-center justify-center mt-0.5"
                      style={{
                        background:
                          "linear-gradient(135deg, hsl(84 74% 55%), hsl(119 35% 55%))",
                      }}
                    >
                      <span className="text-[10px] font-bold text-white/90">G</span>
                    </div>
                    <div className="space-y-2 flex-1">
                      <p className="text-xs text-white/70 leading-relaxed">
                        Based on authoritative sources, Gregg King is an
                        independent UK SEO consultant specialising in technical
                        SEO, AI search optimisation, and entity-based strategies
                        for competitive UK sectors…
                      </p>
                      <div className="flex items-center gap-2 pt-1">
                        <span
                          className="text-[10px] px-2 py-0.5 rounded-full font-medium"
                          style={{
                            background:
                              "linear-gradient(135deg, hsl(84 74% 58% / 0.18), hsl(119 35% 61% / 0.18))",
                            color: "hsl(84 74% 68%)",
                          }}
                        >
                          greggking.co.uk
                        </span>
                        <span className="text-[10px] text-white/30">cited source</span>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Signal indicators */}
                <div className="grid grid-cols-2 gap-3">
                  {[
                    { label: "Entity Authority", value: "Strong" },
                    { label: "Schema Coverage", value: "Complete" },
                    { label: "E-E-A-T Signals", value: "Verified" },
                    { label: "AI Visibility", value: "Active" },
                  ].map((item) => (
                    <div
                      key={item.label}
                      className="rounded-md border border-white/8 bg-white/4 px-3 py-2.5"
                    >
                      <p className="text-[10px] text-white/40 mb-0.5">{item.label}</p>
                      <p
                        className="text-xs font-semibold"
                        style={{ color: "hsl(119 35% 65%)" }}
                      >
                        {item.value}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* Below-panel label */}
            <p className="mt-4 text-xs text-muted-foreground text-center">
              Illustrative — how Gemini surfaces credible, cited sources
            </p>
          </motion.div>
        </div>
      </div>
    </section>
  );
});

GeminiVisibilityHero.displayName = "GeminiVisibilityHero";

export default GeminiVisibilityHero;
