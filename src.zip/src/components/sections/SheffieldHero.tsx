import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { MapPin, View } from "lucide-react";

const SheffieldHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      src="https://images.unsplash.com/photo-1573496130141-209d200cebd8?w=1920&h=1080&fit=crop"
      alt="Two women in suits standing beside wall — Sheffield SEO consultancy"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center"
    >
      <div className="container relative z-10 py-24 md:py-40">
        <div className="flex items-center gap-2 mb-4">
          <MapPin className="h-4 w-4 text-primary" />
          <span className="text-sm uppercase tracking-[0.2em] text-white/80 font-medium">
            Sheffield, South Yorkshire
          </span>
        </div>
        <h1 className="text-4xl md:text-6xl font-bold text-white max-w-3xl leading-tight">
          Sheffield SEO Consultant
        </h1>
        <p className="mt-6 text-lg md:text-xl text-white/90 max-w-2xl leading-relaxed">
          Independent SEO expertise tailored to Sheffield's thriving business landscape. From the Creative Quarter to Kelham Island, I help South Yorkshire businesses rank higher, attract more customers, and outpace the competition online.
        </p>
        <div className="flex flex-wrap gap-4 mt-10">
          <Button
            size="lg"
            className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
            asChild
          >
            <a href="/contact">Get a Free Sheffield SEO Audit</a>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-transparent text-white border-white hover:bg-white/10 font-semibold"
            asChild
          >
            <a href="/services">View Services</a>
          </Button>
        </div>
        <p className="mt-6 text-sm text-white/80">
          No long-term contracts · Transparent pricing · Local Sheffield expertise
        </p>
      </div>
    </ImageBackground>
  );
});

SheffieldHero.displayName = "SheffieldHero";
export default SheffieldHero;
