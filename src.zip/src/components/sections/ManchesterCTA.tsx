import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, Phone, Mail, Contact, Map as MapIcon, Search, View } from "lucide-react";
import { ImageBackground } from "@/components/ImageBackground";

const ManchesterCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="manchester-cta"
      aria-label="Manchester SEO CTA section"
      src="https://images.unsplash.com/photo-1633537065982-712792c23798?w=1920&h=1080&fit=crop"
      alt="Modern Manchester architecture — tall glass buildings against the sky"
      imgProps={{ fetchpriority: "low", loading: "lazy" }}
      className="py-24 md:py-36"
    >
      <div className="container relative z-10">
        <div className="max-w-2xl mx-auto text-center">
          <motion.span
            initial={{ opacity: 0, y: 12 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="inline-block text-xs uppercase tracking-[0.2em] text-white/80 font-semibold mb-5"
          >
            Ready to Dominate Manchester Search?
          </motion.span>

          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.08 }}
            className="text-3xl md:text-5xl font-bold text-white mb-6"
          >
            Start Your Manchester SEO Campaign Today
          </motion.h2>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.16 }}
            className="text-lg text-white/90 leading-relaxed mb-10"
          >
            Whether you're a Manchester SME looking to break into the Map Pack, or an
            enterprise brand competing for category-defining keywords, we build strategies
            that deliver measurable ROI.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.22 }}
            className="flex flex-wrap gap-4 justify-center mb-10"
          >
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold px-8"
              asChild
            >
              <Link to="/contact">
                Get a Free Manchester SEO Audit
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10 font-semibold px-8"
              asChild
            >
              <Link to="/local-seo">View Local SEO Service</Link>
            </Button>
          </motion.div>

          {/* Contact methods */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, delay: 0.28 }}
            className="flex flex-wrap gap-6 justify-center"
          >
            <a
              href="mailto:hello@gregg.com"
              className="flex items-center gap-2 text-sm text-white/80 hover:text-white transition-colors"
            >
              <Mail className="h-4 w-4 text-primary" />
              hello@gregg.com
            </a>
            <a
              href="tel:+441234567890"
              className="flex items-center gap-2 text-sm text-white/80 hover:text-white transition-colors"
            >
              <Phone className="h-4 w-4 text-primary" />
              Manchester consultations available
            </a>
          </motion.div>

          {/* Trust note */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.36 }}
            className="text-sm text-white/80 mt-8"
          >
            No long-term contracts required · Manchester, Salford & Greater Manchester covered · Free initial consultation
          </motion.p>
        </div>
      </div>
    </ImageBackground>
  );
});

ManchesterCTA.displayName = "ManchesterCTA";

export default ManchesterCTA;
