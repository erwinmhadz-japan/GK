import React from "react";
import { Star, TrendingUp, Search, CheckCircle, Target } from "lucide-react";

const results = [
  { metric: "+320%", label: "Organic Traffic Growth", timeframe: "in 8 months" },
  { metric: "#1", label: "Rankings for Target Keywords", timeframe: "across Greater Manchester" },
  { metric: "+180%", label: "Qualified Leads from Search", timeframe: "year-on-year" },
];

const ManchesterTestimonial = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative isolate py-24 md:py-36 border-t border-border overflow-hidden"
    >
      {/* Layer 1 — background image */}
      <img
        src="https://images.unsplash.com/photo-1582005450386-52b25f82d9bb?w=1920&h=1080&fit=crop"
        alt="Manchester business team collaborating around laptops in a bright office"
        className="absolute inset-0 w-full h-full object-cover"
        loading="lazy"
        width="1920"
        height="1080"
      />
      {/* Layer 2 — brand-tint overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/80 via-primary/55 to-accent/60 pointer-events-none" />

      {/* Layer 3 — content */}
      <div className="container relative z-10">
        <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-6">
          Manchester Case Study
        </span>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-14 items-center">
          {/* Testimonial quote */}
          <div>
            <div className="flex gap-1 mb-6">
              {[1, 2, 3, 4, 5].map((i) => (
                <Star key={i} className="h-5 w-5 fill-white text-white" />
              ))}
            </div>
            <blockquote className="text-xl md:text-2xl font-semibold text-white leading-relaxed mb-8">
              "We'd tried other agencies and got nowhere. Within six months of working with Gregg, we were ranking on page one for every major service keyword in Manchester. The phone hasn't stopped ringing."
            </blockquote>
            <div className="flex items-center gap-4">
              <img
                src="https://images.unsplash.com/photo-1734830268394-6c4a1f165af1?w=400&h=400&fit=crop&crop=face"
                alt="James Thornton, Director of Manchester-based financial services firm"
                width="56"
                height="56"
                className="rounded-full object-cover ring-2 ring-white/30"
              />
              <div>
                <p className="font-semibold text-white">James Thornton</p>
                <p className="text-white/80 text-sm">Managing Director, Thornton Financial Services</p>
                <p className="text-white/80 text-xs mt-0.5">Manchester City Centre</p>
              </div>
            </div>
          </div>

          {/* Results metrics */}
          <div className="space-y-4">
            <h3 className="text-xl font-bold text-white mb-6">Campaign Results</h3>
            {results.map((result, index) => (
              <div
                key={index}
                className="bg-white/15 backdrop-blur-sm border border-white/20 rounded-xl p-5 flex items-center gap-4"
              >
                <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-white/20 flex-shrink-0">
                  {index === 0 && <TrendingUp className="h-6 w-6 text-white" />}
                  {index === 1 && <Search className="h-6 w-6 text-white" />}
                  {index === 2 && <CheckCircle className="h-6 w-6 text-white" />}
                </div>
                <div>
                  <p className="text-2xl font-bold text-white">{result.metric}</p>
                  <p className="text-sm font-medium text-white/90">{result.label}</p>
                  <p className="text-xs text-white/80">{result.timeframe}</p>
                </div>
              </div>
            ))}
            <div className="mt-6">
              <a
                href="/contact"
                className="inline-flex items-center gap-2 bg-white text-primary-foreground px-6 py-3 rounded-lg font-semibold hover:bg-white/90 transition-colors text-sm"
                style={{ color: "hsl(225 28% 14%)" }}
              >
                Get Similar Results for Your Business
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

ManchesterTestimonial.displayName = "ManchesterTestimonial";

export default ManchesterTestimonial;
