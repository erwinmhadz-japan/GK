import React from "react";
import { Star, Quote, Group, Stars } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const testimonials = [
  {
    quote:
      "Gregg's approach was unlike any SEO consultant we'd worked with before. He didn't just fix our rankings — he built a framework we can sustain. Our organic enquiries are up 280% and we now appear in AI Overviews for half our key practice areas.",
    name: "Sarah Mitchell",
    title: "Managing Partner",
    firm: "Personal Injury Law Firm, Manchester",
    image: "https://images.unsplash.com/photo-1710778044102-56a3a6b69a1b?w=400&h=400&fit=crop&crop=face",
    stars: 5,
  },
  {
    quote:
      "The technical SEO audit alone uncovered 14 critical issues we had no idea existed. Within 6 months of remediation, our clinic group's organic traffic had more than doubled. Gregg is meticulous, transparent, and genuinely results-driven.",
    name: "Dr. James Hargreaves",
    title: "Clinical Director",
    firm: "Private Healthcare Group, London",
    image: "https://images.unsplash.com/photo-1741455620227-3b1c51e01419?w=400&h=400&fit=crop&crop=face",
    stars: 5,
  },
  {
    quote:
      "Our content strategy was a game-changer. We went from fighting for page 2 positions to generating featured snippets and consistent citations in ChatGPT within a year. The quality of our inbound leads has transformed completely.",
    name: "Rachel Donovan",
    title: "Head of Marketing",
    firm: "Property Investment Consultancy, Birmingham",
    image: "https://images.unsplash.com/photo-1681500920181-0aff411f8cab?w=400&h=400&fit=crop&crop=face",
    stars: 5,
  },
];

const CaseStudiesTestimonials = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="case-studies-testimonials"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
      aria-label="Client testimonials about case study results"
    >
      <div className="container">
        {/* Header */}
        <div className="text-center mb-14">
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Client Voices
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Heard Directly From Clients
          </h2>
          <p className="text-muted-foreground max-w-xl mx-auto text-base md:text-lg">
            Behind every case study metric is a business that chose to invest in
            long-term, results-driven SEO. Here's what they say.
          </p>
        </div>

        {/* Testimonial grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8">
          {testimonials.map(({ quote, name, title, firm, image, stars }) => (
            <Card
              key={name}
              className="flex flex-col border border-border bg-card"
              style={{ boxShadow: "var(--shadow-card)" }}
            >
              <CardContent className="flex flex-col flex-1 gap-5 pt-6 pb-6">
                {/* Stars */}
                <div className="flex gap-1" aria-label={`${stars} out of 5 stars`}>
                  {Array.from({ length: stars }).map((_, i) => (
                    <Star key={i} className="h-4 w-4 fill-primary text-primary" />
                  ))}
                </div>

                {/* Quote icon */}
                <Quote className="h-8 w-8 text-primary/30" aria-hidden="true" />

                {/* Quote text */}
                <blockquote className="text-foreground text-sm md:text-base leading-relaxed flex-1 italic">
                  "{quote}"
                </blockquote>

                {/* Author */}
                <div className="flex items-center gap-3 pt-4 border-t border-border">
                  <img
                    src={image}
                    alt={`${name}, ${title}`}
                    width={48}
                    height={48}
                    loading="lazy"
                    className="h-12 w-12 rounded-full object-cover shrink-0"
                  />
                  <div>
                    <p className="text-sm font-semibold text-foreground">{name}</p>
                    <p className="text-xs text-muted-foreground">{title}</p>
                    <p className="text-xs text-muted-foreground">{firm}</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
});

CaseStudiesTestimonials.displayName = "CaseStudiesTestimonials";

export default CaseStudiesTestimonials;
