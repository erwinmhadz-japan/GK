import React from "react";
import { motion } from "framer-motion";
import { Brain, Search, Layers, Globe, ArrowRight, CheckCircle, Quote } from "lucide-react";
import { Link } from "react-router-dom";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (delay: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut", delay },
  }),
};

const differentiators = [
  {
    icon: Brain,
    heading: "Language models, not link graphs",
    body:
      "AI answer engines like ChatGPT and Perplexity are built on large language models trained on vast corpora of text. They form probabilistic associations between entities, topics, and trusted sources — not ranked lists of backlink-weighted pages.",
  },
  {
    icon: Search,
    heading: "Citations, not click-throughs",
    body:
      "When an LLM surfaces a source, it cites that source as part of a synthesised answer. The user often never visits your site. Visibility in AI search means being the entity a model associates with authority on a given topic.",
  },
  {
    icon: Layers,
    heading: "Entity recognition over keyword matching",
    body:
      "AI engines understand who you are, what you do, and whether authoritative sources confirm it — not just whether your page contains the right keywords. Your brand entity must be clearly defined and corroborated across the web.",
  },
  {
    icon: Globe,
    heading: "Source credibility signals matter more",
    body:
      "To be cited by an AI engine, your content must be discovered by its crawlers, structured so the model can parse it cleanly, and corroborated by third-party mentions from credible, indexed sources.",
  },
];

const AiSearchWhatIsIt = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="ai-search-what-is-it"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <div className="max-w-3xl mx-auto text-center mb-16 md:mb-20">
          <motion.span
            custom={0}
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4"
          >
            Explainer
          </motion.span>

          <motion.h2
            custom={0.1}
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground mb-6 leading-tight"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            What Is AI Search Optimisation?
          </motion.h2>

          <motion.p
            custom={0.2}
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl mx-auto"
          >
            AI search optimisation is the practice of making your business visible and citable in
            AI-powered answer engines — platforms such as ChatGPT, Perplexity, Google AI
            Overviews, Gemini, and Microsoft Copilot. It is a discipline that is distinct from
            traditional SEO in several important ways.
          </motion.p>
        </div>

        {/* Two-column editorial layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-start mb-16 md:mb-20">
          {/* Left: main explainer prose */}
          <motion.div
            custom={0.3}
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="space-y-6"
          >
            <p className="text-base text-muted-foreground leading-relaxed">
              Traditional search engines rank pages. AI answer engines synthesise answers. That
              distinction sounds simple, but it has profound implications for how a business should
              structure its content, build its authority, and signal its expertise online.
            </p>

            <p className="text-base text-muted-foreground leading-relaxed">
              In a traditional Google search, the goal is a high-ranking blue link. In AI search,
              the goal is inclusion — being the source that an LLM selects when a user asks a
              question relevant to your business. That requires a different set of signals and a
              different optimisation mindset.
            </p>

            <p className="text-base text-muted-foreground leading-relaxed">
              The field draws heavily on established SEO disciplines — technical site health,
              authoritative content, structured data, and link authority — but applies them through
              the lens of entity recognition, source credibility, and model training inputs rather
              than keyword rankings alone.
            </p>

            <p className="text-base text-muted-foreground leading-relaxed">
              For UK businesses operating in competitive, trust-led sectors — law, healthcare,
              financial services, property — the stakes are particularly high. AI engines apply
              heightened scrutiny to YMYL (Your Money or Your Life) content, and demonstrating
              verifiable expertise and authority is non-negotiable.
            </p>

            {/* Inline link — subtle, not a CTA block */}
            <p className="text-sm text-muted-foreground">
              Explore the technical components of my approach on the{" "}
              <Link
                to="/ai-search-optimisation"
                className="text-foreground underline underline-offset-4 hover:text-primary transition-colors duration-200"
              >
                AI Search Optimisation service page
              </Link>
              .
            </p>
          </motion.div>

          {/* Right: pull-quote + stat highlight panel */}
          <motion.div
            custom={0.4}
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            className="space-y-6"
          >
            {/* Pull quote */}
            <div className="relative pl-6 border-l-2 border-primary">
              <Quote
                className="absolute -left-3 -top-1 h-5 w-5 text-primary/60"
                aria-hidden="true"
              />
              <blockquote className="text-base md:text-lg text-foreground font-medium leading-relaxed italic">
                "The shift from ranking pages to being cited as a trusted source requires a
                fundamentally different approach to how a business presents its expertise online."
              </blockquote>
              <p className="mt-3 text-xs uppercase tracking-widest text-muted-foreground">
                Gregg King — Independent SEO Consultant
              </p>
            </div>

            {/* Stat highlight panel */}
            <div
              className="rounded-md border border-border p-6 md:p-8"
              style={{
                background: "hsl(225 28% 14%)",
              }}
            >
              <p
                className="text-xs uppercase tracking-[0.18em] mb-4"
                style={{ color: "hsl(214 32% 60%)" }}
              >
                Why it matters now
              </p>
              <ul className="space-y-4">
                {[
                  "AI Overviews appear in over 15% of UK Google searches — and growing",
                  "ChatGPT processes an estimated 10 million queries per day in the UK",
                  "Perplexity and Copilot are becoming first-choice research tools for professionals in law, finance, and healthcare",
                ].map((fact, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <CheckCircle
                      className="h-4 w-4 mt-0.5 shrink-0"
                      style={{ color: "hsl(119 35% 61%)" }}
                      aria-hidden="true"
                    />
                    <span className="text-sm leading-relaxed" style={{ color: "hsl(0 0% 100% / 0.85)" }}>
                      {fact}
                    </span>
                  </li>
                ))}
              </ul>
            </div>
          </motion.div>
        </div>

        {/* How AI engines differ — four differentiator cards */}
        <motion.div
          custom={0.5}
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="mb-10"
        >
          <h3
            className="text-lg md:text-xl font-semibold text-foreground mb-8"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            How AI search differs from traditional SEO
          </h3>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {differentiators.map((item, i) => {
            const Icon = item.icon;
            return (
              <motion.div
                key={item.heading}
                custom={0.55 + i * 0.08}
                variants={fadeUp}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                className="rounded-md border border-border bg-card p-6 md:p-7"
              >
                <div className="flex items-start gap-4">
                  <div
                    className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md"
                    style={{ background: "hsl(225 28% 14%)" }}
                  >
                    <Icon
                      className="h-5 w-5"
                      style={{ color: "hsl(119 35% 61%)" }}
                      aria-hidden="true"
                    />
                  </div>
                  <div>
                    <h4
                      className="text-sm font-semibold text-foreground mb-2 leading-snug"
                      style={{ fontFamily: "Sora, sans-serif" }}
                    >
                      {item.heading}
                    </h4>
                    <p className="text-sm text-muted-foreground leading-relaxed">{item.body}</p>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* Footer note */}
        <motion.div
          custom={0.9}
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="mt-14 pt-8 border-t border-border max-w-2xl"
        >
          <p className="text-sm text-muted-foreground leading-relaxed">
            For a deeper technical breakdown of how I approach AI search optimisation for UK
            clients — including entity optimisation, schema markup, and content structuring — see{" "}
            <Link
              to="/ai-search-optimisation"
              className="inline-flex items-center gap-1 text-foreground underline underline-offset-4 hover:text-primary transition-colors duration-200"
            >
              AI Search Optimisation
              <ArrowRight className="h-3.5 w-3.5" aria-hidden="true" />
            </Link>{" "}
            or explore the individual platform guides in the{" "}
            <Link
              to="/ai-search-optimisation"
              className="text-foreground underline underline-offset-4 hover:text-primary transition-colors duration-200"
            >
              AI Search hub
            </Link>
            .
          </p>
        </motion.div>
      </div>
    </section>
  );
});

AiSearchWhatIsIt.displayName = "AiSearchWhatIsIt";

export default AiSearchWhatIsIt;
