import React from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, FileText, Globe, Search, ArrowRight, CheckCircle, Zap, Target, Section, View } from "lucide-react";

const solutions = [
  {
    badge: "Local SEO",
    icon: MapPin,
    href: "/services-local-seo",
    title: "Hyper-Local Patient Acquisition SEO",
    description:
      "We optimise your Google Business Profile, build consistent citations across healthcare directories (NHS Choices, Doctify, Trustpilot Health), and target geo-specific keywords that map to patient intent at every stage — from discovery to appointment booking.",
    features: [
      "Google Business Profile optimisation & management",
      "Healthcare directory citation building & cleanup",
      "Geo-targeted landing pages for each treatment area",
      "Local rank tracking across clinic postcodes",
      "Review generation strategy & response framework",
    ],
    linkLabel: "Explore Local SEO →",
  },
  {
    badge: "Schema Markup",
    icon: FileText,
    href: "/schema-markup",
    title: "Healthcare Schema Markup & Structured Data",
    description:
      "Structured data is uniquely powerful in healthcare. MedicalOrganization, Physician, MedicalCondition, and MedicalProcedure schema types help Google understand your services precisely — unlocking rich results and establishing entity authority with AI-powered search platforms.",
    features: [
      "MedicalOrganization & MedicalClinic schema",
      "Physician and HealthcareProfessional entity markup",
      "Service & MedicalProcedure structured data",
      "FAQPage schema for patient common questions",
      "AggregateRating schema for trust signals",
    ],
    linkLabel: "Explore Schema Markup →",
  },
  {
    badge: "Entity SEO",
    icon: Globe,
    href: "/services-technical-seo",
    title: "Entity SEO for Medical Providers",
    description:
      "Google's Knowledge Graph increasingly underpins how healthcare businesses are understood and recommended by AI search assistants. We build your clinic's entity authority — ensuring your brand, practitioners, and services are disambiguated, verified, and correctly represented across the semantic web.",
    features: [
      "Google Knowledge Panel establishment & management",
      "Wikidata and medical directory entity alignment",
      "Practitioner entity building for key physicians",
      "Brand mention tracking and unlinked citation conversion",
      "AI search visibility for healthcare queries",
    ],
    linkLabel: "Explore Entity SEO →",
  },
  {
    badge: "Content Strategy",
    icon: Search,
    href: "/content-strategy",
    title: "YMYL-Compliant Medical Content Strategy",
    description:
      "Healthcare content demands rigorous E-E-A-T signals. Our medical content strategies pair clinical expertise with search data to produce authoritative, patient-centred content that ranks for high-value condition and treatment queries — all compliant with ASA and Google's quality rater guidelines.",
    features: [
      "Topical authority mapping for medical specialities",
      "Expert-authored content with practitioner bylines",
      "Condition, symptom, and treatment page development",
      "Internal linking architecture for clinical depth",
      "Content refresh audits aligned to NICE guidelines",
    ],
    linkLabel: "Explore Content Strategy →",
  },
];

const HealthcareClinicsSolutions = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="healthcare-seo-solutions"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-2xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4 font-semibold">
            Our Healthcare SEO Services
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Specialist SEO Solutions Built for Medical Providers
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            From local search dominance to schema markup and AI search visibility — every
            service is engineered specifically for the healthcare sector's demands.
          </p>
        </div>

        {/* Solutions stacked layout */}
        <div className="space-y-10">
          {solutions.map((solution, idx) => {
            const Icon = solution.icon;
            const isEven = idx % 2 === 1;
            return (
              <div
                key={solution.title}
                className={`grid grid-cols-1 lg:grid-cols-2 gap-8 items-center rounded-2xl border border-border bg-card shadow-card p-8 md:p-10 ${isEven ? "lg:direction-rtl" : ""}`}
              >
                {/* Content side */}
                <div className={isEven ? "lg:order-2" : ""}>
                  <div className="flex items-center gap-3 mb-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <Badge variant="outline" className="text-xs font-semibold uppercase tracking-wider">
                      {solution.badge}
                    </Badge>
                  </div>
                  <h3 className="text-xl md:text-2xl font-bold text-foreground mb-3">
                    {solution.title}
                  </h3>
                  <p className="text-muted-foreground leading-relaxed mb-5">
                    {solution.description}
                  </p>
                  <a
                    href={solution.href}
                    className="inline-flex items-center gap-1 text-primary font-semibold text-sm hover:underline"
                  >
                    {solution.linkLabel}
                  </a>
                </div>

                {/* Features side */}
                <div className={`bg-muted rounded-xl p-6 ${isEven ? "lg:order-1" : ""}`}>
                  <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-4">
                    What's included
                  </p>
                  <ul className="space-y-3">
                    {solution.features.map((feature) => (
                      <li key={feature} className="flex items-start gap-3">
                        <CheckCircle className="h-4 w-4 text-primary shrink-0 mt-0.5" />
                        <span className="text-sm text-foreground leading-snug">{feature}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            );
          })}
        </div>

        {/* Mid-page CTA */}
        <div className="mt-14 flex flex-col sm:flex-row items-center gap-4 justify-center">
          <Button size="lg" asChild className="font-semibold shadow-green-glow">
            <a href="/contact">
              Discuss Your Healthcare SEO Strategy
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </Button>
          <Button size="lg" variant="outline" asChild className="font-semibold">
            <a href="/services-local-seo">View Local SEO Service</a>
          </Button>
        </div>
      </div>
    </section>
  );
});

HealthcareClinicsSolutions.displayName = "HealthcareClinicsSolutions";

export default HealthcareClinicsSolutions;
