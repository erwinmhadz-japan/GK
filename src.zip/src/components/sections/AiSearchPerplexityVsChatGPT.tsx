import React from "react";
import { motion } from "framer-motion";
import { CheckCircle, Globe, Brain, RefreshCw, Lightbulb, Bot, Icon, Section } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const comparisons = [
  {
    dimension: "Data source",
    perplexity: "Live web crawl — retrieves fresh pages per query",
    chatgpt: "Static training data — knowledge cutoff applies",
  },
  {
    dimension: "Citations",
    perplexity: "Always shown — numbered source links in every answer",
    chatgpt: "Rarely shown — Browse mode adds some, but not consistently",
  },
  {
    dimension: "Optimisation approach",
    perplexity: "SEO-adjacent: crawlability, freshness, structured data, E-E-A-T",
    chatgpt: "Training data presence, Wikipedia, high-domain-authority mentions",
  },
  {
    dimension: "Content indexing speed",
    perplexity: "Days to weeks — real-time index updated continuously",
    chatgpt: "Months to years — tied to model training cycles",
  },
  {
    dimension: "Best content types",
    perplexity: "News, research, how-to guides, authoritative explainers with clear facts",
    chatgpt: "Brand definitions, evergreen knowledge, FAQ-style content",
  },
];

const strategies = [
  {
    icon: Globe,
    title: "Open Perplexity-Bot Access",
    body: "Verify that PerplexityBot is not blocked in your robots.txt. Unlike some AI crawlers, Perplexity respects standard crawl controls — so you must explicitly allow access.",
  },
  {
    icon: RefreshCw,
    title: "Publish and Update Regularly",
    body: "Fresh content wins. Add visible publication dates and regularly refresh statistics or factual claims on cornerstone pages to signal recency to Perplexity's index.",
  },
  {
    icon: Brain,
    title: "Build Entity Authority",
    body: "Strengthen your brand entity through digital PR, authoritative backlinks, and consistent brand mentions across trusted domains. Entity recognition translates directly into citation priority.",
  },
  {
    icon: Lightbulb,
    title: "Write Citable Summaries",
    body: "Open each major section with a concise, factual summary paragraph. These discrete, quotable blocks are what Perplexity surfaces as source citations in answers.",
  },
];

const AiSearchPerplexityVsChatGPT = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="perplexity-vs-chatgpt"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
      aria-label="Perplexity vs ChatGPT and optimisation strategies"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <div className="max-w-3xl mb-14">
          <Badge variant="outline" className="mb-4 text-xs uppercase tracking-widest text-muted-foreground">
            Perplexity vs ChatGPT
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            How Perplexity Differs from ChatGPT — and Why It Matters
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Many brands treat AI search optimisation as a single discipline. In reality, Perplexity and ChatGPT are fundamentally different engines that reward fundamentally different optimisation approaches.
          </p>
        </div>

        {/* Comparison table */}
        <div className="overflow-x-auto rounded-2xl border border-border bg-background mb-16 shadow-card">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-border">
                <th className="px-6 py-4 text-left font-semibold text-foreground w-1/4">Dimension</th>
                <th className="px-6 py-4 text-left font-semibold text-primary w-3/8">
                  <span className="flex items-center gap-2">
                    <Globe className="h-4 w-4" />
                    Perplexity AI
                  </span>
                </th>
                <th className="px-6 py-4 text-left font-semibold text-muted-foreground w-3/8">
                  <span className="flex items-center gap-2">
                    <Brain className="h-4 w-4" />
                    ChatGPT
                  </span>
                </th>
              </tr>
            </thead>
            <tbody>
              {comparisons.map(({ dimension, perplexity, chatgpt }, i) => (
                <tr
                  key={dimension}
                  className={i % 2 === 0 ? "bg-muted/50" : "bg-background"}
                >
                  <td className="px-6 py-4 font-medium text-foreground align-top">{dimension}</td>
                  <td className="px-6 py-4 text-foreground align-top">{perplexity}</td>
                  <td className="px-6 py-4 text-muted-foreground align-top">{chatgpt}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Optimisation strategies */}
        <div className="mb-10">
          <h3 className="text-2xl md:text-3xl font-bold text-foreground mb-8">
            Optimisation Strategies for Perplexity Visibility
          </h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {strategies.map(({ icon: Icon, title, body }, i) => (
              <motion.div
                key={title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.45, delay: i * 0.1 }}
                className="rounded-xl border border-border bg-card p-6 shadow-card hover-lift"
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-4">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <h4 className="text-base font-bold text-foreground mb-2">{title}</h4>
                <p className="text-sm text-muted-foreground leading-relaxed">{body}</p>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Case insight callout */}
        <div className="rounded-2xl border border-primary/20 bg-primary/5 p-8 md:p-10">
          <div className="flex gap-4 items-start">
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-lg bg-primary/15">
              <CheckCircle className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h4 className="text-lg font-bold text-foreground mb-2">Insight: The Freshness Dividend</h4>
              <p className="text-muted-foreground leading-relaxed text-sm">
                In one case study, a B2B SaaS provider updated and republished 12 existing explainer articles with current statistics, visible updated dates, and FAQ schema. Within six weeks, Perplexity began citing four of those pages in industry-related queries — delivering qualified referral traffic that previously required paid search spend. The key differentiator was not new content, but demonstrably fresh and structured existing content.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

AiSearchPerplexityVsChatGPT.displayName = "AiSearchPerplexityVsChatGPT";

export default AiSearchPerplexityVsChatGPT;
