import React from "react";
import { motion } from "framer-motion";
import { Badge } from "@/components/ui/badge";
import { Code, Network, Brain, MapPin, Landmark, HeartPulse, Home, Briefcase, BadgeCheck, Clock, TrendingUp, FileSearch, Search, Section } from "lucide-react";

// ─── Discipline cards ──────────────────────────────────────────────────────────
const disciplines = [
  {
    icon: Code,
    title: "Technical SEO",
    body: "Deep-level audits covering crawl efficiency, Core Web Vitals, structured data implementation, log file analysis, and JavaScript rendering. I diagnose infrastructure issues that prevent pages from reaching their ranking potential.",
  },
  {
    icon: Network,
    title: "Entity SEO & Schema Markup",
    body: "Entity-first optimisation using schema markup, knowledge panel strategy, and semantic co-occurrence signals. I build the machine-readable context that allows search engines to understand exactly who a business is and what it does.",
  },
  {
    icon: Brain,
    title: "AI Search Optimisation",
    body: "Emerging specialism in optimising content for AI-generated answers across ChatGPT, Perplexity, Google AI Overviews, Gemini, and Copilot. I help UK businesses remain visible as search behaviour shifts.",
  },
  {
    icon: FileSearch,
    title: "SEO Auditing & Strategy",
    body: "Bespoke audits that go beyond surface-level recommendations. Each audit produces a clear, prioritised roadmap — work I can execute myself or hand to an in-house team with full confidence.",
  },
  {
    icon: TrendingUp,
    title: "Content Strategy",
    body: "Keyword research and content architecture designed to capture commercial and informational intent without cannibalisation. I map content to genuine search demand, not guesswork.",
  },
  {
    icon: MapPin,
    title: "Local SEO",
    body: "City and county-level SEO for businesses serving the UK regionally. Warrington, Manchester, Liverpool, Birmingham, Leeds, Sheffield, and London. Includes Google Business Profile optimisation and local citation building.",
  },
];

// ─── Sector cards ─────────────────────────────────────────────────────────────
const sectors = [
  {
    icon: Landmark,
    label: "Law Firms & Solicitors",
    description:
      "Competitive practice-area rankings for firms where organic visibility directly drives case enquiries. I understand the sensitivity required around regulated legal services content.",
  },
  {
    icon: HeartPulse,
    label: "Healthcare & Private Providers",
    description:
      "YMYL-aware SEO for private clinics, specialist consultants, and healthcare brands operating in high-scrutiny search categories where authority and trust signals are critical.",
  },
  {
    icon: Home,
    label: "Estate Agents & Property",
    description:
      "Local and national SEO for estate agencies and property services where intent is hyper-localised and speed-to-ranking matters in a market driven by seasonal demand.",
  },
  {
    icon: Briefcase,
    label: "Financial Services & B2B",
    description:
      "Regulated sector SEO for IFAs, accountancy practices, and professional services firms. Long-form authority content, technical precision, and compliance-aware copy direction.",
  },
];

// ─── Proof points ─────────────────────────────────────────────────────────────
const proofPoints = [
  {
    icon: Clock,
    stat: "10+",
    label: "Years in SEO practice",
  },
  {
    icon: BadgeCheck,
    stat: "100%",
    label: "Work delivered personally",
  },
  {
    icon: MapPin,
    stat: "National",
    label: "Reach from Warrington, Cheshire",
  },
];

// ─── Animation variants ───────────────────────────────────────────────────────
const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  visible: (delay: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut", delay },
  }),
};

const AboutCredentials = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="about-credentials"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* ── Section header ── */}
        <motion.div
          className="mb-14 md:mb-20"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          custom={0}
          variants={fadeUp}
        >
          <span className="inline-block text-xs uppercase tracking-[0.22em] text-muted-foreground mb-4">
            Track Record &amp; Expertise
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-semibold text-foreground leading-tight max-w-2xl">
            Verifiable depth across the disciplines that move the needle
          </h2>
          <p className="mt-5 text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
            I work with UK businesses in competitive, trust-led sectors — industries where
            a superficial SEO approach fails quickly. What follows is an honest account of
            where my practice is deepest, and why that specificity matters for your results.
          </p>
        </motion.div>

        {/* ── Proof strip ── */}
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-16 md:mb-24"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
        >
          {proofPoints.map((point, i) => {
            const Icon = point.icon;
            return (
              <motion.div
                key={point.label}
                custom={i * 0.1}
                variants={fadeUp}
                className="flex items-center gap-4 p-5 rounded-md border border-border bg-muted/40"
              >
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-primary/10">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <p className="text-xl font-semibold text-foreground leading-none mb-1">
                    {point.stat}
                  </p>
                  <p className="text-sm text-muted-foreground">{point.label}</p>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* ── Disciplines ── */}
        <motion.div
          className="mb-6"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          custom={0}
          variants={fadeUp}
        >
          <span className="inline-block text-xs uppercase tracking-[0.22em] text-muted-foreground mb-3">
            Core disciplines
          </span>
          <h3 className="text-xl md:text-2xl font-semibold text-foreground mb-10">
            Where my practice is deepest
          </h3>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-20 md:mb-28">
          {disciplines.map((disc, i) => {
            const Icon = disc.icon;
            return (
              <motion.div
                key={disc.title}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-40px" }}
                custom={i * 0.08}
                variants={fadeUp}
                className="group rounded-md border border-border bg-card p-6 transition-shadow duration-300 hover:shadow-[0_4px_24px_hsl(225_28%_14%/0.10)]"
              >
                <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 transition-colors duration-300 group-hover:bg-primary/20">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <h4 className="text-base font-semibold text-foreground mb-2">
                  {disc.title}
                </h4>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {disc.body}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* ── Sectors ── */}
        <motion.div
          className="mb-6"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          custom={0}
          variants={fadeUp}
        >
          <span className="inline-block text-xs uppercase tracking-[0.22em] text-muted-foreground mb-3">
            Sector experience
          </span>
          <h3 className="text-xl md:text-2xl font-semibold text-foreground mb-2">
            Industries where trust and authority are non-negotiable
          </h3>
          <p className="text-sm md:text-base text-muted-foreground max-w-2xl mb-10 leading-relaxed">
            I have worked across the UK's most competitive and regulated sectors — sectors
            where domain authority, E-E-A-T signals, and technically sound SEO are the
            baseline, not the finish line.
          </p>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16 md:mb-24">
          {sectors.map((sector, i) => {
            const Icon = sector.icon;
            return (
              <motion.div
                key={sector.label}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true, margin: "-40px" }}
                custom={i * 0.1}
                variants={fadeUp}
                className="flex gap-5 rounded-md border border-border bg-card p-6 transition-shadow duration-300 hover:shadow-[0_4px_24px_hsl(225_28%_14%/0.10)]"
              >
                <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-md bg-primary/10 mt-0.5">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h4 className="text-base font-semibold text-foreground mb-1.5">
                    {sector.label}
                  </h4>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {sector.description}
                  </p>
                </div>
              </motion.div>
            );
          })}
        </div>

        {/* ── Methodology note ── */}
        <motion.div
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          custom={0}
          variants={fadeUp}
          className="rounded-md border border-border bg-muted/40 p-7 md:p-10"
        >
          <div className="flex flex-col md:flex-row md:items-start gap-6">
            <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-md bg-primary/10">
              <BadgeCheck className="h-5 w-5 text-primary" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-foreground mb-3">
                My methodology in brief
              </h3>
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-4">
                Every engagement begins with understanding the business — not just the
                keyword targets. I draw on technical auditing, entity analysis, content
                architecture, and sector-specific competitive research to build strategies
                that are executable, measurable, and built to last.
              </p>
              <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-5">
                I do not outsource work or pass projects to juniors. When you engage me, I
                carry out the work myself — from the initial discovery call through to
                ongoing retainer delivery. That accountability is baked into the model.
              </p>
              <div className="flex flex-wrap gap-2">
                {[
                  "SEO consulting",
                  "SEO audit",
                  "SEO retainer",
                  "Technical SEO",
                  "Schema markup",
                  "Entity SEO",
                  "Content strategy",
                  "Local SEO",
                  "Digital PR",
                  "AI search optimisation",
                ].map((service) => (
                  <Badge
                    key={service}
                    variant="secondary"
                    className="text-xs font-normal"
                  >
                    {service}
                  </Badge>
                ))}
              </div>
            </div>
          </div>
        </motion.div>

      </div>
    </section>
  );
});

AboutCredentials.displayName = "AboutCredentials";

export default AboutCredentials;
