import React from "react";
import { motion } from "framer-motion";
import { MapPin, ArrowRight, Globe, View } from "lucide-react";
import { Link } from "react-router-dom";

const locations = [
  {
    city: "Warrington",
    region: "Cheshire",
    keyword: "SEO Consultant Warrington",
    description:
      "Based in Warrington, I work closely with local businesses across Cheshire seeking genuine local search visibility — from professional services and healthcare providers to trades and retail.",
    href: "/locations",
    highlight: true,
  },
  {
    city: "Manchester",
    region: "Greater Manchester",
    keyword: "SEO Consultant Manchester",
    description:
      "Manchester's competitive market demands precise, authority-led local SEO. I help businesses across the city-region rank prominently in local searches and Google's map pack.",
    href: "/locations",
    highlight: false,
  },
  {
    city: "Liverpool",
    region: "Merseyside",
    keyword: "SEO Consultant Liverpool",
    description:
      "From the city centre to the wider Merseyside area, I support Liverpool-based businesses with targeted local SEO strategies that build visibility where their customers are searching.",
    href: "/locations",
    highlight: false,
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay: i * 0.12 },
  }),
};

const LocalSEOLocalSeoLocations = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="local-seolocal-seo-locations"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mb-14 md:mb-20"
        >
          <span className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium">
            Geographic Reach
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground max-w-2xl leading-tight mb-5">
            Local SEO Across the UK
          </h2>
          <p className="text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
            I work with businesses across the North West and beyond. While I am
            based in Warrington, Cheshire, my local SEO practice extends
            throughout the UK — helping businesses rank where their customers
            are searching, regardless of geography.
          </p>
        </motion.div>

        {/* Location tiles — 3 exact */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8 mb-14">
          {locations.map((loc, i) => (
            <motion.div
              key={loc.city}
              custom={i}
              initial="hidden"
              whileInView="visible"
              viewport={{ once: true, margin: "-50px" }}
              variants={fadeUp}
              className={`group relative rounded-md border p-7 md:p-8 flex flex-col gap-5 transition-all duration-300 hover:-translate-y-1 ${
                loc.highlight
                  ? "border-primary/50 bg-primary/[0.04]"
                  : "border-border bg-card hover:border-primary/30"
              }`}
              style={{ boxShadow: "0 2px 12px 0 hsl(225 28% 14% / 0.07)" }}
            >
              {/* City + region */}
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <MapPin className="h-4 w-4 text-primary shrink-0" />
                    <span className="text-xs uppercase tracking-[0.15em] text-muted-foreground font-medium">
                      {loc.region}
                    </span>
                  </div>
                  <h3 className="text-xl md:text-2xl font-bold text-foreground">
                    {loc.city}
                  </h3>
                </div>
                {loc.highlight && (
                  <span className="shrink-0 text-[10px] uppercase tracking-widest bg-primary/10 text-primary border border-primary/20 rounded px-2 py-1 font-semibold">
                    Base
                  </span>
                )}
              </div>

              {/* Keyword tag */}
              <p className="text-xs font-mono text-muted-foreground border border-border rounded px-2.5 py-1.5 bg-muted/50 w-fit">
                {loc.keyword}
              </p>

              {/* Description */}
              <p className="text-sm text-muted-foreground leading-relaxed flex-1">
                {loc.description}
              </p>

              {/* Link */}
              <Link
                to={loc.href}
                className="inline-flex items-center gap-1.5 text-sm text-foreground font-medium hover:text-primary transition-colors duration-200 group-hover:gap-2.5"
                aria-label={`View local SEO details for ${loc.city}`}
              >
                View location details
                <ArrowRight className="h-4 w-4 transition-transform duration-200 group-hover:translate-x-0.5" />
              </Link>
            </motion.div>
          ))}
        </div>

        {/* National reach editorial note + locations hub link */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.55, ease: "easeOut", delay: 0.3 }}
          className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6 border-t border-border pt-10"
        >
          <div className="flex items-start gap-3 max-w-xl">
            <Globe className="h-5 w-5 text-primary shrink-0 mt-0.5" />
            <p className="text-sm text-muted-foreground leading-relaxed">
              I work with clients across the UK — including Birmingham, Leeds,
              Sheffield, and London. All local SEO engagements are delivered
              personally, with no account managers or subcontracted work.
            </p>
          </div>
          <Link
            to="/locations"
            className="inline-flex items-center gap-2 text-sm font-semibold text-foreground border border-border rounded-md px-5 py-3 hover:border-primary/50 hover:text-primary transition-all duration-200 shrink-0"
            aria-label="View all UK locations I serve"
          >
            All UK locations
            <ArrowRight className="h-4 w-4" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
});

LocalSEOLocalSeoLocations.displayName = "LocalSEOLocalSeoLocations";

export default LocalSEOLocalSeoLocations;
