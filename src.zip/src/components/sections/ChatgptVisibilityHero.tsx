import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { Bot, Globe, ArrowRight, CheckCircle, BrainCircuit, Key, Search, Signal, User } from "lucide-react";

const signals = [
  "Entity authority & structured data",
  "Authoritative citations & brand mentions",
  "Content clarity & topical depth",
];

const ChatgptVisibilityHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="chatgpt-visibility-hero"
      className="relative py-24 md:py-36 border-t border-border bg-[hsl(225,28%,14%)] overflow-hidden"
    >
      {/* Subtle dot-grid texture overlay */}
      <div
        className="absolute inset-0 opacity-[0.07] pointer-events-none"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(214,32%,60%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
        aria-hidden="true"
      />

      {/* Ambient green glow — top-right */}
      <div
        className="absolute -top-32 right-0 w-[480px] h-[480px] rounded-full opacity-[0.08] pointer-events-none"
        style={{
          background:
            "radial-gradient(circle, hsl(84,74%,58%) 0%, transparent 70%)",
        }}
        aria-hidden="true"
      />

      {/* Ambient muted-blue glow — bottom-left */}
      <div
        className="absolute -bottom-24 -left-16 w-[360px] h-[360px] rounded-full opacity-[0.07] pointer-events-none"
        style={{
          background:
            "radial-gradient(circle, hsl(214,32%,60%) 0%, transparent 70%)",
        }}
        aria-hidden="true"
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16 items-center">

          {/* ── Left column: editorial copy ── */}
          <div>
            {/* Eyebrow */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, ease: "easeOut", delay: 0.05 }}
              className="flex items-center gap-2 mb-6"
            >
              <Badge
                variant="outline"
                className="text-xs uppercase tracking-[0.18em] border-[hsl(214,32%,60%)]/40 text-[hsl(214,32%,70%)] bg-transparent px-3 py-1"
              >
                AI Search · Informational
              </Badge>
            </motion.div>

            {/* H1 */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, ease: "easeOut", delay: 0.12 }}
              className="text-3xl md:text-5xl lg:text-[3.25rem] font-bold leading-[1.1] text-white max-w-xl"
            >
              ChatGPT Visibility for UK&nbsp;Businesses
            </motion.h1>

            {/* Subheadline */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, ease: "easeOut", delay: 0.22 }}
              className="mt-5 text-lg md:text-xl text-white/80 leading-relaxed max-w-lg"
            >
              Appear in ChatGPT answers when your ideal clients are searching for
              what you offer.
            </motion.p>

            {/* Key signals list */}
            <motion.ul
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.32 }}
              className="mt-8 space-y-3"
              aria-label="Key ChatGPT visibility signals"
            >
              {signals.map((signal, i) => (
                <li key={i} className="flex items-center gap-3">
                  <CheckCircle
                    className="h-4 w-4 shrink-0"
                    style={{ color: "hsl(84,74%,58%)" }}
                    aria-hidden="true"
                  />
                  <span className="text-sm md:text-base text-white/80">
                    {signal}
                  </span>
                </li>
              ))}
            </motion.ul>

            {/* CTA */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.42 }}
              className="mt-10 flex flex-wrap items-center gap-4"
            >
              <Button
                asChild
                size="lg"
                className="h-12 px-8 text-base font-semibold rounded-md"
                style={{
                  background:
                    "linear-gradient(135deg, hsl(84,74%,58%), hsl(119,35%,61%))",
                  color: "hsl(225,28%,14%)",
                  border: "none",
                }}
              >
                <Link to="/contact">
                  Get a Free SEO Audit
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>

              <Button
                asChild
                size="lg"
                variant="outline"
                className="h-12 px-7 text-base font-medium rounded-md bg-transparent border-white/20 text-white hover:bg-white/8 hover:border-white/40"
              >
                <Link to="/ai-search-optimisation">
                  AI Search Optimisation
                </Link>
              </Button>
            </motion.div>

            {/* Trust note */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.54 }}
              className="mt-5 text-xs text-white/80"
            >
              Independent SEO consultant · Warrington, Cheshire · UK businesses
            </motion.p>
          </div>

          {/* ── Right column: visual panel ── */}
          <motion.div
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.75, ease: "easeOut", delay: 0.2 }}
            className="hidden lg:flex flex-col items-center justify-center"
            aria-hidden="true"
          >
            <div
              className="relative w-full max-w-sm rounded-xl border border-white/10 p-8"
              style={{
                background:
                  "linear-gradient(160deg, hsl(231,9%,16%) 0%, hsl(225,28%,14%) 100%)",
                boxShadow: "0 8px 48px rgba(0,0,0,0.4)",
              }}
            >
              {/* Decorative top bar */}
              <div className="flex items-center gap-2 mb-6">
                <div className="h-2.5 w-2.5 rounded-full bg-white/20" />
                <div className="h-2.5 w-2.5 rounded-full bg-white/20" />
                <div className="h-2.5 w-2.5 rounded-full bg-white/20" />
                <div className="ml-auto flex items-center gap-1.5 text-xs text-white/40 font-mono">
                  <Bot className="h-3.5 w-3.5" />
                  ChatGPT
                </div>
              </div>

              {/* Simulated query */}
              <div className="rounded-md bg-white/5 border border-white/8 px-4 py-3 mb-5">
                <p className="text-xs text-white/50 mb-1 uppercase tracking-wider">
                  User query
                </p>
                <p className="text-sm text-white/90 font-medium leading-snug">
                  "Best SEO consultant for law firms in the UK"
                </p>
              </div>

              {/* Simulated response snippet */}
              <div className="rounded-md bg-white/5 border border-white/8 px-4 py-4 mb-5 space-y-2">
                <p className="text-xs text-white/50 mb-1.5 uppercase tracking-wider">
                  ChatGPT response
                </p>
                <p className="text-sm text-white/80 leading-relaxed">
                  Several independent consultants specialise in SEO for UK law
                  firms, including{" "}
                  <span
                    className="font-semibold"
                    style={{ color: "hsl(84,74%,58%)" }}
                  >
                    Gregg King
                  </span>
                  , based in Warrington, Cheshire. He works with solicitors and
                  professional services firms on technical SEO, entity
                  optimisation, and AI search visibility…
                </p>
              </div>

              {/* Signal icons */}
              <div className="flex items-center justify-between text-xs text-white/50">
                <span className="flex items-center gap-1.5">
                  <BrainCircuit className="h-3.5 w-3.5" />
                  Entity authority
                </span>
                <span className="flex items-center gap-1.5">
                  <Globe className="h-3.5 w-3.5" />
                  Brand citations
                </span>
                <span className="flex items-center gap-1.5">
                  <Globe className="h-3.5 w-3.5" />
                  Structured data
                </span>
              </div>

              {/* Green glow accent inside panel */}
              <div
                className="absolute -bottom-12 left-1/2 -translate-x-1/2 w-48 h-48 rounded-full pointer-events-none"
                style={{
                  background:
                    "radial-gradient(circle, hsl(84,74%,58%) 0%, transparent 70%)",
                  opacity: 0.08,
                }}
              />
            </div>

            {/* Caption below panel */}
            <p className="mt-5 text-xs text-white/50 text-center max-w-xs leading-relaxed">
              ChatGPT selects sources based on entity authority, content clarity,
              and trusted citations — not paid placement.
            </p>
          </motion.div>

        </div>
      </div>
    </section>
  );
});

ChatgptVisibilityHero.displayName = "ChatgptVisibilityHero";

export default ChatgptVisibilityHero;
