import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";

const faqs = [
  {
    question: "What does YMYL mean for financial services SEO?",
    answer:
      "YMYL stands for 'Your Money or Your Life' — a classification Google uses for content types that could significantly impact a person's financial wellbeing, health or safety. Financial services content falls squarely into this category. Google applies stricter quality evaluation to YMYL pages, which means financial firms must demonstrate genuine E-E-A-T (Experience, Expertise, Authoritativeness and Trustworthiness) signals throughout their website and content to rank competitively. This includes author credentials, cited sources, regulated status declarations and authoritative backlinks.",
  },
  {
    question: "How does E-E-A-T work for financial services websites?",
    answer:
      "E-E-A-T is Google's quality framework: Experience, Expertise, Authoritativeness and Trustworthiness. For financial services, this means publishing content authored by qualified financial professionals, earning mentions and backlinks from respected financial publications, maintaining accurate and up-to-date regulatory information, and demonstrating real-world experience through case studies and client outcomes. We build E-E-A-T systematically through entity optimisation, credentialed authorship programmes and a targeted digital PR strategy.",
  },
  {
    question: "Can you create content that passes FCA compliance review?",
    answer:
      "Yes. Our content strategy for financial services firms is built with regulatory compliance as a foundation, not an afterthought. We create detailed content briefs that map FCA Conduct of Business Sourcebook requirements and Consumer Duty obligations into the content structure before a word is written. This significantly reduces revision cycles with your compliance team. We regularly achieve first-pass approval rates above 90% for content produced under our financial services programme.",
  },
  {
    question: "How long does financial services SEO take to show results?",
    answer:
      "For competitive financial keywords, meaningful ranking movement typically begins within four to six months, with significant organic traffic gains from six to twelve months. However, the timeline depends on your starting domain authority, competitive landscape and the scope of the programme. Entity SEO and schema markup improvements can yield quicker wins — particularly in AI-generated search features and rich results — while topical authority building is a longer-term compounding strategy.",
  },
  {
    question: "Do you work with regulated financial services firms?",
    answer:
      "Yes — we specialise in regulated financial services environments. Our clients include FCA-authorised wealth managers, financial planning firms, mortgage brokers, insurance intermediaries and fintech companies. We understand the difference between financial promotions, educational content and general information, and we structure content strategies accordingly to avoid regulatory risk while maximising search performance.",
  },
  {
    question: "What is entity SEO and why does it matter for financial firms?",
    answer:
      "Entity SEO is the practice of building a clearly structured, inter-connected presence in Google's knowledge graph — so that Google understands exactly who you are, what services you offer, which markets you serve, and why you're authoritative. For financial services firms, this means your brand, advisers, products and content all exist as related entities that Google can connect and verify. The result is improved rankings, featured appearances in AI-generated answers, and greater brand visibility in knowledge panels and structured search features.",
  },
];

const FinancialServicesFAQ = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="financial-faq"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="max-w-2xl mx-auto text-center mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            Common Questions
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Financial Services SEO — Frequently Asked Questions
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            Answers to the questions we hear most often from financial services marketing teams and
            compliance officers exploring specialist SEO support.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full space-y-3">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="bg-card border border-border rounded-xl px-6 shadow-soft"
              >
                <AccordionTrigger className="text-left font-semibold text-foreground py-5 hover:no-underline">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed pb-5">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>
      </div>
    </section>
  );
});

FinancialServicesFAQ.displayName = "FinancialServicesFAQ";

export default FinancialServicesFAQ;
