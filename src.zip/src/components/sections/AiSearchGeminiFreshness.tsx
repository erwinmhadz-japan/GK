import React from "react";
import { RefreshCw, Award, TrendingUp, Star, Phone, Signal } from "lucide-react";

const signals = [
  {
    icon: RefreshCw,
    title: "Content Freshness Signals",
    items: [
      "Last-modified date in HTTP headers and sitemap",
      "Regular updates to core pages (not just new posts)",
      "Timestamped revisions visible in the page content",
      "Crawl frequency — fast-loading pages get re-indexed sooner",
      "News/blog content with current statistics and examples",
    ],
  },
  {
    icon: Award,
    title: "Authority Signals Gemini Evaluates",
    items: [
      "Domain authority reflected in quality backlink profile",
      "Author credentials and expertise demonstrated on-page",
      "Brand mentions and citations across the wider web",
      "Google Knowledge Graph entity recognition",
      "Consistent NAP (Name, Address, Phone) for local entities",
    ],
  },
  {
    icon: TrendingUp,
    title: "Topical Depth & Coverage",
    items: [
      "Comprehensive content covering a topic from multiple angles",
      "Internal linking creating subject-matter clusters",
      "Supporting content (guides, FAQs, case studies) on the same theme",
      "Regular content audits to identify and fill gaps",
      "Schema markup reinforcing topic and entity relationships",
    ],
  },
];

const caseInsight = {
  context:
    "A UK financial advisory firm creating detailed, author-attributed guides on pension topics saw Gemini begin citing their content within 3 months of implementing structured data and refreshing outdated statistics. Their brand appeared in Gemini answers for 'best pension advice UK' queries — despite not ranking in the top 3 organic results — because Gemini weighted their demonstrated expertise and content depth.",
  takeaway:
    "Gemini citation is not a direct function of search ranking position. Authority signals and content quality matter independently of position.",
};

const AiSearchGeminiFreshness = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="gemini-freshness-authority"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
      aria-labelledby="gemini-freshness-heading"
    >
      <div className="container">
        {/* Header */}
        <div className="max-w-2xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            Freshness & Authority
          </span>
          <h2
            id="gemini-freshness-heading"
            className="text-3xl md:text-5xl font-bold text-foreground mb-5"
          >
            Content Freshness and Authority Signals for Gemini
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Two distinct factors determine whether Gemini trusts your content enough
            to cite it: how fresh it is, and how authoritative the source appears.
            Both need ongoing attention — not a one-time fix.
          </p>
        </div>

        {/* Signal columns */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-14">
          {signals.map((sig) => {
            const Icon = sig.icon;
            return (
              <div
                key={sig.title}
                className="bg-card border border-border rounded-xl p-6 shadow-soft"
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-4">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="text-base font-semibold text-foreground mb-4">
                  {sig.title}
                </h3>
                <ul className="space-y-2.5">
                  {sig.items.map((item) => (
                    <li key={item} className="flex items-start gap-2.5">
                      <Star className="h-3.5 w-3.5 text-primary mt-0.5 shrink-0" />
                      <span className="text-sm text-muted-foreground leading-snug">
                        {item}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            );
          })}
        </div>

        {/* Case insight */}
        <div className="bg-background border border-primary/20 rounded-xl p-8">
          <div className="flex items-start gap-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-primary/10 shrink-0 mt-0.5">
              <TrendingUp className="h-5 w-5 text-primary" />
            </div>
            <div>
              <h3 className="text-base font-semibold text-foreground mb-3">
                Case Insight: Financial Advisory Firm
              </h3>
              <p className="text-sm text-muted-foreground leading-relaxed mb-4">
                {caseInsight.context}
              </p>
              <div className="border-l-2 border-primary pl-4">
                <p className="text-sm font-medium text-foreground italic">
                  "{caseInsight.takeaway}"
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Relationship to AI Overviews */}
        <div className="mt-10 p-6 bg-card border border-border rounded-xl flex flex-col sm:flex-row items-start sm:items-center gap-4">
          <div className="flex-1">
            <p className="text-sm font-semibold text-foreground mb-1">
              Gemini and Google AI Overviews: Closely Related
            </p>
            <p className="text-sm text-muted-foreground">
              The signals that help you appear in Gemini answers largely overlap
              with those that get you into Google AI Overviews. Optimising for one
              effectively optimises for both — a major efficiency gain.
            </p>
          </div>
          <a
            href="/google-ai-overviews"
            className="inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline shrink-0"
          >
            Google AI Overviews guide →
          </a>
        </div>
      </div>
    </section>
  );
});

AiSearchGeminiFreshness.displayName = "AiSearchGeminiFreshness";

export default AiSearchGeminiFreshness;
