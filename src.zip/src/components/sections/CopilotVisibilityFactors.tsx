import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Search, FileText, Fingerprint, Link2, Layers, ChevronRight, Section } from "lucide-react";

interface Factor {
  icon: React.ComponentType<{ className?: string }>;
  title: string;
  body: string;
  signals: string[];
}

const factors: Factor[] = [
  {
    icon: Search,
    title: "Bing Indexation and Crawlability",
    body: "Microsoft Copilot draws on Bing's index as its primary data source. If Bing cannot crawl or index your pages effectively, your content is unlikely to surface in Copilot responses — regardless of your Google ranking. Technical foundations matter here: clean crawl paths, fast load times, and a well-structured sitemap all support Bing's ability to process your content.",
    signals: [
      "Bing Webmaster Tools verification and sitemap submission",
      "Crawlable page structure with no redirect chains or blocked resources",
      "Canonical tags and duplicate content management",
      "Consistent URL structure aligned with Bing crawl behaviour",
    ],
  },
  {
    icon: FileText,
    title: "Structured Data and Schema Markup",
    body: "Schema markup communicates machine-readable context about your content, your organisation, and your expertise directly to Bing's crawlers. Well-implemented schema helps Copilot correctly categorise your brand, understand your services, and surface accurate information in AI-generated responses.",
    signals: [
      "Organisation schema with logo, contact, and social profile references",
      "Article and BlogPosting schema on editorial content",
      "FAQPage schema for common service or sector questions",
      "LocalBusiness schema for location-specific pages",
    ],
  },
  {
    icon: Fingerprint,
    title: "Entity Clarity and Knowledge Graph Alignment",
    body: "Copilot synthesises information based on what it understands about entities — organisations, people, and concepts. The clearer and more consistent your brand entity is across the web, the more reliably Copilot can represent it. This means aligning name, location, description, and expertise signals across your website and third-party sources.",
    signals: [
      "Consistent NAP (name, address, phone) across all platforms",
      "Accurate and detailed Google Business Profile and Bing Places listing",
      "Author entity markup linking content to a named individual or organisation",
      "References on authoritative third-party sites that confirm your expertise",
    ],
  },
  {
    icon: Link2,
    title: "Authoritative Backlinks and Digital PR",
    body: "Copilot is more likely to cite and surface content that is referenced and endorsed by credible sources. Authoritative backlinks — particularly from established trade publications, professional bodies, and reputable news outlets — signal to Bing that your content is trustworthy and worth drawing on in AI-generated answers.",
    signals: [
      "Earned coverage in sector-relevant or regional publications",
      "Links from professional associations, directories, or regulatory bodies",
      "Cited as a source or expert contributor by third-party content",
      "Digital PR campaigns that generate attributable mentions and links",
    ],
  },
  {
    icon: Layers,
    title: "Content Structure and Cited Source Formats",
    body: "AI systems, including Copilot, prefer content that is clearly structured, factually grounded, and directly answerable. Pages that follow editorial best practice — with descriptive headings, well-scoped paragraphs, and factual specificity — are better candidates for citation in AI responses than dense or ambiguous prose.",
    signals: [
      "Clear H1 and H2 hierarchy reflecting distinct topics",
      "Concise, direct answers to likely user queries within the page body",
      "Factual claims supported by data, named sources, or expert attribution",
      "Avoid keyword-stuffed or thin content that lacks informational depth",
    ],
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 24 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const CopilotVisibilityFactors = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="copilot-visibility-factors"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="max-w-2xl mb-14 md:mb-20"
        >
          <span className="inline-block text-xs uppercase tracking-[0.18em] text-muted-foreground mb-4 font-medium">
            Visibility Signals
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground leading-snug mb-4">
            What Influences Your Appearance in Copilot Responses
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
            Microsoft Copilot uses a distinct set of signals to determine which sources it draws on. Understanding those signals is the starting point for improving how your business is represented.
          </p>
        </motion.div>

        {/* Factors list */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          className="space-y-8"
        >
          {factors.map((factor, index) => {
            const Icon = factor.icon;
            return (
              <motion.div
                key={factor.title}
                variants={itemVariants}
                className="group rounded-md border border-border bg-background p-6 md:p-8 transition-shadow duration-300 hover:shadow-[0_4px_24px_-6px_hsl(222_28%_11%_/_0.10),_0_1px_4px_hsl(222_28%_11%_/_0.05)]"
              >
                <div className="flex flex-col md:flex-row md:gap-8">
                  {/* Icon + title column */}
                  <div className="flex items-start gap-4 md:w-64 md:flex-shrink-0 mb-4 md:mb-0">
                    <div className="flex h-10 w-10 flex-shrink-0 items-center justify-center rounded-md bg-primary/10 mt-0.5">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <span className="inline-block text-[11px] uppercase tracking-[0.14em] text-muted-foreground mb-1 font-medium">
                        Factor {String(index + 1).padStart(2, "0")}
                      </span>
                      <h3 className="text-base md:text-lg font-semibold text-foreground leading-snug">
                        {factor.title}
                      </h3>
                    </div>
                  </div>

                  {/* Body + signals column */}
                  <div className="flex-1">
                    <p className="text-sm md:text-base text-muted-foreground leading-relaxed mb-5">
                      {factor.body}
                    </p>
                    <ul className="space-y-2">
                      {factor.signals.map((signal) => (
                        <li
                          key={signal}
                          className="flex items-start gap-3 text-sm text-foreground"
                        >
                          <span
                            className="mt-1.5 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-primary"
                            aria-hidden="true"
                          />
                          {signal}
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Contextual note */}
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.55, ease: "easeOut", delay: 0.2 }}
          className="mt-12 text-sm text-muted-foreground max-w-2xl leading-relaxed"
        >
          These signals are not new concepts — they are established SEO and content best practices applied specifically to how Bing's index feeds Copilot. Addressing them systematically is the most reliable route to improving AI search visibility across the Microsoft ecosystem.
        </motion.p>

        {/* Related services & sibling page links */}
        <motion.div
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.55, ease: "easeOut", delay: 0.3 }}
          className="mt-10 pt-8 border-t border-border"
        >
          <div className="flex flex-col sm:flex-row sm:items-start gap-8">
            <div className="flex-1">
              <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground mb-3 font-medium">
                Related Services
              </p>
              <div className="flex flex-wrap gap-3">
                {[
                  { label: "AI Search Optimisation", to: "/ai-search-optimisation" },
                  { label: "Technical SEO", to: "/technical-seo" },
                  { label: "Schema Markup", to: "/schema-markup" },
                  { label: "Entity SEO", to: "/entity-seo" },
                ].map((link) => (
                  <Link
                    key={link.to}
                    to={link.to}
                    className="inline-flex items-center gap-1.5 text-xs font-medium text-muted-foreground border border-border rounded-md px-3 py-1.5 hover:bg-background hover:text-foreground transition-colors duration-150"
                  >
                    <ChevronRight className="h-3 w-3 flex-shrink-0" aria-hidden="true" />
                    {link.label}
                  </Link>
                ))}
              </div>
            </div>
            <div className="flex-1">
              <p className="text-xs uppercase tracking-[0.18em] text-muted-foreground mb-3 font-medium">
                Other AI Search Platforms
              </p>
              <div className="flex flex-wrap gap-3">
                {[
                  { label: "ChatGPT Visibility", to: "/chatgpt-visibility" },
                  { label: "Google AI Overviews", to: "/google-ai-overviews" },
                  { label: "Gemini Visibility", to: "/gemini-visibility" },
                  { label: "Perplexity Visibility", to: "/perplexity-visibility" },
                ].map((link) => (
                  <Link
                    key={link.to}
                    to={link.to}
                    className="inline-flex items-center gap-1.5 text-xs font-medium text-muted-foreground border border-border rounded-md px-3 py-1.5 hover:bg-background hover:text-foreground transition-colors duration-150"
                  >
                    <ChevronRight className="h-3 w-3 flex-shrink-0" aria-hidden="true" />
                    {link.label}
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
});

CopilotVisibilityFactors.displayName = "CopilotVisibilityFactors";

export default CopilotVisibilityFactors;
