import React from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { ArrowRight, MapPin, Search, LineChart, BadgeCheck, Globe, Lightbulb, Building, Icon } from "lucide-react";

const solutions = [
  {
    icon: MapPin,
    title: "Google Business Profile Optimisation",
    body: "A fully optimised GBP listing is the cornerstone of Warrington local SEO. We audit, enhance, and actively manage your profile — categories, attributes, posts, Q&A, and photo updates — to maximise local pack visibility.",
    link: "#",
  },
  {
    icon: Search,
    title: "Warrington-Focused Keyword Strategy",
    body: "We identify the exact search terms Warrington residents and nearby Cheshire customers use — from 'SEO agency Warrington' to 'accountant near Birchwood'. Every page is mapped to intent-matched, geo-specific keywords.",
    link: "#",
  },
  {
    icon: LineChart,
    title: "Technical SEO & Core Web Vitals",
    body: "Site speed, mobile responsiveness, crawlability, and structured data — we fix the technical foundations that allow Google to properly index and rank your Warrington business pages.",
    link: "#",
  },
  {
    icon: BadgeCheck,
    title: "Citation Building & NAP Consistency",
    body: "We audit and correct your citations across every major UK directory, ensure consistent NAP across Warrington local business listings, and build new citations on authoritative platforms that matter to Google.",
    link: "#",
  },
  {
    icon: Globe,
    title: "Location-Specific Content Creation",
    body: "From dedicated Warrington service pages to blog content targeting North West audiences, we create SEO-optimised content that signals geographic relevance to search engines and builds trust with local customers.",
    link: "#",
  },
  {
    icon: Lightbulb,
    title: "Review Strategy & Reputation Management",
    body: "Systematic review acquisition campaigns that earn genuine 5-star reviews from your Warrington customers — improving both local pack rankings and the first impression you make on new prospects.",
    link: "/contact",
  },
];

const WarringtonSolutions = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative isolate py-24 md:py-36"
    >
      {/* image_brand_tint background */}
      <img
        src="https://images.unsplash.com/photo-1633537065982-712792c23798?w=1920&h=1080&fit=crop"
        alt="Modern North West commercial buildings representing the Warrington business district"
        className="absolute inset-0 w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-br from-primary/80 via-primary/55 to-accent/60 pointer-events-none" />

      <div className="container relative z-10">
        {/* Content band */}
        <div className="max-w-2xl mb-12">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4">
            North West SEO Solutions
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">
            Local SEO Services Built for Warrington
          </h2>
          <p className="text-lg text-white/90 leading-relaxed">
            Every element of your local SEO strategy is tailored to
            Warrington's market — not copy-pasted from a generic template.
            Here's how we deliver measurable, lasting results for North West
            businesses.
          </p>
        </div>

        {/* Solutions grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {solutions.map(({ icon: Icon, title, body, link }) => (
            <a
              key={title}
              href={link}
              className="group block rounded-xl border border-white/20 bg-white/10 backdrop-blur-sm p-6 hover:bg-white/20 transition-all duration-200 hover-lift"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-white/20 mb-4">
                <Icon className="h-5 w-5 text-white" />
              </div>
              <h3 className="text-base font-semibold text-white mb-2 group-hover:text-white">
                {title}
              </h3>
              <p className="text-sm text-white/85 leading-relaxed">{body}</p>
              <div className="mt-4 flex items-center gap-1 text-sm text-white/80 font-medium">
                Learn more <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-1 transition-transform" />
              </div>
            </a>
          ))}
        </div>

        {/* CTA row */}
        <div className="mt-14 flex flex-wrap gap-4 items-center">
          <Button
            size="lg"
            className="bg-white text-primary hover:bg-white/90 font-semibold"
            asChild
          >
            <a href="#">
              See Full Local SEO Service
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-transparent text-white border-white hover:bg-white/10"
            asChild
          >
            <a href="/services">Browse All Services</a>
          </Button>
        </div>
      </div>
    </section>
  );
});

WarringtonSolutions.displayName = "WarringtonSolutions";

export default WarringtonSolutions;
