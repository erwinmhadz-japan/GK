import React from "react";
import { Star, TrendingUp, MapPin, Building2, Icon } from "lucide-react";

const stats = [
  { value: "+214%", label: "Organic traffic in 9 months", icon: TrendingUp },
  { value: "#1", label: "Local pack ranking for 8 target areas", icon: MapPin },
  { value: "3×", label: "Increase in vendor instruction enquiries", icon: Building2 },
];

const IndustriesPropertyTestimonial = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative isolate py-24 md:py-36 border-t border-border"
    >
      {/* Layer 1 — background image */}
      <img
        src="https://images.unsplash.com/photo-1580894732444-8ecded7900cd?w=1920&h=1080&fit=crop"
        alt="Professional estate agency team meeting in a modern office"
        width="1920"
        height="1080"
        loading="lazy"
        className="absolute inset-0 w-full h-full object-cover"
      />
      {/* Layer 2 — brand tint overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/80 via-primary/55 to-accent/60 pointer-events-none" />

      {/* Layer 3 — content */}
      <div className="container relative z-10">
        <div className="max-w-3xl mx-auto text-center mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4">
            Client Case Study
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
            How Hartley & Reeves Doubled Their Instructions
          </h2>

          <div className="flex justify-center gap-1 mb-8">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="h-5 w-5 text-white fill-white" />
            ))}
          </div>

          <blockquote className="text-lg md:text-xl text-white/90 italic leading-relaxed mb-8">
            "We'd been spending a fortune on Rightmove premium listings and getting decent portal
            traffic, but our own website was invisible. Gregg completely overhauled our local SEO —
            new location pages, proper schema markup, and a quarterly market report strategy. Within
            nine months we were ranking first in the local pack for eight of our target postcodes.
            Our vendor enquiry form submissions more than tripled and we've since reduced our portal
            spend because we're generating instructions directly. It's transformed how we win business."
          </blockquote>

          <div className="text-center">
            <p className="font-semibold text-white">Sarah Hartley</p>
            <p className="text-white/80 text-sm">Managing Director, Hartley &amp; Reeves Estate Agents</p>
            <p className="text-white/80 text-sm">South East England</p>
          </div>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-3xl mx-auto">
          {stats.map(({ value, label, icon: Icon }) => (
            <div
              key={label}
              className="flex flex-col items-center text-center p-6 rounded-xl bg-white/10 backdrop-blur-sm border border-white/20"
            >
              <Icon className="h-6 w-6 text-white mb-3" />
              <p className="text-3xl font-bold text-white mb-1">{value}</p>
              <p className="text-white/80 text-sm">{label}</p>
            </div>
          ))}
        </div>

        <div className="text-center mt-10">
          <a
            href="#case-studies-cta"
            className="inline-flex items-center gap-2 text-white/90 hover:text-white font-medium text-sm underline underline-offset-4 transition-colors"
          >
            Read more property case studies
          </a>
        </div>
      </div>
    </section>
  );
});

IndustriesPropertyTestimonial.displayName = "IndustriesPropertyTestimonial";
export default IndustriesPropertyTestimonial;
