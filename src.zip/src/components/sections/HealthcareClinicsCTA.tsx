import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { ArrowRight, Phone, CheckCircle, Book, Search } from "lucide-react";

const benefits = [
  "Free 30-minute healthcare SEO strategy call",
  "Competitor gap analysis included",
  "No long-term contract required",
  "Specialist healthcare SEO, not generalist agencies",
];

const HealthcareClinicsCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="healthcare-cta"
      aria-label="Healthcare clinics SEO call to action"
      src="https://images.unsplash.com/photo-1758691463393-a2aa9900af8a?w=1920&h=1080&fit=crop"
      alt="Smiling doctor wearing glasses and stethoscope representing patient-focused healthcare SEO"
      imgProps={{ fetchpriority: "low", loading: "lazy" }}
      className="py-24 md:py-36 border-t border-border"
    >
      <div className="container relative z-10">
        <div className="max-w-2xl mx-auto text-center">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-5 font-semibold">
            Ready to Grow Your Practice?
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-5">
            More Patients Start Their Search Online. Be There When They Do.
          </h2>
          <p className="text-lg text-white/90 leading-relaxed mb-8">
            Whether you're an independent GP, a specialist clinic, or a multi-site private
            provider — a specialist healthcare SEO strategy will drive patient acquisition at
            a fraction of the cost of paid advertising.
          </p>

          {/* Benefits list */}
          <ul className="flex flex-col items-start gap-2.5 mb-10 max-w-sm mx-auto">
            {benefits.map((benefit) => (
              <li key={benefit} className="flex items-center gap-3 text-white/90 text-sm">
                <CheckCircle className="h-4 w-4 text-primary shrink-0" />
                {benefit}
              </li>
            ))}
          </ul>

          {/* CTA buttons */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold shadow-green-glow"
              asChild
            >
              <a href="/contact">
                Book Your Free Healthcare SEO Consultation
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10 font-semibold"
              asChild
            >
              <a href="/services-local-seo">
                <Phone className="mr-2 h-5 w-5" />
                Explore Local SEO
              </a>
            </Button>
          </div>

          <p className="mt-6 text-sm text-white/80">
            Responses within 24 hours · UK-based healthcare SEO specialist
          </p>
        </div>
      </div>
    </ImageBackground>
  );
});

HealthcareClinicsCTA.displayName = "HealthcareClinicsCTA";

export default HealthcareClinicsCTA;
