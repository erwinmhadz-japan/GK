import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { ArrowRight, HelpCircle, Code, Contact } from "lucide-react";

const faqs = [
  {
    question: "What makes healthcare SEO different from standard SEO?",
    answer:
      "Healthcare content falls under Google's 'Your Money or Your Life' (YMYL) classification, meaning it is held to a higher standard of expertise, authoritativeness, and trustworthiness (E-E-A-T) than other sectors. Tactics that work for e-commerce or hospitality can actually damage rankings for medical providers. We design healthcare SEO strategies that satisfy Google's quality rater guidelines, demonstrate clear clinical authorship, and align with regulatory requirements — delivering sustainable rankings rather than short-term gains.",
  },
  {
    question: "How long does healthcare SEO typically take to show results?",
    answer:
      "For most private clinics, meaningful improvements in local pack positions appear within 60–90 days of implementing Google Business Profile optimisation and citation work. Organic content rankings for competitive treatment and condition keywords typically take 4–9 months, depending on your current domain authority and the competitive landscape in your catchment area. We set realistic timelines upfront and provide transparent monthly reporting on all tracked metrics.",
  },
  {
    question: "Can you help with NHS and CQC compliance for healthcare content?",
    answer:
      "Yes — compliance is central to everything we produce. All content strategies are reviewed against ASA CAP Code guidelines for medical advertising, CQC care standards, and Google's YMYL quality criteria. We do not produce content that makes unsubstantiated medical claims, and we work closely with your clinical team to ensure all published material is accurate, evidence-based, and properly attributed to qualified practitioners.",
  },
  {
    question: "What is schema markup and why is it important for clinics?",
    answer:
      "Schema markup is structured data code added to your website that helps Google understand your business precisely. For healthcare providers, this means implementing MedicalOrganization, Physician, MedicalProcedure, and FAQPage schemas that can generate rich results — displaying your star rating, accepted insurance, opening hours, and key services directly in search results. This dramatically increases click-through rates and builds trust before a patient even visits your site.",
  },
  {
    question: "Do you work with both NHS and private healthcare providers?",
    answer:
      "We work with both. For NHS-funded providers, our focus is typically on increasing awareness and digital accessibility. For private clinics, the emphasis is on patient acquisition, appointment conversion, and competing against larger networks. The core SEO methodology — local search, schema, entity authority, and YMYL-compliant content — is consistent across both, but the commercial objectives and keyword strategies are tailored to your specific operating model.",
  },
  {
    question: "What internal links should I be aware of on this page?",
    answer:
      "This page references several core SEO services relevant to healthcare providers: Local SEO (/services/local-seo), Schema Markup (/services/schema-markup), Entity SEO which helps with Knowledge Panel establishment (/services/entity-seo), and Content Strategy for YMYL-compliant medical content (/services/content-strategy). You can also get in touch directly via the Contact page (/contact) to discuss your specific clinic's requirements.",

  },
];

const HealthcareClinicsFAQ = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="healthcare-faq"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-16">
          {/* Left — heading */}
          <div>
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4 font-semibold">
              Common Questions
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-5">
              Healthcare SEO Questions Answered
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed mb-8">
              Private clinic owners and practice managers often have the same questions
              before starting an SEO engagement. Here are the most common ones — with
              honest answers.
            </p>

            <Button size="lg" asChild className="font-semibold shadow-green-glow">
              <a href="/contact">
                Ask Your Specific Question
                <ArrowRight className="ml-2 h-5 w-5" />
              </a>
            </Button>

            {/* Quick links */}
            <div className="mt-10 p-5 rounded-xl border border-border bg-card">
              <p className="text-xs uppercase tracking-wider text-muted-foreground font-semibold mb-3">
                Related Services
              </p>
              <ul className="space-y-2">
                {[
                  { label: "Local SEO for Healthcare", href: "/services-local-seo" },
                  { label: "Healthcare Schema Markup", href: "/schema-markup" },
                  { label: "Entity SEO & Knowledge Panels", href: "/services-technical-seo" },
                  { label: "YMYL Content Strategy", href: "/content-strategy" },
                ].map((link) => (
                  <li key={link.href}>
                    <a
                      href={link.href}
                      className="flex items-center gap-2 text-sm text-primary hover:underline font-medium"
                    >
                      <ArrowRight className="h-3.5 w-3.5 shrink-0" />
                      {link.label}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* Right — accordion */}
          <div>
            <Accordion type="single" collapsible className="w-full space-y-2">
              {faqs.map((faq, index) => (
                <AccordionItem
                  key={index}
                  value={`item-${index}`}
                  className="bg-card border border-border rounded-xl px-5 py-1"
                >
                  <AccordionTrigger className="text-left font-semibold text-foreground text-sm leading-snug py-4 hover:no-underline">
                    <span className="flex items-start gap-3">
                      <HelpCircle className="h-4 w-4 shrink-0 text-primary mt-0.5" />
                      {faq.question}
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground text-sm leading-relaxed pb-4">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              ))}
            </Accordion>
          </div>
        </div>
      </div>
    </section>
  );
});

HealthcareClinicsFAQ.displayName = "HealthcareClinicsFAQ";

export default HealthcareClinicsFAQ;
