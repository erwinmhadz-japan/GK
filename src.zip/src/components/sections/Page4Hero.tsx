import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { BookOpen, ArrowRight } from "lucide-react";

const Page4Hero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      id="resources-hero"
      aria-label="Resources & Guides hero section"
      src="https://images.unsplash.com/photo-1571120245989-c2878f4c89b9?w=1920&h=1080&fit=crop"
      alt="Modern office space with windows — SEO resources and guides"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[75vh] md:min-h-[85vh] flex items-center"
    >
      <div className="container relative z-10 py-20 md:py-32">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
          className="flex items-center gap-2 mb-5"
        >
          <div className="flex h-8 w-8 items-center justify-center rounded-md bg-primary/20 border border-primary/30">
            <BookOpen className="h-4 w-4 text-primary" />
          </div>
          <span className="text-sm uppercase tracking-[0.2em] text-white/80 font-medium">
            Free SEO Resources
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.1 }}
          className="text-4xl md:text-6xl font-bold text-white max-w-3xl leading-tight"
        >
          SEO Guides, Tools &{" "}
          <span className="text-gradient-green">Expert Resources</span>
        </motion.h1>

        <motion.p
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="mt-6 text-lg md:text-xl text-white/90 max-w-2xl leading-relaxed"
        >
          Practical SEO knowledge distilled from 15+ years of hands-on consultancy.
          Frameworks, checklists, and insights you can apply to your business today.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="flex flex-wrap gap-4 mt-10"
        >
          <Button
            size="lg"
            className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold"
            asChild
          >
            <a href="#guides">
              Browse Guides
              <ArrowRight className="ml-2 h-4 w-4" />
            </a>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-transparent text-white border-white hover:bg-white/10 font-semibold"
            asChild
          >
            <a href="/contact">Work With Gregg</a>
          </Button>
        </motion.div>

        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.8, delay: 0.5 }}
          className="flex flex-wrap gap-6 mt-12"
        >
          {[
            { value: "50+", label: "Free Guides" },
            { value: "15+", label: "Years Experience" },
            { value: "200+", label: "Clients Helped" },
          ].map((stat) => (
            <div key={stat.label} className="flex flex-col">
              <span className="text-2xl font-bold text-white">{stat.value}</span>
              <span className="text-sm text-white/80">{stat.label}</span>
            </div>
          ))}
        </motion.div>
      </div>
    </ImageBackground>
  );
});

Page4Hero.displayName = "Page4Hero";

export default Page4Hero;
