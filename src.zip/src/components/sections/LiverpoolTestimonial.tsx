import React from "react";
import { Star, ArrowRight, Quote, Stars, View, Volume } from "lucide-react";
import { Button } from "@/components/ui/button";

const LiverpoolTestimonial = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="liverpool-testimonial"
      className="relative isolate py-24 md:py-36 border-t border-border"
      aria-label="Liverpool client testimonial"
    >
      {/* faded_photo treatment */}
      <img
        src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=1920&h=1080&fit=crop"
        alt="Team working on laptops in a collaborative office environment"
        className="absolute inset-0 w-full h-full object-cover opacity-20"
      />
      <div className="container relative z-10">
        <div className="max-w-4xl mx-auto">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-8 font-medium">
            Liverpool Case Study
          </span>

          {/* Stars */}
          <div className="flex gap-1 mb-6">
            {[1, 2, 3, 4, 5].map((i) => (
              <Star key={i} className="h-5 w-5 text-primary fill-primary" />
            ))}
          </div>

          {/* Quote */}
          <blockquote className="text-2xl md:text-4xl font-bold text-foreground leading-snug mb-8">
            "Within four months, our Liverpool law firm went from page three to the top three results for our core practice area keywords. The phone hasn't stopped ringing."
          </blockquote>

          {/* Result highlights */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mb-10">
            <div className="bg-background/80 backdrop-blur-sm rounded-xl p-5 border border-border shadow-card">
              <div className="text-3xl font-bold text-primary mb-1">+312%</div>
              <div className="text-sm font-medium text-foreground">Organic Traffic</div>
              <div className="text-xs text-muted-foreground mt-0.5">6-month increase</div>
            </div>
            <div className="bg-background/80 backdrop-blur-sm rounded-xl p-5 border border-border shadow-card">
              <div className="text-3xl font-bold text-primary mb-1">#1–3</div>
              <div className="text-sm font-medium text-foreground">Rankings</div>
              <div className="text-xs text-muted-foreground mt-0.5">For 14 target keywords</div>
            </div>
            <div className="bg-background/80 backdrop-blur-sm rounded-xl p-5 border border-border shadow-card">
              <div className="text-3xl font-bold text-primary mb-1">+58%</div>
              <div className="text-sm font-medium text-foreground">Enquiry Volume</div>
              <div className="text-xs text-muted-foreground mt-0.5">Year-on-year</div>
            </div>
          </div>

          {/* Attribution */}
          <div className="flex items-center gap-4 mb-10">
            <img
              src="https://images.unsplash.com/photo-1542909168-82c3e7fdca5c?w=400&h=400&fit=crop&crop=face"
              alt="Client headshot — Liverpool law firm director"
              width="64"
              height="64"
              className="rounded-full object-cover h-14 w-14 border-2 border-primary/30"
            />
            <div>
              <div className="font-semibold text-foreground">James Whitfield</div>
              <div className="text-sm text-muted-foreground">Managing Partner, Whitfield &amp; Co Solicitors — Liverpool L2</div>
            </div>
          </div>

          <Button size="lg" asChild className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold">
            <a href="#case-studies-cta">
              View More Case Studies
              <ArrowRight className="ml-2 h-5 w-5" />
            </a>
          </Button>
        </div>
      </div>
    </section>
  );
});

LiverpoolTestimonial.displayName = "LiverpoolTestimonial";

export default LiverpoolTestimonial;
