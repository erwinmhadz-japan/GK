import React from "react";
import { motion } from "framer-motion";
import { ScanSearch, FileText, PhoneCall, Section } from "lucide-react";

const steps = [
  {
    number: "01",
    icon: ScanSearch,
    title: "Initial Briefing & Discovery",
    description:
      "We begin with a structured briefing call — typically 30 to 45 minutes — in which I take time to understand your business, your competitive landscape, your site's history, and the specific challenges you're facing. This isn't a generic intake form; it's a focused conversation that shapes the entire audit and ensures I'm looking in the right places from the outset.",
    details: [
      "One-to-one call — no account managers or junior staff",
      "Review of current rankings, traffic trends, and known issues",
      "Discussion of competitors and sector context",
      "Identification of priority areas to investigate",
    ],
  },
  {
    number: "02",
    icon: FileText,
    title: "In-Depth Audit & Analysis",
    description:
      "I conduct the audit personally — not through an automated tool that fires a report at you. Every finding is assessed in context: a technical issue that matters for one site may be irrelevant for another. I analyse technical health, on-page signals, content structure, backlink profile, entity coverage, and AI search visibility, then translate what I find into clear, prioritised recommendations.",
    details: [
      "Full technical crawl and manual verification of critical issues",
      "On-page content and keyword signal review",
      "Backlink profile and authority assessment",
      "Entity and structured data evaluation",
    ],
  },
  {
    number: "03",
    icon: PhoneCall,
    title: "Delivery & Debrief Call",
    description:
      "You receive a structured written audit report — clearly organised, priority-ranked, and written in plain English. We then hold a debrief call to walk through the findings together, answer your questions, and agree on next steps. You leave with a complete picture of your site's SEO health and a practical roadmap to act on it.",
    details: [
      "Written report delivered prior to the debrief call",
      "Findings ranked by impact and urgency — not buried in data",
      "Debrief call to discuss priorities and clarify recommendations",
      "Optional follow-on retainer or project engagement discussed",
    ],
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.18,
    },
  },
};

const stepVariants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.65, ease: "easeOut" },
  },
};

const SEOAuditSeoAuditProcess = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seoaudit-seo-audit-process"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          className="max-w-2xl mb-14 md:mb-20"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.65, ease: "easeOut" }}
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            The Process
          </span>
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight mb-4">
            How the Audit Process Works
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed">
            Every audit is a personal, structured engagement — from the first briefing call through to delivery and debrief. You work directly with me throughout, not an automated system or a team of junior analysts.
          </p>
        </motion.div>

        {/* Steps */}
        <motion.div
          className="relative"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
        >
          {/* Vertical connector line — desktop */}
          <div
            className="hidden md:block absolute left-[2.6rem] top-10 bottom-10 w-px bg-border"
            aria-hidden="true"
          />

          <div className="flex flex-col gap-10 md:gap-14">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <motion.div
                  key={step.number}
                  variants={stepVariants}
                  className="relative flex flex-col md:flex-row gap-6 md:gap-10"
                >
                  {/* Step number + icon column */}
                  <div className="flex md:flex-col items-center gap-4 md:gap-0 shrink-0">
                    {/* Icon circle */}
                    <div className="relative z-10 flex items-center justify-center w-[5.2rem] h-[5.2rem] rounded-full bg-background border-2 border-border shadow-sm shrink-0">
                      {/* Step number badge */}
                      <span className="absolute -top-2 -right-2 flex items-center justify-center w-6 h-6 rounded-full bg-primary text-[10px] font-bold text-primary-foreground leading-none">
                        {index + 1}
                      </span>
                      <Icon className="h-6 w-6 text-foreground" />
                    </div>
                  </div>

                  {/* Content */}
                  <div className="flex-1 md:pt-4 pb-2">
                    {/* Overline number */}
                    <span className="block text-xs uppercase tracking-[0.18em] font-medium text-muted-foreground mb-2">
                      Step {step.number}
                    </span>

                    <h3 className="text-xl md:text-2xl font-semibold text-foreground mb-3 leading-snug">
                      {step.title}
                    </h3>

                    <p className="text-base text-muted-foreground leading-relaxed mb-5 max-w-prose">
                      {step.description}
                    </p>

                    {/* Detail points */}
                    <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2">
                      {step.details.map((detail, di) => (
                        <li key={di} className="flex items-start gap-2.5">
                          <span
                            className="mt-1.5 flex-shrink-0 w-1.5 h-1.5 rounded-full bg-primary"
                            aria-hidden="true"
                          />
                          <span className="text-sm text-muted-foreground leading-relaxed">
                            {detail}
                          </span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </motion.div>
              );
            })}
          </div>
        </motion.div>

        {/* Closing reassurance note */}
        <motion.p
          className="mt-14 md:mt-20 text-sm text-muted-foreground border-t border-border pt-8 max-w-2xl"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true, margin: "-40px" }}
          transition={{ duration: 0.7, ease: "easeOut", delay: 0.2 }}
        >
          The entire audit is conducted by me, Gregg King — an independent SEO consultant based in Warrington, Cheshire. Every recommendation is informed by context, not produced by a tool.
        </motion.p>
      </div>
    </section>
  );
});

SEOAuditSeoAuditProcess.displayName = "SEOAuditSeoAuditProcess";

export default SEOAuditSeoAuditProcess;
