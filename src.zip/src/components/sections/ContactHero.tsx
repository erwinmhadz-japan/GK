import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MessageSquare, Phone, User, Shield, Contact, Icon, Send } from "lucide-react";

const ContactHero = React.forwardRef<HTMLElement>((props, ref) => {
  const trustPills = [
    { icon: User, label: "Direct access — no account managers" },
    { icon: Shield, label: "Independent consultant, not an agency" },
    { icon: Phone, label: "01925 214707" },
  ];

  return (
    <section
      ref={ref}
      id="contact-hero"
      className="relative py-20 md:py-32 border-t border-border bg-muted overflow-hidden"
    >
      {/* Subtle dot-grid background texture */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.04]"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(225 28% 14%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
      />

      {/* Subtle top accent line */}
      <div
        aria-hidden="true"
        className="absolute top-0 left-0 w-24 h-1 bg-gradient-to-r from-[hsl(84_74%_58%)] to-[hsl(119_35%_61%)]"
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl">
          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="mb-6"
          >
            <Badge
              variant="outline"
              className="text-xs uppercase tracking-[0.15em] border-border text-muted-foreground px-3 py-1"
            >
              Contact
            </Badge>
          </motion.div>

          {/* H1 */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.08 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-foreground leading-[1.08] mb-6"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Get in Touch
          </motion.h1>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.16 }}
            className="text-lg md:text-xl text-muted-foreground leading-relaxed max-w-2xl mb-8"
          >
            Independent SEO consultancy for UK businesses. Speak directly with
            Gregg — no account managers, no handoffs.
          </motion.p>

          {/* Trust pills */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.24 }}
            className="flex flex-wrap gap-3 mb-10"
          >
            {trustPills.map(({ icon: Icon, label }) => (
              <div
                key={label}
                className="inline-flex items-center gap-2 rounded-md border border-border bg-background px-3 py-1.5 text-xs text-muted-foreground"
              >
                <Icon className="h-3.5 w-3.5 text-[hsl(119_35%_61%)] shrink-0" />
                <span>{label}</span>
              </div>
            ))}
          </motion.div>

          {/* CTA */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.32 }}
            className="flex flex-wrap gap-4 items-center"
          >
            <Button
              size="lg"
              className="h-12 px-8 text-base font-semibold text-[hsl(225_28%_14%)] bg-gradient-to-r from-[hsl(84_74%_58%)] to-[hsl(119_35%_61%)] hover:opacity-90 transition-opacity border-0 shadow-none"
              asChild
            >
              <a href="#contact-form">
                <MessageSquare className="h-4 w-4 mr-2" />
                Send an Enquiry
              </a>
            </Button>

            <a
              href="tel:01925214707"
              className="inline-flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors group"
            >
              <Phone className="h-4 w-4 text-[hsl(119_35%_61%)] group-hover:text-[hsl(84_74%_58%)] transition-colors" />
              <span className="underline-offset-4 hover:underline">
                01925 214707
              </span>
            </a>
          </motion.div>

          {/* FREE GBP AUDIT note */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.44 }}
            className="mt-6 text-xs text-muted-foreground"
          >
            Mention{" "}
            <span className="font-semibold text-foreground">
              FREE GBP AUDIT
            </span>{" "}
            when you get in touch to receive a complimentary Google Business
            Profile audit with your initial consultation.
          </motion.p>
        </div>
      </div>
    </section>
  );
});

ContactHero.displayName = "ContactHero";

export default ContactHero;
