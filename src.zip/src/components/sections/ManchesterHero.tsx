import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { MapPin, TrendingUp, Users, View } from "lucide-react";

const ManchesterHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      src="https://images.unsplash.com/photo-1573496130141-209d200cebd8?w=1920&h=1080&fit=crop"
      alt="two women in suits standing beside wall — Manchester business professionals"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center py-24 md:py-32"
    >
      <div className="container relative z-10">
        <div className="flex items-center gap-2 mb-6">
          <MapPin className="h-4 w-4 text-primary" />
          <span className="text-white/80 text-sm uppercase tracking-widest font-medium">
            Manchester, UK
          </span>
        </div>

        <Badge className="mb-6 bg-primary/20 text-primary border-primary/30 hover:bg-primary/30">
          Local SEO Specialists
        </Badge>

        <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 max-w-4xl">
          Manchester SEO Consultant — Grow Your Business in the North West
        </h1>

        <p className="text-xl md:text-2xl text-white/90 mb-8 max-w-2xl leading-relaxed">
          Expert SEO services for Manchester businesses. Dominate local search, outrank competitors, and capture Manchester's booming digital market.
        </p>

        <div className="flex flex-wrap gap-4 mb-10">
          <Button size="lg" className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold" asChild>
            <a href="/contact">Get a Free Consultation</a>
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="bg-transparent text-white border-white hover:bg-white/10"
            asChild
          >
            <a href="/services">View Services</a>
          </Button>
        </div>

        <div className="flex flex-wrap gap-6 mt-4">
          <div className="flex items-center gap-2 text-white/80">
            <TrendingUp className="h-5 w-5 text-primary" />
            <span className="text-sm">3.2M+ Population Market</span>
          </div>
          <div className="flex items-center gap-2 text-white/80">
            <Users className="h-5 w-5 text-primary" />
            <span className="text-sm">100+ Manchester Businesses Served</span>
          </div>
          <div className="flex items-center gap-2 text-white/80">
            <MapPin className="h-5 w-5 text-primary" />
            <span className="text-sm">Greater Manchester Coverage</span>
          </div>
        </div>
      </div>
    </ImageBackground>
  );
});

ManchesterHero.displayName = "ManchesterHero";

export default ManchesterHero;
