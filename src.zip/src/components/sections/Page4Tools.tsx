import React from "react";
import { motion } from "framer-motion";
import { Card, CardContent } from "@/components/ui/card";
import { Search, FileSearch, Globe, BarChart, Layers, Zap, ExternalLink, Link, Monitor } from "lucide-react";
import { Button } from "@/components/ui/button";

const tools = [
  {
    icon: Search,
    name: "Google Search Console",
    description:
      "Monitor your site's presence in Google Search results, identify crawl errors, and track keyword performance directly from Google.",
    category: "Analytics",
    href: "https://search.google.com/search-console",
  },
  {
    icon: FileSearch,
    name: "Screaming Frog SEO Spider",
    description:
      "Desktop crawler to audit technical SEO issues: broken links, redirect chains, duplicate content, missing meta data, and more.",
    category: "Technical Audit",
    href: "https://www.screamingfrog.co.uk/seo-spider/",
  },
  {
    icon: Globe,
    name: "Ahrefs",
    description:
      "Backlink analysis, keyword research, rank tracking, and competitor intelligence — one of the most comprehensive SEO data platforms available.",
    category: "Research",
    href: "https://ahrefs.com",
  },
  {
    icon: BarChart,
    name: "Google Analytics 4",
    description:
      "Understand how users find and interact with your website. Essential for measuring SEO ROI and identifying content opportunities.",
    category: "Analytics",
    href: "https://analytics.google.com",
  },
  {
    icon: Layers,
    name: "Schema Markup Validator",
    description:
      "Google's official tool to test and validate structured data (JSON-LD, Microdata) so your schema markup is correct before deployment.",
    category: "Structured Data",
    href: "https://validator.schema.org",
  },
  {
    icon: Zap,
    name: "PageSpeed Insights",
    description:
      "Measure Core Web Vitals and performance scores for mobile and desktop — key signals for ranking in both standard and AI-powered search.",
    category: "Performance",
    href: "https://pagespeed.web.dev",
  },
];

const categoryColour: Record<string, string> = {
  Analytics: "bg-blue-50 text-blue-700 border-blue-200",
  "Technical Audit": "bg-amber-50 text-amber-700 border-amber-200",
  Research: "bg-purple-50 text-purple-700 border-purple-200",
  "Structured Data": "bg-emerald-50 text-emerald-700 border-emerald-200",
  Performance: "bg-rose-50 text-rose-700 border-rose-200",
};

const containerVariants = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.08 } },
};

const itemVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.45 } },
};

const Page4Tools = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="tools"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        {/* Header */}
        <div className="text-center max-w-2xl mx-auto mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground font-medium mb-4">
            Recommended Toolset
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
            Tools Gregg Uses{" "}
            <span className="text-gradient-green">Every Day</span>
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            No affiliate links. No paid placements. Just the tools that consistently
            deliver results across client engagements — from startups to enterprise.
          </p>
        </div>

        {/* Tools grid */}
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
        >
          {tools.map((tool) => {
            const Icon = tool.icon;
            const catClass =
              categoryColour[tool.category] ??
              "bg-gray-50 text-gray-700 border-gray-200";

            return (
              <motion.div key={tool.name} variants={itemVariants} className="hover-lift">
                <Card className="h-full border border-border bg-card shadow-soft group">
                  <CardContent className="p-6 flex flex-col gap-4 h-full">
                    {/* Icon + category */}
                    <div className="flex items-start justify-between">
                      <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10">
                        <Icon className="h-5 w-5 text-primary" />
                      </div>
                      <span
                        className={`text-xs font-medium px-2 py-1 rounded-full border ${catClass}`}
                      >
                        {tool.category}
                      </span>
                    </div>

                    {/* Name */}
                    <h3 className="text-base font-semibold text-foreground leading-snug">
                      {tool.name}
                    </h3>

                    {/* Description */}
                    <p className="text-sm text-muted-foreground leading-relaxed flex-1">
                      {tool.description}
                    </p>

                    {/* Link */}
                    <a
                      href={tool.href}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 text-sm font-medium text-primary hover:text-primary/80 transition-colors mt-auto"
                    >
                      Visit tool
                      <ExternalLink className="h-3.5 w-3.5" />
                    </a>
                  </CardContent>
                </Card>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Bottom note */}
        <div className="mt-12 text-center">
          <p className="text-sm text-muted-foreground max-w-xl mx-auto">
            Need help interpreting data from these tools?{" "}
            <a href="/seo-audit" className="text-primary font-medium hover:underline">
              Commission a full SEO audit
            </a>{" "}
            and get expert analysis delivered within 5 working days.
          </p>
        </div>
      </div>
    </section>
  );
});

Page4Tools.displayName = "Page4Tools";

export default Page4Tools;
