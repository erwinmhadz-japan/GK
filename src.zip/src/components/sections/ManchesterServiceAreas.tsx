import React from "react";
import { MapPin, ChevronRight, Check, Map as MapIcon } from "lucide-react";

const areas = [
  { name: "Manchester City Centre", description: "Spinningfields, Northern Quarter, Piccadilly, Deansgate" },
  { name: "Salford", description: "MediaCityUK, Salford Quays, Eccles, Swinton" },
  { name: "Stockport", description: "Stockport town centre, Cheadle, Hazel Grove, Bramhall" },
  { name: "Bolton", description: "Bolton town centre, Horwich, Farnworth, Kearsley" },
  { name: "Oldham", description: "Oldham, Rochdale, Middleton, Chadderton" },
  { name: "Bury", description: "Bury town centre, Ramsbottom, Radcliffe, Prestwich" },
  { name: "Trafford", description: "Stretford, Sale, Altrincham, Urmston" },
  { name: "Tameside", description: "Ashton-under-Lyne, Stalybridge, Hyde, Denton" },
  { name: "Wigan", description: "Wigan, Leigh, Atherton, Hindley" },
  { name: "Rochdale", description: "Rochdale, Heywood, Littleborough, Milnrow" },
];

const ManchesterServiceAreas = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Coverage Map
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
            Manchester Service Areas &amp; Coverage
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            I provide SEO services across all ten boroughs of Greater Manchester — from the city centre to the surrounding towns and suburbs.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mb-12">
          {areas.map((area, index) => (
            <div
              key={index}
              className="bg-card border border-border rounded-xl p-5 hover-lift shadow-soft group"
            >
              <div className="flex items-start gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary/10 flex-shrink-0 mt-0.5">
                  <MapPin className="h-4 w-4 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground text-sm mb-1">{area.name}</h3>
                  <p className="text-xs text-muted-foreground leading-relaxed">{area.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="bg-card border border-border rounded-2xl p-8 md:p-10 flex flex-col md:flex-row items-center gap-6 justify-between shadow-card">
          <div>
            <h3 className="text-xl font-bold text-foreground mb-2">Not Sure If I Cover Your Area?</h3>
            <p className="text-muted-foreground text-sm max-w-xl">
              I work with businesses across all of Greater Manchester and the wider North West — including Cheshire, Lancashire, and the Merseyside borders.
              Get in touch and I'll confirm coverage for your specific location.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-3 flex-shrink-0">
            <a
              href="/contact"
              className="inline-flex items-center gap-2 bg-primary text-primary-foreground px-6 py-3 rounded-lg font-semibold hover:bg-primary/90 transition-colors text-sm whitespace-nowrap"
            >
              Check Your Area <ChevronRight className="h-4 w-4" />
            </a>
            <a
              href="/locations"
              className="inline-flex items-center gap-2 border border-border text-foreground px-6 py-3 rounded-lg font-medium hover:bg-muted transition-colors text-sm whitespace-nowrap"
            >
              All Locations
            </a>
          </div>
        </div>
      </div>
    </section>
  );
});

ManchesterServiceAreas.displayName = "ManchesterServiceAreas";

export default ManchesterServiceAreas;
