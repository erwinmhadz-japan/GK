import React from "react";
import { CheckCircle, TrendingUp, Shield, Target, Globe, Zap, Award, Layers, Search, Users } from "lucide-react";

const benefits = [
  {
    icon: TrendingUp,
    title: "Stay Ahead of the Curve",
    description:
      "AI Search is growing at an extraordinary pace. Businesses that establish AI visibility now will build durable competitive advantage before competitors recognise the opportunity.",
  },
  {
    icon: Globe,
    title: "Multi-Platform Presence",
    description:
      "Your customers use different AI tools. A cross-platform strategy ensures your business appears whether they're asking ChatGPT, searching Perplexity, or using Google AI Overviews.",
  },
  {
    icon: Shield,
    title: "Future-Proof Your SEO",
    description:
      "The signals that drive AI visibility — E-E-A-T, entity authority, structured data — also strengthen traditional SEO. You're not starting over; you're building on solid foundations.",
  },
  {
    icon: Target,
    title: "Higher-Intent Traffic",
    description:
      "Users of AI search tools are typically further along the decision-making journey. Being recommended by an AI assistant delivers highly qualified traffic with strong conversion intent.",
  },
  {
    icon: Award,
    title: "Brand Authority Signals",
    description:
      "AI models cite businesses with consistent, authoritative web presences. Optimising for AI Search reinforces your brand's trustworthiness and credibility across the whole web.",
  },
  {
    icon: Zap,
    title: "Citation & Mention Tracking",
    description:
      "Unlike traditional rankings, AI visibility requires monitoring citation frequency, brand mentions, and recommendation patterns — giving you a richer picture of true brand reach.",
  },
  {
    icon: Layers,
    title: "Content That Actually Gets Used",
    description:
      "AI models draw from well-structured, semantically rich content. The process of optimising for AI Search naturally improves content quality and topic depth site-wide.",
  },
  {
    icon: CheckCircle,
    title: "Independent, Platform-Agnostic Advice",
    description:
      "As an independent consultant with no agency agenda, I give unbiased recommendations tailored to where your specific audience is actually searching — not a generic template.",
  },
];

const AiSearchBenefits = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        <div className="max-w-3xl mx-auto text-center mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Why It Matters
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
            Why Invest in AI Search Optimisation?
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            More than one billion searches per day are now influenced by AI-generated answers.
            Here is what a structured AI Search strategy delivers for your business.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {benefits.map((benefit) => {
            const Icon = benefit.icon;
            return (
              <div
                key={benefit.title}
                className="group bg-card rounded-xl border border-border p-6 hover-lift transition-all duration-300"
              >
                <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-4">
                  <Icon className="h-5 w-5 text-primary" />
                </div>
                <h3 className="text-base font-bold text-foreground mb-2 leading-snug">
                  {benefit.title}
                </h3>
                <p className="text-sm text-muted-foreground leading-relaxed">
                  {benefit.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Supporting stat band */}
        <div className="mt-14 grid grid-cols-1 md:grid-cols-3 gap-6">
          {[
            { stat: "40%+", label: "of Gen Z start searches on AI tools, not Google" },
            { stat: "5x", label: "faster growth in AI search queries vs traditional search" },
            { stat: "1 in 3", label: "UK consumers now use AI assistants for purchase research" },
          ].map(({ stat, label }) => (
            <div
              key={stat}
              className="bg-gradient-hero-panel rounded-xl p-6 text-center"
            >
              <div className="text-3xl md:text-4xl font-bold text-gradient-green mb-2">
                {stat}
              </div>
              <p className="text-sm text-white/80 leading-relaxed">{label}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
});

AiSearchBenefits.displayName = "AiSearchBenefits";

export default AiSearchBenefits;
