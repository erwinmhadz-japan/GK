import React from "react";
import { motion } from "framer-motion";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { HelpCircle, Building, Section } from "lucide-react";

const faqs = [
  {
    question: "What is an entity in SEO?",
    answer:
      "In SEO, an entity is any clearly defined, real-world concept that Google can understand and categorise — a person, a business, a place, a product, or an idea. Rather than matching keywords, modern search engines build a map of entities and the relationships between them. Your business, your brand name, and even you as an individual are all entities. Entity SEO is the practice of ensuring Google understands exactly what each of those entities is, and how they relate to one another.",
  },
  {
    question: "How do I get a Google Knowledge Panel?",
    answer:
      "A Knowledge Panel is Google's summary card for a recognised entity. It typically appears for businesses, public figures, brands, and organisations once Google has gathered enough corroborating signals from across the web. To qualify, you need consistent NAP (name, address, phone) information across authoritative directories, structured data on your website, mentions and citations on third-party sites, and ideally a Wikidata or Wikipedia presence. There is no guaranteed path — it is about building sufficient, consistent evidence that Google recognises your entity. I help clients build and consolidate those signals as part of a structured entity SEO engagement.",
  },
  {
    question: "Is entity SEO the same as schema markup?",
    answer:
      "Schema markup is one tool within entity SEO, but the two are not the same thing. Schema markup (structured data) is code you add to your website to help search engines understand your content in a standardised way. Entity SEO is the broader strategy of building a clearly defined, well-corroborated identity across the web — your website, third-party directories, editorial mentions, social profiles, and knowledge bases. Schema markup strengthens the on-site signals; entity SEO encompasses all the off-site and structural signals too. Both matter, and both are part of how I approach this work.",
  },
  {
    question: "How long does entity SEO take to show results?",
    answer:
      "Entity SEO is a medium to long-term investment. Initial improvements — such as correcting inconsistencies and adding structured data — can have a relatively quick impact on how your brand appears in search. However, building genuine entity authority (Knowledge Panel acquisition, improved AI Overviews presence, richer entity associations) typically takes three to six months of consistent effort. The timeline depends on your starting position, the competitiveness of your sector, and how much groundwork has already been done. I set realistic expectations at the outset of every engagement.",
  },
  {
    question: "Does entity SEO help with AI search visibility?",
    answer:
      "Yes — this is one of the most important reasons to invest in entity SEO now. AI systems such as Google's Gemini, ChatGPT, and Perplexity draw on Knowledge Graph data, structured information, and well-corroborated entity signals when generating responses and citations. If your business is a well-defined, authoritative entity in Google's understanding, you are significantly more likely to be referenced, cited, or surfaced in AI-generated answers. Entity SEO and AI search optimisation are closely related, and I address both as part of a joined-up strategy.",
  },
  {
    question: "What is entity disambiguation and why does it matter?",
    answer:
      "Entity disambiguation is the process of helping search engines distinguish your entity from others with similar names or characteristics. For example, if your brand name is also a common word, or if there is another business with a similar name, Google may conflate them or fail to build a clear picture of either. Disambiguation work involves creating consistent, distinct identity signals — structured data, unique descriptors, authoritative mentions — that make it unambiguous who you are and what you do. It is particularly important for law firms, healthcare providers, and professional services businesses operating in competitive markets.",
  },
  {
    question: "Can entity SEO benefit local businesses?",
    answer:
      "Absolutely. For local businesses, entity SEO is closely tied to local search performance. Google's local results are entity-driven — the business entity needs to be well-defined, correctly categorised, and consistently referenced across the web for it to rank well. This means consistent NAP data, a properly structured Google Business Profile, schema markup for local businesses, and authoritative local citations. I work with UK businesses across locations including Warrington, Manchester, Liverpool, and beyond, helping them build the entity foundations that underpin strong local visibility.",
  },
  {
    question: "Do I need a Wikipedia page to benefit from entity SEO?",
    answer:
      "Not necessarily. Wikipedia and Wikidata are highly authoritative signals and can accelerate entity recognition, but they are not a prerequisite. Many businesses build strong entity authority without a Wikipedia presence by focusing on Wikidata entries, consistent structured data, editorial mentions in reputable publications, and well-maintained knowledge bases. That said, if a Wikipedia entry is attainable — typically for businesses or individuals with sufficient third-party coverage — it can make a meaningful difference to how quickly and confidently Google recognises the entity.",
  },
  {
    question: "How does entity SEO relate to brand authority?",
    answer:
      "Entity SEO and brand authority are deeply connected. When Google has a well-defined, richly corroborated understanding of your brand entity, it is more likely to rank your content, surface your business in AI-generated answers, and associate you with the topics your brand is known for. Building entity authority is, in effect, building brand authority in Google's eyes — not through marketing signals, but through structured, verifiable information. For UK businesses in competitive sectors such as law, finance, and healthcare, this is an increasingly important competitive differentiator.",
  },
  {
    question: "What should I expect from an entity SEO engagement with you?",
    answer:
      "I begin with a thorough entity audit — reviewing how your brand, business, and key individuals are currently understood by search engines, identifying gaps, inconsistencies, and missed opportunities. From there, I develop a structured plan covering schema implementation, off-site citation consolidation, Knowledge Graph targeting, and where relevant, Wikidata setup. Throughout the engagement, I work as your sole point of contact, providing clear, jargon-free reporting on progress. There are no junior staff or account managers — you work directly with me.",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.08,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 18 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: "easeOut" },
  },
};

const EntitySeoFAQ = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="entity-seo-faq"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mb-12 md:mb-16"
        >
          <div className="flex items-center gap-3 mb-4">
            <span className="inline-flex items-center justify-center h-8 w-8 rounded-md bg-primary/10">
              <HelpCircle className="h-4 w-4 text-primary" />
            </span>
            <span className="text-xs uppercase tracking-[0.18em] text-muted-foreground font-medium">
              Frequently Asked Questions
            </span>
          </div>

          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground tracking-tight max-w-3xl">
            Entity SEO: Common Questions
          </h2>

          <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-2xl leading-relaxed">
            Answers to the questions I hear most often from UK businesses
            exploring entity-based search for the first time.
          </p>
        </motion.div>

        {/* FAQ accordion */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
        >
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <motion.div key={index} variants={itemVariants}>
                <AccordionItem
                  value={`faq-${index}`}
                  className="border-b border-border"
                >
                  <AccordionTrigger className="text-left py-5 text-base md:text-lg font-medium text-foreground hover:text-primary transition-colors duration-200 [&[data-state=open]]:text-primary">
                    {faq.question}
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground text-base leading-relaxed pb-6 max-w-3xl">
                    {faq.answer}
                  </AccordionContent>
                </AccordionItem>
              </motion.div>
            ))}
          </Accordion>
        </motion.div>

        {/* Subtle closing note */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4, ease: "easeOut" }}
          className="mt-10 text-sm text-muted-foreground"
        >
          Have a question not covered here?{" "}
          <a
            href="/contact"
            className="text-primary underline underline-offset-4 hover:text-primary/80 transition-colors duration-200"
          >
            Get in touch
          </a>{" "}
          and I'll answer it directly.
        </motion.p>
      </div>

      {/* FAQPage structured data for SEO */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            mainEntity: faqs.map((faq) => ({
              "@type": "Question",
              name: faq.question,
              acceptedAnswer: {
                "@type": "Answer",
                text: faq.answer,
              },
            })),
          }),
        }}
      />
    </section>
  );
});

EntitySeoFAQ.displayName = "EntitySeoFAQ";

export default EntitySeoFAQ;
