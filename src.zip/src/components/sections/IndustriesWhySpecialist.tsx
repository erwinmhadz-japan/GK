import React from "react";
import { Shield, TrendingUp, Users, CheckCircle2, Search, View } from "lucide-react";

const reasons = [
  {
    icon: Shield,
    title: "Regulatory Awareness",
    description:
      "Professional sectors from healthcare to financial services operate under strict compliance rules. Every content and link-building strategy I deliver is designed with your regulatory environment in mind — no shortcuts that put your firm at risk.",
  },
  {
    icon: TrendingUp,
    title: "Competitive Intelligence",
    description:
      "I research your sector's SERP landscape before I write a single word of strategy. That means understanding who ranks, why they rank, and exactly where the gaps are for your firm to build lasting visibility.",
  },
  {
    icon: Users,
    title: "Buyer Journey Mapping",
    description:
      "Professional service buyers conduct thorough due diligence before choosing a provider. My SEO strategies align with each stage of that journey — from initial awareness searches through to shortlisting and appointment booking.",
  },
  {
    icon: CheckCircle2,
    title: "AI Search Ready",
    description:
      "AI tools like ChatGPT, Perplexity, and Google AI Overviews are reshaping how professionals find services. I build your brand's entity authority so it appears in AI-generated answers, not just traditional search results.",
  },
];

const IndustriesWhySpecialist = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left — image */}
          <div className="relative rounded-2xl overflow-hidden shadow-card">
            <img
              src="https://images.unsplash.com/photo-1582005450386-52b25f82d9bb?w=800&h=600&fit=crop"
              alt="Three women sitting together reviewing strategy on laptops"
              width={800}
              height={600}
              loading="lazy"
              className="w-full h-full object-cover aspect-[4/3]"
            />
            {/* Stat badge */}
            <div className="absolute bottom-6 left-6 bg-card rounded-xl px-5 py-4 shadow-card border border-border">
              <p className="text-3xl font-bold text-foreground">8+</p>
              <p className="text-sm text-muted-foreground mt-1">Years in professional sector SEO</p>
            </div>
          </div>

          {/* Right — content */}
          <div>
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-3">
              Why Specialist Matters
            </span>
            <h2 className="text-3xl md:text-4xl font-bold text-foreground">
              Industry Expertise That Generic Agencies Can't Match
            </h2>
            <p className="mt-4 text-muted-foreground leading-relaxed">
              A one-size-fits-all SEO strategy fails in professional services. Your clients search
              differently, your competitors are sophisticated, and the content standards set by Google
              demand genuine expertise. I've spent years building deep knowledge across legal, healthcare,
              property, financial, and B2B sectors — so I hit the ground running.
            </p>

            <div className="mt-8 grid grid-cols-1 sm:grid-cols-2 gap-6">
              {reasons.map((reason) => {
                const Icon = reason.icon;
                return (
                  <div key={reason.title} className="flex gap-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 shrink-0 mt-0.5">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <h3 className="font-semibold text-foreground text-base">{reason.title}</h3>
                      <p className="mt-1 text-sm text-muted-foreground leading-relaxed">
                        {reason.description}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="mt-8 flex flex-wrap gap-4">
              <a
                href="/services"
                className="inline-flex items-center gap-1.5 text-primary font-semibold text-sm hover:underline"
              >
                View All Services →
              </a>
              <a
                href="#case-studies-cta"
                className="inline-flex items-center gap-1.5 text-muted-foreground font-semibold text-sm hover:underline hover:text-foreground transition-colors"
              >
                Browse Case Studies →
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

IndustriesWhySpecialist.displayName = "IndustriesWhySpecialist";

export default IndustriesWhySpecialist;
