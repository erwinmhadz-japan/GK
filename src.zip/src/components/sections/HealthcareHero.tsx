import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Stethoscope, ShieldCheck, MapPin, View } from "lucide-react";

const HealthcareHero: React.FC = () => {
  return (
    <ImageBackground
      src="https://images.unsplash.com/photo-1758691461916-dc7894eb8f94?w=1920&h=1080&fit=crop"
      alt="Doctor wearing a stethoscope at his desk"
      imgProps={{ fetchpriority: "high", loading: "eager" }}
      className="min-h-[85vh] md:min-h-screen flex items-center"
    >
      {/* JSON-LD: Service + LocalBusiness + Organization */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify([
            {
              "@context": "https://schema.org",
              "@type": "Service",
              "name": "Healthcare SEO for Clinics & Private Providers",
              "description":
                "Specialist SEO services for healthcare clinics, private practices, and medical providers — covering local visibility, YMYL compliance, patient trust signals, and HIPAA-safe technical SEO.",
              "provider": {
                "@type": "Organization",
                "name": "Gregg's SEO Consulting",
                "url": "https://www.greggsseo.com"
              },
              "serviceType": "Healthcare SEO",
              "areaServed": {
                "@type": "Country",
                "name": "United Kingdom"
              }
            },
            {
              "@context": "https://schema.org",
              "@type": "LocalBusiness",
              "name": "Gregg's SEO Consulting",
              "description":
                "Independent SEO consultancy specialising in healthcare, clinics, and private medical providers.",
              "url": "https://www.greggsseo.com",
              "telephone": "+44-XXXX-XXXXXX",
              "address": {
                "@type": "PostalAddress",
                "addressCountry": "GB"
              }
            },
            {
              "@context": "https://schema.org",
              "@type": "Organization",
              "name": "Gregg's SEO Consulting",
              "url": "https://www.greggsseo.com",
              "sameAs": [],
              "knowsAbout": [
                "Healthcare SEO",
                "YMYL Compliance",
                "Local SEO for Clinics",
                "Medical Schema Markup",
                "HIPAA-Safe Technical SEO"
              ]
            }
          ])
        }}
      />

      <div className="container relative z-10 py-24 md:py-32">
        <div className="max-w-3xl">
          <div className="flex flex-wrap gap-2 mb-6">
            <Badge className="bg-primary/20 text-primary border-primary/30 backdrop-blur-sm">
              <Stethoscope className="h-3 w-3 mr-1" />
              Healthcare & Clinics
            </Badge>
            <Badge className="bg-white/10 text-white border-white/20 backdrop-blur-sm">
              <ShieldCheck className="h-3 w-3 mr-1" />
              YMYL Compliant
            </Badge>
            <Badge className="bg-white/10 text-white border-white/20 backdrop-blur-sm">
              <MapPin className="h-3 w-3 mr-1" />
              Local SEO Specialists
            </Badge>
          </div>

          <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
            SEO for Healthcare Clinics &{" "}
            <span className="text-gradient-green">Private Providers</span>
          </h1>

          <p className="text-lg md:text-xl text-white/90 mb-4 leading-relaxed max-w-2xl">
            Helping GP surgeries, private clinics, dental practices, and specialist medical providers
            rank higher in local search — while meeting Google's Your Money or Your Life (YMYL)
            standards and building genuine patient trust.
          </p>

          <p className="text-base text-white/80 mb-10 max-w-xl">
            Independent healthcare SEO consultancy. No agency markup. No conflicting clients.
            Measurable results for regulated medical businesses.
          </p>

          <div className="flex flex-wrap gap-4">
            <Button
              size="lg"
              className="bg-primary text-primary-foreground hover:bg-primary/90 font-semibold px-8"
              asChild
            >
              <a href="/contact">Get a Free Healthcare SEO Audit</a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10"
              asChild
            >
              <a href="#case-studies-cta">View Case Studies</a>
            </Button>
          </div>

          <p className="mt-6 text-sm text-white/80">
            Trusted by clinics across the UK · No long-term contracts · HIPAA & GDPR aware
          </p>
        </div>
      </div>
    </ImageBackground>
  );
};

export default HealthcareHero;
