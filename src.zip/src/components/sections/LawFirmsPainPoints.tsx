import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, MapPin, TrendingUp, Eye, Scale, Briefcase, Cookie, Search, Section } from "lucide-react";

const painPoints = [
  {
    icon: Users,
    title: "Fierce Competition for High-Value Clients",
    description:
      "Hundreds of firms compete for the same search terms — 'solicitors near me', 'family law advice', 'commercial property lawyer'. Without deliberate SEO strategy, your firm remains invisible to the very prospects most likely to instruct you.",
  },
  {
    icon: MapPin,
    title: "Local Search is Winner-Takes-Most",
    description:
      "Google's local pack displays just three firms for any given query. If your practice isn't in those three positions, you're effectively absent from the conversation. Local SEO isn't optional — it's your primary lead generation channel.",
  },
  {
    icon: Eye,
    title: "Generic Marketing Agencies Miss Legal Nuance",
    description:
      "Most agencies don't understand legal sector compliance, practice area terminology, or the trust signals that convince prospective clients to make first contact. Cookie-cutter SEO wastes budget and fails to convert.",
  },
  {
    icon: TrendingUp,
    title: "Lead Generation Costs Keep Rising",
    description:
      "Paid advertising CPCs for legal keywords are among the highest in any industry. Law firms spending heavily on Google Ads without organic visibility are on a treadmill — cost without compounding returns.",
  },
  {
    icon: Scale,
    title: "Authority and Trust Are Everything",
    description:
      "Clients choose solicitors on trust. Google's E-E-A-T signals (Experience, Expertise, Authoritativeness, Trustworthiness) align perfectly with how clients evaluate legal firms — and your SEO must reflect this.",
  },
  {
    icon: Briefcase,
    title: "Practice Area Pages Lack Search Depth",
    description:
      "Many law firm websites treat practice areas as brochure pages rather than answer-rich resources. Thin, duplicated content fails to rank for the long-tail queries that signal genuine client intent.",
  },
];

const LawFirmsPainPoints = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-2xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            The Challenge
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Why Law Firms Struggle to Generate Leads Online
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            The legal sector has unique digital marketing challenges. Understanding
            them is the first step to building an SEO strategy that actually
            delivers new client instructions.
          </p>
        </div>

        {/* Pain points grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {painPoints.map((point) => {
            const Icon = point.icon;
            return (
              <Card
                key={point.title}
                className="bg-card border-border shadow-card hover-lift transition-all duration-300"
              >
                <CardHeader className="pb-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-4">
                    <Icon className="h-6 w-6 text-primary" />
                  </div>
                  <CardTitle className="text-lg text-foreground leading-snug">
                    {point.title}
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-sm leading-relaxed">
                    {point.description}
                  </p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Callout banner */}
        <div className="mt-14 rounded-xl bg-[image:var(--gradient-hero-panel)] p-8 md:p-10">
          <div className="max-w-2xl">
            <p className="text-lg md:text-xl font-semibold text-white leading-relaxed">
              "Law firms that invest in specialist SEO generate 3–5× more organic
              enquiries within 12 months compared to those relying solely on
              paid acquisition."
            </p>
            <p className="mt-3 text-sm text-white/80">
              — Industry benchmark across UK legal sector clients
            </p>
          </div>
        </div>
      </div>
    </section>
  );
});

LawFirmsPainPoints.displayName = "LawFirmsPainPoints";

export default LawFirmsPainPoints;
