import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { HelpCircle, Search } from "lucide-react";

const faqs = [
  {
    question: "How does Google Gemini decide which websites to cite in its answers?",
    answer:
      "Gemini evaluates sources based on a combination of signals: domain authority (reflected in your backlink profile), content quality and depth, freshness of the information, structured data that helps Gemini understand your content, and E-E-A-T signals like author credentials and first-hand experience. It draws from Google's live search index, so pages must be crawlable and properly indexed to be eligible for citation.",
  },
  {
    question: "Is Gemini visibility the same as Google AI Overviews visibility?",
    answer:
      "They are closely related but not identical. Google AI Overviews — the AI-generated summaries that appear at the top of Google Search results — are powered by Gemini. Optimising for Gemini visibility substantially overlaps with improving your chances of appearing in AI Overviews. However, Gemini also surfaces across the standalone Gemini app and Google Workspace, where AI Overview logic doesn't apply. A unified strategy addresses both.",
  },
  {
    question: "Does my page need to rank on the first page of Google to appear in Gemini answers?",
    answer:
      "Not necessarily. Gemini can surface content that doesn't rank in the top 10 organic results if it demonstrates strong authority signals and directly answers a specific question. That said, pages with higher organic rankings are inherently more likely to be indexed deeply and recognised as authoritative — so traditional SEO and Gemini visibility share a common foundation rather than being separate pursuits.",
  },
  {
    question: "What indexing and crawlability requirements does Gemini have?",
    answer:
      "Because Gemini sources from Google's index, the requirements mirror standard Google crawlability: pages must not be blocked via robots.txt or noindex directives; content should not require login or paywalls; JavaScript-heavy pages should render server-side or support static HTML; internal linking should help Googlebot discover pages efficiently; and your sitemap should be up to date. Fast page load times also correlate with more frequent re-crawling, which matters for content freshness.",
  },
  {
    question: "How long does it take to start appearing in Gemini answers after optimisation?",
    answer:
      "The timeline varies by domain age, existing authority, and how competitive the query space is. For established domains with existing crawl coverage, improvements to content structure, schema, and E-E-A-T signals can begin influencing Gemini citation within 4–12 weeks. For newer domains, building the underlying authority takes longer — but a focused strategy around topical depth and structured data accelerates the process significantly.",
  },
  {
    question: "Does schema markup really help with Gemini visibility?",
    answer:
      "Yes — structured data in Schema.org formats (FAQPage, Article, HowTo, Organisation) provides Gemini with machine-readable signals about your content's purpose, context, and entities. This reduces the ambiguity Gemini faces when synthesising answers and increases the chance it correctly attributes your content. FAQPage schema in particular is valuable as it aligns with the question-and-answer format Gemini uses when presenting information. See our schema markup guide for implementation detail.",
  },
  {
    question: "What content formats perform best in Gemini visibility?",
    answer:
      "Concise, answer-first content performs best. Lead with the direct answer to a query, then support it with detail. Use descriptive headers (ideally phrased as questions), numbered lists for processes, and factual statements that can stand alone as citations. Longer, authoritative guides on specific topics also perform well — Gemini rewards depth alongside directness. Avoid padding, keyword stuffing, and content that buries the answer.",
  },
];

// FAQ JSON-LD structured data
const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((faq) => ({
    "@type": "Question",
    name: faq.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: faq.answer,
    },
  })),
};

const AiSearchGeminiFAQ = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="gemini-faq"
      className="relative py-20 md:py-32 border-t border-border bg-background"
      aria-labelledby="gemini-faq-heading"
    >
      {/* FAQ JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />

      <div className="container">
        {/* Header */}
        <div className="max-w-2xl mb-14">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
              <HelpCircle className="h-5 w-5 text-primary" />
            </div>
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold">
              Frequently Asked Questions
            </span>
          </div>
          <h2
            id="gemini-faq-heading"
            className="text-3xl md:text-5xl font-bold text-foreground mb-5"
          >
            Gemini Indexing & Visibility: Common Questions
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Practical answers to the most common questions about how Google Gemini
            selects sources, what authority signals matter, and how to improve your
            chances of being cited.
          </p>
        </div>

        {/* FAQ Accordion */}
        <div className="max-w-3xl">
          <Accordion type="single" collapsible className="w-full space-y-2">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="bg-card border border-border rounded-xl px-6 data-[state=open]:border-primary/30 transition-colors"
              >
                <AccordionTrigger className="text-left font-semibold text-foreground py-5 hover:no-underline">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed pb-5">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        {/* Related topics */}
        <div className="mt-12 grid grid-cols-1 sm:grid-cols-3 gap-4 max-w-3xl">
          <a
            href="/schema-markup"
            className="group p-4 bg-muted border border-border rounded-xl hover:border-primary/40 transition-colors"
          >
            <p className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">
              Schema Markup Guide →
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Structured data for AI visibility
            </p>
          </a>
          <a
            href="/entity-seo"
            className="group p-4 bg-muted border border-border rounded-xl hover:border-primary/40 transition-colors"
          >
            <p className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">
              Entity SEO →
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Build entity recognition for Gemini
            </p>
          </a>
          <a
            href="#ai-search-cta"
            className="group p-4 bg-muted border border-border rounded-xl hover:border-primary/40 transition-colors"
          >
            <p className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors">
              AI Search Hub →
            </p>
            <p className="text-xs text-muted-foreground mt-1">
              Full platform visibility guide
            </p>
          </a>
        </div>
      </div>
    </section>
  );
});

AiSearchGeminiFAQ.displayName = "AiSearchGeminiFAQ";

export default AiSearchGeminiFAQ;
