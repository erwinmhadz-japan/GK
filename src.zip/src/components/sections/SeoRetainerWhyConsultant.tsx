import React from "react";
import { motion } from "framer-motion";
import { UserCheck, Eye, BarChart2, Section, Text } from "lucide-react";
import { Link } from "react-router-dom";

const reasons = [
  {
    icon: UserCheck,
    heading: "Direct accountability, every month",
    body: "With an agency retainer, you pay for a team but rarely speak to the person doing the work. With Gregg King, the strategist and the practitioner are the same individual. Every deliverable, every recommendation, every reporting call — handled personally, with no hand-offs to junior account managers.",
  },
  {
    icon: Eye,
    heading: "Senior-level attention throughout",
    body: "Agency retainers are won by senior consultants and executed by graduates. A consultant-led retainer inverts that entirely. The expertise that wins the engagement is the expertise that stays with it — ensuring the quality of thinking never erodes once the contract is signed.",
  },
  {
    icon: BarChart2,
    heading: "Transparent reporting, not managed metrics",
    body: "Independent consultants have no internal benchmarks to protect and no agency margins to obscure. Reporting is direct: organic performance, ranking progress, and ROI — presented plainly, without the dashboard theatre that often accompanies agency contracts.",
  },
];

const SeoRetainerWhyConsultant = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seo-retainer-why-consultant"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="max-w-2xl mb-14 md:mb-20"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Why a consultant retainer
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground font-[Sora,sans-serif] leading-snug max-w-xl">
            What makes a consultant retainer different from an agency contract
          </h2>
        </motion.div>

        {/* Three editorial points */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-10 md:gap-8 lg:gap-12">
          {reasons.map((reason, index) => {
            const Icon = reason.icon;
            return (
              <motion.div
                key={reason.heading}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{ duration: 0.55, ease: "easeOut", delay: index * 0.12 }}
                className="flex flex-col gap-5"
              >
                {/* Icon container */}
                <div className="flex-shrink-0 w-11 h-11 rounded-md border border-border bg-muted flex items-center justify-center"
                  style={{ boxShadow: "0 2px 12px -2px hsl(222 28% 11% / 0.06), 0 1px 3px hsl(222 28% 11% / 0.04)" }}>
                  <Icon className="h-5 w-5 text-primary" aria-hidden="true" />
                </div>

                {/* Text block */}
                <div className="flex flex-col gap-3">
                  <h3 className="text-base md:text-lg font-semibold text-foreground font-[Sora,sans-serif] leading-snug">
                    {reason.heading}
                  </h3>
                  <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
                    {reason.body}
                  </p>
                </div>

                {/* Subtle green accent rule */}
                <div
                  className="w-8 h-0.5 rounded-full mt-auto"
                  style={{ background: "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)" }}
                  aria-hidden="true"
                />
              </motion.div>
            );
          })}
        </div>

        {/* Closing editorial note */}
        <motion.p
          initial={{ opacity: 0, y: 16 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.55, ease: "easeOut", delay: 0.4 }}
          className="mt-14 md:mt-16 max-w-2xl text-sm text-muted-foreground leading-relaxed border-l-2 pl-5"
          style={{ borderColor: "hsl(84 74% 58% / 0.5)" }}
        >
          For UK businesses in competitive and trust-led sectors —{" "}
          <Link to="#law-firms-cta" className="text-foreground underline underline-offset-2 hover:text-primary transition-colors">law</Link>,{" "}
          <Link to="#healthcare-cta" className="text-foreground underline underline-offset-2 hover:text-primary transition-colors">healthcare</Link>,{" "}
          <Link to="#financial-services-cta" className="text-foreground underline underline-offset-2 hover:text-primary transition-colors">finance</Link>,{" "}
          <Link to="#estate-agents-cta" className="text-foreground underline underline-offset-2 hover:text-primary transition-colors">property</Link>{" "}
          — the distinction matters. You are not buying a managed service; you are retaining an individual who is professionally accountable for your organic performance.
        </motion.p>

      </div>
    </section>
  );
});

SeoRetainerWhyConsultant.displayName = "SeoRetainerWhyConsultant";

export default SeoRetainerWhyConsultant;
