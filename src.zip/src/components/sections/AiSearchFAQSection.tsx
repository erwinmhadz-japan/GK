import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";
import { HelpCircle, ArrowRight, Search } from "lucide-react";

const faqs = [
  {
    question: "What is AI Search and how is it different from traditional SEO?",
    answer:
      "Traditional SEO is focused on ranking your website in the list of blue links on search engine results pages (SERPs). AI Search — delivered by tools like ChatGPT, Perplexity, Google AI Overviews, Gemini, and Microsoft Copilot — generates a direct, conversational answer to a user's query, often without showing a traditional list of links. Rather than ranking for position 1–10, AI Search optimisation focuses on getting your brand cited, named, or recommended within those generated answers. The underlying signals differ too: AI platforms weight entity authority, semantic clarity, structured data, and consistent brand presence more heavily than raw backlink counts.",
  },
  {
    question: "Do I still need traditional SEO if I invest in AI Search optimisation?",
    answer:
      "Yes — traditional SEO and AI Search optimisation are complementary, not competing. Many of the ranking signals that benefit traditional SEO (authoritative content, E-E-A-T, structured data, strong backlink profiles) also inform AI platforms. However, AI Search requires additional layers: entity recognition, knowledge graph presence, citation-friendly content architecture, and structured FAQ or How-To schema. A robust strategy addresses both simultaneously, and in practice the work done for AI visibility almost always improves traditional rankings too.",
  },
  {
    question: "Which AI platforms should my business focus on first?",
    answer:
      "It depends on your audience and industry. For B2C brands with broad consumer reach, Google AI Overviews and ChatGPT are typically the highest priority, given their combined user volume. For B2B or high-research purchase decisions, Perplexity AI is increasingly influential because it cites sources directly and attracts research-oriented users. Microsoft Copilot is essential if your audience is enterprise or Microsoft-heavy. Google Gemini matters most if your customers are deeply embedded in the Google ecosystem. I work with clients to identify which platforms their specific customers are actually using and prioritise accordingly.",
  },
  {
    question: "How long does it take to see results from AI Search optimisation?",
    answer:
      "AI Search visibility can be faster to achieve than traditional SEO for some queries, particularly if your content already has strong foundational authority. Typically, clients begin to see measurable citation improvements within 2–4 months of implementing structured data, entity-building, and citation-optimised content. However, AI models update their training data and retrieval indices on different cycles, and some platforms (particularly ChatGPT's browsing and knowledge base) refresh less frequently than others. I track citation frequency and brand mention patterns monthly to give you a clear picture of progress.",
  },
  {
    question: "How does AI Search optimisation differ across platforms — ChatGPT vs Perplexity vs Google AI Overviews?",
    answer:
      "Each platform has distinct retrieval mechanisms. ChatGPT's browsing feature pulls from live web results, similar to Bing's index — so Bing visibility and strong domain authority are critical. Perplexity retrieves and cites live web sources, favouring structured, well-organised pages with clear topical depth; it rewards brands with consistent digital PR and earned mentions. Google AI Overviews draw from Google's own index and are heavily influenced by E-E-A-T signals, schema markup, and the same signals that drive featured snippet selection. Google Gemini is similarly Google-index-driven but increasingly integrates with Google's Knowledge Graph. Microsoft Copilot relies primarily on Bing's web index. Each platform receives a tailored approach within an integrated AI Search strategy.",
  },
  {
    question: "Can smaller businesses compete in AI Search against larger brands?",
    answer:
      "Yes — and in some respects, AI Search levels the playing field. AI models are not simply ranking by domain authority or ad spend. They're looking for the most relevant, clearly structured, and authoritative answer to a user's query. A specialist independent business with deep expertise, clear entity signals, and well-structured content can be cited ahead of a generic large brand in many niches. Localised queries, niche service areas, and long-tail informational queries are particularly strong opportunities for smaller businesses to gain AI visibility quickly.",
  },
];

const faqJsonLd = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map(({ question, answer }) => ({
    "@type": "Question",
    name: question,
    acceptedAnswer: {
      "@type": "Answer",
      text: answer,
    },
  })),
};

const AiSearchFAQSection = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      {/* FAQ JSON-LD structured data */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqJsonLd) }}
      />

      <div className="container">
        <div className="max-w-3xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="flex justify-center mb-4">
              <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                <HelpCircle className="h-6 w-6 text-primary" />
              </div>
            </div>
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
              Common Questions
            </span>
            <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
              AI Search FAQs
            </h2>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Everything you need to know about AI Search visibility and how it differs from
              traditional SEO.
            </p>
          </div>

          {/* Accordion */}
          <Accordion type="single" collapsible className="w-full space-y-3">
            {faqs.map((faq, index) => (
              <AccordionItem
                key={index}
                value={`item-${index}`}
                className="bg-background rounded-xl border border-border px-6 data-[state=open]:shadow-card"
              >
                <AccordionTrigger className="text-left font-semibold text-foreground py-5 hover:no-underline hover:text-primary transition-colors">
                  {faq.question}
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed pb-5 text-sm md:text-base">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          {/* Footer CTA */}
          <div className="mt-10 text-center">
            <p className="text-muted-foreground mb-4">
              Have a question not answered here?
            </p>
            <Button asChild>
              <a href="/contact">
                Ask Me Directly
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
});

AiSearchFAQSection.displayName = "AiSearchFAQSection";

export default AiSearchFAQSection;
