import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, MessageSquare } from "lucide-react";

const AboutCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="about-cta"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center">

          {/* Eyebrow label */}
          <motion.span
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-6 font-medium"
          >
            Ready to get started?
          </motion.span>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground tracking-tight mb-6"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Work Directly With Gregg
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.2 }}
            className="text-base md:text-lg text-muted-foreground leading-relaxed mb-10 max-w-2xl mx-auto"
          >
            Enquire about a free GBP audit or an initial consultation — no
            obligation, no agency handoffs.
          </motion.p>

          {/* CTA buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            {/* Primary CTA */}
            <Button
              size="lg"
              className="w-full sm:w-auto h-12 px-8 text-base font-semibold bg-primary text-primary-foreground hover:bg-primary/90 transition-colors duration-200 rounded-md"
              asChild
            >
              <Link to="/contact">
                Start a Conversation
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>

            {/* Secondary CTA — FREE GBP AUDIT verbatim */}
            <Button
              size="lg"
              variant="outline"
              className="w-full sm:w-auto h-12 px-8 text-base font-semibold border-border text-foreground hover:bg-accent/10 hover:border-primary transition-colors duration-200 rounded-md"
              asChild
            >
              <Link to="/contact">
                <MessageSquare className="mr-2 h-4 w-4" />
                FREE GBP AUDIT
              </Link>
            </Button>
          </motion.div>

          {/* Trust reassurance line */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.45 }}
            className="mt-8 text-sm text-muted-foreground"
          >
            Senior SEO expertise applied directly — no account managers, no
            junior teams.
          </motion.p>
        </div>
      </div>
    </section>
  );
});

AboutCTA.displayName = "AboutCTA";

export default AboutCTA;
