import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ArrowRight, Brain, Sparkles, Search, View } from "lucide-react";

const AISearchOptimisationCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="aisearch-optimisation-cta"
      className="relative py-20 md:py-32 border-t border-border bg-muted overflow-hidden"
    >
      {/* Subtle background texture — decorative grid, no image backdrop */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute inset-0 opacity-[0.03]"
        style={{
          backgroundImage:
            "repeating-linear-gradient(0deg, hsl(222 42% 8%) 0px, transparent 1px, transparent 40px, hsl(222 42% 8%) 40px), repeating-linear-gradient(90deg, hsl(222 42% 8%) 0px, transparent 1px, transparent 40px, hsl(222 42% 8%) 40px)",
        }}
      />

      {/* Ambient green glow — decorative only */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -top-32 right-1/4 h-64 w-64 rounded-full"
        style={{
          background:
            "radial-gradient(circle, hsl(84 74% 58% / 0.12) 0%, transparent 70%)",
        }}
      />
      <div
        aria-hidden="true"
        className="pointer-events-none absolute -bottom-24 left-1/3 h-48 w-48 rounded-full"
        style={{
          background:
            "radial-gradient(circle, hsl(119 35% 61% / 0.10) 0%, transparent 70%)",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">

          {/* Eyebrow */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5, ease: "easeOut" }}
            className="flex items-center justify-center gap-2 mb-6"
          >
            <Brain
              className="h-4 w-4"
              style={{ color: "hsl(84 74% 58%)" }}
              aria-hidden="true"
            />
            <span
              className="text-xs uppercase tracking-[0.18em] font-medium"
              style={{ color: "hsl(84 74% 58%)" }}
            >
              AI Search Optimisation
            </span>
          </motion.div>

          {/* Headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.08 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight mb-6 max-w-2xl mx-auto"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Ready to Improve Your AI Search Visibility?
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.16 }}
            className="text-base md:text-lg text-muted-foreground leading-relaxed mb-10 max-w-2xl mx-auto"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Gregg works with UK businesses to build the authority signals that AI
            platforms reward. Explore the AI search optimisation service or get in
            touch to discuss your situation.
          </motion.p>

          {/* CTA buttons */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0.24 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            {/* Primary CTA → commercial service page */}
            <Button
              size="lg"
              asChild
              className="h-12 px-8 text-sm font-semibold tracking-wide rounded-md"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 58%) 0%, hsl(119 35% 61%) 100%)",
                color: "hsl(222 42% 8%)",
                border: "none",
              }}
            >
              <Link to="/ai-search-optimisation">
                View AI Search Optimisation
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>

            {/* Secondary CTA → contact page */}
            <Button
              size="lg"
              variant="outline"
              asChild
              className="h-12 px-8 text-sm font-semibold tracking-wide rounded-md border-border hover:bg-accent/5 text-foreground"
            >
              <Link to="/contact">
                Discuss Your Situation
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </motion.div>

          {/* Reassurance note */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.36 }}
            className="mt-8 text-xs text-muted-foreground"
            style={{ fontFamily: "Inter, sans-serif" }}
          >
            Independent SEO consultant based in Warrington, Cheshire.&ensp;
            <span className="inline-flex items-center gap-1 whitespace-nowrap">
              <Sparkles
                className="h-3 w-3"
                style={{ color: "hsl(84 74% 58%)" }}
                aria-hidden="true"
              />
              No agency mark-up. No sales pipeline.
            </span>
          </motion.p>

          {/* Hub back-link */}
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.44 }}
            className="mt-6"
          >
            <Link
              to="#ai-search-cta"
              className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors duration-200"
            >
              <ArrowRight className="h-3 w-3 rotate-180" aria-hidden="true" />
              Back to AI Search Hub
            </Link>
          </motion.div>
        </div>
      </div>
    </section>
  );
});

AISearchOptimisationCTA.displayName = "AISearchOptimisationCTA";

export default AISearchOptimisationCTA;
