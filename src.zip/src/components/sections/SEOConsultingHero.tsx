import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { ArrowRight, CheckCircle, MapPin, Search } from "lucide-react";

const credentialItems = [
  "Independent consultant — no account managers",
  "Direct access to senior-level expertise",
  "Strategy built around commercial objectives",
];

const SEOConsultingHero = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="seoconsulting-hero"
      className="relative py-20 md:py-32 border-t border-border bg-background overflow-hidden"
    >
      {/* Subtle dot-grid background texture */}
      <div
        className="absolute inset-0 opacity-[0.035] pointer-events-none"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(225 28% 14%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
        aria-hidden="true"
      />

      {/* Subtle gradient wash — top-left accent */}
      <div
        className="absolute -top-40 -left-40 w-[600px] h-[600px] rounded-full pointer-events-none"
        style={{
          background:
            "radial-gradient(circle, hsl(84 74% 60% / 0.06) 0%, transparent 70%)",
        }}
        aria-hidden="true"
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-16 items-center">

          {/* ── Left column: copy ── */}
          <div>
            {/* Eyebrow */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, ease: "easeOut", delay: 0 }}
              className="flex items-center gap-2 mb-5"
            >
              <MapPin className="h-4 w-4 text-muted-foreground shrink-0" />
              <span className="text-xs uppercase tracking-[0.18em] text-muted-foreground font-medium">
                Independent SEO Consultant · Warrington, Cheshire
              </span>
            </motion.div>

            {/* H1 */}
            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, ease: "easeOut", delay: 0.1 }}
              className="text-4xl md:text-5xl lg:text-[3.25rem] font-bold leading-[1.1] tracking-tight text-foreground max-w-xl"
            >
              SEO Consulting for{" "}
              <span
                className="inline-block"
                style={{
                  background:
                    "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                  WebkitBackgroundClip: "text",
                  WebkitTextFillColor: "transparent",
                  backgroundClip: "text",
                }}
              >
                UK Businesses
              </span>
            </motion.h1>

            {/* Subheadline */}
            <motion.p
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.65, ease: "easeOut", delay: 0.2 }}
              className="mt-5 text-lg md:text-xl text-muted-foreground leading-relaxed max-w-lg"
            >
              Independent SEO consulting built around your commercial
              objectives — no account managers, no juniors, just direct expert
              advice.
            </motion.p>

            {/* Credential checklist */}
            <motion.ul
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
              className="mt-7 space-y-3"
              aria-label="Consulting credentials"
            >
              {credentialItems.map((item) => (
                <li key={item} className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 shrink-0 mt-[1px]" style={{ color: "hsl(119 35% 61%)" }} />
                  <span className="text-sm text-muted-foreground">{item}</span>
                </li>
              ))}
            </motion.ul>

            {/* CTA buttons */}
            <motion.div
              initial={{ opacity: 0, y: 16 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.4 }}
              className="mt-9 flex flex-wrap gap-3"
            >
              <Button
                size="lg"
                className="h-12 px-7 text-base font-semibold"
                style={{
                  background:
                    "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                  color: "hsl(225 28% 14%)",
                  border: "none",
                }}
                asChild
              >
                <Link to="/contact">
                  Enquire Now
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Link>
              </Button>

              <Button
                size="lg"
                variant="outline"
                className="h-12 px-7 text-base font-medium border-border text-foreground hover:bg-muted"
                asChild
              >
                <Link to="/services-seo-audit">
                  Free SEO Audit
                </Link>
              </Button>
            </motion.div>

            {/* Trust note */}
            <motion.p
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.5, ease: "easeOut", delay: 0.55 }}
              className="mt-5 text-xs text-muted-foreground"
            >
              Trusted by UK businesses in law, finance, healthcare &amp; property.
            </motion.p>
          </div>

          {/* ── Right column: dark panel ── */}
          <motion.div
            initial={{ opacity: 0, x: 24 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.7, ease: "easeOut", delay: 0.25 }}
            className="relative"
          >
            <div
              className="rounded-xl border border-border p-8 md:p-10 shadow-lg"
              style={{
                background:
                  "linear-gradient(160deg, hsl(225 28% 14%), hsl(231 9% 16%) 60%, hsl(214 32% 60% / 0.12))",
              }}
            >
              {/* Panel header */}
              <div className="flex items-center gap-3 mb-7">
                <div
                  className="flex h-10 w-10 items-center justify-center rounded-lg"
                  style={{
                    background:
                      "linear-gradient(135deg, hsl(84 74% 58% / 0.2), hsl(119 35% 61% / 0.15))",
                  }}
                >
                  <Search className="h-5 w-5" style={{ color: "hsl(84 74% 58%)" }} />
                </div>
                <div>
                  <p className="text-sm font-semibold text-white">SEO Consulting UK</p>
                  <p className="text-xs" style={{ color: "hsl(214 32% 60%)" }}>
                    Gregg King · Independent Consultant
                  </p>
                </div>
              </div>

              {/* What I offer */}
              <p className="text-xs uppercase tracking-widest mb-4" style={{ color: "hsl(214 32% 60%)" }}>
                What I offer
              </p>

              <ul className="space-y-2.5 mb-8">
                {[
                  "SEO strategy aligned to business goals",
                  "Technical SEO & site architecture review",
                  "Schema markup & entity optimisation",
                  "Content strategy & topical authority",
                  "Local SEO & multi-location campaigns",
                  "AI search optimisation & GEO",
                ].map((service) => (
                  <li key={service} className="flex items-center gap-2.5">
                    <span
                      className="flex h-1.5 w-1.5 rounded-full shrink-0"
                      style={{ background: "hsl(84 74% 58%)" }}
                      aria-hidden="true"
                    />
                    <span className="text-sm text-white/80">{service}</span>
                  </li>
                ))}
              </ul>

              {/* FREE GBP AUDIT badge — verbatim */}
              <div
                className="rounded-lg px-4 py-3 flex items-center justify-between"
                style={{
                  background: "hsl(84 74% 58% / 0.12)",
                  border: "1px solid hsl(84 74% 58% / 0.25)",
                }}
              >
                <span className="text-sm font-semibold" style={{ color: "hsl(84 74% 58%)" }}>
                  FREE GBP AUDIT
                </span>
                <Badge
                  variant="outline"
                  className="text-xs border-0 font-normal px-0"
                  style={{ color: "hsl(214 32% 60%)" }}
                >
                  included with enquiry
                </Badge>
              </div>

              {/* Keyword targeting note */}
              <p className="mt-5 text-xs leading-relaxed" style={{ color: "hsl(214 32% 60%)" }}>
                I work directly with decision-makers at law firms, healthcare
                providers, financial services businesses, and property companies
                across the UK — bringing senior-level SEO expertise to every
                engagement.
              </p>
            </div>

            {/* Decorative glow behind panel */}
            <div
              className="absolute -bottom-6 -right-6 w-48 h-48 rounded-full pointer-events-none -z-0"
              style={{
                background:
                  "radial-gradient(circle, hsl(119 35% 61% / 0.12) 0%, transparent 70%)",
              }}
              aria-hidden="true"
            />
          </motion.div>
        </div>
      </div>
    </section>
  );
});

SEOConsultingHero.displayName = "SEOConsultingHero";

export default SEOConsultingHero;
