import React from "react";
import { ImageBackground } from "@/components/ImageBackground";
import { Button } from "@/components/ui/button";
import { ArrowRight, BookOpen, Book, Group, Search, View } from "lucide-react";

const AiSearchHubCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <ImageBackground
      ref={ref}
      src="https://images.unsplash.com/photo-1641951820920-c90394aef512?w=1920&h=1080&fit=crop"
      alt="Group of professionals collaborating around laptops representing AI search strategy"
      imgProps={{ loading: "lazy" }}
      className="py-24 md:py-36 flex items-center"
    >
      <div className="container relative z-10">
        <div className="max-w-2xl mx-auto text-center">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4">
            Get Started Today
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6 leading-tight">
            Ready to Win in AI Search?
          </h2>
          <p className="text-lg md:text-xl text-white/90 leading-relaxed mb-4">
            AI Search is not a future trend — it is happening right now. Every day without a
            strategy is an opportunity handed to your competitors.
          </p>
          <p className="text-base text-white/80 leading-relaxed mb-10">
            Whether you need a full AI Search audit, platform-specific optimisation, or an
            integrated strategy alongside your existing SEO, I can help. Let us talk about
            where your business stands and how to build visibility that lasts.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-8">
            <Button
              size="lg"
              className="bg-gradient-cta text-primary-foreground font-semibold hover:opacity-90 transition-opacity"
              asChild
            >
              <a href="/services-ai-search-optimisation">
                View AI Search Optimisation Service
                <ArrowRight className="ml-2 h-4 w-4" />
              </a>
            </Button>
            <Button
              size="lg"
              variant="outline"
              className="bg-transparent text-white border-white hover:bg-white/10"
              asChild
            >
              <a href="/contact">
                Book a Free Consultation
              </a>
            </Button>
          </div>

          {/* Internal links */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 text-sm text-white/80">
            <a
              href="#insights-cta"
              className="inline-flex items-center gap-1.5 text-white/80 hover:text-white transition-colors"
            >
              <BookOpen className="h-4 w-4" />
              Read AI Search Insights
            </a>
            <span className="hidden sm:inline text-white/40">|</span>
            <a
              href="/ai-search-optimisation"
              className="inline-flex items-center gap-1.5 text-white/80 hover:text-white transition-colors"
            >
              <ArrowRight className="h-4 w-4" />
              AI Search Optimisation Overview
            </a>
          </div>
        </div>
      </div>
    </ImageBackground>
  );
});

AiSearchHubCTA.displayName = "AiSearchHubCTA";

export default AiSearchHubCTA;
