import React from "react";
import { Phone, Mail, MapPin, ArrowRight, Book, Contact } from "lucide-react";
import { Button } from "@/components/ui/button";

const SheffieldContact = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left — CTA copy */}
          <div>
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-3">
              Sheffield SEO Contact
            </span>
            <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">
              Ready to Grow Your Sheffield Business Online?
            </h2>
            <p className="text-muted-foreground text-lg leading-relaxed mb-8">
              Whether you're a Sheffield startup looking for your first traction in organic search, or an established South Yorkshire business ready to outpace the competition, let's talk. I offer a free initial consultation with no sales pressure.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <Button size="lg" asChild>
                <a href="/contact">
                  Book a Free Consultation
                  <ArrowRight className="ml-2 h-4 w-4" />
                </a>
              </Button>
              <Button size="lg" variant="outline" asChild>
                <a href="/services">Explore Services</a>
              </Button>
            </div>

            {/* Internal links */}
            <div className="mt-10 flex flex-wrap gap-x-6 gap-y-2 text-sm">
              <a href="/locations" className="text-primary hover:underline font-medium">
                All UK Locations
              </a>
              <a href="/local-seo" className="text-primary hover:underline font-medium">
                Local SEO Service
              </a>
              <a href="#industries-cta" className="text-primary hover:underline font-medium">
                Industries We Serve
              </a>
            </div>
          </div>

          {/* Right — contact details card */}
          <div className="bg-muted rounded-2xl p-8 border border-border shadow-card">
            <h3 className="text-xl font-bold text-foreground mb-6">
              Sheffield Contact Details
            </h3>
            <ul className="space-y-5">
              <li className="flex items-start gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 shrink-0">
                  <MapPin className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <div className="font-semibold text-foreground text-sm mb-0.5">
                    Serving Sheffield &amp; South Yorkshire
                  </div>
                  <div className="text-muted-foreground text-sm leading-relaxed">
                    Sheffield, South Yorkshire, S1<br />
                    Also covering Rotherham, Doncaster, Barnsley &amp; Chesterfield
                  </div>
                </div>
              </li>
              <li className="flex items-start gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 shrink-0">
                  <Phone className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <div className="font-semibold text-foreground text-sm mb-0.5">
                    Phone
                  </div>
                  <a
                    href="tel:+441142000000"
                    className="text-muted-foreground text-sm hover:text-primary transition-colors"
                  >
                    +44 (0)114 200 0000
                  </a>
                </div>
              </li>
              <li className="flex items-start gap-4">
                <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10 shrink-0">
                  <Mail className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <div className="font-semibold text-foreground text-sm mb-0.5">
                    Email
                  </div>
                  <a
                    href="mailto:sheffield@example.com"
                    className="text-muted-foreground text-sm hover:text-primary transition-colors"
                  >
                    sheffield@example.com
                  </a>
                </div>
              </li>
            </ul>

            <div className="mt-8 pt-6 border-t border-border">
              <p className="text-sm text-muted-foreground leading-relaxed">
                <strong className="text-foreground">Response time:</strong> I typically respond to Sheffield enquiries within one business day. For urgent matters, please call directly.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

SheffieldContact.displayName = "SheffieldContact";
export default SheffieldContact;
