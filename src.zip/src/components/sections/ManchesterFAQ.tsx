import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { HelpCircle, Phone } from "lucide-react";

const faqs = [
  {
    question: "Why do I need a Manchester-specific SEO consultant rather than a generic agency?",
    answer:
      "Manchester's local search market has its own nuances — from neighbourhood-level buyer intent (Altrincham vs Oldham behave very differently) to the competitive dynamics between local independents and national chains. A Manchester-specific approach means keyword research and content that speaks to local audiences, citations from regional directories, and link-building from respected North West publications. Generic agencies apply a one-size-fits-all formula; I build strategies around Greater Manchester's unique digital geography.",
  },
  {
    question: "How long does SEO take to show results for a Manchester business?",
    answer:
      "Most Manchester clients see measurable ranking improvements within 3–4 months, with significant organic traffic growth in 6–9 months. Local SEO (Google Business Profile, local pack rankings) often moves faster — you can see results in 4–8 weeks for well-optimised location signals. The timeline depends on your starting point, the competitiveness of your niche, and the scope of work — I'll give you a realistic forecast at the outset.",
  },
  {
    question: "What areas of Greater Manchester do you cover?",
    answer:
      "I work with businesses across all ten Greater Manchester boroughs: the City of Manchester, Salford, Trafford, Stockport, Tameside, Oldham, Rochdale, Bury, Bolton, and Wigan. I also serve businesses in surrounding areas including Cheshire East, Warrington, and parts of Lancashire that trade into the Manchester market. Remote-first working means location is no barrier — I've delivered results for Manchester clients from national competitors.",
  },
  {
    question: "Do you offer local SEO specifically for Manchester Google Maps rankings?",
    answer:
      "Yes. Google Business Profile optimisation and local pack ranking is a core part of my Manchester SEO offering. This includes GBP setup and ongoing optimisation, NAP (Name, Address, Phone) consistency across local directories, review strategy, local citation building with Manchester-specific sources, and proximity targeting to ensure you appear in local packs for the right geographic searches. See my dedicated Local SEO service page for full details.",
  },
  {
    question: "How much do Manchester SEO services cost?",
    answer:
      "Investment depends on the scope, competitiveness of your sector, and your goals. I offer project-based engagements (such as SEO audits from £750 and local SEO packages from £1,200/month), as well as ongoing retainers for businesses wanting sustained, long-term growth. I'm transparent about pricing — all proposals come with clear deliverables and expected outcomes. Get in touch for a free initial consultation and tailored quote.",
  },
];

const faqSchema = {
  "@context": "https://schema.org",
  "@type": "FAQPage",
  mainEntity: faqs.map((faq) => ({
    "@type": "Question",
    name: faq.question,
    acceptedAnswer: {
      "@type": "Answer",
      text: faq.answer,
    },
  })),
};

const ManchesterFAQ = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      {/* FAQ JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{ __html: JSON.stringify(faqSchema) }}
      />

      <div className="container">
        <div className="text-center max-w-3xl mx-auto mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Common Questions
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-4">
            Manchester SEO — Frequently Asked Questions
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Everything you need to know about SEO in Manchester and how I can help your business grow in the North West.
          </p>
        </div>

        <div className="max-w-3xl mx-auto">
          <Accordion type="single" collapsible className="w-full">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border-border">
                <AccordionTrigger className="text-left font-medium text-foreground hover:text-primary transition-colors">
                  <span className="flex items-center gap-3">
                    <HelpCircle className="h-4 w-4 shrink-0 text-primary" />
                    {faq.question}
                  </span>
                </AccordionTrigger>
                <AccordionContent className="text-muted-foreground leading-relaxed pl-7">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>
        </div>

        <div className="mt-12 text-center">
          <p className="text-muted-foreground text-sm">
            Have a question not answered here?{" "}
            <a href="/contact" className="text-primary font-medium hover:underline">
              Get in touch and I'll respond within 24 hours →
            </a>
          </p>
        </div>
      </div>
    </section>
  );
});

ManchesterFAQ.displayName = "ManchesterFAQ";

export default ManchesterFAQ;
