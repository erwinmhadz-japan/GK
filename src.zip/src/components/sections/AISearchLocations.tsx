import React from "react";
import { motion } from "framer-motion";
import { MapPin, Globe, ArrowRight, Search, Type, View } from "lucide-react";
import { Link } from "react-router-dom";

const locations = [
  {
    name: "Warrington, Cheshire",
    type: "Based here",
    description:
      "I'm an independent SEO consultant based in Warrington, Cheshire — working with clients locally and across the UK from a single point of contact.",
    detail: "Warrington · WA4 5BS",
    icon: MapPin,
    primary: true,
  },
  {
    name: "Manchester",
    type: "Serving Greater Manchester",
    description:
      "I work with businesses across Greater Manchester — from legal and financial firms in the city centre to B2B services throughout the region.",
    detail: "Greater Manchester · M1 & surrounding",
    icon: MapPin,
    primary: false,
  },
  {
    name: "Liverpool",
    type: "Serving Merseyside",
    description:
      "Clients in Liverpool and across Merseyside benefit from the same direct consultancy model — no account managers, no handoffs.",
    detail: "Merseyside · L1 & surrounding",
    icon: MapPin,
    primary: false,
  },
];

const fadeUp = {
  hidden: { opacity: 0, y: 22 },
  visible: (i: number) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut", delay: i * 0.12 },
  }),
};

const AISearchLocations = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="aisearch-locations"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 18 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, ease: "easeOut" }}
          className="mb-12 md:mb-16"
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Location &amp; Reach
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground leading-tight max-w-2xl">
            UK-Based AI Search Consultant
          </h2>
          <p className="mt-4 text-base md:text-lg text-muted-foreground max-w-xl leading-relaxed">
            Based in Warrington, Cheshire — available to businesses nationwide.
            I work directly with clients across the North West and beyond, with
            no agency overhead and no junior intermediaries.
          </p>
        </motion.div>

        {/* Location signposts */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
          {locations.map((loc, i) => {
            const Icon = loc.icon;
            return (
              <motion.div
                key={loc.name}
                custom={i}
                initial="hidden"
                whileInView="visible"
                viewport={{ once: true }}
                variants={fadeUp}
                className={[
                  "relative group rounded-md border p-6 md:p-7 transition-all duration-300",
                  loc.primary
                    ? "bg-[hsl(var(--navy-deep,225_28%_14%))] border-[hsl(var(--navy-mid,231_9%_16%))] shadow-[0_4px_24px_hsl(225_28%_8%/0.35)]"
                    : "bg-background border-border hover:border-[hsl(var(--blue-muted,214_32%_60%)/0.4)] hover:shadow-md",
                ].join(" ")}
              >
                {/* Type badge */}
                <span
                  className={[
                    "inline-block text-xs uppercase tracking-widest font-medium mb-4",
                    loc.primary
                      ? "text-[hsl(var(--green-mid,119_35%_61%))]"
                      : "text-muted-foreground",
                  ].join(" ")}
                >
                  {loc.type}
                </span>

                {/* Icon + name */}
                <div className="flex items-start gap-3 mb-3">
                  <div
                    className={[
                      "flex h-9 w-9 shrink-0 items-center justify-center rounded-md",
                      loc.primary
                        ? "bg-[hsl(var(--green-mid,119_35%_61%)/0.15)]"
                        : "bg-muted",
                    ].join(" ")}
                  >
                    <Icon
                      className={[
                        "h-4 w-4",
                        loc.primary
                          ? "text-[hsl(var(--green-mid,119_35%_61%))]"
                          : "text-muted-foreground",
                      ].join(" ")}
                    />
                  </div>
                  <h3
                    className={[
                      "text-base md:text-lg font-semibold leading-snug pt-1",
                      loc.primary ? "text-white" : "text-foreground",
                    ].join(" ")}
                  >
                    {loc.name}
                  </h3>
                </div>

                {/* Description */}
                <p
                  className={[
                    "text-sm leading-relaxed mb-4",
                    loc.primary ? "text-white/80" : "text-muted-foreground",
                  ].join(" ")}
                >
                  {loc.description}
                </p>

                {/* Detail line */}
                <p
                  className={[
                    "text-xs font-mono",
                    loc.primary
                      ? "text-white/50"
                      : "text-muted-foreground/60",
                  ].join(" ")}
                >
                  {loc.detail}
                </p>
              </motion.div>
            );
          })}
        </div>

        {/* National reach note + link to locations */}
        <motion.div
          initial={{ opacity: 0, y: 14 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.55, ease: "easeOut", delay: 0.42 }}
          className="mt-10 md:mt-12 flex flex-col sm:flex-row items-start sm:items-center gap-4 justify-between border-t border-border pt-8"
        >
          <div className="flex items-start gap-3">
            <Globe className="h-5 w-5 text-muted-foreground shrink-0 mt-0.5" />
            <p className="text-sm text-muted-foreground max-w-lg leading-relaxed">
              I work with clients across the UK — remote-first, with in-person
              meetings available throughout the North West. All consultancy is
              delivered directly by me.
            </p>
          </div>
          <Link
            to="/locations"
            className="inline-flex items-center gap-2 text-sm font-medium text-foreground hover:text-primary transition-colors duration-200 shrink-0 group"
          >
            View all locations
            <ArrowRight className="h-4 w-4 group-hover:translate-x-0.5 transition-transform duration-200" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
});

AISearchLocations.displayName = "AISearchLocations";

export default AISearchLocations;
