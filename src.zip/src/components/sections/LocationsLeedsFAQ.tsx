import React from "react";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { Button } from "@/components/ui/button";

const faqs = [
  {
    question: "How long does it take to see SEO results in Leeds?",
    answer:
      "Most Leeds businesses start seeing measurable improvements in local rankings and organic traffic within 3–4 months. More competitive terms — like 'solicitors Leeds' or 'digital agency Leeds' — typically take 6–12 months to achieve and sustain top-3 positions. The timeline depends on your starting position, the competitiveness of your target keywords, and how quickly technical issues can be resolved.",
  },
  {
    question: "Do I need a Leeds-specific SEO strategy, or is general SEO enough?",
    answer:
      "Leeds has its own search dynamics. Localised intent queries — searches that include 'Leeds', 'West Yorkshire', or nearby towns — require a distinct approach from broad national SEO. A Leeds-specific strategy includes geo-targeted landing pages, Google Business Profile optimisation, Leeds-focused citation building, and content addressing local topics your competitors overlook. General SEO alone leaves significant local visibility on the table.",
  },
  {
    question: "What makes Leeds such a competitive SEO market?",
    answer:
      "Leeds is the UK's third-largest city by economy, home to over 120,000 businesses across legal, finance, tech, retail, healthcare, and professional services. The city's business density means dozens of competitors are often targeting the same local queries. Additionally, national brands have set up Leeds offices, bringing national-level SEO budgets to local search, which raises the bar for independent and regional businesses.",
  },
  {
    question: "Can you help my Leeds business appear in AI search tools like ChatGPT or Google AI Overviews?",
    answer:
      "Yes. AI search visibility is a growing priority for Leeds businesses, particularly in professional services and B2B sectors where buyers research extensively before contacting a provider. We optimise your brand's entity signals, structured data, and content authority so that AI tools like ChatGPT, Perplexity, and Google's AI Overviews cite your business confidently when users ask relevant questions.",
  },
  {
    question: "Do you work with Leeds businesses remotely or in person?",
    answer:
      "We work with most Leeds clients remotely — strategy sessions, reporting, and communication are handled online. For larger projects or initial discovery workshops, we're happy to meet in Leeds. Distance has no impact on the quality or depth of our SEO work.",
  },
];

const LocationsLeedsFAQ = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      {/* FAQ JSON-LD */}
      <script
        type="application/ld+json"
        dangerouslySetInnerHTML={{
          __html: JSON.stringify({
            "@context": "https://schema.org",
            "@type": "FAQPage",
            mainEntity: faqs.map(({ question, answer }) => ({
              "@type": "Question",
              name: question,
              acceptedAnswer: {
                "@type": "Answer",
                text: answer,
              },
            })),
          }),
        }}
      />

      <div className="container">
        <div className="max-w-2xl mx-auto text-center mb-12">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-3">
            Leeds SEO FAQs
          </span>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground">
            Frequently Asked Questions
          </h2>
          <p className="mt-4 text-muted-foreground">
            Common questions from Leeds business owners about SEO, local
            visibility, and working with an independent SEO consultant.
          </p>
        </div>

        <Accordion
          type="single"
          collapsible
          className="w-full max-w-3xl mx-auto mb-12"
        >
          {faqs.map((faq, index) => (
            <AccordionItem key={index} value={`item-${index}`}>
              <AccordionTrigger className="text-left font-medium text-foreground">
                {faq.question}
              </AccordionTrigger>
              <AccordionContent className="text-muted-foreground leading-relaxed">
                {faq.answer}
              </AccordionContent>
            </AccordionItem>
          ))}
        </Accordion>

        <div className="text-center">
          <p className="text-muted-foreground mb-6">
            Have a different question? We're happy to chat about your specific
            Leeds SEO situation.
          </p>
          <div className="flex flex-wrap justify-center gap-4">
            <Button asChild>
              <a href="/contact">Ask a Question</a>
            </Button>
            <Button variant="outline" asChild>
              <a href="/services">Explore Our Services</a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
});

LocationsLeedsFAQ.displayName = "LocationsLeedsFAQ";
export default LocationsLeedsFAQ;
