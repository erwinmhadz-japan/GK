import React from "react";
import { motion, type Variants } from "framer-motion";
import { Link } from "react-router-dom";
import { Gavel, HeartPulse, Home, TrendingUp, Briefcase, ArrowRight, Search, Section, View } from "lucide-react";

const industries = [
  {
    icon: Gavel,
    label: "Law Firms & Solicitors",
    descriptor: "SEO for legal practices competing on high-value, high-trust search terms.",
    href: "/industries-law-firms-solicitors",
    accent: "Legal",
  },
  {
    icon: HeartPulse,
    label: "Healthcare & Private Providers",
    descriptor: "Search visibility for clinics, consultants, and private healthcare services.",
    href: "/industries-healthcare-clinic-private-providers",
    accent: "Healthcare",
  },
  {
    icon: Home,
    label: "Estate Agents & Property",
    descriptor: "Local and national SEO for property services in competitive UK markets.",
    href: "/industries-estate-agents-property-services",
    accent: "Property",
  },
  {
    icon: TrendingUp,
    label: "Financial Services",
    descriptor: "Regulated-sector SEO that builds authority and compliant search presence.",
    href: "/industries-financial-services",
    accent: "Finance",
  },
  {
    icon: Briefcase,
    label: "B2B Professional Services",
    descriptor: "Organic lead generation for consultancies, agencies, and professional firms.",
    href: "/industries-b2b-professional-services",
    accent: "B2B",
  },
];

const containerVariants: Variants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const cardVariants: Variants = {
  hidden: { opacity: 0, y: 28 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.55, ease: "easeOut" },
  },
};

const headingVariants: Variants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.6, ease: "easeOut" } },
};

const HomeIndustries = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="home-industries"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">
        {/* Section header */}
        <motion.div
          className="mb-12 md:mb-16 max-w-2xl"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-80px" }}
          variants={headingVariants}
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-4 font-medium">
            Industries
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground font-[Sora,sans-serif] mb-4 max-w-xl">
            Sector Expertise
          </h2>
          <p className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-prose">
            SEO for regulated and trust-led industries — where search visibility is business-critical.
          </p>
        </motion.div>

        {/* Industry cards — exact 5, single row on lg, 2+3 on md */}
        <motion.div
          className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-4 md:gap-5"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={containerVariants}
        >
          {industries.map((industry) => {
            const Icon = industry.icon;
            return (
              <motion.div key={industry.label} variants={cardVariants}>
                <Link
                  to={industry.href}
                  className="group flex flex-col h-full rounded-md border border-border bg-background p-6 transition-all duration-300 hover:border-primary/60 hover:shadow-md hover:-translate-y-0.5 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
                  aria-label={`View SEO services for ${industry.label}`}
                >
                  {/* Icon */}
                  <div className="mb-4 flex h-10 w-10 items-center justify-center rounded-md bg-primary/10 text-primary transition-colors duration-300 group-hover:bg-primary/20">
                    <Icon className="h-5 w-5" aria-hidden="true" />
                  </div>

                  {/* Accent / sector tag */}
                  <span className="mb-2 text-[10px] uppercase tracking-[0.18em] font-semibold text-muted-foreground">
                    {industry.accent}
                  </span>

                  {/* Name */}
                  <h3 className="mb-2 text-sm md:text-base font-semibold text-foreground leading-snug font-[Sora,sans-serif] group-hover:text-primary transition-colors duration-300">
                    {industry.label}
                  </h3>

                  {/* Descriptor */}
                  <p className="text-xs md:text-sm text-muted-foreground leading-relaxed flex-1">
                    {industry.descriptor}
                  </p>

                  {/* Inline link cue */}
                  <span className="mt-4 inline-flex items-center gap-1 text-xs font-medium text-primary opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                    Explore
                    <ArrowRight className="h-3 w-3 translate-x-0 group-hover:translate-x-0.5 transition-transform duration-300" aria-hidden="true" />
                  </span>
                </Link>
              </motion.div>
            );
          })}
        </motion.div>

        {/* Hub link — subtle text link only, no CTA block */}
        <motion.div
          className="mt-10 md:mt-12"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.4, ease: "easeOut" }}
        >
          <Link
            to="#industries-cta"
            className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-primary transition-colors duration-200 group"
          >
            View all industry sectors
            <ArrowRight className="h-3.5 w-3.5 group-hover:translate-x-0.5 transition-transform duration-200" aria-hidden="true" />
          </Link>
        </motion.div>
      </div>
    </section>
  );
});

HomeIndustries.displayName = "HomeIndustries";

export default HomeIndustries;
