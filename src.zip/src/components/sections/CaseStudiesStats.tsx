import React from "react";
import { TrendingUp, Award, Users, BarChart, Globe, Zap, Icon } from "lucide-react";

const stats = [
  {
    value: "312%",
    label: "Average Traffic Increase",
    description: "Across all active retainer clients in the past 24 months",
    icon: TrendingUp,
  },
  {
    value: "94%",
    label: "Clients Reaching Page 1",
    description: "For their primary target keywords within 6 months",
    icon: Award,
  },
  {
    value: "4.8×",
    label: "Average Lead Growth",
    description: "B2B and professional services clients on SEO retainers",
    icon: Users,
  },
  {
    value: "50+",
    label: "Published Case Studies",
    description: "Spanning legal, healthcare, property, financial, and B2B",
    icon: BarChart,
  },
  {
    value: "17",
    label: "Sectors Served",
    description: "From regulated industries to fast-growth technology companies",
    icon: Globe,
  },
  {
    value: "91%",
    label: "AI Overview Inclusion",
    description: "Clients optimised for AI search featured in ChatGPT or Perplexity",
    icon: Zap,
  },
];

const CaseStudiesStats = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="case-studies-stats"
      className="relative isolate py-20 md:py-32 overflow-hidden"
      aria-label="Case study results statistics"
    >
      {/* Background */}
      <img
        src="https://images.unsplash.com/photo-1571677246347-5040036b95cc?w=1920&h=1080&fit=crop"
        alt="SEO analytics dashboard results on laptop screen"
        className="absolute inset-0 w-full h-full object-cover"
        width={1920}
        height={1080}
        loading="lazy"
      />
      {/* Brand overlay */}
      <div className="absolute inset-0 bg-gradient-to-br from-primary/80 via-primary/55 to-accent/60 pointer-events-none" />

      {/* Content */}
      <div className="container relative z-10">
        <div className="text-center mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-white/80 mb-4">
            Aggregate Results
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-4">
            The Numbers Behind the Work
          </h2>
          <p className="text-base md:text-lg text-white/90 max-w-2xl mx-auto leading-relaxed">
            These figures represent real outcomes across diverse client engagements —
            not cherry-picked wins, but consistent performance at scale.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {stats.map(({ value, label, description, icon: Icon }) => (
            <div
              key={label}
              className="relative bg-white/10 backdrop-blur-sm border border-white/20 rounded-2xl p-6 flex flex-col gap-3 hover:bg-white/15 transition-colors duration-200"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/20">
                <Icon className="h-6 w-6 text-white" />
              </div>
              <div>
                <p className="text-4xl font-bold text-white leading-none mb-1">{value}</p>
                <p className="text-sm font-semibold text-white">{label}</p>
              </div>
              <p className="text-sm text-white/80 leading-relaxed">{description}</p>
            </div>
          ))}
        </div>

        <p className="mt-10 text-center text-xs text-white/80">
          Results based on aggregated data from active and completed client engagements. Individual results may vary.
        </p>
      </div>
    </section>
  );
});

CaseStudiesStats.displayName = "CaseStudiesStats";

export default CaseStudiesStats;
