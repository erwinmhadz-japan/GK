import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "react-router-dom";
import { ArrowRight, CheckCheck, TrendingUp, Clock, Icon } from "lucide-react";

const SeoRetainerHero = React.forwardRef<HTMLElement>((props, ref) => {
  const pillars = [
    { icon: TrendingUp, text: "Sustained organic growth" },
    { icon: CheckCheck, text: "Monthly strategic oversight" },
    { icon: Clock, text: "Direct consultant access" },
  ];

  return (
    <section
      ref={ref}
      id="seo-retainer-hero"
      className="relative py-24 md:py-36 border-t border-border bg-[hsl(225_28%_14%)] overflow-hidden"
      aria-label="SEO Retainer Consultant UK hero"
    >
      {/* Subtle dot-grid texture */}
      <div
        className="absolute inset-0 opacity-[0.04] pointer-events-none"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(214 32% 60%) 1px, transparent 1px)",
          backgroundSize: "28px 28px",
        }}
        aria-hidden="true"
      />

      {/* Subtle green gradient accent — top-right corner */}
      <div
        className="absolute -top-32 -right-32 w-96 h-96 rounded-full opacity-10 pointer-events-none blur-3xl"
        style={{
          background:
            "radial-gradient(circle, hsl(84 74% 58%) 0%, transparent 70%)",
        }}
        aria-hidden="true"
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl">
          {/* Eyebrow badge */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, ease: "easeOut", delay: 0 }}
            className="mb-6"
          >
            <Badge
              variant="outline"
              className="border-[hsl(214_32%_60%)/40] text-[hsl(214_32%_60%)] bg-transparent text-xs uppercase tracking-[0.18em] px-3 py-1"
            >
              Independent SEO Consultant UK
            </Badge>
          </motion.div>

          {/* H1 — primary keyword */}
          <motion.h1
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.1 }}
            className="text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-[1.1] tracking-tight font-[Sora,sans-serif]"
          >
            SEO Retainer{" "}
            <span
              className="inline-block"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                WebkitBackgroundClip: "text",
                WebkitTextFillColor: "transparent",
                backgroundClip: "text",
              }}
            >
              Consultant UK
            </span>
          </motion.h1>

          {/* Subheadline — muted blue */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.2 }}
            className="mt-6 text-lg md:text-xl text-[hsl(214_32%_60%)] leading-relaxed max-w-2xl font-[Inter,sans-serif]"
          >
            Ongoing SEO expertise on a retained basis — consistent, strategic, and accountable.
          </motion.p>

          {/* Supporting copy — first person, consultant voice */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.28 }}
            className="mt-4 text-base text-white/80 leading-relaxed max-w-2xl font-[Inter,sans-serif]"
          >
            I work with UK businesses on a retained basis to deliver sustained organic growth — not a one-off project, but a continuous strategic engagement with direct access to me as your consultant every month.
          </motion.p>

          {/* Three-pillar trust indicators */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.36 }}
            className="mt-8 flex flex-wrap gap-4"
          >
            {pillars.map(({ icon: Icon, text }) => (
              <div
                key={text}
                className="flex items-center gap-2 text-sm text-white/80 font-[Inter,sans-serif]"
              >
                <div className="flex h-7 w-7 items-center justify-center rounded-md bg-[hsl(84_74%_58%)/15]">
                  <Icon className="h-4 w-4 text-[hsl(84_74%_58%)]" />
                </div>
                <span>{text}</span>
              </div>
            ))}
          </motion.div>

          {/* CTA group */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.44 }}
            className="mt-10 flex flex-wrap items-center gap-4"
          >
            <Button
              asChild
              size="lg"
              className="text-base h-12 px-8 font-semibold font-[Inter,sans-serif]"
              style={{
                background:
                  "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                color: "hsl(225 28% 14%)",
                border: "none",
              }}
            >
              <Link to="/contact">
                Get in Touch
                <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>

            <Button
              asChild
              size="lg"
              variant="outline"
              className="text-base h-12 px-8 bg-transparent text-white border-white/25 hover:bg-white/8 hover:border-white/40 font-[Inter,sans-serif]"
            >
              <Link to="/seo-audit">
                FREE GBP AUDIT
              </Link>
            </Button>
          </motion.div>

          {/* Trust note */}
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.65, ease: "easeOut", delay: 0.54 }}
            className="mt-5 text-sm text-white/80 font-[Inter,sans-serif]"
          >
            Based in Warrington, Cheshire — working with UK businesses across competitive sectors.
          </motion.p>
        </div>
      </div>
    </section>
  );
});

SeoRetainerHero.displayName = "SeoRetainerHero";

export default SeoRetainerHero;
