import React from "react";
import { Globe, Search, TrendingUp, Zap, Heading, Scale } from "lucide-react";

const stats = [
  { value: "~47%", label: "of US searches now trigger an AI Overview" },
  { value: "Top 3", label: "citations come almost exclusively from page-1 results" },
  { value: "2x", label: "more likely to be cited with strong EEAT signals" },
  { value: "2024", label: "global rollout following UK & US launch" },
];

const highlights = [
  {
    icon: Search,
    title: "What Are Google AI Overviews?",
    body:
      "Google AI Overviews (formerly Search Generative Experience / SGE) are AI-generated summaries that appear at the top of Google search results pages. They synthesise information from multiple sources to directly answer a user's query, often displacing traditional blue-link results for informational and research-led searches.",
  },
  {
    icon: Globe,
    title: "Scale & Reach",
    body:
      "Following a broad rollout in the US and UK in 2024, AI Overviews now appear across hundreds of millions of queries globally. Google has stated that AI Overviews generate more search traffic to supporting websites than equivalent traditional snippets — but only for sources that are cited.",
  },
  {
    icon: TrendingUp,
    title: "Why It Matters for Your Business",
    body:
      "AI Overviews fundamentally change organic visibility. A brand that does not appear in AI-generated citations risks being invisible even when it ranks on page one. Proactively optimising for AI Overview inclusion is now a core component of any future-focused SEO strategy.",
  },
  {
    icon: Zap,
    title: "From SGE to AI Overviews",
    body:
      "Google rebranded SGE as 'AI Overviews' to reflect its shift from an experimental feature to a core part of search. The underlying technology — Google's Gemini model — pulls from indexed content, evaluates source quality, and assembles a multi-source answer that links out to the most trustworthy results.",
  },
];

const AiSearchGoogleAiOverviewsWhat = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        {/* Heading */}
        <div className="max-w-3xl mx-auto text-center mb-16">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
            Understanding AI Overviews
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">
            What Are Google AI Overviews?
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Google AI Overviews represent the most significant change to search results
            in over a decade — here's everything you need to know about how they work
            and what reach they have.
          </p>
        </div>

        {/* Stats row */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-6 mb-16">
          {stats.map((stat) => (
            <div
              key={stat.value}
              className="text-center rounded-xl border border-border bg-muted/40 p-6"
            >
              <div className="text-3xl md:text-4xl font-bold text-primary mb-2">
                {stat.value}
              </div>
              <div className="text-sm text-muted-foreground leading-snug">
                {stat.label}
              </div>
            </div>
          ))}
        </div>

        {/* Highlights grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {highlights.map((item) => (
            <div
              key={item.title}
              className="rounded-xl border border-border bg-card p-8 hover-lift shadow-soft"
            >
              <div className="flex h-12 w-12 items-center justify-center rounded-lg bg-primary/10 mb-5">
                <item.icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-xl font-bold text-foreground mb-3">{item.title}</h3>
              <p className="text-muted-foreground leading-relaxed">{item.body}</p>
            </div>
          ))}
        </div>

        {/* Internal link nudge */}
        <p className="mt-10 text-center text-sm text-muted-foreground">
          Want the full picture?{" "}
          <a href="#ai-search-cta" className="text-primary underline hover:no-underline font-medium">
            Explore our complete AI Search guide
          </a>{" "}
          or learn how{" "}
          <a href="/entity-seo" className="text-primary underline hover:no-underline font-medium">
            Entity SEO
          </a>{" "}
          drives AI citation success.
        </p>
      </div>
    </section>
  );
});

AiSearchGoogleAiOverviewsWhat.displayName = "AiSearchGoogleAiOverviewsWhat";

export default AiSearchGoogleAiOverviewsWhat;
