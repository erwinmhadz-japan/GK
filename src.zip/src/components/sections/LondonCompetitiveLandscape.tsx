import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BarChart2, Building2, Globe, Shield, Target, Zap, Building } from "lucide-react";

const challenges = [
  {
    icon: BarChart2,
    title: "Extreme Keyword Competition",
    description:
      "London-based searches like 'SEO agency London' or 'solicitor London' attract tens of thousands of monthly searches — and hundreds of agencies bidding for the same real estate. Generic tactics won't cut it.",
  },
  {
    icon: Building2,
    title: "Multi-Borough Targeting",
    description:
      "Reaching customers across Shoreditch, Canary Wharf, Chelsea, and Croydon requires hyper-local strategies that account for different search behaviours and intent patterns across London's 33 boroughs.",
  },
  {
    icon: Globe,
    title: "International Competition",
    description:
      "London attracts global players. Your SEO strategy must compete not just with local rivals but with international brands who have invested heavily in London's digital market.",
  },
  {
    icon: Zap,
    title: "Algorithm Sensitivity",
    description:
      "London-targeted search results are among the first to reflect Google's core updates. Staying ahead requires continuous monitoring and rapid adaptation — especially for YMYL industries.",
  },
  {
    icon: Shield,
    title: "E-E-A-T Demands",
    description:
      "Google's Experience, Expertise, Authoritativeness, and Trustworthiness signals are scrutinised intensely in London's finance, legal, and healthcare sectors. Building genuine authority takes expert guidance.",
  },
  {
    icon: Target,
    title: "Rising Click Costs",
    description:
      "London CPCs on Google Ads are among the highest in the UK. Organic SEO provides a long-term alternative that compounds in value — but only with a coherent, well-executed strategy.",
  },
];

const LondonCompetitiveLandscape = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="london-competitive-landscape"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        <div className="max-w-2xl mx-auto text-center mb-14">
          <Badge variant="outline" className="mb-4 text-primary border-primary/30">
            The London Challenge
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Why London SEO Demands a Specialist Approach
          </h2>
          <p className="text-muted-foreground text-lg leading-relaxed">
            The capital's digital landscape is unlike anywhere else in the UK. Here's what makes
            London SEO uniquely complex — and why cookie-cutter approaches consistently fail.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {challenges.map((item) => {
            const Icon = item.icon;
            return (
              <Card key={item.title} className="hover-lift shadow-card border-border bg-card">
                <CardHeader className="pb-3">
                  <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-3">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <CardTitle className="text-lg text-foreground">{item.title}</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground text-sm leading-relaxed">{item.description}</p>
                </CardContent>
              </Card>
            );
          })}
        </div>

        <div className="mt-12 text-center">
          <p className="text-muted-foreground text-sm">
            Ready to overcome London's SEO challenges?{" "}
            <a href="/local-seo" className="text-primary font-medium hover:underline">
              Explore our Local SEO services →
            </a>
          </p>
        </div>
      </div>
    </section>
  );
});

LondonCompetitiveLandscape.displayName = "LondonCompetitiveLandscape";
export default LondonCompetitiveLandscape;
