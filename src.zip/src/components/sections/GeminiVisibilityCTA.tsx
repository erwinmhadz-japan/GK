import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, Sparkles, Search } from "lucide-react";

const GeminiVisibilityCTA = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="gemini-visibility-cta"
      className="relative py-20 md:py-28 border-t border-border bg-muted overflow-hidden"
      style={{
        background: "hsl(225 28% 14%)",
      }}
    >
      {/* Subtle dot grid background texture */}
      <div
        className="absolute inset-0 pointer-events-none opacity-30"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(84 74% 58% / 0.12) 1px, transparent 1px)",
          backgroundSize: "32px 32px",
        }}
        aria-hidden="true"
      />

      {/* Ambient green glow */}
      <div
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[300px] rounded-full pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse at center, hsl(84 74% 58% / 0.08) 0%, transparent 70%)",
        }}
        aria-hidden="true"
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <div className="max-w-3xl mx-auto text-center">
          {/* Eyebrow label */}
          <motion.div
            initial={{ opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.55, ease: "easeOut" }}
            className="flex items-center justify-center gap-2 mb-6"
          >
            <Sparkles
              className="h-4 w-4"
              style={{ color: "hsl(84 74% 58%)" }}
              aria-hidden="true"
            />
            <span
              className="text-xs uppercase tracking-[0.2em] font-medium"
              style={{ color: "hsl(84 74% 58%)" }}
            >
              AI Search Optimisation
            </span>
          </motion.div>

          {/* Main headline */}
          <motion.h2
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-white leading-tight mb-6"
            style={{ fontFamily: "Sora, sans-serif" }}
          >
            Want to Appear in Google Gemini Answers?
          </motion.h2>

          {/* Subheadline */}
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.2 }}
            className="text-base md:text-lg leading-relaxed mb-10 max-w-2xl mx-auto"
            style={{ color: "hsl(0 0% 100% / 0.80)", fontFamily: "Inter, sans-serif" }}
          >
            Explore Gregg King's AI Search Optimisation service — the commercial
            offering behind Gemini and wider AI visibility.
          </motion.p>

          {/* CTA button */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Button
              asChild
              size="lg"
              className="h-12 px-8 text-base font-semibold transition-all duration-300"
              style={{
                background: "linear-gradient(135deg, hsl(84 74% 58%), hsl(119 35% 61%))",
                color: "hsl(225 28% 14%)",
                boxShadow: "0 0 0 0 hsl(84 74% 58% / 0)",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.boxShadow =
                  "0 0 32px hsl(84 74% 58% / 0.35)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.boxShadow =
                  "0 0 0 0 hsl(84 74% 58% / 0)";
              }}
            >
              <Link to="/ai-search-optimisation">
                AI Search Optimisation
                <ArrowRight className="ml-2 h-4 w-4" aria-hidden="true" />
              </Link>
            </Button>

            <Button
              asChild
              size="lg"
              variant="ghost"
              className="h-12 px-6 text-base font-medium border transition-colors duration-200"
              style={{
                color: "hsl(0 0% 100% / 0.80)",
                borderColor: "hsl(0 0% 100% / 0.20)",
                background: "transparent",
              }}
              onMouseEnter={(e) => {
                (e.currentTarget as HTMLElement).style.background =
                  "hsl(0 0% 100% / 0.08)";
                (e.currentTarget as HTMLElement).style.color =
                  "hsl(0 0% 100%)";
              }}
              onMouseLeave={(e) => {
                (e.currentTarget as HTMLElement).style.background =
                  "transparent";
                (e.currentTarget as HTMLElement).style.color =
                  "hsl(0 0% 100% / 0.80)";
              }}
            >
              <Link to="/contact">Get in Touch</Link>
            </Button>
          </motion.div>

          {/* Trust note */}
          <motion.p
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, ease: "easeOut", delay: 0.45 }}
            className="mt-8 text-sm"
            style={{ color: "hsl(0 0% 100% / 0.50)" }}
          >
            Independent UK SEO consultant · No agency overheads · Direct senior-level work
          </motion.p>
        </div>
      </div>
    </section>
  );
});

GeminiVisibilityCTA.displayName = "GeminiVisibilityCTA";

export default GeminiVisibilityCTA;
