import React from "react";
import { motion } from "framer-motion";
import { Network, Database, Search, Globe, Brain, Link2, Layers, Building, Section } from "lucide-react";

const fadeUp = {
  hidden: { opacity: 0, y: 24 },
  visible: (delay: number = 0) => ({
    opacity: 1,
    y: 0,
    transition: { duration: 0.6, ease: "easeOut", delay },
  }),
};

const concepts = [
  {
    icon: Network,
    term: "Knowledge Graphs",
    explanation:
      "Google's Knowledge Graph is a vast database of real-world entities — people, organisations, places, and concepts — and the relationships between them. Rather than matching keywords, Google maps entities to one another to understand context and meaning.",
  },
  {
    icon: Brain,
    term: "Entity Disambiguation",
    explanation:
      "When two entities share a name, Google must determine which is relevant to a given query. Entity SEO creates clear, unambiguous signals that distinguish your brand from others — ensuring search engines identify you correctly and consistently.",
  },
  {
    icon: Database,
    term: "Structured Data",
    explanation:
      "Schema markup provides machine-readable context for your content. By annotating your pages with structured data, you give search engines explicit signals about your organisation type, services, location, and authority.",
  },
  {
    icon: Globe,
    term: "Brand Entities",
    explanation:
      "Your brand is an entity in its own right. Building a strong brand entity means creating consistent, corroborated signals across the web — your website, Google Business Profile, Wikipedia, Wikidata, and authoritative third-party sources.",
  },
  {
    icon: Search,
    term: "Beyond Keywords",
    explanation:
      "Traditional SEO optimises for keywords. Entity SEO optimises for meaning. Google's algorithms are designed to understand topics, not just match strings. Businesses that build entity authority rank more reliably across a broader range of relevant queries.",
  },
  {
    icon: Link2,
    term: "Entity Co-occurrence",
    explanation:
      "When authoritative sources consistently mention your brand alongside the services you offer and the sector you serve, Google associates your entity with those topics. This co-occurrence is a foundational signal for entity authority.",
  },
];

const EntitySeoWhatIsIt = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="entity-seo-what-is-it"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <div className="max-w-3xl mb-14 md:mb-20">
          <motion.span
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={0}
            className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground font-medium mb-4"
          >
            Foundational concepts
          </motion.span>

          <motion.h2
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={0.08}
            className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground leading-tight mb-6"
          >
            What Is Entity SEO?
          </motion.h2>

          <motion.p
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={0.16}
            className="text-base md:text-lg text-muted-foreground leading-relaxed max-w-2xl"
          >
            Entity SEO is the practice of helping search engines understand your brand as a distinct, trusted entity in the world — not simply a collection of keywords on a page. It is the foundation of how modern search engines, from Google to AI-powered platforms, comprehend and represent businesses, organisations, and individuals.
          </motion.p>
        </div>

        {/* Introductory explainer block */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          custom={0.22}
          className="bg-background border border-border rounded-md p-7 md:p-10 mb-14 md:mb-20"
          style={{ boxShadow: "0 4px 24px -6px hsl(222 28% 11% / 0.10), 0 1px 4px hsl(222 28% 11% / 0.05)" }}
        >
          <div className="flex flex-col md:flex-row md:gap-10 gap-6">
            <div className="flex-shrink-0 flex items-start">
              <div className="flex items-center justify-center w-12 h-12 rounded-md bg-primary/10">
                <Layers className="h-6 w-6 text-primary" />
              </div>
            </div>
            <div className="space-y-4">
              <p className="text-foreground text-base md:text-lg leading-relaxed">
                Google no longer reads your website in isolation. It builds a model of the world — a knowledge graph — made up of entities and the relationships between them. An entity is any real-world thing: a person, a business, a location, a service, a concept. When Google understands your brand as an entity — who you are, what you do, and why you are authoritative — it can surface you across a far broader set of queries, including AI-generated answers, featured snippets, and Knowledge Panels.
              </p>
              <p className="text-muted-foreground text-base leading-relaxed">
                For UK businesses operating in competitive, trust-led sectors — law, finance, healthcare, professional services — this distinction matters enormously. Authority and credibility are not just marketing attributes; they are ranking signals. Entity SEO is how you encode them into the architecture of the web.
              </p>
            </div>
          </div>
        </motion.div>

        {/* Core concepts grid */}
        <div className="mb-10">
          <motion.h3
            variants={fadeUp}
            initial="hidden"
            whileInView="visible"
            viewport={{ once: true }}
            custom={0}
            className="text-xl md:text-2xl font-semibold text-foreground mb-8"
          >
            Core concepts explained
          </motion.h3>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {concepts.map((concept, index) => {
              const Icon = concept.icon;
              return (
                <motion.div
                  key={concept.term}
                  variants={fadeUp}
                  initial="hidden"
                  whileInView="visible"
                  viewport={{ once: true }}
                  custom={0.06 + index * 0.07}
                  className="bg-background border border-border rounded-md p-6 flex flex-col gap-4 hover:border-primary/40 transition-colors duration-300"
                  style={{ boxShadow: "0 2px 12px -2px hsl(222 28% 11% / 0.06), 0 1px 3px hsl(222 28% 11% / 0.04)" }}
                >
                  <div className="flex items-center gap-3">
                    <div className="flex items-center justify-center w-9 h-9 rounded-md bg-primary/10 flex-shrink-0">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <h4 className="text-sm font-semibold text-foreground">
                      {concept.term}
                    </h4>
                  </div>
                  <p className="text-sm text-muted-foreground leading-relaxed">
                    {concept.explanation}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>

        {/* Closing clarification note */}
        <motion.div
          variants={fadeUp}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          custom={0.1}
          className="border-t border-border pt-10 mt-10 flex flex-col md:flex-row md:items-start gap-6"
        >
          <div className="flex-shrink-0">
            <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10">
              <Brain className="h-5 w-5 text-primary" />
            </div>
          </div>
          <div className="space-y-3 max-w-3xl">
            <p className="text-sm font-semibold text-foreground uppercase tracking-wide">
              How this differs from traditional SEO
            </p>
            <p className="text-sm md:text-base text-muted-foreground leading-relaxed">
              Traditional on-page SEO optimises for keyword relevance — placing the right words in the right places. Entity SEO goes further: it establishes your brand identity across the entire web, so that search engines and AI platforms confidently associate you with your sector, your services, and your expertise. The two approaches are complementary, but entity optimisation is increasingly what separates brands that appear in AI-generated answers from those that do not.
            </p>
          </div>
        </motion.div>

      </div>
    </section>
  );
});

EntitySeoWhatIsIt.displayName = "EntitySeoWhatIsIt";

export default EntitySeoWhatIsIt;
