import React from "react";
import { Search, MapPin, Target, Shield, TrendingUp, CheckCircle, Book, Building, Icon, Section } from "lucide-react";
import { Button } from "@/components/ui/button";

const strategyPillars = [
  {
    icon: MapPin,
    title: "Hyperlocal Keyword Architecture",
    body: "We map intent across Birmingham's neighbourhoods — from Harborne to Handsworth, Moseley to the Jewellery Quarter. Your pages rank for the suburb-level searches your competitors overlook, driving qualified local traffic from people ready to buy.",
  },
  {
    icon: Search,
    title: "Google Business Profile Optimisation",
    body: "Birmingham's local pack is fiercely contested. We fully optimise your GBP listing — categories, service areas, Q&A, photos, and review velocity — to secure your place in the map results that drive the majority of local clicks.",
  },
  {
    icon: Target,
    title: "B2B Intent Targeting",
    body: "Birmingham's strong B2B economy means procurement-stage and decision-stage keywords can deliver high-value leads. We research commercial intent queries in your sector and build content that converts professional buyers, not just browsers.",
  },
  {
    icon: Shield,
    title: "Technical SEO Foundation",
    body: "Core Web Vitals, structured data, crawl efficiency, and site architecture — the technical scaffolding that keeps Google's algorithms happy and your rankings stable. We audit and fix issues that undermine even good content.",
  },
  {
    icon: TrendingUp,
    title: "Authority Building in the Midlands",
    body: "Local citations, regional media placements, and links from Midlands business directories and trade publications build topical authority that national competitors can't easily replicate. Provable local trust signals accelerate ranking velocity.",
  },
  {
    icon: CheckCircle,
    title: "Monthly Reporting & Strategy Reviews",
    body: "Transparent, jargon-free reports tied to business outcomes — rankings, traffic, enquiries, and pipeline. Strategy evolves with algorithm updates and competitive shifts so you're never caught off guard.",
  },
];

const localTactics = [
  "Birmingham-specific keyword research across all 69 wards",
  "Multi-location landing pages for Solihull, Coventry & Black Country",
  "Local schema markup for services, reviews, and events",
  "NAP consistency audit across 50+ directories",
  "Competitor gap analysis in your Birmingham niche",
  "Review generation and reputation management",
];

const BirminghamStrategy = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="birmingham-strategy"
      className="relative py-20 md:py-32 border-t border-border bg-muted"
    >
      <div className="container">
        {/* Section header */}
        <div className="max-w-3xl mb-14">
          <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-primary font-semibold mb-4">
            Local SEO Strategy
          </span>
          <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-5">
            How We Win Search in Birmingham
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Birmingham's search landscape rewards specificity. Broad national SEO
            tactics rarely cut through in a city where local proximity, industry
            signals, and neighbourhood relevance drive ranking decisions. Our
            Birmingham SEO methodology is built on six interconnected pillars.
          </p>
        </div>

        {/* Strategy pillars */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
          {strategyPillars.map(({ icon: Icon, title, body }) => (
            <div
              key={title}
              className="bg-card border border-border rounded-xl p-7 shadow-soft hover-lift group"
            >
              <div className="h-12 w-12 rounded-xl bg-primary/10 flex items-center justify-center mb-5 group-hover:bg-primary/20 transition-colors">
                <Icon className="h-6 w-6 text-primary" />
              </div>
              <h3 className="text-lg font-semibold text-foreground mb-3">{title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">{body}</p>
            </div>
          ))}
        </div>

        {/* Local tactics checklist + CTA */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10 items-start">
          <div className="bg-card border border-border rounded-xl p-8 shadow-soft">
            <h3 className="text-xl font-bold text-foreground mb-6">
              Birmingham-Specific Tactics Included in Every Retainer
            </h3>
            <ul className="space-y-3">
              {localTactics.map((tactic) => (
                <li key={tactic} className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-primary shrink-0 mt-0.5" />
                  <span className="text-muted-foreground text-sm">{tactic}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="space-y-6">
            <div className="bg-gradient-hero-panel rounded-xl p-8 shadow-card">
              <h3 className="text-xl font-bold text-white mb-4">
                Ready to Dominate Birmingham Search Results?
              </h3>
              <p className="text-white/80 text-sm mb-6 leading-relaxed">
                Book a free 30-minute SEO strategy call. We'll review your current
                rankings, identify quick wins in your Birmingham market, and outline
                a roadmap to page 1.
              </p>
              <Button
                size="lg"
                className="bg-primary text-primary-foreground hover:bg-primary/90 w-full font-semibold"
                asChild
              >
                <a href="/contact">Book Your Free Strategy Call</a>
              </Button>
            </div>

            <div className="bg-card border border-border rounded-xl p-6 shadow-soft">
              <p className="text-sm text-muted-foreground leading-relaxed">
                Not sure if you need local SEO or a broader search strategy?
                Explore our full{" "}
                <a
                  href="/local-seo"
                  className="text-primary underline underline-offset-2 hover:text-primary/80 transition-colors"
                >
                  Local SEO service
                </a>{" "}
                or review our{" "}
                <a
                  href="/services"
                  className="text-primary underline underline-offset-2 hover:text-primary/80 transition-colors"
                >
                  full services portfolio
                </a>{" "}
                to find the right engagement for your growth stage.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

BirminghamStrategy.displayName = "BirminghamStrategy";

export default BirminghamStrategy;
