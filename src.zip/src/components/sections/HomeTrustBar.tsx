import React from "react";
import { motion } from "framer-motion";
import { UserCheck, MapPin, ShieldCheck, Brain } from "lucide-react";

const trustItems = [
  {
    icon: UserCheck,
    label: "Independent consultant — not an agency",
  },
  {
    icon: ShieldCheck,
    label: "Specialist in trust-led & regulated sectors",
  },
  {
    icon: MapPin,
    label: "National reach from Warrington, Cheshire",
  },
  {
    icon: Brain,
    label: "AI search & entity SEO expertise",
  },
];

const HomeTrustBar = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="home-trust-bar"
      className="relative py-4 md:py-5 border-t border-border bg-muted overflow-hidden"
      aria-label="Trust signals"
    >
      {/* Subtle dot texture */}
      <div
        className="pointer-events-none absolute inset-0 opacity-30"
        aria-hidden="true"
        style={{
          backgroundImage:
            "radial-gradient(circle, hsl(var(--border)) 1px, transparent 1px)",
          backgroundSize: "20px 20px",
        }}
      />

      <div className="container max-w-6xl mx-auto px-4 relative z-10">
        <ul className="flex flex-col sm:flex-row sm:flex-wrap items-start sm:items-center justify-center gap-y-3 gap-x-8 md:gap-x-10 lg:gap-x-14">
          {trustItems.map((item, index) => {
            const Icon = item.icon;
            return (
              <motion.li
                key={item.label}
                initial={{ opacity: 0, y: 8 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{
                  duration: 0.5,
                  ease: "easeOut",
                  delay: index * 0.08,
                }}
                className="flex items-center gap-2.5 group"
              >
                {/* Icon pip */}
                <span
                  className="flex-shrink-0 flex items-center justify-center w-6 h-6 rounded-sm bg-primary/15"
                  aria-hidden="true"
                >
                  <Icon className="h-3.5 w-3.5 text-primary" strokeWidth={2} />
                </span>

                {/* Label */}
                <span className="text-xs font-medium tracking-wide uppercase text-muted-foreground leading-none whitespace-nowrap">
                  {item.label}
                </span>
              </motion.li>
            );
          })}
        </ul>
      </div>
    </section>
  );
});

HomeTrustBar.displayName = "HomeTrustBar";

export default HomeTrustBar;
