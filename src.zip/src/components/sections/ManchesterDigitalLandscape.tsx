import React from "react";
import { Building2, Users, TrendingUp, Award, Construction, Image, Key, View } from "lucide-react";

const stats = [
  {
    icon: Building2,
    value: "80,000+",
    label: "Businesses in Greater Manchester",
    description: "One of the UK's largest business ecosystems outside London.",
  },
  {
    icon: Users,
    value: "3.2M",
    label: "Population Across Greater Manchester",
    description: "The largest metropolitan area in the UK outside the capital.",
  },
  {
    icon: TrendingUp,
    value: "£75B",
    label: "Annual Economic Output",
    description: "Manchester's economy rivals many European capitals in scale and growth.",
  },
  {
    icon: Award,
    value: "Top 3",
    label: "UK Digital & Tech Hub",
    description: "MediaCityUK, NOMA, and Spinningfields drive Manchester's digital reputation.",
  },
];

const sectors = [
  "Financial & Professional Services",
  "Digital, Tech & Media",
  "Healthcare & Life Sciences",
  "Retail & eCommerce",
  "Hospitality & Tourism",
  "Education & Universities",
  "Manufacturing & Engineering",
  "Construction & Property",
];

const ManchesterDigitalLandscape = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          {/* Left: copy */}
          <div>
            <span className="inline-block text-xs md:text-sm uppercase tracking-[0.2em] text-muted-foreground mb-4">
              The Manchester Market
            </span>
            <h2 className="text-3xl md:text-5xl font-bold text-foreground mb-6">
              Manchester's Digital Landscape — A Market Worth Winning
            </h2>
            <p className="text-lg text-muted-foreground mb-6 leading-relaxed">
              Manchester is the UK's second city in all but name. Its thriving economy, diverse industry base, and digitally savvy population make it one of the most competitive — and rewarding — local search markets in Britain.
            </p>
            <p className="text-base text-muted-foreground mb-8 leading-relaxed">
              Businesses that dominate Manchester search results capture a massive, high-intent audience. Whether you serve Salford, Stockport, Bury, or the city centre, strong SEO is the difference between being found — and being invisible.
            </p>

            <div className="mb-8">
              <h3 className="text-base font-semibold text-foreground mb-4">Key Sectors We Serve in Manchester</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                {sectors.map((sector, i) => (
                  <div key={i} className="flex items-center gap-2">
                    <div className="h-1.5 w-1.5 rounded-full bg-primary flex-shrink-0" />
                    <span className="text-sm text-muted-foreground">{sector}</span>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex flex-wrap gap-3">
              <a
                href="#industries-cta"
                className="inline-flex items-center gap-1 text-sm text-primary font-medium hover:underline"
              >
                View all industries we serve →
              </a>
            </div>
          </div>

          {/* Right: stats */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
            {stats.map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div
                  key={index}
                  className="bg-card border border-border rounded-xl p-6 shadow-card hover-lift"
                >
                  <div className="flex h-11 w-11 items-center justify-center rounded-lg bg-primary/10 mb-4">
                    <Icon className="h-5 w-5 text-primary" />
                  </div>
                  <div className="text-3xl font-bold text-foreground mb-1">{stat.value}</div>
                  <div className="text-sm font-semibold text-foreground mb-2">{stat.label}</div>
                  <p className="text-xs text-muted-foreground leading-relaxed">{stat.description}</p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Image band */}
        <div className="mt-16 rounded-2xl overflow-hidden relative h-64 md:h-80">
          <img
            src="https://images.unsplash.com/photo-1519389950473-47ba0277781c?w=1920&h=600&fit=crop"
            alt="Manchester business professionals collaborating around laptops in a modern workspace"
            width="1920"
            height="600"
            loading="lazy"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-foreground/60 to-transparent" />
          <div className="absolute inset-0 flex items-center">
            <div className="container">
              <p className="text-white text-xl md:text-2xl font-semibold max-w-md">
                Manchester businesses deserve SEO built for the North West market.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
});

ManchesterDigitalLandscape.displayName = "ManchesterDigitalLandscape";

export default ManchesterDigitalLandscape;
