import React from "react";
import { motion } from "framer-motion";
import { Link } from "react-router-dom";
import { ChevronRight, Building, Search, Section, Text } from "lucide-react";

interface Service {
  title: string;
  description: string;
  href: string;
}

const services: Service[] = [
  {
    title: "SEO Consulting",
    description: "Strategic SEO direction tailored to your business — no templates, no handoffs.",
    href: "#seo-consulting-cta",
  },
  {
    title: "SEO Audit",
    description: "A thorough, technical audit of your site's current search performance and opportunities.",
    href: "/seo-audit",
  },
  {
    title: "SEO Retainer",
    description: "Ongoing monthly consultancy for businesses that need consistent, strategic SEO support.",
    href: "/seo-retainer",
  },
  {
    title: "Technical SEO",
    description: "Crawlability, indexation, Core Web Vitals, and site architecture — resolved at source.",
    href: "/technical-seo",
  },
  {
    title: "Schema Markup",
    description: "Structured data implementation to help search engines and AI platforms understand your content.",
    href: "/schema-markup",
  },
  {
    title: "Entity SEO",
    description: "Building your brand as a recognised, trusted entity across the knowledge graph.",
    href: "/entity-seo",
  },
  {
    title: "Content Strategy",
    description: "Keyword-mapped, intent-led content planning that builds topical authority over time.",
    href: "/content-strategy",
  },
  {
    title: "Local SEO",
    description: "Location-specific visibility for UK businesses competing in regional and city-level searches.",
    href: "/local-seo",
  },
  {
    title: "Digital PR",
    description: "Earning authoritative UK press coverage and citations that strengthen your backlink profile.",
    href: "/digital-pr",
  },
  {
    title: "AI Search Optimisation",
    description: "Optimising for visibility in ChatGPT, Perplexity, Gemini, and Google AI Overviews.",
    href: "/ai-search-optimisation",
  },
];

const containerVariants = {
  hidden: {},
  visible: {
    transition: {
      staggerChildren: 0.06,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 16 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.45, ease: "easeOut" },
  },
};

const headingVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0, transition: { duration: 0.55, ease: "easeOut" } },
};

const AISearchServices = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section
      ref={ref}
      id="aisearch-services"
      className="relative py-20 md:py-32 border-t border-border bg-background"
    >
      <div className="container max-w-6xl mx-auto px-4">

        {/* Section header */}
        <motion.div
          className="mb-12 md:mb-16"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-60px" }}
          variants={headingVariants}
        >
          <span className="inline-block text-xs uppercase tracking-[0.2em] text-muted-foreground mb-3 font-medium">
            Full-Service SEO
          </span>
          <h2 className="text-2xl md:text-3xl lg:text-4xl font-bold text-foreground max-w-2xl leading-tight">
            AI Search Optimisation Services
          </h2>
          <p className="mt-4 text-base text-muted-foreground max-w-xl leading-relaxed">
            AI search optimisation sits within a broader SEO strategy. Below are the ten services I offer — each one
            plays a distinct role in building visibility, authority, and trust across both traditional and AI-powered
            search.
          </p>
        </motion.div>

        {/* Service card grid — exactly 10 items in a 2-column layout */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 gap-px bg-border rounded-md overflow-hidden border border-border"
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, margin: "-40px" }}
          variants={containerVariants}
        >
          {services.map((service, index) => (
            <motion.div key={service.title} variants={itemVariants}>
              <Link
                to={service.href}
                className={[
                  "group flex items-start gap-4 p-6 bg-background hover:bg-muted transition-colors duration-200",
                  // Bottom-right corner item on desktop (index 8 and 9 form the last row)
                  // No special treatment needed — grid handles it
                ].join(" ")}
                aria-label={`Learn more about ${service.title}`}
              >
                {/* Index marker */}
                <span
                  className="flex-shrink-0 mt-0.5 w-6 h-6 rounded-sm flex items-center justify-center text-[10px] font-semibold text-muted-foreground bg-muted group-hover:bg-primary/10 group-hover:text-primary transition-colors duration-200"
                  aria-hidden="true"
                >
                  {String(index + 1).padStart(2, "0")}
                </span>

                {/* Text */}
                <div className="flex-1 min-w-0">
                  <span className="flex items-center gap-1.5 mb-1">
                    <span className="text-sm font-semibold text-foreground group-hover:text-primary transition-colors duration-200 leading-snug">
                      {service.title}
                    </span>
                    <ChevronRight
                      className="h-3.5 w-3.5 text-muted-foreground opacity-0 group-hover:opacity-100 group-hover:translate-x-0.5 transition-all duration-200"
                      aria-hidden="true"
                    />
                  </span>
                  <p className="text-xs text-muted-foreground leading-relaxed">
                    {service.description}
                  </p>
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>

        {/* Supporting note */}
        <motion.p
          className="mt-8 text-xs text-muted-foreground max-w-lg"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3, ease: "easeOut" }}
        >
          Each service can be engaged independently or as part of a broader retainer. I work directly with you — no
          account managers, no outsourcing.
        </motion.p>

      </div>
    </section>
  );
});

AISearchServices.displayName = "AISearchServices";

export default AISearchServices;
